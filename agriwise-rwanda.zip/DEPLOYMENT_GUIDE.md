# AGRIWISE Production Deployment & Operations Guide

**Document Version:** 1.0.0 DevOps Manual  

---

## 1. Production Architecture Overview

AGRIWISE is deployed using containerized microservices on Cloud Run and Google Kubernetes Engine (GKE) Autopilot across multi-region nodes (Kigali and Nairobi). The stack utilizes Express with TypeScript, PostGIS spatial database with WAL replication, and Redis L2 cache.

---

## 2. Environment Variables & Secrets Configuration

Ensure the following variables are configured in Secret Manager:
```env
PORT=3000
NODE_ENV=production
GEMINI_API_KEY=your_production_gemini_key
DATABASE_URL=postgresql://user:pass@postgis-primary:5432/agriwise
REDIS_URL=redis://redis-cluster:6379
MOMO_ESCROW_API_KEY=your_momo_escrow_secret
JWT_SECRET=your_jwt_production_secret
```

---

## 3. Deployment Steps

1. **Build Container Image:**
   ```bash
   npm run build
   ```
2. **Start Production Container:**
   ```bash
   npm run start
   ```
3. **Verify Health Endpoint:**
   `GET /api/health` returns `{ "status": "ok" }`.
