# AGRIWISE USSD (*111#) & 1111 Voice AI Gateway Architecture Specification

## Executive Overview
The **AGRIWISE Telecom Gateway Engine** connects smallholder farmers, cooperatives, and pastoralists using basic feature phones (2G/GSM) directly into AGRIWISE’s AI-powered agricultural core. Through **USSD (*111#)** and **Voice AI (1111)**, farmers can access real-time weather forecasts, daily market prices, Gemini 3.6 AI agronomic advice in **Kinyarwanda, English, and French**, register farm boundaries, report crop diseases, and connect directly with extension officers without requiring smartphone hardware or internet connectivity.

---

## Part 1: USSD Service Architecture (*111#)

```
 [ Farmer's Feature Phone ]
            │
            ▼ (GSM Unstructured Supplementary Service Data - MAP/SS7)
 ┌──────────────────────────────────────────────┐
 │ MTN Rwanda / Airtel Rwanda USSD Gateway      │
 └──────────────────────┬───────────────────────┘
                        │
                        ▼ (HTTP/HTTPS REST Webhook API - 180s Session Keep-Alive)
 ┌──────────────────────────────────────────────┐
 │ AGRIWISE USSD Gateway Engine (`/api/ussd`)   │
 ├──────────────────────────────────────────────┤
 │ • Menu State Machine & Router                │
 │ • Language Engine (Kinyarwanda/EN/FR)        │
 │ • 160-Char Page Formatter & Pagination       │
 └──────────────────────┬───────────────────────┘
                        │
            ┌───────────┴───────────┐
            ▼                       ▼
 ┌──────────────────────┐ ┌─────────────────────────┐
 │ Gemini 3.6 Flash AI  │ │ AGRIWISE Core Services   │
 │ Agronomist Reasoning │ │ (Weather, Markets, DB)  │
 └──────────────────────┘ └─────────────────────────┘
```

### USSD Screen Output Protocol
1. **CON**: Continuous session — prompts farmer for further keypad input.
2. **END**: Termination response — displays final message and closes connection, triggering asynchronous follow-up SMS.

---

## Part 2 & 3: Complete USSD Menu Navigation & Registration Flows

### Initial Dial Flow: `*111#`
```
WELCOME TO AGRIWISE
Kaza muri AGRIWISE

Choose Language / Hitamo Ururimi:
1. Kinyarwanda
2. English
3. Français
```

### Main Menu (Kinyarwanda Example)
```
CON AGRIWISE (Musanze - Kinigi)
1. Iteganyagihe (Weather)
2. Izina n'Ibiciro zv'Ibisarurwa (Market Prices)
3. Babaza Umuganga w'Ibihingwa AI (Ask AI)
4. Kwandika Isambu Yange (Register Farm)
5. Kumenyesha Indwara y'Ibihingwa (Report Disease)
6. Ubworozi n'Matungo (Livestock Support)
7. Ibitabo by'Isambu (Farm Records)
8. Kuvugana n'Umworozi/Umwalimu (Expert Support)
9. Konti Yange (My Account)
```

### Detailed Menu Operations:

1. **Weather Information (`1`)**:
   - Fetches RAB & Meteo Rwanda satellite forecast by farmer district.
   - Output: `CON [Musanze Weather] Today: Light Rain (18°C). 3-Day Forecast: Heavy rains after 48 hrs. ADVICE: Delay fertilizer top-dressing until Thursday.`

2. **Market Prices (`2`)**:
   - Sub-menu: `1. Irish Potatoes (Ibirayi) 2. Maize (Amasaka) 3. Beans (Ibishingwe) 4. Milk (Amasunzu)`
   - Location selection: `1. Kigali (Kimironko) 2. Musanze 3. Nyagatare`
   - Output: `CON Irish Potatoes (Musanze Market): 420 RWF/kg (▲ +15 RWF vs yesterday). Demand: HIGH. Selling recommendation: Hold for 2 days for peak price.`

3. **Ask AI Agriculture Assistant (`3`)**:
   - Prompt: `CON Wandike ikibazo cyawe cy'ubuhinzi (Type your farming query):`
   - Farmer enters text: *"Ibirayi byange bifite ibibabi by'umuhondo"*
   - AI contextualizes farmer location + crop + recent weather -> generates concise advice.
   - Output: `END AGRIWISE AI: Yellowing potato leaves indicate Early Blight or Nitrogen deficiency. Spray Mancozeb 80% WP (2kg/ha). Detailed SMS sent to your phone.`

4. **Register Farm (`4`)**:
   - Interactive multi-step form:
     1. Name
     2. District
     3. Sector
     4. Farm Size (Hectares / Ares)
     5. Main Crop
   - Saves directly into `USSDUser` and `SavedFarmBoundary` cloud database.

5. **Report Crop Disease (`5`)**:
   - Guides farmer to report affected crop area, severity, and symptoms. Flags high-priority alert to district agricultural officer.

6. **Expert Support (`8`)**:
   - Instantly triggers callback from live extension officer or transfers to 1111 Call Center.

---

## Part 7, 8 & 9: 1111 Voice AI Service Architecture

```
 [ Incoming Call to 1111 ]
            │
            ▼ (SIP Trunking / E1 ISDN PRI Gateway)
 ┌──────────────────────────────────────────────┐
 │ Telecom Voice Gateway                        │
 └──────────────────────┬───────────────────────┘
                        │
                        ▼ (RTP Audio Streaming / WebSockets)
 ┌──────────────────────────────────────────────┐
 │ AGRIWISE Voice AI Pipeline (`/api/voice`)    │
 ├──────────────────────────────────────────────┤
 │ 1. Automatic Phone Authentication            │
 │ 2. Kinyarwanda Speech-to-Text (STT)          │
 │ 3. Gemini 3.6 Flash Conversational AI        │
 │ 4. Kinyarwanda Text-to-Speech (TTS) Synthesis│
 └──────────────────────┬───────────────────────┘
                        │
             ┌──────────┴──────────┐
             ▼                     ▼
  ┌──────────────────┐  ┌─────────────────────┐
  │ Live Audio Output│  │ Human Expert Call   │
  │ Stream to Phone  │  │ Center Transfer     │
  └──────────────────┘  └─────────────────────┘
```

### Voice AI Call Flow Example:
1. **Farmer Dials 1111**.
2. **IVR Greeting**: *"Murakaza neza mu murongo w'ubuhinzi AGRIWISE 1111. Mbabarira mubaze ikibazo cyose cy'ubuhinzi..."*
3. **Farmer Speaks**: *"Inyanya zange zifite iminyorogoto n'ibibabi byumye, nkoreshe uwuhe muti?"*
4. **STT Transcribes**: Recognized Kinyarwanda phonetics.
5. **AI Processing**: Identifies *Tomato Leaf Miner (Tuta absoluta)* or *Late Blight*.
6. **TTS Voice Response**: Speaks clear, natural Kinyarwanda audio instructions back through the phone e.g., *"Inyanya zanyu zibasiriwe n'isazi y'inyanya. Koresha umuti wa Deltamethrin cyangwa Spinosad..."*
7. **SMS Follow-Up**: Automatically dispatches SMS receipt with exact medicine dosage and local agro-dealer stockists in Musanze.

---

## Part 10 & 11: Human Expert Escalation & SMS Engine

- **Escalation Trigger**: If AI confidence score < 80% or if farmer mentions severe epidemic outbreak ("Amasunzu ararwaye ikibore"), AI says: *"Mbabariye ndakuhuza n'umuganga w'matungo Musanze..."* and transfers call.
- **SMS Engine**: Uses MTN/Airtel SMS REST Gateways with instant delivery receipt tracking (`/api/sms/send`).

---

## Part 12: Database Design Schema

```sql
-- USSD Users Table
CREATE TABLE ussd_users (
    phone_number VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100),
    language VARCHAR(5) DEFAULT 'rw',
    district VARCHAR(50),
    sector VARCHAR(50),
    village VARCHAR(50),
    farm_size_ha DECIMAL(10,2),
    main_crops TEXT[],
    livestock_type VARCHAR(50),
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- USSD Sessions Table
CREATE TABLE ussd_sessions (
    session_id VARCHAR(100) PRIMARY KEY,
    phone_number VARCHAR(20) REFERENCES ussd_users(phone_number),
    current_menu_path VARCHAR(100),
    temp_data JSONB,
    last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Voice Calls Table
CREATE TABLE voice_call_logs (
    call_id VARCHAR(100) PRIMARY KEY,
    phone_number VARCHAR(20),
    language VARCHAR(5),
    duration_seconds INT,
    status VARCHAR(20),
    transcript_summary TEXT,
    ai_sentiment VARCHAR(20),
    transferred_to_expert BOOLEAN DEFAULT FALSE,
    expert_name VARCHAR(100),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- SMS Logs Table
CREATE TABLE sms_messages (
    id VARCHAR(100) PRIMARY KEY,
    phone_number VARCHAR(20),
    message_body TEXT,
    status VARCHAR(20),
    gateway VARCHAR(50),
    type VARCHAR(30),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## Part 13 & 14: Telecom Integration & Security

1. **Gateways Supported**: MTN Rwanda Mobile Money & USSD API, Airtel Rwanda WASP Gateway.
2. **Security & Anti-Fraud**:
   - HMAC-SHA256 signature verification on incoming webhook payloads.
   - Rate limiting per phone number (max 15 USSD sessions/hour).
   - Session timeout enforced strictly at 180 seconds.
   - Phone number verification via MSISDN header injection.

---

## Part 15: Implementation & Testing Verification Plan
- **USSD Interactive Dialing Simulator**: Dial `*111#` on live simulated mobile handset UI.
- **1111 Voice AI Call Simulator**: Dial `1111`, speak or type query, view live speech waveform, listen to synthesized audio response, and test expert transfer.
- **Telecom Operations Monitoring Center**: Live metrics for session latency, active voice calls, SMS delivery receipts, and Kinyarwanda AI confidence levels.
