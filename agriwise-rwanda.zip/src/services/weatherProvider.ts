import { UserRole } from '../types';

export interface WeatherCondition {
  text: string;
  icon: 'sun' | 'rain' | 'cloud-sun' | 'heavy-rain';
}

export interface HourlyForecast {
  time: string;
  tempC: number;
  rainPct: number;
  condition: string;
}

export interface DayForecast {
  day: string;
  date: string;
  tempHighC: number;
  tempLowC: number;
  rainPct: number;
  rainfallMm: number;
  condition: string;
  agronomyNote: {
    rw: string;
    en: string;
    fr: string;
  };
}

export interface AgronomyWindow {
  status: 'optimal' | 'caution' | 'hazardous';
  label: { rw: string; en: string; fr: string };
  advice: { rw: string; en: string; fr: string };
}

export interface DistrictWeatherTelemetry {
  district: string;
  province: string;
  altitudeMeters: number;
  tempC: number;
  feelsLikeC: number;
  condition: WeatherCondition;
  humidityPct: number;
  rainfallMm: number;
  rainProbabilityPct: number;
  windSpeedKmh: number;
  windDirection: string;
  uvIndex: number;
  soilMoisturePct: number;
  evapotranspirationMmDay: number;
  alert?: {
    type: 'warning' | 'info' | 'critical';
    title: { rw: string; en: string; fr: string };
    description: { rw: string; en: string; fr: string };
  };
  windows: {
    planting: AgronomyWindow;
    irrigation: AgronomyWindow;
    spraying: AgronomyWindow;
    fertilizer: AgronomyWindow;
    harvesting: AgronomyWindow;
  };
  hourly: HourlyForecast[];
  forecast7Days: DayForecast[];
  mitigationChecklist: {
    id: string;
    text: { rw: string; en: string; fr: string };
    completed: boolean;
  }[];
}

export interface IWeatherProvider {
  getWeatherForDistrict(districtName: string): Promise<DistrictWeatherTelemetry>;
  getAllDistricts(): string[];
}

// Default Telemetry Store for Rwanda's Key Agricultural Zones
const WEATHER_DATABASE: Record<string, DistrictWeatherTelemetry> = {
  Musanze: {
    district: 'Musanze',
    province: 'Northern Province (Volcanic Belt)',
    altitudeMeters: 2200,
    tempC: 21,
    feelsLikeC: 20,
    condition: { text: 'Scattered Showers', icon: 'rain' },
    humidityPct: 82,
    rainfallMm: 18.5,
    rainProbabilityPct: 70,
    windSpeedKmh: 11,
    windDirection: 'NE',
    uvIndex: 7,
    soilMoisturePct: 78,
    evapotranspirationMmDay: 3.2,
    alert: {
      type: 'warning',
      title: {
        rw: 'Imvura Nyinshi & Risk ya Blight mu Birayi',
        en: 'High Rainfall & Irish Potato Late Blight Alert',
        fr: 'Alerte Pluies Abondantes & Mildiou de la Pomme de Terre',
      },
      description: {
        rw: 'Meteo Rwanda iraburira imvura nyinshi mu murenge wa Kinigi & Nyange. Inzira z\'isuri no ku miferege mu mashyamba zikwiye gusukurwa.',
        en: 'Meteo Rwanda forecasts heavy rainfall in Kinigi & Nyange sectors. High spore transmission risk for Irish potato late blight on volcanic slopes.',
        fr: 'Meteo Rwanda prévoit de fortes pluies dans les secteurs de Kinigi et Nyange. Risque élevé de mildiou sur les pentes volcaniques.',
      },
    },
    windows: {
      planting: {
        status: 'caution',
        label: {
          rw: 'Gutera Ibirayi mu gitondo cyane gusa',
          en: 'Plant Early Morning Only',
          fr: 'Plantation tôt le matin uniquement',
        },
        advice: {
          rw: 'Ubutaka burimo amazi ahagije ariko kora imiferege irinda ibirayi ku borera.',
          en: 'High soil moisture is optimal for germination, but ensure raised ridges to prevent tuber rot.',
          fr: 'Super humidité du sol pour la germination, créez de hautes buttes pour éviter le pourrissement.',
        },
      },
      irrigation: {
        status: 'hazardous',
        label: {
          rw: 'Nta kuvomerera gukenewe uyu munsi',
          en: 'No Supplemental Irrigation Needed',
          fr: 'Aucune irrigation requise aujourd\'hui',
        },
        advice: {
          rw: 'Imvura n\'ubukonje by mu birunga bihagije ku bihingwa byose.',
          en: 'Natural precipitation and low evapotranspiration meet all crop moisture needs.',
          fr: 'Les précipitations naturelles satisfont tous les besoins en eau des cultures.',
        },
      },
      spraying: {
        status: 'caution',
        label: {
          rw: 'Tera umuti mbere ya saa 11:00 AM gusa',
          en: 'Spray Before 11:00 AM Only',
          fr: 'Pulvériser avant 11h00 uniquement',
        },
        advice: {
          rw: 'Koresha umuti w\'ibihumyo (fungicide) kare kabiri n\'umwuka urimo umuyaga muke.',
          en: 'Apply systemic fungicides early before rain wash-off occurs in the afternoon.',
          fr: 'Appliquez des fongicides systémiques tôt le matin avant le lessivage par les pluies de l\'après-midi.',
        },
      },
      fertilizer: {
        status: 'optimal',
        label: {
          rw: 'Igihe cyiza cyo gushyiramo NPK',
          en: 'Optimal Window for Top-Dressing NPK',
          fr: 'Favorable pour l\'application d\'engrais NPK',
        },
        advice: {
          rw: 'Imvura yoroheje yo mu gitondo ituma ifumbire igera ku mizi ntarusobe.',
          en: 'Gentle moisture helps dissolve granular fertilizers into deep volcanic topsoil.',
          fr: 'L\'humidité douce dissout efficacement les engrais granulés dans le sol volcanique.',
        },
      },
      harvesting: {
        status: 'hazardous',
        label: {
          rw: 'Subika gukura ibirayi uyu munsi',
          en: 'Delay Potato Tuber Harvesting',
          fr: 'Retarder la récolte des pommes de terre',
        },
        advice: {
          rw: 'Ubutaka bwatobye cyane bushobora kubora ibirayi mu bubiko. Tegereza Kuwa Kane.',
          en: 'Excess wet soil will cause tubers to rot during transit. Wait for dry spell on Thursday.',
          fr: 'Le sol détrempé risque de faire pourrir les tubercules. Attendez le créneau sec de jeudi.',
        },
      },
    },
    hourly: [
      { time: '06:00', tempC: 15, rainPct: 15, condition: 'Cool Fog' },
      { time: '09:00', tempC: 19, rainPct: 25, condition: 'Partly Cloudy' },
      { time: '12:00', tempC: 22, rainPct: 45, condition: 'Light Rain' },
      { time: '15:00', tempC: 20, rainPct: 75, condition: 'Heavy Showers' },
      { time: '18:00', tempC: 17, rainPct: 40, condition: 'Overcast' },
      { time: '21:00', tempC: 15, rainPct: 20, condition: 'Clear Night' },
    ],
    forecast7Days: [
      {
        day: 'Today',
        date: 'Aug 5',
        tempHighC: 22,
        tempLowC: 15,
        rainPct: 70,
        rainfallMm: 18.5,
        condition: 'Scattered Showers',
        agronomyNote: {
          rw: 'Tera umuti w\'ibihumyo ku ibirayi mbere y\'imvura.',
          en: 'Spray systemic fungicide early morning.',
          fr: 'Pulvériser le fongicide systémique tôt le matin.',
        },
      },
      {
        day: 'Tomorrow',
        date: 'Aug 6',
        tempHighC: 21,
        tempLowC: 14,
        rainPct: 80,
        rainfallMm: 24.0,
        condition: 'Heavy Rain',
        agronomyNote: {
          rw: 'Sukuramo imiferege ku matarase.',
          en: 'Clear drainage ditches along mountain terraces.',
          fr: 'Nettoyer les canaux de drainage le long des terrasses.',
        },
      },
      {
        day: 'Thursday',
        date: 'Aug 7',
        tempHighC: 23,
        tempLowC: 15,
        rainPct: 30,
        rainfallMm: 4.2,
        condition: 'Partly Cloudy',
        agronomyNote: {
          rw: 'Igihe cyiza cyo gusarura ibirayi n\'ibigori.',
          en: 'Ideal day for potato tuber harvesting.',
          fr: 'Journée idéale pour la récolte des pommes de terre.',
        },
      },
      {
        day: 'Friday',
        date: 'Aug 8',
        tempHighC: 24,
        tempLowC: 16,
        rainPct: 20,
        rainfallMm: 1.5,
        condition: 'Sunny',
        agronomyNote: {
          rw: 'Anika umusaruro ku zuba.',
          en: 'Excellent sun-drying window for grains.',
          fr: 'Excellente journée pour sécher les grains au soleil.',
        },
      },
      {
        day: 'Saturday',
        date: 'Aug 9',
        tempHighC: 23,
        tempLowC: 15,
        rainPct: 40,
        rainfallMm: 6.8,
        condition: 'Light Rain',
        agronomyNote: {
          rw: 'Shyiramo ifumbire ya Urea ku bihingwa.',
          en: 'Apply top-dressing Urea fertilizer.',
          fr: 'Appliquer l\'engrais Urea de couverture.',
        },
      },
      {
        day: 'Sunday',
        date: 'Aug 10',
        tempHighC: 24,
        tempLowC: 14,
        rainPct: 15,
        rainfallMm: 0.8,
        condition: 'Clear Sky',
        agronomyNote: {
          rw: 'Tegura umurima w\'igihe cy\'ihinga.',
          en: 'Land preparation for next planting cycle.',
          fr: 'Préparation du sol pour le prochain cycle.',
        },
      },
      {
        day: 'Monday',
        date: 'Aug 11',
        tempHighC: 25,
        tempLowC: 15,
        rainPct: 10,
        rainfallMm: 0.0,
        condition: 'Sunny',
        agronomyNote: {
          rw: 'Ubutaka bwameze neza.',
          en: 'Optimal soil moisture balance maintained.',
          fr: 'Équilibre parfait de l\'humidité du sol.',
        },
      },
    ],
    mitigationChecklist: [
      {
        id: '1',
        text: {
          rw: 'Sukuramo imiferege ku matarase arwanya isuri',
          en: 'Clear drainage channels on anti-erosion terraces',
          fr: 'Nettoyer les canaux de drainage sur les terrasses',
        },
        completed: true,
      },
      {
        id: '2',
        text: {
          rw: 'Zamura imigende y\'ibirayi kurinda amaze kurenga',
          en: 'Prepare raised ridges for Irish Potato tubers',
          fr: 'Préparer des buttes élevées pour les pommes de terre',
        },
        completed: true,
      },
      {
        id: '3',
        text: {
          rw: 'Genzura inzu z\'icyerekezo n\'inshunde z\'amashyamba',
          en: 'Check greenhouse or nursery shade netting against strong gusts',
          fr: 'Vérifier les ombrières de pépinière contre le vent',
        },
        completed: false,
      },
      {
        id: '4',
        text: {
          rw: 'Bika ingano n\'imbuto ahakomeye kandi humbye',
          en: 'Store harvested grains in dry elevated storehouses',
          fr: 'Stocker les récoltes dans un endroit sec et élevé',
        },
        completed: false,
      },
    ],
  },

  Nyagatare: {
    district: 'Nyagatare',
    province: 'Eastern Province (Savanna Belt)',
    altitudeMeters: 1350,
    tempC: 28,
    feelsLikeC: 29,
    condition: { text: 'Sunny & Dry', icon: 'sun' },
    humidityPct: 48,
    rainfallMm: 0.0,
    rainProbabilityPct: 10,
    windSpeedKmh: 18,
    windDirection: 'SE',
    uvIndex: 9,
    soilMoisturePct: 32,
    evapotranspirationMmDay: 5.8,
    alert: {
      type: 'info',
      title: {
        rw: 'Igihe cy\'Izuba & Kwita ku Matungo y\'Inka',
        en: 'Dry Spell Advisory & Cattle Hydration',
        fr: 'Conseil Sécheresse & Hydratation du Bétail',
      },
      description: {
        rw: 'Izuba ryinshi mu mirenge wa Matimba & Karangazi. Ha amatungo amazi afite isuku n\'ubwatsi busharira (silage).',
        en: 'High solar radiation and dry winds in Matimba & Karangazi. Ensure dairy cows have access to clean drinking water and silage.',
        fr: 'Fort rayonnement solaire à Matimba & Karangazi. Assurez l\'accès à l\'eau potable pour les vaches laitières.',
      },
    },
    windows: {
      planting: {
        status: 'hazardous',
        label: {
          rw: 'Tegereza imvura ibanza',
          en: 'Delay Planting - Dry Topsoil',
          fr: 'Attendre la première pluie - Sol Sec',
        },
        advice: {
          rw: 'Ubutaka burakomeye cyane. Gutera ubu bishobora gutuma imbuto zikama.',
          en: 'Topsoil moisture is insufficient for seed germination without micro-irrigation.',
          fr: 'Humidité du sol insuffisante pour la germination sans système d\'irrigation.',
        },
      },
      irrigation: {
        status: 'optimal',
        label: {
          rw: 'Fungura amazi yo kuvomerera (Solar Pump)',
          en: 'Run Solar Drip / Pivot Irrigation',
          fr: 'Activer l\'irrigation solaire au goutte-à-goutte',
        },
        advice: {
          rw: 'Koresha nka litiro 4-5 ku kimera mu gitondo n\'umugoroba.',
          en: 'Deliver targeted drip volume early morning and late afternoon to minimize evaporation.',
          fr: 'Appliquer l\'irrigation goutte-à-goutte tôt le matin et en fin d\'après-midi.',
        },
      },
      spraying: {
        status: 'optimal',
        label: {
          rw: 'Igihe cyiza cyo gutera umuti w\'isazi/sururu',
          en: 'Optimal All-Day Pest Spraying Window',
          fr: 'Créneau idéal de pulvérisation d\'insecticide',
        },
        advice: {
          rw: 'Imvura ntagari. Urashobora gukora spray ku biryo by\'ibigori (Fall Armyworm).',
          en: 'Zero wash-off risk allows systemic Fall Armyworm control in maize plots.',
          fr: 'Aucun risque de lessivage pour traiter la chenille légionnaire du maïs.',
        },
      },
      fertilizer: {
        status: 'caution',
        label: {
          rw: 'Saba kuvomerera nyuma yo gushyiramo ifumbire',
          en: 'Requires Irrigation After Application',
          fr: 'Nécessite une irrigation immédiate après engrais',
        },
        advice: {
          rw: 'Izuba rya saa sita rishobora gukamura ifumbire yo mu bwoko bwa Urea.',
          en: 'Dry soil surface limits fertilizer absorption unless drip lines are turned on.',
          fr: 'Le sol sec limite l\'absorption; activez l\'irrigation immédiatement.',
        },
      },
      harvesting: {
        status: 'optimal',
        label: {
          rw: 'Igihe cyiza cyo kwanika ibigori n\'ibishyimbo',
          en: 'Perfect Grain Drying & Harvest Weather',
          fr: 'Météo parfaite pour sécher et récolter les grains',
        },
        advice: {
          rw: 'Ubushyuhe n\'umuyaga bifasha kwanika ibigori munsi ya 13.5% ya moisture.',
          en: 'High solar power guarantees rapid moisture reduction below 13.5% target.',
          fr: 'Ensoleillement idéal garantissant un taux d\'humidité inférieur à 13,5%.',
        },
      },
    },
    hourly: [
      { time: '06:00', tempC: 20, rainPct: 5, condition: 'Clear Sunrise' },
      { time: '09:00', tempC: 25, rainPct: 5, condition: 'Sunny' },
      { time: '12:00', tempC: 29, rainPct: 10, condition: 'Hot Sun' },
      { time: '15:00', tempC: 28, rainPct: 10, condition: 'Breezy' },
      { time: '18:00', tempC: 24, rainPct: 5, condition: 'Clear Evening' },
      { time: '21:00', tempC: 21, rainPct: 5, condition: 'Starlight' },
    ],
    forecast7Days: [
      {
        day: 'Today',
        date: 'Aug 5',
        tempHighC: 29,
        tempLowC: 19,
        rainPct: 10,
        rainfallMm: 0.0,
        condition: 'Sunny',
        agronomyNote: {
          rw: 'Uha inka amazi ahagije n\'igicucu.',
          en: 'Provide clean drinking water for dairy cattle.',
          fr: 'Fournir de l\'eau potable propre aux vaches laitières.',
        },
      },
      {
        day: 'Tomorrow',
        date: 'Aug 6',
        tempHighC: 30,
        tempLowC: 20,
        rainPct: 15,
        rainfallMm: 0.0,
        condition: 'Clear Sky',
        agronomyNote: {
          rw: 'Anika ibigori ku rugo rw\'icyuma.',
          en: 'Sun dry maize to under 13.5% moisture.',
          fr: 'Sécher le maïs à moins de 13,5% d\'humidité.',
        },
      },
      {
        day: 'Thursday',
        date: 'Aug 7',
        tempHighC: 28,
        tempLowC: 18,
        rainPct: 20,
        rainfallMm: 1.2,
        condition: 'Partly Cloudy',
        agronomyNote: {
          rw: 'Genzura inka niba zifite ikirura (ticks).',
          en: 'Inspect cattle for tick infestations.',
          fr: 'Inspecter le bétail contre les tiques.',
        },
      },
      {
        day: 'Friday',
        date: 'Aug 8',
        tempHighC: 27,
        tempLowC: 18,
        rainPct: 35,
        rainfallMm: 4.5,
        condition: 'Light Rain',
        agronomyNote: {
          rw: 'Imvura yoroheje mu nzuri.',
          en: 'Welcome light rain shower for pasture grass.',
          fr: 'Pluie légère bénéfique pour les pâturages.',
        },
      },
      {
        day: 'Saturday',
        date: 'Aug 9',
        tempHighC: 28,
        tempLowC: 19,
        rainPct: 15,
        rainfallMm: 0.0,
        condition: 'Sunny',
        agronomyNote: {
          rw: 'Vomerera iboga n\'imbuto.',
          en: 'Irrigate vegetable gardens.',
          fr: 'Irriguer les cultures potagères.',
        },
      },
      {
        day: 'Sunday',
        date: 'Aug 10',
        tempHighC: 29,
        tempLowC: 20,
        rainPct: 10,
        rainfallMm: 0.0,
        condition: 'Sunny',
        agronomyNote: {
          rw: 'Tegura imyobo y\'ubwatsi (Silage pit).',
          en: 'Prepare silage pits for dry period feeding.',
          fr: 'Préparer des fosses à ensilage pour l\'alimentation.',
        },
      },
      {
        day: 'Monday',
        date: 'Aug 11',
        tempHighC: 30,
        tempLowC: 20,
        rainPct: 10,
        rainfallMm: 0.0,
        condition: 'Hot Sun',
        agronomyNote: {
          rw: 'Genzura imirasire y\'izuba y\'amazi.',
          en: 'Maintain livestock drinking water troughs.',
          fr: 'Entretenir les abreuvoirs du bétail.',
        },
      },
    ],
    mitigationChecklist: [
      {
        id: '1',
        text: {
          rw: 'Uzuzuza icyuma cy\'amazi y\'inka n\'iminsi 2 mbere',
          en: 'Fill livestock drinking troughs early morning',
          fr: 'Remplir les abreuvoirs du bétail tôt le matin',
        },
        completed: true,
      },
      {
        id: '2',
        text: {
          rw: 'Shyiraho ibarizo/ibyatsi mu murima (mulching)',
          en: 'Apply straw mulching around crops to retain moisture',
          fr: 'Appliquer un paillage pour conserver l\'humidité',
        },
        completed: true,
      },
      {
        id: '3',
        text: {
          rw: 'Genzura moteri yo kuvomerera y\'imirasire',
          en: 'Inspect solar irrigation pumps and filter screens',
          fr: 'Inspecter les pompes d\'irrigation solaires',
        },
        completed: false,
      },
    ],
  },
};

export class MeteoRwandaProvider implements IWeatherProvider {
  async getWeatherForDistrict(districtName: string): Promise<DistrictWeatherTelemetry> {
    // Return district telemetry or default to Musanze fallback
    return WEATHER_DATABASE[districtName] || WEATHER_DATABASE['Musanze'];
  }

  getAllDistricts(): string[] {
    return Object.keys(WEATHER_DATABASE);
  }
}

export const defaultWeatherProvider = new MeteoRwandaProvider();
