import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  getDocs,
  serverTimestamp,
  Timestamp,
  getDocFromServer,
  runTransaction
} from 'firebase/firestore';
import { db, auth } from './firebase';
import {
  User,
  BusinessOrganization,
  BusinessMember,
  BusinessRole,
  BusinessMemberStatus,
  BusinessPermission,
  AuditLogRecord,
  OwnerNotification,
  EmailDeliveryStatus,
  Product,
  Category,
  Inventory,
  InventoryMovement,
  ProductStatus,
  CategoryStatus,
  InventoryMovementType,
  ProductCatalogStats,
  CustomerDoc,
  CustomerType,
  CustomerStatus,
  SaleDoc,
  SaleStatus,
  SalePaymentStatus,
  SalePaymentMethod,
  SaleItemDoc,
  SalesDashboardStats,
  CustomerSummary
} from '../types';
import { BUSINESS_ROLE_PERMISSIONS } from '../config/permissions';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    providerInfo?: any[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const currentUser = auth.currentUser;
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: currentUser?.uid,
      email: currentUser?.email,
      emailVerified: currentUser?.emailVerified,
      isAnonymous: currentUser?.isAnonymous,
      providerInfo: currentUser?.providerData?.map(p => ({
        providerId: p.providerId,
        email: p.email,
      })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error Details:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// ==========================================
// USER PROFILE FIRESTORE OPERATIONS
// ==========================================

/**
 * Fetch authoritative user profile from users/{uid}
 */
export async function getUserProfileDoc(uid: string): Promise<User | null> {
  const path = `users/${uid}`;
  try {
    const docRef = doc(db, 'users', uid);
    const snap = await getDoc(docRef);
    if (!snap.exists()) {
      return null;
    }
    const data = snap.data();
    return {
      id: uid,
      name: data.displayName || data.name || 'AgriWise Member',
      email: data.email || '',
      phone: data.phoneNumber || data.phone || '',
      phoneNumber: data.phoneNumber || data.phone || '',
      role: data.role || 'farmer',
      district: data.district || 'Musanze',
      sector: data.sector || 'Kinigi',
      cell: data.cell,
      village: data.village,
      province: data.province,
      language: data.preferredLanguage || data.language || 'rw',
      avatarUrl: data.photoURL || data.avatarUrl,
      verified: !!data.emailVerified || !!data.verified,
      accountStatus: data.accountStatus || 'active',
      userRegistrationStatus: data.userRegistrationStatus || 'Verified',
      identityStatus: data.identityStatus || 'not_started',
      nationalIdMasked: data.nationalIdMasked,
      nationalIdHash: data.nationalIdHash,
      emailVerified: !!data.emailVerified,
      businessId: data.businessId,
      subscription: data.subscription || {
        planId: 'free',
        planName: 'Free Trial Plan',
        status: 'trial',
        freeRequestsRemaining: 2,
        maxFreeRequests: 2,
        usedRequestsCount: 0,
      },
      creditScore: data.creditScore || 720,
      cooperativeName: data.cooperativeName,
      momoNumber: data.momoNumber,
      farmSizeHectares: data.farmSizeHectares,
      primaryCrops: data.primaryCrops || [],
      primaryLivestock: data.primaryLivestock || [],
    };
  } catch (error: any) {
    if (error?.message?.includes('offline') || error?.message?.includes('unavailable') || error?.code === 'unavailable') {
      console.warn(`Firestore getDoc offline/unavailable for ${path}:`, error?.message);
      return null;
    }
    handleFirestoreError(error, OperationType.GET, path);
  }
}

/**
 * Create or update authoritative user profile in users/{uid}
 */
export async function saveUserProfileDoc(user: User): Promise<void> {
  const path = `users/${user.id}`;
  try {
    const docRef = doc(db, 'users', user.id);

    const docData: Record<string, any> = {
      uid: user.id,
      email: user.email.toLowerCase(),
      displayName: user.name || 'AgriWise Member',
      phoneNumber: user.phoneNumber || user.phone || '',
      phone: user.phone || user.phoneNumber || '',
      photoURL: user.avatarUrl || '',
      preferredLanguage: user.language || 'rw',
      role: user.role || 'farmer',
      accountStatus: user.accountStatus || 'active',
      emailVerified: !!user.emailVerified,
      verified: !!user.verified,
      userRegistrationStatus: user.userRegistrationStatus || 'Verified',
      district: user.district || '',
      sector: user.sector || '',
      cell: user.cell || '',
      village: user.village || '',
      province: user.province || '',
      momoNumber: user.momoNumber || '',
      cooperativeName: user.cooperativeName || '',
      farmSizeHectares: user.farmSizeHectares || 0,
      primaryCrops: user.primaryCrops || [],
      primaryLivestock: user.primaryLivestock || [],
      creditScore: user.creditScore || 720,
      subscription: user.subscription || null,
      identityStatus: user.identityStatus || 'not_started',
      updatedAt: serverTimestamp(),
    };

    if (user.businessId) {
      docData.businessId = user.businessId;
    }

    if (user.nationalIdMasked) {
      docData.nationalIdMasked = user.nationalIdMasked;
    }
    if (user.nationalIdHash) {
      docData.nationalIdHash = user.nationalIdHash;
    }
    if (user.notificationPreferences) {
      docData.notificationPreferences = user.notificationPreferences;
    }

    await setDoc(docRef, docData, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// ==========================================
// BUSINESS FOUNDATION FIRESTORE OPERATIONS
// ==========================================

/**
 * Create a new business organization in businesses/{businessId}
 */
export async function createBusinessDoc(
  businessData: Omit<BusinessOrganization, 'businessId' | 'ownerId' | 'createdAt' | 'updatedAt'>,
  ownerUid: string
): Promise<BusinessOrganization> {
  const businessId = `biz_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
  const path = `businesses/${businessId}`;

  try {
    const newBizDoc: Record<string, any> = {
      businessId,
      name: businessData.name,
      ownerId: ownerUid,
      businessType: businessData.businessType || 'Agriculture Enterprise',
      country: businessData.country || 'Rwanda',
      district: businessData.district || 'Musanze',
      sector: businessData.sector || 'Kinigi',
      contactPhone: businessData.contactPhone || '',
      contactEmail: businessData.contactEmail || '',
      status: 'active',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    await setDoc(doc(db, 'businesses', businessId), newBizDoc);

    // Automatically create Owner member document in subcollection businesses/{businessId}/members/{ownerUid}
    const currentUser = auth.currentUser;
    const memberDocRef = doc(db, 'businesses', businessId, 'members', ownerUid);
    const ownerMemberData: Record<string, any> = {
      uid: ownerUid,
      businessId,
      email: currentUser?.email || businessData.contactEmail || '',
      displayName: currentUser?.displayName || 'Business Owner',
      phoneNumber: currentUser?.phoneNumber || businessData.contactPhone || '',
      role: 'owner',
      platformRole: 'farmer',
      status: 'active',
      permissions: BUSINESS_ROLE_PERMISSIONS.owner,
      joinedAt: serverTimestamp(),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    await setDoc(memberDocRef, ownerMemberData);

    // Update user profile with businessId
    const userRef = doc(db, 'users', ownerUid);
    await updateDoc(userRef, {
      businessId,
      updatedAt: serverTimestamp(),
    }).catch(() => {});

    // Audit Log for Business Creation
    await createAuditLogDoc({
      userId: ownerUid,
      userName: currentUser?.displayName || 'Owner',
      action: 'BUSINESS_CREATED',
      businessId,
      description: `Business '${businessData.name}' created with ID ${businessId}. Owner member record auto-created.`,
    });

    return {
      businessId,
      name: businessData.name,
      ownerId: ownerUid,
      businessType: businessData.businessType || 'Agriculture Enterprise',
      country: businessData.country || 'Rwanda',
      district: businessData.district || 'Musanze',
      sector: businessData.sector || 'Kinigi',
      contactPhone: businessData.contactPhone || '',
      contactEmail: businessData.contactEmail || '',
      status: 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Fetch business organization by ID
 */
export async function getBusinessDoc(businessId: string): Promise<BusinessOrganization | null> {
  const path = `businesses/${businessId}`;
  try {
    const docRef = doc(db, 'businesses', businessId);
    const snap = await getDoc(docRef);
    if (!snap.exists()) return null;
    const data = snap.data();
    return {
      businessId: data.businessId,
      name: data.name,
      ownerId: data.ownerId,
      businessType: data.businessType,
      country: data.country,
      district: data.district,
      sector: data.sector,
      contactPhone: data.contactPhone,
      contactEmail: data.contactEmail,
      status: data.status,
      createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
      updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate().toISOString() : new Date().toISOString(),
    };
  } catch (error: any) {
    if (error?.message?.includes('offline') || error?.message?.includes('unavailable') || error?.code === 'unavailable') {
      console.warn(`Firestore getBusinessDoc offline/unavailable for ${path}:`, error?.message);
      return null;
    }
    handleFirestoreError(error, OperationType.GET, path);
  }
}

/**
 * Fetch all businesses owned by a specific Firebase Auth user
 */
export async function getUserBusinesses(ownerUid: string): Promise<BusinessOrganization[]> {
  const path = 'businesses';
  try {
    const q = query(collection(db, 'businesses'), where('ownerId', '==', ownerUid));
    const snap = await getDocs(q);
    return snap.docs.map(docSnap => {
      const data = docSnap.data();
      return {
        businessId: data.businessId || docSnap.id,
        name: data.name,
        ownerId: data.ownerId,
        businessType: data.businessType,
        country: data.country,
        district: data.district,
        sector: data.sector,
        contactPhone: data.contactPhone,
        contactEmail: data.contactEmail,
        status: data.status,
        createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
        updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate().toISOString() : new Date().toISOString(),
      };
    });
  } catch (error: any) {
    if (error?.message?.includes('offline') || error?.message?.includes('unavailable') || error?.code === 'unavailable') {
      console.warn(`Firestore getUserBusinesses offline/unavailable for ${path}:`, error?.message);
      return [];
    }
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

// ==========================================
// AUDIT LOG & NOTIFICATION OPERATIONS
// ==========================================

export async function createAuditLogDoc(log: {
  userId: string;
  userName: string;
  action: string;
  description: string;
  businessId?: string;
  ipAddress?: string;
  status?: 'SUCCESS' | 'FAILED' | 'BLOCKED' | 'WARNING';
}): Promise<void> {
  const logId = `log_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
  const path = `auditLogs/${logId}`;
  try {
    await setDoc(doc(db, 'auditLogs', logId), {
      logId,
      userId: log.userId,
      businessId: log.businessId || null,
      userName: log.userName,
      action: log.action,
      details: log.description,
      ipAddress: log.ipAddress || '127.0.0.1',
      status: log.status || 'SUCCESS',
      timestamp: serverTimestamp(),
    });
  } catch (error) {
    // Non-blocking log catch
    console.warn('Audit log write error:', error);
  }
}

export async function createNotificationDoc(notif: {
  userId: string;
  title: string;
  message: string;
  type?: string;
  category?: string;
  priority?: string;
  businessId?: string;
  emailDeliveryStatus?: EmailDeliveryStatus;
  deliveryChannels?: ('in_app' | 'email' | 'sms')[];
  recipientEmail?: string;
  relatedRecordId?: string;
  relatedRecordType?: string;
}): Promise<string> {
  const notificationId = `notif_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
  const path = `notifications/${notificationId}`;
  try {
    await setDoc(doc(db, 'notifications', notificationId), {
      notificationId,
      userId: notif.userId,
      businessId: notif.businessId || null,
      title: notif.title,
      message: notif.message,
      type: notif.type || 'system',
      category: notif.category || notif.type || 'general',
      priority: notif.priority || 'medium',
      read: false,
      emailDeliveryStatus: notif.emailDeliveryStatus || 'IN_APP_ONLY',
      deliveryChannels: notif.deliveryChannels || ['in_app'],
      recipientEmail: notif.recipientEmail || null,
      relatedRecordId: notif.relatedRecordId || null,
      relatedRecordType: notif.relatedRecordType || null,
      createdAt: serverTimestamp(),
    });
    return notificationId;
  } catch (error) {
    console.warn('Notification write error:', error);
    return notificationId;
  }
}

/**
 * Fetch user notifications from Firestore
 */
export async function getUserNotificationsDoc(userId: string): Promise<any[]> {
  const path = 'notifications';
  try {
    const q = query(collection(db, 'notifications'), where('userId', '==', userId));
    const snap = await getDocs(q);
    return snap.docs.map(docSnap => ({ id: docSnap.id, ...docSnap.data() }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

// ==========================================
// BUSINESS MEMBERSHIP FIRESTORE OPERATIONS
// ==========================================

/**
 * Add or invite a new member to a business: businesses/{businessId}/members/{targetUid}
 */
export async function addBusinessMemberDoc(params: {
  businessId: string;
  targetUid: string;
  email: string;
  displayName: string;
  phoneNumber?: string;
  role: BusinessRole;
  platformRole?: string;
  status?: BusinessMemberStatus;
  invitedByUid: string;
  invitedByName: string;
}): Promise<BusinessMember> {
  const { businessId, targetUid, email, displayName, phoneNumber, role, platformRole, status = 'invited', invitedByUid, invitedByName } = params;
  const path = `businesses/${businessId}/members/${targetUid}`;

  try {
    const memberRef = doc(db, 'businesses', businessId, 'members', targetUid);
    const assignedPermissions = BUSINESS_ROLE_PERMISSIONS[role] || [];

    const memberData: Record<string, any> = {
      uid: targetUid,
      businessId,
      email: email.toLowerCase(),
      displayName,
      phoneNumber: phoneNumber || '',
      role,
      platformRole: platformRole || 'farmer',
      status,
      permissions: assignedPermissions,
      joinedAt: serverTimestamp(),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    await setDoc(memberRef, memberData);

    // Audit log
    const auditAction = status === 'invited' ? 'MEMBER_INVITED' : 'MEMBER_ACCEPTED';
    await createAuditLogDoc({
      userId: invitedByUid,
      userName: invitedByName,
      action: auditAction,
      businessId,
      description: `Member ${displayName} (${email}) added to Business ${businessId} with role '${role}'.`,
    });

    return {
      uid: targetUid,
      businessId,
      email: email.toLowerCase(),
      displayName,
      phoneNumber,
      role,
      platformRole: (platformRole as any) || 'farmer',
      status,
      permissions: assignedPermissions,
      joinedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Fetch all members of a business: businesses/{businessId}/members
 */
export async function getBusinessMembersDoc(businessId: string): Promise<BusinessMember[]> {
  const path = `businesses/${businessId}/members`;
  try {
    const membersRef = collection(db, 'businesses', businessId, 'members');
    const snap = await getDocs(membersRef);
    return snap.docs.map((docSnap) => {
      const data = docSnap.data();
      return {
        uid: data.uid || docSnap.id,
        businessId: data.businessId || businessId,
        email: data.email || '',
        displayName: data.displayName || 'Member',
        phoneNumber: data.phoneNumber || '',
        role: (data.role as BusinessRole) || 'staff',
        platformRole: data.platformRole || 'farmer',
        status: (data.status as BusinessMemberStatus) || 'active',
        permissions: data.permissions || BUSINESS_ROLE_PERMISSIONS[data.role as BusinessRole] || [],
        joinedAt: data.joinedAt?.toDate ? data.joinedAt.toDate().toISOString() : new Date().toISOString(),
        createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
        updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate().toISOString() : new Date().toISOString(),
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

/**
 * Fetch member document for a specific user in a business
 */
export async function getBusinessMemberRecordDoc(
  businessId: string,
  targetUid: string
): Promise<BusinessMember | null> {
  const path = `businesses/${businessId}/members/${targetUid}`;
  try {
    const memberRef = doc(db, 'businesses', businessId, 'members', targetUid);
    const snap = await getDoc(memberRef);
    if (!snap.exists()) return null;
    const data = snap.data();
    return {
      uid: data.uid,
      businessId: data.businessId,
      email: data.email,
      displayName: data.displayName,
      phoneNumber: data.phoneNumber,
      role: (data.role as BusinessRole) || 'staff',
      platformRole: data.platformRole,
      status: (data.status as BusinessMemberStatus) || 'active',
      permissions: data.permissions || [],
      joinedAt: data.joinedAt?.toDate ? data.joinedAt.toDate().toISOString() : new Date().toISOString(),
      createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
      updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate().toISOString() : new Date().toISOString(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

/**
 * Update role and permissions of a member in businesses/{businessId}/members/{targetUid}
 */
export async function updateBusinessMemberRoleDoc(params: {
  businessId: string;
  targetUid: string;
  newRole: BusinessRole;
  updatedByUid: string;
  updatedByName: string;
}): Promise<void> {
  const { businessId, targetUid, newRole, updatedByUid, updatedByName } = params;
  const path = `businesses/${businessId}/members/${targetUid}`;

  try {
    const memberRef = doc(db, 'businesses', businessId, 'members', targetUid);
    const newPermissions = BUSINESS_ROLE_PERMISSIONS[newRole] || [];

    await updateDoc(memberRef, {
      role: newRole,
      permissions: newPermissions,
      updatedAt: serverTimestamp(),
    });

    await createAuditLogDoc({
      userId: updatedByUid,
      userName: updatedByName,
      action: 'MEMBER_ROLE_CHANGED',
      businessId,
      description: `Role of member ${targetUid} changed to '${newRole}' in Business ${businessId}.`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Update status (active, suspended, removed) of a member in businesses/{businessId}/members/{targetUid}
 */
export async function updateBusinessMemberStatusDoc(params: {
  businessId: string;
  targetUid: string;
  newStatus: BusinessMemberStatus;
  updatedByUid: string;
  updatedByName: string;
}): Promise<void> {
  const { businessId, targetUid, newStatus, updatedByUid, updatedByName } = params;
  const path = `businesses/${businessId}/members/${targetUid}`;

  try {
    const memberRef = doc(db, 'businesses', businessId, 'members', targetUid);

    await updateDoc(memberRef, {
      status: newStatus,
      updatedAt: serverTimestamp(),
    });

    const action = newStatus === 'suspended' ? 'MEMBER_SUSPENDED' : 'MEMBER_REMOVED';
    await createAuditLogDoc({
      userId: updatedByUid,
      userName: updatedByName,
      action,
      businessId,
      description: `Membership status of user ${targetUid} changed to '${newStatus}' in Business ${businessId}.`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// ==========================================
// CATEGORY FIRESTORE OPERATIONS
// ==========================================

export async function createCategoryDoc(params: {
  businessId: string;
  name: string;
  description?: string;
  createdByUid: string;
}): Promise<Category> {
  const { businessId, name, description = '', createdByUid } = params;
  if (!name.trim()) throw new Error('Category name is required.');

  const categoryId = `cat_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
  const path = `categories/${categoryId}`;

  try {
    const catData = {
      categoryId,
      businessId,
      name: name.trim(),
      description: description.trim(),
      status: 'active' as CategoryStatus,
      createdBy: createdByUid,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    await setDoc(doc(db, 'categories', categoryId), catData);

    await createAuditLogDoc({
      userId: createdByUid,
      userName: 'User',
      action: 'CATEGORY_CREATED',
      businessId,
      description: `Category '${name}' created (ID: ${categoryId}).`,
    });

    return {
      categoryId,
      businessId,
      name: name.trim(),
      description: description.trim(),
      status: 'active',
      createdBy: createdByUid,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

export async function getCategoriesDoc(businessId: string): Promise<Category[]> {
  const path = 'categories';
  try {
    const q = query(
      collection(db, 'categories'),
      where('businessId', '==', businessId)
    );
    const snap = await getDocs(q);
    const list = snap.docs
      .map(docSnap => {
        const d = docSnap.data();
        return {
          categoryId: d.categoryId || docSnap.id,
          businessId: d.businessId,
          name: d.name,
          description: d.description || '',
          status: (d.status as CategoryStatus) || 'active',
          createdBy: d.createdBy || '',
          createdAt: d.createdAt?.toDate ? d.createdAt.toDate().toISOString() : new Date().toISOString(),
          updatedAt: d.updatedAt?.toDate ? d.updatedAt.toDate().toISOString() : new Date().toISOString(),
        };
      })
      .filter(c => c.status === 'active');
    return list;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function updateCategoryDoc(params: {
  categoryId: string;
  businessId: string;
  name: string;
  description?: string;
  updatedByUid: string;
}): Promise<void> {
  const { categoryId, businessId, name, description = '', updatedByUid } = params;
  if (!name.trim()) throw new Error('Category name is required.');
  const path = `categories/${categoryId}`;

  try {
    await updateDoc(doc(db, 'categories', categoryId), {
      name: name.trim(),
      description: description.trim(),
      updatedAt: serverTimestamp(),
    });

    await createAuditLogDoc({
      userId: updatedByUid,
      userName: 'User',
      action: 'CATEGORY_UPDATED',
      businessId,
      description: `Category '${categoryId}' updated to '${name}'.`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function archiveCategoryDoc(categoryId: string, businessId: string, updatedByUid: string): Promise<void> {
  const path = `categories/${categoryId}`;
  try {
    await updateDoc(doc(db, 'categories', categoryId), {
      status: 'archived',
      updatedAt: serverTimestamp(),
    });

    await createAuditLogDoc({
      userId: updatedByUid,
      userName: 'User',
      action: 'CATEGORY_ARCHIVED',
      businessId,
      description: `Category '${categoryId}' archived.`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function seedRecommendedCategoriesDoc(businessId: string, userId: string): Promise<Category[]> {
  const recommendedNames = [
    'Agriculture Tools',
    'Veterinary Medicine',
    'Foods',
    'Animal Feeds',
    'Electronic Devices',
    'Clothes & Fashion',
    'Shoes',
    'Cosmetics & Beauty',
    'Household Items',
    'Beverages',
    'Stationery & Office Supplies',
    'Hardware & Construction Materials',
    'Spare Parts & Accessories',
    'Baby Products',
    'General Merchandise',
  ];

  const createdCategories: Category[] = [];
  for (const name of recommendedNames) {
    try {
      const cat = await createCategoryDoc({
        businessId,
        name,
        description: `Recommended category for ${name}`,
        createdByUid: userId,
      });
      createdCategories.push(cat);
    } catch (e) {
      console.warn(`Category '${name}' creation skipped:`, e);
    }
  }

  return createdCategories;
}

// ==========================================
// PRODUCT FIRESTORE OPERATIONS
// ==========================================

export async function createProductDoc(params: {
  businessId: string;
  ownerId: string;
  name: string;
  description?: string;
  categoryId: string;
  categoryName: string;
  sku?: string;
  barcode?: string;
  unit: string;
  sellingPrice: number;
  costPrice: number;
  initialQuantity?: number;
  minimumStockLevel?: number;
  imageUrl?: string;
  supplierId?: string;
  createdByUid: string;
  createdByName: string;
}): Promise<Product> {
  const {
    businessId,
    ownerId,
    name,
    description = '',
    categoryId,
    categoryName,
    sku = '',
    barcode = '',
    unit,
    sellingPrice,
    costPrice,
    initialQuantity = 0,
    minimumStockLevel = 5,
    imageUrl = '',
    supplierId = '',
    createdByUid,
    createdByName,
  } = params;

  // Strict Validations
  if (!name.trim()) throw new Error('Product name is required.');
  if (!categoryId) throw new Error('Category is required.');
  if (!unit.trim()) throw new Error('Unit of measure is required.');
  if (sellingPrice < 0) throw new Error('Selling price must be non-negative.');
  if (costPrice < 0) throw new Error('Cost price must be non-negative.');
  if (initialQuantity < 0) throw new Error('Initial quantity must be non-negative.');
  if (minimumStockLevel < 0) throw new Error('Minimum stock level must be non-negative.');

  const productId = `prod_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
  const productPath = `products/${productId}`;
  const inventoryId = `inv_${productId}`;
  const generatedSku = sku.trim() || `SKU-${Math.floor(100000 + Math.random() * 900000)}`;

  try {
    // 1. Create Product document
    const productData = {
      productId,
      businessId,
      ownerId,
      name: name.trim(),
      description: description.trim(),
      categoryId,
      categoryName,
      sku: generatedSku,
      barcode: barcode.trim(),
      unit: unit.trim(),
      sellingPrice: Number(sellingPrice),
      costPrice: Number(costPrice),
      currency: 'RWF',
      quantity: Number(initialQuantity),
      minimumStockLevel: Number(minimumStockLevel),
      status: 'active' as ProductStatus,
      imageUrl: imageUrl.trim(),
      supplierId: supplierId.trim(),
      createdBy: createdByUid,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    await setDoc(doc(db, 'products', productId), productData);

    // 2. Create Inventory tracking record
    const invStatus: 'In Stock' | 'Low Stock' | 'Out of Stock' =
      initialQuantity <= 0
        ? 'Out of Stock'
        : initialQuantity <= minimumStockLevel
        ? 'Low Stock'
        : 'In Stock';

    const inventoryData = {
      inventoryId,
      businessId,
      ownerId,
      productId,
      quantity: Number(initialQuantity),
      reservedQuantity: 0,
      availableQuantity: Number(initialQuantity),
      minimumStockLevel: Number(minimumStockLevel),
      unit: unit.trim(),
      status: invStatus,
      updatedAt: serverTimestamp(),
      updatedBy: createdByUid,
    };

    await setDoc(doc(db, 'inventory', inventoryId), inventoryData);

    // 3. Initial Stock Movement Record (if quantity > 0)
    if (initialQuantity > 0) {
      const movementId = `mov_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
      await setDoc(doc(db, 'inventoryMovements', movementId), {
        movementId,
        businessId,
        productId,
        type: 'STOCK_IN' as InventoryMovementType,
        quantity: Number(initialQuantity),
        reason: 'Initial Product Creation Stock',
        createdBy: createdByUid,
        createdAt: serverTimestamp(),
      });
    }

    // 4. Audit Log
    await createAuditLogDoc({
      userId: createdByUid,
      userName: createdByName,
      action: 'PRODUCT_CREATED',
      businessId,
      description: `Product '${name}' created with SKU '${generatedSku}' and initial stock ${initialQuantity}.`,
    });

    return {
      productId,
      businessId,
      ownerId,
      name: name.trim(),
      description: description.trim(),
      categoryId,
      categoryName,
      sku: generatedSku,
      barcode: barcode.trim(),
      unit: unit.trim(),
      sellingPrice: Number(sellingPrice),
      costPrice: Number(costPrice),
      currency: 'RWF',
      quantity: Number(initialQuantity),
      minimumStockLevel: Number(minimumStockLevel),
      status: 'active',
      imageUrl: imageUrl.trim(),
      supplierId: supplierId.trim(),
      createdBy: createdByUid,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, productPath);
    throw error;
  }
}

export async function getProductsDoc(
  businessId: string,
  options?: { includeArchived?: boolean; categoryId?: string; search?: string }
): Promise<Product[]> {
  const path = 'products';
  try {
    const q = query(collection(db, 'products'), where('businessId', '==', businessId));
    const snap = await getDocs(q);

    let products = snap.docs.map(docSnap => {
      const d = docSnap.data();
      return {
        productId: d.productId || docSnap.id,
        businessId: d.businessId,
        ownerId: d.ownerId,
        name: d.name || 'Product',
        description: d.description || '',
        categoryId: d.categoryId || '',
        categoryName: d.categoryName || 'General',
        sku: d.sku || '',
        barcode: d.barcode || '',
        unit: d.unit || 'Item',
        sellingPrice: Number(d.sellingPrice || 0),
        costPrice: Number(d.costPrice || 0),
        currency: d.currency || 'RWF',
        quantity: Number(d.quantity || 0),
        minimumStockLevel: Number(d.minimumStockLevel || 0),
        status: (d.status as ProductStatus) || 'active',
        imageUrl: d.imageUrl || '',
        supplierId: d.supplierId || '',
        createdBy: d.createdBy || '',
        createdAt: d.createdAt?.toDate ? d.createdAt.toDate().toISOString() : new Date().toISOString(),
        updatedAt: d.updatedAt?.toDate ? d.updatedAt.toDate().toISOString() : new Date().toISOString(),
      };
    });

    if (!options?.includeArchived) {
      products = products.filter(p => p.status === 'active');
    }

    if (options?.categoryId && options.categoryId !== 'All') {
      products = products.filter(p => p.categoryId === options.categoryId);
    }

    if (options?.search) {
      const s = options.search.toLowerCase();
      products = products.filter(
        p =>
          p.name.toLowerCase().includes(s) ||
          p.sku.toLowerCase().includes(s) ||
          p.categoryName.toLowerCase().includes(s)
      );
    }

    return products;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function getProductByIdDoc(productId: string): Promise<Product | null> {
  const path = `products/${productId}`;
  try {
    const docRef = doc(db, 'products', productId);
    const snap = await getDoc(docRef);
    if (!snap.exists()) return null;
    const d = snap.data();
    return {
      productId: d.productId || snap.id,
      businessId: d.businessId,
      ownerId: d.ownerId,
      name: d.name,
      description: d.description || '',
      categoryId: d.categoryId || '',
      categoryName: d.categoryName || '',
      sku: d.sku || '',
      barcode: d.barcode || '',
      unit: d.unit || 'Item',
      sellingPrice: Number(d.sellingPrice || 0),
      costPrice: Number(d.costPrice || 0),
      currency: d.currency || 'RWF',
      quantity: Number(d.quantity || 0),
      minimumStockLevel: Number(d.minimumStockLevel || 0),
      status: (d.status as ProductStatus) || 'active',
      imageUrl: d.imageUrl || '',
      supplierId: d.supplierId || '',
      createdBy: d.createdBy || '',
      createdAt: d.createdAt?.toDate ? d.createdAt.toDate().toISOString() : new Date().toISOString(),
      updatedAt: d.updatedAt?.toDate ? d.updatedAt.toDate().toISOString() : new Date().toISOString(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return null;
  }
}

export async function updateProductDoc(params: {
  productId: string;
  businessId: string;
  name: string;
  description?: string;
  categoryId: string;
  categoryName: string;
  sku?: string;
  barcode?: string;
  unit: string;
  sellingPrice: number;
  costPrice: number;
  minimumStockLevel: number;
  imageUrl?: string;
  supplierId?: string;
  updatedByUid: string;
  updatedByName: string;
}): Promise<void> {
  const {
    productId,
    businessId,
    name,
    description = '',
    categoryId,
    categoryName,
    sku = '',
    barcode = '',
    unit,
    sellingPrice,
    costPrice,
    minimumStockLevel,
    imageUrl = '',
    supplierId = '',
    updatedByUid,
    updatedByName,
  } = params;

  if (!name.trim()) throw new Error('Product name is required.');
  if (sellingPrice < 0) throw new Error('Selling price must be non-negative.');
  if (costPrice < 0) throw new Error('Cost price must be non-negative.');
  if (minimumStockLevel < 0) throw new Error('Minimum stock level must be non-negative.');

  const path = `products/${productId}`;
  try {
    await updateDoc(doc(db, 'products', productId), {
      name: name.trim(),
      description: description.trim(),
      categoryId,
      categoryName,
      sku: sku.trim(),
      barcode: barcode.trim(),
      unit: unit.trim(),
      sellingPrice: Number(sellingPrice),
      costPrice: Number(costPrice),
      minimumStockLevel: Number(minimumStockLevel),
      imageUrl: imageUrl.trim(),
      supplierId: supplierId.trim(),
      updatedAt: serverTimestamp(),
    });

    // Update inventory minimumStockLevel
    const invRef = doc(db, 'inventory', `inv_${productId}`);
    await updateDoc(invRef, {
      minimumStockLevel: Number(minimumStockLevel),
      updatedAt: serverTimestamp(),
      updatedBy: updatedByUid,
    }).catch(() => {});

    await createAuditLogDoc({
      userId: updatedByUid,
      userName: updatedByName,
      action: 'PRODUCT_UPDATED',
      businessId,
      description: `Product '${name}' (ID: ${productId}) updated.`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    throw error;
  }
}

export async function archiveProductDoc(params: {
  productId: string;
  businessId: string;
  updatedByUid: string;
  updatedByName: string;
}): Promise<void> {
  const { productId, businessId, updatedByUid, updatedByName } = params;
  const path = `products/${productId}`;

  try {
    await updateDoc(doc(db, 'products', productId), {
      status: 'archived',
      updatedAt: serverTimestamp(),
    });

    await createAuditLogDoc({
      userId: updatedByUid,
      userName: updatedByName,
      action: 'PRODUCT_ARCHIVED',
      businessId,
      description: `Product ${productId} set to archived status. Historical data preserved.`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    throw error;
  }
}

// ==========================================
// INVENTORY & STOCK TRANSACTION OPERATIONS
// ==========================================

export async function getInventoryDoc(businessId: string): Promise<Inventory[]> {
  const path = 'inventory';
  try {
    const q = query(collection(db, 'inventory'), where('businessId', '==', businessId));
    const snap = await getDocs(q);
    return snap.docs.map(docSnap => {
      const d = docSnap.data();
      return {
        inventoryId: d.inventoryId || docSnap.id,
        businessId: d.businessId,
        ownerId: d.ownerId,
        productId: d.productId,
        quantity: Number(d.quantity || 0),
        reservedQuantity: Number(d.reservedQuantity || 0),
        availableQuantity: Number(d.availableQuantity || 0),
        minimumStockLevel: Number(d.minimumStockLevel || 0),
        maximumStockLevel: d.maximumStockLevel ? Number(d.maximumStockLevel) : undefined,
        unit: d.unit || 'Item',
        location: d.location || '',
        warehouse: d.warehouse || '',
        status: (d.status as Inventory['status']) || 'In Stock',
        updatedAt: d.updatedAt?.toDate ? d.updatedAt.toDate().toISOString() : new Date().toISOString(),
        updatedBy: d.updatedBy || '',
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

/**
 * Perform Atomic Stock In Transaction
 */
export async function performStockInTransaction(params: {
  businessId: string;
  productId: string;
  addQuantity: number;
  reason?: string;
  createdByUid: string;
  createdByName: string;
}): Promise<{ newQuantity: number }> {
  const { businessId, productId, addQuantity, reason = 'Stock In Deposit', createdByUid, createdByName } = params;
  if (addQuantity <= 0) throw new Error('Stock in quantity must be greater than zero.');

  const productRef = doc(db, 'products', productId);
  const inventoryRef = doc(db, 'inventory', `inv_${productId}`);
  const movementId = `mov_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
  const movementRef = doc(db, 'inventoryMovements', movementId);

  try {
    const result = await runTransaction(db, async (transaction) => {
      const prodSnap = await transaction.get(productRef);
      if (!prodSnap.exists()) throw new Error('Product not found.');
      const prodData = prodSnap.data();
      if (prodData.businessId !== businessId) throw new Error('Unauthorized business product access.');

      const invSnap = await transaction.get(inventoryRef);
      const currentQty = invSnap.exists() ? Number(invSnap.data().quantity || 0) : Number(prodData.quantity || 0);
      const currentReserved = invSnap.exists() ? Number(invSnap.data().reservedQuantity || 0) : 0;
      const minStock = invSnap.exists() ? Number(invSnap.data().minimumStockLevel || prodData.minimumStockLevel || 5) : 5;

      const newQty = currentQty + addQuantity;
      const newAvail = newQty - currentReserved;
      const newStatus: 'In Stock' | 'Low Stock' | 'Out of Stock' =
        newAvail <= 0 ? 'Out of Stock' : newAvail <= minStock ? 'Low Stock' : 'In Stock';

      transaction.update(productRef, {
        quantity: newQty,
        updatedAt: serverTimestamp(),
      });

      if (invSnap.exists()) {
        transaction.update(inventoryRef, {
          quantity: newQty,
          availableQuantity: newAvail,
          status: newStatus,
          updatedAt: serverTimestamp(),
          updatedBy: createdByUid,
        });
      } else {
        transaction.set(inventoryRef, {
          inventoryId: `inv_${productId}`,
          businessId,
          ownerId: prodData.ownerId || createdByUid,
          productId,
          quantity: newQty,
          reservedQuantity: currentReserved,
          availableQuantity: newAvail,
          minimumStockLevel: minStock,
          unit: prodData.unit || 'Item',
          status: newStatus,
          updatedAt: serverTimestamp(),
          updatedBy: createdByUid,
        });
      }

      transaction.set(movementRef, {
        movementId,
        businessId,
        productId,
        type: 'STOCK_IN' as InventoryMovementType,
        quantity: addQuantity,
        reason,
        createdBy: createdByUid,
        createdAt: serverTimestamp(),
      });

      return { newQuantity: newQty };
    });

    await createAuditLogDoc({
      userId: createdByUid,
      userName: createdByName,
      action: 'STOCK_ADDED',
      businessId,
      description: `Stock IN: Added ${addQuantity} units to Product ${productId}. New total: ${result.newQuantity}.`,
    });

    return result;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `products/${productId}`);
    throw error;
  }
}

/**
 * Perform Atomic Stock Adjustment Transaction (Strict Negative Stock Protection)
 */
export async function performStockAdjustmentTransaction(params: {
  businessId: string;
  productId: string;
  targetQuantity: number;
  reason: string;
  createdByUid: string;
  createdByName: string;
}): Promise<{ newQuantity: number; delta: number }> {
  const { businessId, productId, targetQuantity, reason, createdByUid, createdByName } = params;
  if (targetQuantity < 0) {
    throw new Error('Stock adjustment rejected: Stock quantity cannot be negative.');
  }
  if (!reason.trim()) {
    throw new Error('A valid reason is required for stock adjustment.');
  }

  const productRef = doc(db, 'products', productId);
  const inventoryRef = doc(db, 'inventory', `inv_${productId}`);
  const movementId = `mov_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
  const movementRef = doc(db, 'inventoryMovements', movementId);

  try {
    const result = await runTransaction(db, async (transaction) => {
      const prodSnap = await transaction.get(productRef);
      if (!prodSnap.exists()) throw new Error('Product not found.');
      const prodData = prodSnap.data();
      if (prodData.businessId !== businessId) throw new Error('Unauthorized business product access.');

      const invSnap = await transaction.get(inventoryRef);
      const currentQty = invSnap.exists() ? Number(invSnap.data().quantity || 0) : Number(prodData.quantity || 0);
      const currentReserved = invSnap.exists() ? Number(invSnap.data().reservedQuantity || 0) : 0;
      const minStock = invSnap.exists() ? Number(invSnap.data().minimumStockLevel || prodData.minimumStockLevel || 5) : 5;

      const delta = targetQuantity - currentQty;
      const newAvail = targetQuantity - currentReserved;

      if (newAvail < 0) {
        throw new Error('Adjustment rejected: Reserved stock exceeds target quantity.');
      }

      const newStatus: 'In Stock' | 'Low Stock' | 'Out of Stock' =
        newAvail <= 0 ? 'Out of Stock' : newAvail <= minStock ? 'Low Stock' : 'In Stock';

      transaction.update(productRef, {
        quantity: targetQuantity,
        updatedAt: serverTimestamp(),
      });

      if (invSnap.exists()) {
        transaction.update(inventoryRef, {
          quantity: targetQuantity,
          availableQuantity: newAvail,
          status: newStatus,
          updatedAt: serverTimestamp(),
          updatedBy: createdByUid,
        });
      } else {
        transaction.set(inventoryRef, {
          inventoryId: `inv_${productId}`,
          businessId,
          ownerId: prodData.ownerId || createdByUid,
          productId,
          quantity: targetQuantity,
          reservedQuantity: currentReserved,
          availableQuantity: newAvail,
          minimumStockLevel: minStock,
          unit: prodData.unit || 'Item',
          status: newStatus,
          updatedAt: serverTimestamp(),
          updatedBy: createdByUid,
        });
      }

      transaction.set(movementRef, {
        movementId,
        businessId,
        productId,
        type: 'ADJUSTMENT' as InventoryMovementType,
        quantity: delta,
        reason: reason.trim(),
        createdBy: createdByUid,
        createdAt: serverTimestamp(),
      });

      return { newQuantity: targetQuantity, delta };
    });

    await createAuditLogDoc({
      userId: createdByUid,
      userName: createdByName,
      action: 'STOCK_ADJUSTED',
      businessId,
      description: `Stock ADJUSTMENT: Product ${productId} set to ${targetQuantity} (delta ${result.delta}). Reason: ${reason}.`,
    });

    return result;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `products/${productId}`);
    throw error;
  }
}

/**
 * Perform Atomic Stock Out Transaction
 */
export async function performStockOutTransaction(params: {
  businessId: string;
  productId: string;
  deductQuantity: number;
  reason?: string;
  referenceId?: string;
  createdByUid: string;
  createdByName: string;
}): Promise<{ newQuantity: number }> {
  const { businessId, productId, deductQuantity, reason = 'Stock Out Removal', referenceId = '', createdByUid, createdByName } = params;
  if (deductQuantity <= 0) throw new Error('Deduct quantity must be greater than zero.');

  const productRef = doc(db, 'products', productId);
  const inventoryRef = doc(db, 'inventory', `inv_${productId}`);
  const movementId = `mov_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
  const movementRef = doc(db, 'inventoryMovements', movementId);

  try {
    const result = await runTransaction(db, async (transaction) => {
      const prodSnap = await transaction.get(productRef);
      if (!prodSnap.exists()) throw new Error('Product not found.');
      const prodData = prodSnap.data();
      if (prodData.businessId !== businessId) throw new Error('Unauthorized business product access.');

      const invSnap = await transaction.get(inventoryRef);
      const currentQty = invSnap.exists() ? Number(invSnap.data().quantity || 0) : Number(prodData.quantity || 0);
      const currentReserved = invSnap.exists() ? Number(invSnap.data().reservedQuantity || 0) : 0;
      const minStock = invSnap.exists() ? Number(invSnap.data().minimumStockLevel || prodData.minimumStockLevel || 5) : 5;

      const newQty = currentQty - deductQuantity;
      if (newQty < 0) {
        throw new Error(`Insufficient stock available. Required: ${deductQuantity}, Available: ${currentQty}. Negative stock is prohibited.`);
      }

      const newAvail = newQty - currentReserved;
      const newStatus: 'In Stock' | 'Low Stock' | 'Out of Stock' =
        newAvail <= 0 ? 'Out of Stock' : newAvail <= minStock ? 'Low Stock' : 'In Stock';

      transaction.update(productRef, {
        quantity: newQty,
        updatedAt: serverTimestamp(),
      });

      if (invSnap.exists()) {
        transaction.update(inventoryRef, {
          quantity: newQty,
          availableQuantity: newAvail,
          status: newStatus,
          updatedAt: serverTimestamp(),
          updatedBy: createdByUid,
        });
      }

      transaction.set(movementRef, {
        movementId,
        businessId,
        productId,
        type: 'STOCK_OUT' as InventoryMovementType,
        quantity: deductQuantity,
        reason,
        referenceId,
        createdBy: createdByUid,
        createdAt: serverTimestamp(),
      });

      return { newQuantity: newQty };
    });

    await createAuditLogDoc({
      userId: createdByUid,
      userName: createdByName,
      action: 'STOCK_REMOVED',
      businessId,
      description: `Stock OUT: Deducted ${deductQuantity} units from Product ${productId}. Remaining: ${result.newQuantity}.`,
    });

    return result;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `products/${productId}`);
    throw error;
  }
}

export async function getInventoryMovementsDoc(businessId: string, productId?: string): Promise<InventoryMovement[]> {
  const path = 'inventoryMovements';
  try {
    let q = query(collection(db, 'inventoryMovements'), where('businessId', '==', businessId));
    if (productId) {
      q = query(collection(db, 'inventoryMovements'), where('businessId', '==', businessId), where('productId', '==', productId));
    }
    const snap = await getDocs(q);
    return snap.docs.map(docSnap => {
      const d = docSnap.data();
      return {
        movementId: d.movementId || docSnap.id,
        businessId: d.businessId,
        productId: d.productId,
        type: d.type as InventoryMovementType,
        quantity: Number(d.quantity || 0),
        reason: d.reason || '',
        referenceId: d.referenceId || '',
        createdBy: d.createdBy || '',
        createdAt: d.createdAt?.toDate ? d.createdAt.toDate().toISOString() : new Date().toISOString(),
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function getProductStatsDoc(businessId: string): Promise<ProductCatalogStats> {
  const products = await getProductsDoc(businessId, { includeArchived: false });
  const totalProducts = products.length;
  const activeProducts = products.filter(p => p.status === 'active').length;
  const lowStockProducts = products.filter(p => p.quantity > 0 && p.quantity <= p.minimumStockLevel).length;
  const outOfStockProducts = products.filter(p => p.quantity <= 0).length;
  const totalInventoryQuantity = products.reduce((acc, p) => acc + (p.quantity || 0), 0);
  const totalStockValueRwf = products.reduce((acc, p) => acc + (p.sellingPrice * (p.quantity || 0)), 0);

  return {
    totalProducts,
    activeProducts,
    lowStockProducts,
    outOfStockProducts,
    totalInventoryQuantity,
    totalStockValueRwf,
  };
}

// ==========================================
// PHASE 4: CUSTOMER FIRESTORE OPERATIONS
// ==========================================

export async function getCustomersDoc(businessId: string): Promise<CustomerDoc[]> {
  const path = 'customers';
  try {
    const q = query(
      collection(db, 'customers'),
      where('businessId', '==', businessId),
      where('status', '==', 'active')
    );
    const snap = await getDocs(q);
    return snap.docs.map(docSnap => {
      const d = docSnap.data();
      return {
        customerId: docSnap.id,
        businessId: d.businessId,
        ownerId: d.ownerId,
        name: d.name || '',
        phone: d.phone || '',
        email: d.email || '',
        address: d.address || '',
        customerType: (d.customerType as CustomerType) || 'individual',
        status: (d.status as CustomerStatus) || 'active',
        createdBy: d.createdBy || '',
        createdAt: d.createdAt?.toDate ? d.createdAt.toDate().toISOString() : (d.createdAt || new Date().toISOString()),
        updatedAt: d.updatedAt?.toDate ? d.updatedAt.toDate().toISOString() : (d.updatedAt || new Date().toISOString()),
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function createCustomerDoc(params: {
  businessId: string;
  name: string;
  phone?: string;
  email?: string;
  address?: string;
  customerType: CustomerType;
  createdByUid: string;
  createdByName: string;
}): Promise<CustomerDoc> {
  const { businessId, name, phone = '', email = '', address = '', customerType, createdByUid, createdByName } = params;
  if (!name.trim()) throw new Error('Customer name is required.');

  const customerId = `cust_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const docRef = doc(db, 'customers', customerId);

  const payload = {
    customerId,
    businessId,
    name: name.trim(),
    phone: phone.trim(),
    email: email.trim(),
    address: address.trim(),
    customerType,
    status: 'active' as CustomerStatus,
    createdBy: createdByUid,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  try {
    await setDoc(docRef, payload);
    await createAuditLogDoc({
      userId: createdByUid,
      userName: createdByName,
      action: 'CUSTOMER_CREATED',
      businessId,
      description: `Created customer record '${name.trim()}' (${customerType})`,
    });

    return {
      ...payload,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `customers/${customerId}`);
    throw error;
  }
}

export async function updateCustomerDoc(params: {
  customerId: string;
  businessId: string;
  name?: string;
  phone?: string;
  email?: string;
  address?: string;
  customerType?: CustomerType;
  updatedByUid: string;
  updatedByName: string;
}): Promise<void> {
  const { customerId, businessId, name, phone, email, address, customerType, updatedByUid, updatedByName } = params;
  const docRef = doc(db, 'customers', customerId);

  const updateData: Record<string, any> = {
    updatedAt: serverTimestamp(),
  };
  if (name !== undefined) updateData.name = name.trim();
  if (phone !== undefined) updateData.phone = phone.trim();
  if (email !== undefined) updateData.email = email.trim();
  if (address !== undefined) updateData.address = address.trim();
  if (customerType !== undefined) updateData.customerType = customerType;

  try {
    await updateDoc(docRef, updateData);
    await createAuditLogDoc({
      userId: updatedByUid,
      userName: updatedByName,
      action: 'CUSTOMER_UPDATED',
      businessId,
      description: `Updated customer record '${customerId}'`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `customers/${customerId}`);
  }
}

export async function archiveCustomerDoc(params: {
  customerId: string;
  businessId: string;
  updatedByUid: string;
  updatedByName: string;
}): Promise<void> {
  const { customerId, businessId, updatedByUid, updatedByName } = params;
  const docRef = doc(db, 'customers', customerId);
  try {
    await updateDoc(docRef, {
      status: 'archived',
      updatedAt: serverTimestamp(),
    });
    await createAuditLogDoc({
      userId: updatedByUid,
      userName: updatedByName,
      action: 'CUSTOMER_ARCHIVED',
      businessId,
      description: `Archived customer record '${customerId}'`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `customers/${customerId}`);
  }
}

// ==========================================
// PHASE 4: ATOMIC SALES & TRANSACTION ENGINE
// ==========================================

export async function createAndCompleteSaleTransaction(params: {
  businessId: string;
  customerId?: string;
  customerName?: string;
  items: Array<{ productId: string; quantity: number; discount?: number }>;
  overallDiscount?: number;
  tax?: number;
  paymentMethod: SalePaymentMethod;
  paymentStatus?: SalePaymentStatus;
  createdByUid: string;
  createdByName: string;
}): Promise<{ sale: SaleDoc; items: SaleItemDoc[] }> {
  const {
    businessId,
    customerId = 'walk_in',
    customerName = 'Walk-in Customer',
    items,
    overallDiscount = 0,
    tax = 0,
    paymentMethod,
    paymentStatus = 'paid',
    createdByUid,
    createdByName,
  } = params;

  if (!items || items.length === 0) {
    throw new Error('Cannot process empty sale. At least one item is required.');
  }

  const saleId = `sale_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const saleRef = doc(db, 'sales', saleId);
  const counterRef = doc(db, 'counters', `sales_${businessId}`);

  try {
    const transactionResult = await runTransaction(db, async (transaction) => {
      // 1. Validate counter & compute sale number
      const counterSnap = await transaction.get(counterRef);
      const currentCount = counterSnap.exists() ? Number(counterSnap.data().count || 0) : 0;
      const newCount = currentCount + 1;
      const saleNumber = `AGR-${String(newCount).padStart(6, '0')}`;

      // 2. Read products & validate stock & price
      let totalRawSubtotal = 0;
      let totalItemDiscounts = 0;
      const processedItems: Array<{
        productId: string;
        productName: string;
        sku: string;
        quantity: number;
        unitPrice: number;
        costPrice: number;
        discount: number;
        subtotal: number;
        currentProdQty: number;
        minStock: number;
      }> = [];

      for (const item of items) {
        if (item.quantity <= 0) {
          throw new Error(`Invalid item quantity ${item.quantity} for product ID ${item.productId}`);
        }

        const prodRef = doc(db, 'products', item.productId);
        const prodSnap = await transaction.get(prodRef);

        if (!prodSnap.exists()) {
          throw new Error(`Product record not found for ID: ${item.productId}`);
        }

        const prodData = prodSnap.data();
        if (prodData.businessId !== businessId) {
          throw new Error(`Unauthorized cross-business product transaction for product ${item.productId}`);
        }

        const availableQty = Number(prodData.quantity || 0);
        if (availableQty < item.quantity) {
          throw new Error(
            `Insufficient stock for product "${prodData.name}". Required: ${item.quantity}, Available: ${availableQty}. Transaction rejected to prevent negative inventory.`
          );
        }

        // Authoritative price read directly from Firestore product doc
        const unitPrice = Number(prodData.sellingPrice || 0);
        const costPrice = Number(prodData.costPrice || 0);
        const itemDiscount = Number(item.discount || 0);
        const itemSubtotal = Math.max(0, item.quantity * unitPrice - itemDiscount);

        totalRawSubtotal += item.quantity * unitPrice;
        totalItemDiscounts += itemDiscount;

        processedItems.push({
          productId: item.productId,
          productName: prodData.name || 'Agri Product',
          sku: prodData.sku || '',
          quantity: item.quantity,
          unitPrice,
          costPrice,
          discount: itemDiscount,
          subtotal: itemSubtotal,
          currentProdQty: availableQty,
          minStock: Number(prodData.minimumStockLevel || 5),
        });
      }

      const totalDiscount = overallDiscount + totalItemDiscounts;
      const finalTotal = Math.max(0, totalRawSubtotal - totalDiscount + tax);

      // 3. Update counter
      transaction.set(
        counterRef,
        {
          businessId,
          count: newCount,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );

      // 4. Create Sale Record
      const saleData = {
        saleId,
        businessId,
        customerId,
        customerName,
        saleNumber,
        status: 'completed' as SaleStatus,
        subtotal: totalRawSubtotal,
        discount: totalDiscount,
        tax,
        total: finalTotal,
        currency: 'RWF',
        paymentStatus,
        paymentMethod,
        createdBy: createdByUid,
        createdByName,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };
      transaction.set(saleRef, saleData);

      // 5. Create SaleItems & Deduct Product Inventory
      const createdSaleItems: SaleItemDoc[] = [];

      for (let i = 0; i < processedItems.length; i++) {
        const item = processedItems[i];
        const saleItemId = `sitem_${saleId}_${i}`;
        const saleItemRef = doc(db, 'saleItems', saleItemId);
        const prodRef = doc(db, 'products', item.productId);
        const invRef = doc(db, 'inventory', `inv_${item.productId}`);
        const movId = `mov_sale_${saleId}_${i}`;
        const movRef = doc(db, 'inventoryMovements', movId);

        const newProdQty = item.currentProdQty - item.quantity;
        const newStatus = newProdQty <= 0 ? 'Out of Stock' : newProdQty <= item.minStock ? 'Low Stock' : 'In Stock';

        // Update product document
        transaction.update(prodRef, {
          quantity: newProdQty,
          updatedAt: serverTimestamp(),
        });

        // Update inventory document if present
        transaction.set(
          invRef,
          {
            inventoryId: `inv_${item.productId}`,
            businessId,
            productId: item.productId,
            quantity: newProdQty,
            availableQuantity: newProdQty,
            status: newStatus,
            updatedAt: serverTimestamp(),
            updatedBy: createdByUid,
          },
          { merge: true }
        );

        // Save sale item
        const itemPayload = {
          saleItemId,
          saleId,
          businessId,
          productId: item.productId,
          productName: item.productName,
          sku: item.sku,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          costPrice: item.costPrice,
          discount: item.discount,
          subtotal: item.subtotal,
          createdAt: serverTimestamp(),
        };
        transaction.set(saleItemRef, itemPayload);

        createdSaleItems.push({
          saleItemId,
          saleId,
          businessId,
          productId: item.productId,
          productName: item.productName,
          sku: item.sku,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          costPrice: item.costPrice,
          discount: item.discount,
          subtotal: item.subtotal,
          createdAt: new Date().toISOString(),
        });

        // Create inventory movement STOCK_OUT
        transaction.set(movRef, {
          movementId: movId,
          businessId,
          productId: item.productId,
          type: 'STOCK_OUT' as InventoryMovementType,
          quantity: item.quantity,
          reason: `Customer Sale ${saleNumber}`,
          referenceId: saleId,
          createdBy: createdByUid,
          createdAt: serverTimestamp(),
        });
      }

      return {
        sale: {
          saleId,
          businessId,
          customerId,
          customerName,
          saleNumber,
          status: 'completed' as SaleStatus,
          subtotal: totalRawSubtotal,
          discount: totalDiscount,
          tax,
          total: finalTotal,
          currency: 'RWF',
          paymentStatus,
          paymentMethod,
          createdBy: createdByUid,
          createdByName,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        items: createdSaleItems,
      };
    });

    await createAuditLogDoc({
      userId: createdByUid,
      userName: createdByName,
      action: 'SALE_COMPLETED',
      businessId,
      description: `Sale ${transactionResult.sale.saleNumber} completed for RWF ${transactionResult.sale.total.toLocaleString()} (${transactionResult.sale.paymentMethod}).`,
    });

    return transactionResult;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `sales/${saleId}`);
    throw error;
  }
}

export async function cancelSaleTransaction(params: {
  saleId: string;
  businessId: string;
  cancelledByUid: string;
  cancelledByName: string;
  reason: string;
}): Promise<void> {
  const { saleId, businessId, cancelledByUid, cancelledByName, reason } = params;
  const saleRef = doc(db, 'sales', saleId);

  try {
    // 1. Fetch sale items to know what inventory needs restoration
    const itemsQuery = query(
      collection(db, 'saleItems'),
      where('saleId', '==', saleId),
      where('businessId', '==', businessId)
    );
    const itemsSnap = await getDocs(itemsQuery);
    const saleItems = itemsSnap.docs.map(docSnap => docSnap.data());

    await runTransaction(db, async (transaction) => {
      const saleSnap = await transaction.get(saleRef);
      if (!saleSnap.exists()) throw new Error('Sale record not found.');
      const saleData = saleSnap.data();
      if (saleData.businessId !== businessId) throw new Error('Unauthorized business sale access.');
      if (saleData.status === 'cancelled') throw new Error('Sale is already cancelled.');

      // Restore inventory for each item
      for (let i = 0; i < saleItems.length; i++) {
        const item = saleItems[i];
        const prodRef = doc(db, 'products', item.productId);
        const invRef = doc(db, 'inventory', `inv_${item.productId}`);
        const movId = `mov_cancel_${saleId}_${i}`;
        const movRef = doc(db, 'inventoryMovements', movId);

        const prodSnap = await transaction.get(prodRef);
        if (prodSnap.exists()) {
          const prodData = prodSnap.data();
          const restoredQty = Number(prodData.quantity || 0) + Number(item.quantity || 0);
          const minStock = Number(prodData.minimumStockLevel || 5);
          const newStatus = restoredQty <= 0 ? 'Out of Stock' : restoredQty <= minStock ? 'Low Stock' : 'In Stock';

          transaction.update(prodRef, {
            quantity: restoredQty,
            updatedAt: serverTimestamp(),
          });

          transaction.set(
            invRef,
            {
              inventoryId: `inv_${item.productId}`,
              businessId,
              productId: item.productId,
              quantity: restoredQty,
              availableQuantity: restoredQty,
              status: newStatus,
              updatedAt: serverTimestamp(),
              updatedBy: cancelledByUid,
            },
            { merge: true }
          );

          transaction.set(movRef, {
            movementId: movId,
            businessId,
            productId: item.productId,
            type: 'STOCK_IN' as InventoryMovementType,
            quantity: Number(item.quantity || 0),
            reason: `Sale Cancelled: ${saleData.saleNumber} - ${reason}`,
            referenceId: saleId,
            createdBy: cancelledByUid,
            createdAt: serverTimestamp(),
          });
        }
      }

      // Update sale status
      transaction.update(saleRef, {
        status: 'cancelled',
        paymentStatus: 'refunded',
        cancelledBy: cancelledByUid,
        cancelledAt: serverTimestamp(),
        cancelReason: reason.trim(),
        updatedAt: serverTimestamp(),
      });
    });

    await createAuditLogDoc({
      userId: cancelledByUid,
      userName: cancelledByName,
      action: 'SALE_CANCELLED',
      businessId,
      description: `Cancelled sale ${saleId}. Reason: ${reason}. Inventory restored.`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `sales/${saleId}`);
    throw error;
  }
}

export async function getSalesDoc(
  businessId: string,
  filters?: { status?: SaleStatus; customerId?: string }
): Promise<SaleDoc[]> {
  const path = 'sales';
  try {
    let q = query(collection(db, 'sales'), where('businessId', '==', businessId));
    if (filters?.status) {
      q = query(collection(db, 'sales'), where('businessId', '==', businessId), where('status', '==', filters.status));
    }
    if (filters?.customerId) {
      q = query(collection(db, 'sales'), where('businessId', '==', businessId), where('customerId', '==', filters.customerId));
    }

    const snap = await getDocs(q);
    const list = snap.docs.map(docSnap => {
      const d = docSnap.data();
      return {
        saleId: docSnap.id,
        businessId: d.businessId,
        ownerId: d.ownerId,
        customerId: d.customerId || 'walk_in',
        customerName: d.customerName || 'Walk-in Customer',
        saleNumber: d.saleNumber || docSnap.id,
        status: (d.status as SaleStatus) || 'completed',
        subtotal: Number(d.subtotal || 0),
        discount: Number(d.discount || 0),
        tax: Number(d.tax || 0),
        total: Number(d.total || 0),
        currency: d.currency || 'RWF',
        paymentStatus: (d.paymentStatus as SalePaymentStatus) || 'paid',
        paymentMethod: (d.paymentMethod as SalePaymentMethod) || 'Cash',
        createdBy: d.createdBy || '',
        createdByName: d.createdByName || 'Staff',
        createdAt: d.createdAt?.toDate ? d.createdAt.toDate().toISOString() : (d.createdAt || new Date().toISOString()),
        updatedAt: d.updatedAt?.toDate ? d.updatedAt.toDate().toISOString() : (d.updatedAt || new Date().toISOString()),
        cancelledBy: d.cancelledBy,
        cancelledAt: d.cancelledAt?.toDate ? d.cancelledAt.toDate().toISOString() : d.cancelledAt,
        cancelReason: d.cancelReason,
      };
    });

    // Sort descending by creation date
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function getSaleItemsDoc(saleId: string, businessId: string): Promise<SaleItemDoc[]> {
  const path = 'saleItems';
  try {
    const q = query(
      collection(db, 'saleItems'),
      where('saleId', '==', saleId),
      where('businessId', '==', businessId)
    );
    const snap = await getDocs(q);
    return snap.docs.map(docSnap => {
      const d = docSnap.data();
      return {
        saleItemId: docSnap.id,
        saleId: d.saleId,
        businessId: d.businessId,
        ownerId: d.ownerId,
        productId: d.productId,
        productName: d.productName || 'Product',
        sku: d.sku || '',
        quantity: Number(d.quantity || 0),
        unitPrice: Number(d.unitPrice || 0),
        costPrice: Number(d.costPrice || 0),
        discount: Number(d.discount || 0),
        subtotal: Number(d.subtotal || 0),
        createdAt: d.createdAt?.toDate ? d.createdAt.toDate().toISOString() : (d.createdAt || new Date().toISOString()),
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function getSalesStatsDoc(businessId: string): Promise<SalesDashboardStats> {
  const sales = await getSalesDoc(businessId);
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

  let todaysSalesCount = 0;
  let todaysRevenueRwf = 0;
  let totalSalesCount = sales.length;
  let totalRevenueRwf = 0;
  let completedSalesCount = 0;
  let unpaidSalesCount = 0;
  let cancelledSalesCount = 0;

  for (const s of sales) {
    if (s.status === 'completed') {
      completedSalesCount++;
      totalRevenueRwf += s.total;

      const saleTime = new Date(s.createdAt).getTime();
      if (saleTime >= startOfDay) {
        todaysSalesCount++;
        todaysRevenueRwf += s.total;
      }
    } else if (s.status === 'cancelled') {
      cancelledSalesCount++;
    }

    if (s.paymentStatus === 'unpaid' || s.paymentStatus === 'pending') {
      unpaidSalesCount++;
    }
  }

  return {
    todaysSalesCount,
    todaysRevenueRwf,
    totalSalesCount,
    totalRevenueRwf,
    completedSalesCount,
    unpaidSalesCount,
    cancelledSalesCount,
  };
}

export async function getCustomerSalesSummaryDoc(
  customerId: string,
  businessId: string
): Promise<{ sales: SaleDoc[]; totalPurchasesRwf: number; salesCount: number; lastPurchaseDate?: string }> {
  const sales = await getSalesDoc(businessId, { customerId });
  const completedSales = sales.filter(s => s.status === 'completed');
  const totalPurchasesRwf = completedSales.reduce((acc, s) => acc + s.total, 0);
  const salesCount = completedSales.length;
  const lastPurchaseDate = completedSales.length > 0 ? completedSales[0].createdAt : undefined;

  return {
    sales,
    totalPurchasesRwf,
    salesCount,
    lastPurchaseDate,
  };
}



