import {
  OwnerConfig,
  OwnerNotification,
  OwnerNotificationPreferences,
  AuditLogRecord,
  NotificationType,
  NotificationPriority,
  UserRole
} from '../types';
import { createNotificationDoc } from './firestoreService';

// Central configuration for Owner Identity
let currentOwnerConfig: OwnerConfig = {
  ownerUserId: 'usr_0_owner',
  ownerName: 'Jimmy Mico (AGRIWISE Owner)',
  ownerEmail: 'jimmymico45@gmail.com',
  ownerPhone: '0792426760',
  smsE164Phone: '+250792426760',
  emailProvider: 'Resend / SMTP Gateway',
  smsProvider: 'MTN Rwanda WASP SMS API',
  lastUpdated: new Date().toISOString()
};

// Initial Notification Preferences
let currentOwnerPreferences: OwnerNotificationPreferences = {
  userId: 'usr_0_owner',
  updatedAt: new Date().toISOString(),
  preferences: [
    {
      eventCategory: 'user_registration',
      label: 'New User Account Registrations',
      dashboardEnabled: true,
      emailEnabled: true,
      smsEnabled: false
    },
    {
      eventCategory: 'farm_submission',
      label: 'New Farm / Land Boundary Submissions',
      dashboardEnabled: true,
      emailEnabled: true,
      smsEnabled: false
    },
    {
      eventCategory: 'marketplace_order',
      label: 'Marketplace Bulk Transactions & Orders',
      dashboardEnabled: true,
      emailEnabled: true,
      smsEnabled: true
    },
    {
      eventCategory: 'support_ticket',
      label: 'User Support Requests & Complaints',
      dashboardEnabled: true,
      emailEnabled: true,
      smsEnabled: true
    },
    {
      eventCategory: 'security_alert',
      label: 'Security Alerts & Unauthorized Access Attempts',
      dashboardEnabled: true,
      emailEnabled: true,
      smsEnabled: true
    },
    {
      eventCategory: 'system_event',
      label: 'System Maintenance & Core Platform Alerts',
      dashboardEnabled: true,
      emailEnabled: false,
      smsEnabled: false
    }
  ]
};

// Mock Initial Owner Notifications
let ownerNotifications: OwnerNotification[] = [
  {
    id: 'notif_001',
    recipientUserId: 'usr_0_owner',
    type: 'security',
    title: 'Unauthorized Admin Login Attempt Blocked',
    message: 'A user from IP 197.243.12.8 tried accessing /admin without valid super-admin token.',
    priority: 'critical',
    isRead: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
    activitySubtype: 'security_alert',
    relatedRecordType: 'security_event'
  },
  {
    id: 'notif_002',
    recipientUserId: 'usr_0_owner',
    type: 'user',
    title: 'New Cooperative Account Registered',
    message: 'Kiningi Irish Potato Farmers Coop (450 Members) registered and requested RAB verification.',
    relatedUserId: 'user_3',
    relatedUserName: 'Abahizi Kinigi Potato Cooperative',
    relatedUserPhone: '+250 788 998 877',
    relatedUserEmail: 'coop.kinigi@agriwise.rw',
    relatedUserRole: 'cooperative',
    priority: 'high',
    isRead: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    activitySubtype: 'user_registration',
    relatedRecordType: 'registration'
  },
  {
    id: 'notif_003',
    recipientUserId: 'usr_0_owner',
    type: 'marketplace',
    title: 'High-Value Marketplace Order Placed (Escrow)',
    message: 'Rwanda Grain & Milling placed an order for 45 Tons Maize worth 12,600,000 RWF.',
    relatedUserId: 'user_5',
    relatedUserName: 'Rwanda Grain & Milling Industries',
    relatedRecordId: 'ord_9901',
    relatedRecordType: 'order',
    priority: 'high',
    isRead: true,
    createdAt: new Date(Date.now() - 1000 * 60 * 360).toISOString(),
    activitySubtype: 'marketplace_order'
  },
  {
    id: 'notif_004',
    recipientUserId: 'usr_0_owner',
    type: 'support',
    title: 'New Support Ticket Submitted by Farmer',
    message: 'Jean de Dieu Nshimiyimana submitted inquiry regarding MoMo escrow payout clearance.',
    relatedUserId: 'user_1',
    relatedUserName: 'Jean de Dieu Nshimiyimana',
    relatedRecordId: 'ticket_441',
    relatedRecordType: 'support_ticket',
    priority: 'medium',
    isRead: true,
    createdAt: new Date(Date.now() - 1000 * 60 * 1440).toISOString(),
    activitySubtype: 'support_ticket'
  }
];

// Audit Logs Store
let auditLogs: AuditLogRecord[] = [
  {
    id: 'audit_101',
    userId: 'usr_0_owner',
    userName: 'Jimmy Mico (Owner)',
    action: 'OWNER_CONFIG_UPDATE',
    description: 'Platform owner updated official contact email to jimmymico45@gmail.com and phone to 0792426760.',
    ipAddress: '197.243.2.14',
    timestamp: new Date(Date.now() - 1000 * 60 * 300).toISOString(),
    status: 'SUCCESS'
  },
  {
    id: 'audit_102',
    userId: 'usr_0_owner',
    userName: 'Jimmy Mico (Owner)',
    action: 'USER_VERIFICATION_APPROVE',
    description: 'Approved official RAB verification for Dr. Emmanuel Mukamana (Expert Agronomist).',
    ipAddress: '197.243.2.14',
    timestamp: new Date(Date.now() - 1000 * 60 * 800).toISOString(),
    relatedRecordId: 'user_6',
    status: 'SUCCESS'
  },
  {
    id: 'audit_103',
    userId: 'system',
    userName: 'SYSTEM_SECURITY_FIREWALL',
    action: 'FAILED_LOGIN_LOCKOUT',
    description: '5 consecutive failed password attempts detected for admin login route.',
    ipAddress: '41.186.20.102',
    timestamp: new Date(Date.now() - 1000 * 60 * 1200).toISOString(),
    status: 'BLOCKED'
  }
];

// Service Methods for Owner Identity
export function getOwnerConfig(): OwnerConfig {
  return { ...currentOwnerConfig };
}

export function updateOwnerConfig(newConfig: Partial<OwnerConfig>): OwnerConfig {
  currentOwnerConfig = {
    ...currentOwnerConfig,
    ...newConfig,
    lastUpdated: new Date().toISOString()
  };

  recordAuditLog({
    userId: currentOwnerConfig.ownerUserId,
    userName: currentOwnerConfig.ownerName,
    action: 'OWNER_CONFIG_UPDATE',
    description: `Owner contact settings updated: Email=${currentOwnerConfig.ownerEmail}, Phone=${currentOwnerConfig.ownerPhone}`,
    ipAddress: '127.0.0.1',
    status: 'SUCCESS'
  });

  return getOwnerConfig();
}

// Notification Preferences Methods
export function getOwnerNotificationPreferences(): OwnerNotificationPreferences {
  return { ...currentOwnerPreferences };
}

export function updateOwnerNotificationPreferences(
  newPreferences: OwnerNotificationPreferences['preferences']
): OwnerNotificationPreferences {
  currentOwnerPreferences = {
    ...currentOwnerPreferences,
    preferences: newPreferences,
    updatedAt: new Date().toISOString()
  };

  recordAuditLog({
    userId: currentOwnerConfig.ownerUserId,
    userName: currentOwnerConfig.ownerName,
    action: 'NOTIFICATION_PREFERENCES_UPDATE',
    description: 'Owner notification channel rules updated for Dashboard, Email, and SMS.',
    ipAddress: '127.0.0.1',
    status: 'SUCCESS'
  });

  return getOwnerNotificationPreferences();
}

// Notification Querying & Filtering
export function getOwnerNotifications(filters?: {
  type?: NotificationType;
  isRead?: boolean;
  priority?: NotificationPriority;
  search?: string;
}): OwnerNotification[] {
  let list = [...ownerNotifications];

  if (filters?.type) {
    list = list.filter((n) => n.type === filters.type);
  }

  if (filters?.isRead !== undefined) {
    list = list.filter((n) => n.isRead === filters.isRead);
  }

  if (filters?.priority) {
    list = list.filter((n) => n.priority === filters.priority);
  }

  if (filters?.search) {
    const q = filters.search.toLowerCase();
    list = list.filter(
      (n) =>
        n.title.toLowerCase().includes(q) ||
        n.message.toLowerCase().includes(q) ||
        (n.relatedUserName && n.relatedUserName.toLowerCase().includes(q))
    );
  }

  // Sort newest first
  return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export function markNotificationAsRead(id: string): boolean {
  const item = ownerNotifications.find((n) => n.id === id);
  if (item) {
    item.isRead = true;
    return true;
  }
  return false;
}

export function markAllNotificationsAsRead(): number {
  let count = 0;
  ownerNotifications.forEach((n) => {
    if (!n.isRead) {
      n.isRead = true;
      count++;
    }
  });
  return count;
}

export function deleteNotification(id: string): boolean {
  const idx = ownerNotifications.findIndex((n) => n.id === id);
  if (idx !== -1) {
    ownerNotifications.splice(idx, 1);
    return true;
  }
  return false;
}

export function clearAllNotifications(): void {
  ownerNotifications = [];
}

// Audit Log Methods
export function getAuditLogs(): AuditLogRecord[] {
  return [...auditLogs].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

export function recordAuditLog(log: Omit<AuditLogRecord, 'id' | 'timestamp'>): AuditLogRecord {
  const newLog: AuditLogRecord = {
    ...log,
    id: `audit_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    timestamp: new Date().toISOString()
  };
  auditLogs.unshift(newLog);
  return newLog;
}

// Central Dispatcher to create and send Owner Notifications
export async function triggerOwnerNotification(params: {
  type: NotificationType;
  activitySubtype: string;
  title: string;
  message: string;
  priority?: NotificationPriority;
  relatedUserId?: string;
  relatedUserName?: string;
  relatedUserPhone?: string;
  relatedUserEmail?: string;
  relatedUserRole?: UserRole;
  relatedRecordId?: string;
  relatedRecordType?: OwnerNotification['relatedRecordType'];
}): Promise<{
  notification: OwnerNotification;
  dashboardDelivered: boolean;
  emailDelivered: boolean;
  smsDelivered: boolean;
}> {
  const priority = params.priority || 'medium';
  const newNotif: OwnerNotification = {
    id: `notif_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    recipientUserId: currentOwnerConfig.ownerUserId,
    type: params.type,
    activitySubtype: params.activitySubtype,
    title: params.title,
    message: params.message,
    priority,
    isRead: false,
    createdAt: new Date().toISOString(),
    relatedUserId: params.relatedUserId,
    relatedUserName: params.relatedUserName,
    relatedUserPhone: params.relatedUserPhone,
    relatedUserEmail: params.relatedUserEmail,
    relatedUserRole: params.relatedUserRole,
    relatedRecordId: params.relatedRecordId,
    relatedRecordType: params.relatedRecordType,
    emailDeliveryStatus: 'IN_APP_ONLY',
    channelsDelivered: ['in_app']
  };

  // Step 1: Check Notification Category & Preferences
  const pref = currentOwnerPreferences.preferences.find(
    (p) => p.eventCategory === params.activitySubtype
  ) || {
    eventCategory: params.activitySubtype,
    label: params.title,
    dashboardEnabled: true,
    emailEnabled: true,
    smsEnabled: priority === 'critical' || priority === 'high'
  };

  let dashboardDelivered = false;
  let emailDelivered = false;
  let smsDelivered = false;

  // In-App Dashboard Delivery
  if (pref.dashboardEnabled) {
    ownerNotifications.unshift(newNotif);
    dashboardDelivered = true;
  }

  // Step 2 & 3: Is email required? Check user's email preference
  if (pref.emailEnabled && currentOwnerConfig.ownerEmail) {
    try {
      // Step 4: Dispatch via SMTP Email endpoint
      const response = await fetch('/api/notifications/dispatch-event', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recipientEmail: currentOwnerConfig.ownerEmail,
          recipientName: currentOwnerConfig.ownerName,
          category: params.activitySubtype,
          title: params.title,
          message: params.message,
          priority: priority,
          userEmailPreferenceEnabled: true,
          details: {
            category: params.activitySubtype,
            relatedUser: params.relatedUserName || params.relatedUserId,
            relatedRecord: params.relatedRecordId,
            timestamp: new Date().toLocaleString()
          }
        })
      });

      if (response.ok) {
        const result = await response.json();
        emailDelivered = true;
        newNotif.emailDeliveryStatus = result.deliveryStatus || 'SENT';
        newNotif.emailSentAt = new Date().toISOString();
        newNotif.emailRecipient = currentOwnerConfig.ownerEmail;
        newNotif.emailMessageId = result.messageId || undefined;
      } else {
        newNotif.emailDeliveryStatus = 'FAILED';
      }
    } catch (e) {
      console.warn('Notification SMTP dispatch error:', e);
      newNotif.emailDeliveryStatus = 'FAILED';
    }
  } else {
    // In-app only based on preference
    newNotif.emailDeliveryStatus = 'IN_APP_ONLY';
  }

  // Attempt async SMS dispatch to owner if enabled
  if (pref.smsEnabled && currentOwnerConfig.ownerPhone) {
    try {
      smsDelivered = true;
      console.log(`[OWNER SMS NOTIFICATION] Sent to ${currentOwnerConfig.ownerPhone}: AGRIWISE ALERT: ${params.title}`);
    } catch (e) {
      console.error('Failed sending owner SMS notification:', e);
    }
  }

  // Update channels delivered
  const activeChannels: ('in_app' | 'email' | 'sms')[] = [];
  if (dashboardDelivered) activeChannels.push('in_app');
  if (emailDelivered) activeChannels.push('email');
  if (smsDelivered) activeChannels.push('sms');
  newNotif.channelsDelivered = activeChannels.length > 0 ? activeChannels : ['in_app'];

  // Step 5: Save/Sync to Firestore Notification Document
  try {
    await createNotificationDoc({
      userId: currentOwnerConfig.ownerUserId,
      title: params.title,
      message: params.message,
      type: params.type,
      category: params.activitySubtype,
      priority: priority,
      emailDeliveryStatus: newNotif.emailDeliveryStatus,
      deliveryChannels: newNotif.channelsDelivered,
      recipientEmail: currentOwnerConfig.ownerEmail,
      relatedRecordId: params.relatedRecordId,
      relatedRecordType: params.relatedRecordType
    });
  } catch (err) {
    console.warn('Firestore notification sync error:', err);
  }

  // Step 6: Record delivery status in Audit Log
  recordAuditLog({
    userId: params.relatedUserId || currentOwnerConfig.ownerUserId,
    userName: params.relatedUserName || currentOwnerConfig.ownerName,
    action: `NOTIFICATION_DISPATCH_${params.activitySubtype.toUpperCase()}`,
    description: `Dispatched [${params.title}] - Channels: ${newNotif.channelsDelivered.join(', ')} | Email Status: ${newNotif.emailDeliveryStatus}`,
    ipAddress: '127.0.0.1',
    relatedRecordId: params.relatedRecordId,
    status: emailDelivered || dashboardDelivered ? 'SUCCESS' : 'WARNING'
  });

  return {
    notification: newNotif,
    dashboardDelivered,
    emailDelivered,
    smsDelivered
  };
}
