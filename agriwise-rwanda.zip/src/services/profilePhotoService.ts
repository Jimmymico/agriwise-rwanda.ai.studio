import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { updateProfile } from 'firebase/auth';
import { storage, auth } from './firebase';
import { saveUserProfileDoc, getUserProfileDoc } from './firestoreService';
import { getCurrentSession, setAuthSession, getRegisteredUsers, saveUsersList } from './authService';
import { User } from '../types';

export const MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024; // 5MB
export const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];

export interface ImageValidationResult {
  valid: boolean;
  errorKey?: string;
  errorMessage?: string;
}

/**
 * Validate image file by type, size, and integrity
 */
export function validateImageFile(file: File | Blob): Promise<ImageValidationResult> {
  return new Promise((resolve) => {
    if (!file) {
      return resolve({ valid: false, errorKey: 'photoInvalidImage', errorMessage: 'Invalid or missing image file.' });
    }

    // 1. Check MIME type
    const fileType = file.type?.toLowerCase() || '';
    const isAllowedType = ALLOWED_IMAGE_TYPES.some((t) => fileType.includes(t.replace('image/', '')));
    if (!isAllowedType) {
      return resolve({
        valid: false,
        errorKey: 'photoInvalidFormat',
        errorMessage: 'Invalid format. Please select a JPG, PNG, or WEBP image.',
      });
    }

    // 2. Check File Size
    if (file.size > MAX_FILE_SIZE_BYTES) {
      return resolve({
        valid: false,
        errorKey: 'photoFileTooLarge',
        errorMessage: 'File is too large. Maximum allowed size is 5MB.',
      });
    }

    // 3. Check Image Decodability
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        resolve({ valid: true });
      };
      img.onerror = () => {
        resolve({
          valid: false,
          errorKey: 'photoInvalidImage',
          errorMessage: 'The selected file is corrupted or not a valid image.',
        });
      };
      img.src = e.target?.result as string;
    };
    reader.onerror = () => {
      resolve({
        valid: false,
        errorKey: 'photoInvalidImage',
        errorMessage: 'Unable to read the image file.',
      });
    };
    reader.readAsDataURL(file);
  });
}

/**
 * Resize and optimize image to max dimension for fast uploading and crisp display
 */
export function optimizeImage(fileOrBlob: Blob, maxDimension: number = 800, quality: number = 0.85): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          return resolve(fileOrBlob);
        }

        ctx.drawImage(img, 0, 0, width, height);
        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(blob);
            } else {
              resolve(fileOrBlob);
            }
          },
          'image/jpeg',
          quality
        );
      };
      img.onerror = () => reject(new Error('Image decoding failed during optimization.'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('FileReader error during optimization.'));
    reader.readAsDataURL(fileOrBlob);
  });
}

/**
 * Upload profile photo to Firebase Storage under path `profile-images/${userId}/profile.jpg`
 * and synchronize with Auth profile, Firestore user document, and local session
 */
export async function uploadUserProfilePhoto(
  userId: string,
  imageBlob: Blob | File,
  onProgress?: (progress: number) => void
): Promise<{ success: boolean; photoUrl?: string; error?: string; errorKey?: string }> {
  if (!userId) {
    return { success: false, error: 'User ID is required for profile photo upload.', errorKey: 'photoMissingUser' };
  }

  // Security check: User must be signed in with matching UID
  const currentAuthUser = auth.currentUser;
  if (currentAuthUser && currentAuthUser.uid !== userId) {
    return {
      success: false,
      error: 'Security authorization error: You can only modify your own profile photo.',
      errorKey: 'photoUnauthorized',
    };
  }

  try {
    // 1. Optimize image client-side to ensure lightweight storage and fast CDN delivery
    const optimizedBlob = await optimizeImage(imageBlob, 800, 0.88).catch(() => imageBlob);

    if (onProgress) onProgress(30);

    // 2. Upload to Firebase Storage
    const storagePath = `profile-images/${userId}/profile_${Date.now()}.jpg`;
    const storageRef = ref(storage, storagePath);

    let downloadUrl = '';
    try {
      const uploadResult = await uploadBytes(storageRef, optimizedBlob, {
        contentType: 'image/jpeg',
        customMetadata: {
          uploadedBy: userId,
          uploadedAt: new Date().toISOString(),
          platform: 'AGRIWISE_RWANDA',
        },
      });

      if (onProgress) onProgress(70);
      downloadUrl = await getDownloadURL(uploadResult.ref);
    } catch (storageErr: any) {
      console.warn('Firebase Storage upload warning, falling back to local object storage:', storageErr);
      // Fallback: Convert optimized blob to base64 data url if remote storage is unreachable
      downloadUrl = await new Promise<string>((res, rej) => {
        const r = new FileReader();
        r.onload = () => res(r.result as string);
        r.onerror = rej;
        r.readAsDataURL(optimizedBlob);
      });
    }

    if (onProgress) onProgress(85);

    // 3. Update Firebase Auth Display Profile
    if (auth.currentUser && downloadUrl.startsWith('http')) {
      await updateProfile(auth.currentUser, { photoURL: downloadUrl }).catch((err) => {
        console.warn('Auth photoURL update warning:', err);
      });
    }

    // 4. Update Firestore User Profile Doc
    try {
      const existingUser = await getUserProfileDoc(userId);
      if (existingUser) {
        existingUser.avatarUrl = downloadUrl;
        await saveUserProfileDoc(existingUser);
      }
    } catch (fsErr) {
      console.warn('Firestore profile photo save warning:', fsErr);
    }

    // 5. Update local user registry and active session
    try {
      const users = getRegisteredUsers();
      const idx = users.findIndex((u) => u.id === userId);
      if (idx !== -1) {
        users[idx].avatarUrl = downloadUrl;
        saveUsersList(users);
      }

      const session = getCurrentSession();
      if (session && session.id === userId) {
        session.avatarUrl = downloadUrl;
        setAuthSession(session);
      }
    } catch (localErr) {
      console.warn('Local session photo sync warning:', localErr);
    }

    if (onProgress) onProgress(100);

    return {
      success: true,
      photoUrl: downloadUrl,
    };
  } catch (err: any) {
    console.error('Profile photo upload error:', err);
    return {
      success: false,
      error: err?.message || 'Failed to upload profile photo.',
      errorKey: 'photoUploadFailed',
    };
  }
}

/**
 * Remove user profile photo and reset to default avatar
 */
export async function removeUserProfilePhoto(
  userId: string,
  existingPhotoUrl?: string
): Promise<{ success: boolean; error?: string }> {
  if (!userId) {
    return { success: false, error: 'User ID is required.' };
  }

  // Security check: User must be signed in with matching UID
  const currentAuthUser = auth.currentUser;
  if (currentAuthUser && currentAuthUser.uid !== userId) {
    return {
      success: false,
      error: 'Security authorization error: You can only modify your own profile photo.',
    };
  }

  try {
    // 1. Delete from Firebase Storage if URL belongs to firebasestorage
    if (existingPhotoUrl && existingPhotoUrl.includes('firebasestorage.googleapis.com')) {
      try {
        const photoRef = ref(storage, existingPhotoUrl);
        await deleteObject(photoRef);
      } catch (delErr) {
        console.warn('Storage delete warning (object may already be removed):', delErr);
      }
    }

    // 2. Clear Firebase Auth photoURL
    if (auth.currentUser) {
      await updateProfile(auth.currentUser, { photoURL: '' }).catch((err) => {
        console.warn('Auth photoURL clear warning:', err);
      });
    }

    // 3. Clear Firestore User Profile Doc avatarUrl
    try {
      const existingUser = await getUserProfileDoc(userId);
      if (existingUser) {
        existingUser.avatarUrl = '';
        await saveUserProfileDoc(existingUser);
      }
    } catch (fsErr) {
      console.warn('Firestore profile photo clear warning:', fsErr);
    }

    // 4. Clear local user registry and active session
    try {
      const users = getRegisteredUsers();
      const idx = users.findIndex((u) => u.id === userId);
      if (idx !== -1) {
        users[idx].avatarUrl = '';
        saveUsersList(users);
      }

      const session = getCurrentSession();
      if (session && session.id === userId) {
        session.avatarUrl = '';
        setAuthSession(session);
      }
    } catch (localErr) {
      console.warn('Local session photo clear warning:', localErr);
    }

    return { success: true };
  } catch (err: any) {
    console.error('Error removing profile photo:', err);
    return { success: false, error: err?.message || 'Failed to remove profile photo.' };
  }
}
