import { recordAuditLog } from './ownerNotificationService';
import { User } from '../types';

export interface SocialLinkConfig {
  id: 'twitter' | 'linkedin' | 'facebook' | 'youtube' | 'github';
  name: string;
  icon: string;
  url: string;
  enabled: boolean;
}

export interface FooterConfig {
  address: string;
  displayEmail: string;
  mailtoEmail: string;
  primaryPhone: string;
  secondaryPhone: string;
  openingHours: string;
  connectHeading: string;
  connectDescription: string;
  socialLinks: SocialLinkConfig[];
  privacyPolicyUrl: string;
  termsOfServiceUrl: string;
  updatedAt?: string;
  updatedBy?: string;
}

export const DEFAULT_FOOTER_CONFIG: FooterConfig = {
  address: 'Kigali Innovation City, KG 7 Ave, Kigali, Rwanda',
  displayEmail: 'info@agriwise.rw',
  mailtoEmail: 'info@agriwise.rw',
  primaryPhone: '+250 788 000 000',
  secondaryPhone: '+250 788 123 456',
  openingHours: 'Mon - Sat: 7:00 AM - 7:00 PM (CAT)',
  connectHeading: 'Connect & Support',
  connectDescription: 'Follow AGRIWISE on official social networks for real-time agronomic advisories.',
  socialLinks: [
    { id: 'twitter', name: 'X / Twitter', icon: '𝕏', url: 'https://twitter.com', enabled: true },
    { id: 'linkedin', name: 'LinkedIn', icon: 'in', url: 'https://linkedin.com', enabled: true },
    { id: 'facebook', name: 'Facebook', icon: 'fb', url: 'https://facebook.com', enabled: true },
    { id: 'youtube', name: 'YouTube', icon: 'yt', url: 'https://youtube.com', enabled: true },
    { id: 'github', name: 'GitHub', icon: 'gh', url: 'https://github.com', enabled: true },
  ],
  privacyPolicyUrl: '',
  termsOfServiceUrl: '',
};

const STORAGE_KEY = 'agriwise_footer_config';
const EVENT_NAME = 'agriwise_footer_config_updated';

let memoryConfig: FooterConfig = { ...DEFAULT_FOOTER_CONFIG };

function loadSavedConfig(): FooterConfig {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        ...DEFAULT_FOOTER_CONFIG,
        ...parsed,
        socialLinks: DEFAULT_FOOTER_CONFIG.socialLinks.map((defaultLink) => {
          const matched = parsed.socialLinks?.find((s: SocialLinkConfig) => s.id === defaultLink.id);
          return matched ? { ...defaultLink, ...matched } : defaultLink;
        }),
      };
    }
  } catch (e) {
    console.warn('Could not read footer config from storage, using defaults:', e);
  }
  return { ...DEFAULT_FOOTER_CONFIG };
}

// Initialize
memoryConfig = loadSavedConfig();

export function getFooterConfig(): FooterConfig {
  return { ...memoryConfig };
}

export function isValidUrl(url: string): boolean {
  if (!url || !url.trim()) return true;
  const trimmed = url.trim();
  try {
    const parsed = new URL(trimmed.startsWith('http://') || trimmed.startsWith('https://') ? trimmed : `https://${trimmed}`);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

export function updateFooterConfig(
  newConfig: Partial<FooterConfig>,
  adminUser?: User,
  affectedSection: string = 'All Sections'
): { success: boolean; config: FooterConfig; error?: string } {
  // Authorization Check: Must be admin or system_owner
  if (adminUser && adminUser.role !== 'admin' && adminUser.role !== 'system_owner') {
    return {
      success: false,
      config: getFooterConfig(),
      error: 'Unauthorized: Only system_owner and admin can modify footer configuration.',
    };
  }

  // URL Validation
  if (newConfig.socialLinks) {
    for (const link of newConfig.socialLinks) {
      if (link.enabled && link.url && !isValidUrl(link.url)) {
        return {
          success: false,
          config: getFooterConfig(),
          error: `Invalid URL format for ${link.name}: "${link.url}"`,
        };
      }
    }
  }

  if (newConfig.privacyPolicyUrl && !isValidUrl(newConfig.privacyPolicyUrl)) {
    return {
      success: false,
      config: getFooterConfig(),
      error: `Invalid URL format for Privacy Policy: "${newConfig.privacyPolicyUrl}"`,
    };
  }

  if (newConfig.termsOfServiceUrl && !isValidUrl(newConfig.termsOfServiceUrl)) {
    return {
      success: false,
      config: getFooterConfig(),
      error: `Invalid URL format for Terms of Service: "${newConfig.termsOfServiceUrl}"`,
    };
  }

  memoryConfig = {
    ...memoryConfig,
    ...newConfig,
    updatedAt: new Date().toISOString(),
    updatedBy: adminUser?.name || 'Administrator',
  };

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(memoryConfig));
  } catch (e) {
    console.warn('Failed to save footer config to localStorage:', e);
  }

  // Audit Logging
  recordAuditLog({
    userId: adminUser?.id || 'admin',
    userName: adminUser?.name || 'Administrator',
    action: 'FOOTER_CONFIGURATION_UPDATED',
    description: `Footer configuration updated by ${adminUser?.name || 'Admin'} (Section: ${affectedSection})`,
    ipAddress: '127.0.0.1',
    status: 'SUCCESS',
  });

  // Dispatch custom event for reactive UI update
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: memoryConfig }));
  }

  return {
    success: true,
    config: { ...memoryConfig },
  };
}

export function resetFooterConfigToDefault(adminUser?: User): { success: boolean; config: FooterConfig; error?: string } {
  // Authorization Check
  if (adminUser && adminUser.role !== 'admin' && adminUser.role !== 'system_owner') {
    return {
      success: false,
      config: getFooterConfig(),
      error: 'Unauthorized: Only system_owner and admin can reset footer configuration.',
    };
  }

  memoryConfig = {
    ...DEFAULT_FOOTER_CONFIG,
    updatedAt: new Date().toISOString(),
    updatedBy: adminUser?.name || 'Administrator',
  };

  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.warn('Failed to clear footer config from localStorage:', e);
  }

  // Audit Logging
  recordAuditLog({
    userId: adminUser?.id || 'admin',
    userName: adminUser?.name || 'Administrator',
    action: 'FOOTER_CONFIGURATION_UPDATED',
    description: `Footer configuration reset to factory defaults by ${adminUser?.name || 'Admin'}`,
    ipAddress: '127.0.0.1',
    status: 'SUCCESS',
  });

  // Dispatch event
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: memoryConfig }));
  }

  return {
    success: true,
    config: { ...memoryConfig },
  };
}

export function subscribeToFooterConfig(callback: (config: FooterConfig) => void): () => void {
  if (typeof window === 'undefined') {
    return () => {};
  }

  const handler = (event: Event) => {
    const customEvent = event as CustomEvent<FooterConfig>;
    if (customEvent.detail) {
      callback(customEvent.detail);
    } else {
      callback(getFooterConfig());
    }
  };

  window.addEventListener(EVENT_NAME, handler);
  return () => {
    window.removeEventListener(EVENT_NAME, handler);
  };
}
