import { recordAuditLog } from './ownerNotificationService';

export interface SystemContactInfo {
  officialName: string;
  officialEmail: string;
  officialPhone: string; // "0792426760"
  alternativePhone: string;
  whatsappNumber: string; // "0792426760"
  physicalAddress: string;
  websiteDomain: string;
  supportEmail: string;
  emergencyContactPhone: string;
  socialTwitter: string;
  socialLinkedin: string;
  socialFacebook: string;
}

export interface RegistrationSettings {
  enableRegistration: boolean;
  requireEmailVerification: boolean;
  requirePhoneVerification: boolean;
  requireAdminApproval: boolean;
  allowedRoles: string[];
}

export interface SecuritySettings {
  sessionTimeoutMinutes: number;
  loginAttemptLimit: number;
  passwordMinLength: number;
  twoFactorEnforced: boolean;
  accountLockoutDurationMinutes: number;
}

export interface GeneralSystemSettings {
  systemName: string;
  logoUrl: string;
  faviconUrl: string;
  description: string;
  timeZone: string;
  defaultLanguage: string;
  defaultCurrency: string; // "RWF"
}

export interface EmailNotificationConfig {
  systemEmailAddress: string;
  senderName: string;
  emailProvider: string;
  enabled: boolean;
  templates: {
    id: string;
    eventTrigger: string;
    subject: string;
    bodyTemplate: string;
    enabled: boolean;
  }[];
}

export interface SmsNotificationConfig {
  systemPhoneNumber: string; // "0792426760"
  smsProvider: string; // "MTN Rwanda WASP SMS Gateway"
  enabled: boolean;
  templates: {
    id: string;
    eventTrigger: string;
    messageTemplate: string;
    enabled: boolean;
  }[];
}

export interface SystemCategoryItem {
  id: string;
  type: 'product' | 'agricultural' | 'livestock' | 'crop' | 'service' | 'location' | 'unit';
  nameRw: string;
  nameEn: string;
  code: string;
  isActive: boolean;
  itemCount: number;
}

export interface SupportTicket {
  id: string;
  ticketNumber: string;
  userId: string;
  userName: string;
  userPhone: string;
  userEmail: string;
  userRole: string;
  subject: string;
  category: 'technical' | 'payment' | 'account' | 'marketplace' | 'verification' | 'other';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'new' | 'open' | 'in_progress' | 'resolved' | 'closed';
  message: string;
  adminReply?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SystemBackupRecord {
  id: string;
  backupName: string;
  fileSizeMb: number;
  status: 'completed' | 'in_progress' | 'failed';
  createdByName: string;
  createdAt: string;
  downloadUrl?: string;
}

// Initial System State
let currentContactInfo: SystemContactInfo = {
  officialName: 'AGRIWISE RWANDA Enterprise Platform',
  officialEmail: 'support@agriwise.rw',
  officialPhone: '0792426760',
  alternativePhone: '+250 788 111 222',
  whatsappNumber: '0792426760',
  physicalAddress: 'AGRIWISE Tower, KG 7 Ave, Kigali, Rwanda',
  websiteDomain: 'https://agriwise.rw',
  supportEmail: 'support@agriwise.rw',
  emergencyContactPhone: '0792426760',
  socialTwitter: 'https://x.com/agriwise_rw',
  socialLinkedin: 'https://linkedin.com/company/agriwise-rwanda',
  socialFacebook: 'https://facebook.com/agriwise.rw'
};

let currentGeneralSettings: GeneralSystemSettings = {
  systemName: 'AGRIWISE RWANDA',
  logoUrl: '/logo.png',
  faviconUrl: '/favicon.ico',
  description: 'Rwanda\'s Official Enterprise AI & USSD Agricultural Intelligence Platform.',
  timeZone: 'Africa/Kigali',
  defaultLanguage: 'rw',
  defaultCurrency: 'RWF'
};

let currentRegistrationSettings: RegistrationSettings = {
  enableRegistration: true,
  requireEmailVerification: false,
  requirePhoneVerification: true,
  requireAdminApproval: false,
  allowedRoles: ['farmer', 'livestock_farmer', 'cooperative', 'agrodealer', 'buyer', 'expert', 'transporter', 'bank']
};

let currentSecuritySettings: SecuritySettings = {
  sessionTimeoutMinutes: 30,
  loginAttemptLimit: 5,
  passwordMinLength: 8,
  twoFactorEnforced: true,
  accountLockoutDurationMinutes: 15
};

let isMaintenanceModeActive = false;
let maintenanceModeMessage = 'AGRIWISE RWANDA is currently undergoing scheduled maintenance. Please check back soon.';

let currentEmailConfig: EmailNotificationConfig = {
  systemEmailAddress: 'support@agriwise.rw',
  senderName: 'AGRIWISE RWANDA System',
  emailProvider: 'Resend / SMTP Enterprise Gateway',
  enabled: true,
  templates: [
    {
      id: 'tpl_em_01',
      eventTrigger: 'New User Registration',
      subject: 'Welcome to AGRIWISE RWANDA!',
      bodyTemplate: 'Dear {user_name}, welcome to AGRIWISE RWANDA. Your account has been initialized as {role}.',
      enabled: true
    },
    {
      id: 'tpl_em_02',
      eventTrigger: 'New Marketplace Order',
      subject: 'New Order Received #{order_id}',
      bodyTemplate: 'An order for {product_name} worth {amount_rwf} RWF has been placed.',
      enabled: true
    },
    {
      id: 'tpl_em_03',
      eventTrigger: 'Support Request Received',
      subject: 'Support Ticket Received #{ticket_id}',
      bodyTemplate: 'We have received your support request regarding {subject}. Our team will respond shortly.',
      enabled: true
    },
    {
      id: 'tpl_em_04',
      eventTrigger: 'Security Alert Triggered',
      subject: 'CRITICAL: Security Event Detected',
      bodyTemplate: 'Security alert: {details} from IP {ip_address}.',
      enabled: true
    }
  ]
};

let currentSmsConfig: SmsNotificationConfig = {
  systemPhoneNumber: '0792426760',
  smsProvider: 'MTN Rwanda WASP SMS API Gateway',
  enabled: true,
  templates: [
    {
      id: 'tpl_sms_01',
      eventTrigger: 'New Account Registration OTP',
      messageTemplate: 'Mwaramutse {user_name}, kode yanyu yo kwemeza akaunti muri AGRIWISE ni: {code}. Mwarakoze!',
      enabled: true
    },
    {
      id: 'tpl_sms_02',
      eventTrigger: 'Marketplace Escrow Order Alert',
      messageTemplate: 'AGRIWISE: Komande #{order_id} y\'ibiro {quantity} bya {product_name} yishyuwe. Frw {amount_rwf}.',
      enabled: true
    },
    {
      id: 'tpl_sms_03',
      eventTrigger: 'Weather & Pest Alert',
      messageTemplate: 'AGRIWISE ALERT: Mube maso mu karere ka {district}. Imvura nyinshi biteganijwe ko igwa kuri uyu wa gatanu.',
      enabled: true
    }
  ]
};

let initialCategories: SystemCategoryItem[] = [
  { id: 'cat_01', type: 'product', nameRw: 'Inyongeramusaruro & Imbuto', nameEn: 'Seeds & Fertilizers', code: 'INPUTS', isActive: true, itemCount: 142 },
  { id: 'cat_02', type: 'product', nameRw: 'Musaruro w\'Ibihingwa', nameEn: 'Crop Produce Harvest', code: 'PRODUCE', isActive: true, itemCount: 380 },
  { id: 'cat_03', type: 'product', nameRw: 'Inyamaswa & Amatungo', nameEn: 'Livestock & Animals', code: 'LIVESTOCK', isActive: true, itemCount: 95 },
  { id: 'cat_04', type: 'agricultural', nameRw: 'Ubuhinzi bw\'Ibirayi', nameEn: 'Irish Potato Farming', code: 'AGRI_POTATO', isActive: true, itemCount: 512 },
  { id: 'cat_05', type: 'crop', nameRw: 'Ibigori & Imboga', nameEn: 'Maize & Vegetables', code: 'CROP_MAIZE', isActive: true, itemCount: 680 },
  { id: 'cat_06', type: 'livestock', nameRw: 'Inka z\'Inyange & Intama', nameEn: 'Cattle & Dairy Livestock', code: 'LS_CATTLE', isActive: true, itemCount: 210 },
  { id: 'cat_07', type: 'service', nameRw: 'Bisi & Transport y\'Musaruro', nameEn: 'Produce Transportation', code: 'LOGISTICS', isActive: true, itemCount: 64 },
  { id: 'cat_08', type: 'unit', nameRw: 'Kilogramo (Kg)', nameEn: 'Kilogram (Kg)', code: 'UNIT_KG', isActive: true, itemCount: 1200 },
  { id: 'cat_09', type: 'unit', nameRw: 'Tani (Tons)', nameEn: 'Metric Tons', code: 'UNIT_TONS', isActive: true, itemCount: 450 },
  { id: 'cat_10', type: 'unit', nameRw: 'Litiro (Liters)', nameEn: 'Liters (Milk/Oil)', code: 'UNIT_LITERS', isActive: true, itemCount: 310 }
];

let initialSupportTickets: SupportTicket[] = [
  {
    id: 's_001',
    ticketNumber: 'TCK-2026-8801',
    userId: 'USR-001',
    userName: 'Jean-Paul Nsengiyumva',
    userPhone: '+250 788 123 456',
    userEmail: 'jean.paul@agriwise.rw',
    userRole: 'farmer',
    subject: 'MoMo Escrow Payout Delay for Potato Harvest',
    category: 'payment',
    priority: 'high',
    status: 'in_progress',
    message: 'I sold 2.5 Tons of Irish Potatoes on the marketplace 2 days ago. The buyer confirmed receipt, but MoMo release is pending.',
    adminReply: 'Checked escrow transaction TX-9912. Payout batch will settle at 14:00 today.',
    createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 30).toISOString()
  },
  {
    id: 's_002',
    ticketNumber: 'TCK-2026-8802',
    userId: 'USR-002',
    userName: 'Claire Uwera (Musanze Potato Coop)',
    userPhone: '+250 788 654 321',
    userEmail: 'claire@musanzecoop.rw',
    userRole: 'cooperative',
    subject: 'Request for Bulk Member Export CSV',
    category: 'technical',
    priority: 'medium',
    status: 'new',
    message: 'We need to export 450 cooperative member profiles with GPS coordinates for RAB Subsidy registration.',
    createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 45).toISOString()
  },
  {
    id: 's_003',
    ticketNumber: 'TCK-2026-8803',
    userId: 'USR-004',
    userName: 'Eric Kwizera Agrovet',
    userPhone: '+250 788 444 333',
    userEmail: 'kwizera.inputs@gmail.com',
    userRole: 'agrodealer',
    subject: 'Verification Badge Status Inquiry',
    category: 'verification',
    priority: 'medium',
    status: 'resolved',
    message: 'Uploaded RAB agro-dealer license number RAB-AGR-2026-901. Please activate verified badge.',
    adminReply: 'RAB license confirmed. Agro-dealer account verified.',
    createdAt: new Date(Date.now() - 1000 * 60 * 1200).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 600).toISOString()
  }
];

let initialBackups: SystemBackupRecord[] = [
  {
    id: 'bkp_101',
    backupName: 'AGRIWISE_FULL_DB_SNAP_20260810.sql.gz',
    fileSizeMb: 142.8,
    status: 'completed',
    createdByName: 'System Owner (Jimmy Mico)',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
    downloadUrl: '#'
  },
  {
    id: 'bkp_102',
    backupName: 'AGRIWISE_WEEKLY_ARCHIVE_20260803.sql.gz',
    fileSizeMb: 138.4,
    status: 'completed',
    createdByName: 'System Owner (Jimmy Mico)',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 8).toISOString(),
    downloadUrl: '#'
  }
];

// Service Functions
export function getSystemContact(): SystemContactInfo {
  return { ...currentContactInfo };
}

export function updateSystemContact(data: Partial<SystemContactInfo>): SystemContactInfo {
  currentContactInfo = { ...currentContactInfo, ...data };
  recordAuditLog({
    userId: 'owner',
    userName: 'System Owner',
    action: 'SYSTEM_CONTACT_UPDATE',
    description: `System contact updated: Email=${currentContactInfo.officialEmail}, Phone=${currentContactInfo.officialPhone}`,
    ipAddress: '127.0.0.1',
    status: 'SUCCESS'
  });
  return getSystemContact();
}

export function getGeneralSettings(): GeneralSystemSettings {
  return { ...currentGeneralSettings };
}

export function updateGeneralSettings(data: Partial<GeneralSystemSettings>): GeneralSystemSettings {
  currentGeneralSettings = { ...currentGeneralSettings, ...data };
  recordAuditLog({
    userId: 'owner',
    userName: 'System Owner',
    action: 'GENERAL_SETTINGS_UPDATE',
    description: `System name updated to ${currentGeneralSettings.systemName}`,
    ipAddress: '127.0.0.1',
    status: 'SUCCESS'
  });
  return getGeneralSettings();
}

export function getRegistrationSettings(): RegistrationSettings {
  return { ...currentRegistrationSettings };
}

export function updateRegistrationSettings(data: Partial<RegistrationSettings>): RegistrationSettings {
  currentRegistrationSettings = { ...currentRegistrationSettings, ...data };
  recordAuditLog({
    userId: 'owner',
    userName: 'System Owner',
    action: 'REGISTRATION_SETTINGS_UPDATE',
    description: 'Updated user registration policies and required approvals.',
    ipAddress: '127.0.0.1',
    status: 'SUCCESS'
  });
  return getRegistrationSettings();
}

export function getSecuritySettings(): SecuritySettings {
  return { ...currentSecuritySettings };
}

export function updateSecuritySettings(data: Partial<SecuritySettings>): SecuritySettings {
  currentSecuritySettings = { ...currentSecuritySettings, ...data };
  recordAuditLog({
    userId: 'owner',
    userName: 'System Owner',
    action: 'SECURITY_SETTINGS_UPDATE',
    description: `Session timeout set to ${currentSecuritySettings.sessionTimeoutMinutes} min, 2FA=${currentSecuritySettings.twoFactorEnforced}`,
    ipAddress: '127.0.0.1',
    status: 'SUCCESS'
  });
  return getSecuritySettings();
}

export function getMaintenanceMode(): { enabled: boolean; message: string } {
  return { enabled: isMaintenanceModeActive, message: maintenanceModeMessage };
}

export function setMaintenanceMode(enabled: boolean, message?: string): { enabled: boolean; message: string } {
  isMaintenanceModeActive = enabled;
  if (message) maintenanceModeMessage = message;

  recordAuditLog({
    userId: 'owner',
    userName: 'System Owner',
    action: 'MAINTENANCE_MODE_TOGGLE',
    description: `Maintenance mode ${enabled ? 'ENABLED' : 'DISABLED'}. Message: "${maintenanceModeMessage}"`,
    ipAddress: '127.0.0.1',
    status: 'SUCCESS'
  });

  return getMaintenanceMode();
}

export function getEmailConfig(): EmailNotificationConfig {
  return { ...currentEmailConfig };
}

export function updateEmailConfig(data: Partial<EmailNotificationConfig>): EmailNotificationConfig {
  currentEmailConfig = { ...currentEmailConfig, ...data };
  recordAuditLog({
    userId: 'owner',
    userName: 'System Owner',
    action: 'EMAIL_CONFIG_UPDATE',
    description: `Email configuration updated: ${currentEmailConfig.systemEmailAddress}`,
    ipAddress: '127.0.0.1',
    status: 'SUCCESS'
  });
  return getEmailConfig();
}

export function getSmsConfig(): SmsNotificationConfig {
  return { ...currentSmsConfig };
}

export function updateSmsConfig(data: Partial<SmsNotificationConfig>): SmsNotificationConfig {
  currentSmsConfig = { ...currentSmsConfig, ...data };
  recordAuditLog({
    userId: 'owner',
    userName: 'System Owner',
    action: 'SMS_CONFIG_UPDATE',
    description: `SMS WASP configuration updated: ${currentSmsConfig.systemPhoneNumber}`,
    ipAddress: '127.0.0.1',
    status: 'SUCCESS'
  });
  return getSmsConfig();
}

export function getSystemCategories(): SystemCategoryItem[] {
  return [...initialCategories];
}

export function addSystemCategory(category: Omit<SystemCategoryItem, 'id'>): SystemCategoryItem {
  const newItem: SystemCategoryItem = {
    id: `cat_${Date.now()}`,
    ...category
  };
  initialCategories.unshift(newItem);

  recordAuditLog({
    userId: 'owner',
    userName: 'System Owner',
    action: 'CATEGORY_CREATE',
    description: `Created new system category [${category.type}]: ${category.nameEn} (${category.nameRw})`,
    ipAddress: '127.0.0.1',
    status: 'SUCCESS'
  });

  return newItem;
}

export function updateSystemCategory(id: string, data: Partial<SystemCategoryItem>): SystemCategoryItem[] {
  initialCategories = initialCategories.map((c) => (c.id === id ? { ...c, ...data } : c));
  return getSystemCategories();
}

export function deleteSystemCategory(id: string): SystemCategoryItem[] {
  initialCategories = initialCategories.filter((c) => c.id !== id);
  return getSystemCategories();
}

export function getSupportTickets(): SupportTicket[] {
  return [...initialSupportTickets];
}

export function updateSupportTicket(id: string, status: SupportTicket['status'], adminReply?: string): SupportTicket[] {
  initialSupportTickets = initialSupportTickets.map((t) => {
    if (t.id === id) {
      return {
        ...t,
        status,
        adminReply: adminReply !== undefined ? adminReply : t.adminReply,
        updatedAt: new Date().toISOString()
      };
    }
    return t;
  });

  recordAuditLog({
    userId: 'owner',
    userName: 'System Owner',
    action: 'SUPPORT_TICKET_UPDATE',
    description: `Updated support ticket ${id} status to ${status.toUpperCase()}`,
    ipAddress: '127.0.0.1',
    status: 'SUCCESS'
  });

  return getSupportTickets();
}

export function getBackups(): SystemBackupRecord[] {
  return [...initialBackups];
}

export function triggerSystemBackup(): SystemBackupRecord {
  const newBackup: SystemBackupRecord = {
    id: `bkp_${Date.now().toString().slice(-4)}`,
    backupName: `AGRIWISE_FULL_DB_SNAP_${new Date().toISOString().slice(0, 10).replace(/-/g, '')}.sql.gz`,
    fileSizeMb: Number((140 + Math.random() * 10).toFixed(1)),
    status: 'completed',
    createdByName: 'System Owner (Jimmy Mico)',
    createdAt: new Date().toISOString(),
    downloadUrl: '#'
  };

  initialBackups.unshift(newBackup);

  recordAuditLog({
    userId: 'owner',
    userName: 'System Owner',
    action: 'DATABASE_BACKUP_CREATE',
    description: `Manual database backup created: ${newBackup.backupName} (${newBackup.fileSizeMb} MB)`,
    ipAddress: '127.0.0.1',
    status: 'SUCCESS'
  });

  return newBackup;
}
