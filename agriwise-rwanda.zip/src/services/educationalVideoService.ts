import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  getDocs,
  query,
  where,
  orderBy
} from 'firebase/firestore';
import {
  ref,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject
} from 'firebase/storage';
import { db, storage } from './firebase';
import { EducationalVideo, EducationalVideoFilterOptions, EducationalVideoStatus } from '../types';
import { INITIAL_EDUCATIONAL_VIDEOS } from '../data/mockEducationalVideos';
import { recordAuditLog } from './ownerNotificationService';

const COLLECTION_NAME = 'educationalVideos';
const LOCAL_STORAGE_KEY = 'agriwise_educational_videos_cache';

// In-memory / local storage cache for offline / demo fallback
function getLocalVideosCache(): EducationalVideo[] {
  try {
    const cached = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (cached) {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Could not read educational videos from local cache', err);
  }
  return INITIAL_EDUCATIONAL_VIDEOS;
}

function saveLocalVideosCache(videos: EducationalVideo[]): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(videos));
  } catch (err) {
    console.warn('Could not save educational videos to local cache', err);
  }
}

/**
 * Upload a Video file to Firebase Storage
 */
export async function uploadVideoFileToStorage(
  videoId: string,
  file: File,
  onProgress?: (progress: number) => void
): Promise<{ downloadUrl: string; storagePath: string }> {
  const extension = file.name.split('.').pop() || 'mp4';
  const storagePath = `educational-videos/${videoId}/video.${extension}`;
  const storageRef = ref(storage, storagePath);

  return new Promise((resolve, reject) => {
    const uploadTask = uploadBytesResumable(storageRef, file, {
      contentType: file.type || 'video/mp4'
    });

    uploadTask.on(
      'state_changed',
      (snapshot) => {
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        if (onProgress) {
          onProgress(Math.round(progress));
        }
      },
      (error) => {
        console.error('Video file upload error:', error);
        // Fallback for demo environments or when storage is in mock mode:
        // Create an Object URL or data placeholder if network fails
        const objectUrl = URL.createObjectURL(file);
        resolve({ downloadUrl: objectUrl, storagePath });
      },
      async () => {
        try {
          const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);
          resolve({ downloadUrl, storagePath });
        } catch (err) {
          console.warn('Error obtaining download URL, using object URL fallback', err);
          const objectUrl = URL.createObjectURL(file);
          resolve({ downloadUrl: objectUrl, storagePath });
        }
      }
    );
  });
}

/**
 * Upload a Thumbnail file to Firebase Storage
 */
export async function uploadThumbnailFileToStorage(
  videoId: string,
  file: File,
  onProgress?: (progress: number) => void
): Promise<{ downloadUrl: string; storagePath: string }> {
  const extension = file.name.split('.').pop() || 'jpg';
  const storagePath = `educational-videos/${videoId}/thumbnail.${extension}`;
  const storageRef = ref(storage, storagePath);

  return new Promise((resolve, reject) => {
    const uploadTask = uploadBytesResumable(storageRef, file, {
      contentType: file.type || 'image/jpeg'
    });

    uploadTask.on(
      'state_changed',
      (snapshot) => {
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        if (onProgress) {
          onProgress(Math.round(progress));
        }
      },
      (error) => {
        console.error('Thumbnail upload error:', error);
        const reader = new FileReader();
        reader.onload = (e) => {
          resolve({ downloadUrl: (e.target?.result as string) || '', storagePath });
        };
        reader.onerror = () => {
          resolve({ downloadUrl: 'https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=800&auto=format&fit=crop&q=80', storagePath });
        };
        reader.readAsDataURL(file);
      },
      async () => {
        try {
          const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);
          resolve({ downloadUrl, storagePath });
        } catch (err) {
          console.warn('Error obtaining thumbnail download URL', err);
          const reader = new FileReader();
          reader.onload = (e) => {
            resolve({ downloadUrl: (e.target?.result as string) || '', storagePath });
          };
          reader.readAsDataURL(file);
        }
      }
    );
  });
}

/**
 * Fetch all educational videos (For Admin Dashboard)
 */
export async function fetchAllEducationalVideos(): Promise<EducationalVideo[]> {
  try {
    const videosRef = collection(db, COLLECTION_NAME);
    const snap = await getDocs(videosRef);
    if (!snap.empty) {
      const liveVideos: EducationalVideo[] = [];
      snap.forEach((docSnap) => {
        liveVideos.push(docSnap.data() as EducationalVideo);
      });
      // Sort newest first
      liveVideos.sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime());
      saveLocalVideosCache(liveVideos);
      return liveVideos;
    }
  } catch (err) {
    console.warn('Firestore fetch all videos failed, falling back to local cache:', err);
  }
  return getLocalVideosCache();
}

/**
 * Fetch published educational videos (For Farmer Learning Center)
 */
export async function fetchPublishedEducationalVideos(): Promise<EducationalVideo[]> {
  try {
    const videosRef = collection(db, COLLECTION_NAME);
    const q = query(videosRef, where('status', '==', 'PUBLISHED'));
    const snap = await getDocs(q);
    if (!snap.empty) {
      const liveVideos: EducationalVideo[] = [];
      snap.forEach((docSnap) => {
        liveVideos.push(docSnap.data() as EducationalVideo);
      });
      liveVideos.sort((a, b) => new Date(b.publishedAt || b.uploadedAt).getTime() - new Date(a.publishedAt || a.uploadedAt).getTime());
      return liveVideos;
    }
  } catch (err) {
    console.warn('Firestore fetch published videos failed, falling back to cache:', err);
  }
  const cached = getLocalVideosCache();
  return cached.filter((v) => v.status === 'PUBLISHED');
}

/**
 * Create a new educational video document
 */
export async function createEducationalVideo(
  videoData: Omit<EducationalVideo, 'id' | 'uploadedAt' | 'updatedAt' | 'viewsCount'> & { id?: string },
  adminUser: { id: string; name: string; role: string; email?: string }
): Promise<EducationalVideo> {
  const videoId = videoData.id || `vid-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();

  const newVideo: EducationalVideo = {
    ...videoData,
    id: videoId,
    status: videoData.status || 'DRAFT',
    uploadedBy: {
      id: adminUser.id,
      name: adminUser.name,
      role: adminUser.role,
      email: adminUser.email
    },
    uploadedAt: now,
    updatedAt: now,
    publishedAt: videoData.status === 'PUBLISHED' ? now : null,
    viewsCount: 0
  };

  // 1. Try Firestore save
  try {
    const docRef = doc(db, COLLECTION_NAME, videoId);
    await setDoc(docRef, newVideo);
  } catch (err) {
    console.warn('Firestore save video error:', err);
  }

  // 2. Update local cache
  const cached = getLocalVideosCache();
  const updated = [newVideo, ...cached.filter((v) => v.id !== videoId)];
  saveLocalVideosCache(updated);

  // 3. Record Audit Log
  recordAuditLog({
    userId: adminUser.id,
    userName: adminUser.name,
    action: 'EDUCATIONAL_VIDEO_UPLOAD',
    description: `Uploaded educational video [${newVideo.title}] in category [${newVideo.category}] as ${newVideo.status}`,
    ipAddress: '127.0.0.1',
    relatedRecordId: videoId,
    status: 'SUCCESS'
  });

  return newVideo;
}

/**
 * Update video metadata
 */
export async function updateEducationalVideo(
  videoId: string,
  updates: Partial<EducationalVideo>,
  adminUser: { id: string; name: string; role: string }
): Promise<EducationalVideo> {
  const now = new Date().toISOString();
  const payload = {
    ...updates,
    updatedAt: now
  };

  // If status changed to PUBLISHED and publishedAt is empty, set it
  if (updates.status === 'PUBLISHED' && !updates.publishedAt) {
    payload.publishedAt = now;
  }

  // 1. Firestore update
  try {
    const docRef = doc(db, COLLECTION_NAME, videoId);
    await updateDoc(docRef, payload);
  } catch (err) {
    console.warn('Firestore update video error:', err);
  }

  // 2. Update local cache
  const cached = getLocalVideosCache();
  let updatedVideo: EducationalVideo | null = null;
  const updated = cached.map((v) => {
    if (v.id === videoId) {
      updatedVideo = { ...v, ...payload };
      return updatedVideo;
    }
    return v;
  });
  saveLocalVideosCache(updated);

  // 3. Record Audit Log
  recordAuditLog({
    userId: adminUser.id,
    userName: adminUser.name,
    action: 'EDUCATIONAL_VIDEO_EDIT',
    description: `Edited educational video [${videoId}] metadata: ${Object.keys(updates).join(', ')}`,
    ipAddress: '127.0.0.1',
    relatedRecordId: videoId,
    status: 'SUCCESS'
  });

  return updatedVideo || ({ ...updates, id: videoId } as EducationalVideo);
}

/**
 * Toggle Publish / Unpublish status
 */
export async function togglePublishEducationalVideo(
  videoId: string,
  newStatus: EducationalVideoStatus,
  adminUser: { id: string; name: string; role: string }
): Promise<EducationalVideo> {
  return updateEducationalVideoStatus(videoId, newStatus, adminUser);
}

/**
 * Update video status across review lifecycle (DRAFT -> PENDING_REVIEW -> APPROVED -> PUBLISHED / REJECTED)
 */
export async function updateEducationalVideoStatus(
  videoId: string,
  newStatus: EducationalVideoStatus,
  adminUser: { id: string; name: string; role: string }
): Promise<EducationalVideo> {
  const now = new Date().toISOString();
  const updates: Partial<EducationalVideo> = {
    status: newStatus,
    updatedAt: now,
    publishedAt: newStatus === 'PUBLISHED' ? now : null
  };

  // 1. Firestore update
  try {
    const docRef = doc(db, COLLECTION_NAME, videoId);
    await updateDoc(docRef, updates);
  } catch (err) {
    console.warn('Firestore status update error:', err);
  }

  // 2. Update local cache
  const cached = getLocalVideosCache();
  let resultVideo: EducationalVideo | null = null;
  const updated = cached.map((v) => {
    if (v.id === videoId) {
      resultVideo = { ...v, ...updates };
      return resultVideo;
    }
    return v;
  });
  saveLocalVideosCache(updated);

  // 3. Record Audit Log
  recordAuditLog({
    userId: adminUser.id,
    userName: adminUser.name,
    action: `EDUCATIONAL_VIDEO_STATUS_${newStatus}`,
    description: `Updated status of educational video [${videoId}] to ${newStatus}`,
    ipAddress: '127.0.0.1',
    relatedRecordId: videoId,
    status: 'SUCCESS'
  });

  return resultVideo || ({ id: videoId, status: newStatus } as EducationalVideo);
}

/**
 * Delete educational video (Firestore doc + Storage files)
 */
export async function deleteEducationalVideo(
  video: EducationalVideo,
  adminUser: { id: string; name: string; role: string }
): Promise<{ success: boolean; message?: string }> {
  const videoId = video.id;

  // 1. Attempt to delete storage files
  if (video.videoStoragePath) {
    try {
      const videoStorageRef = ref(storage, video.videoStoragePath);
      await deleteObject(videoStorageRef);
    } catch (err) {
      console.warn('Video file storage delete warning (may not exist):', err);
    }
  }

  if (video.thumbnailStoragePath) {
    try {
      const thumbStorageRef = ref(storage, video.thumbnailStoragePath);
      await deleteObject(thumbStorageRef);
    } catch (err) {
      console.warn('Thumbnail storage delete warning (may not exist):', err);
    }
  }

  // 2. Delete Firestore Document
  try {
    const docRef = doc(db, COLLECTION_NAME, videoId);
    await deleteDoc(docRef);
  } catch (err) {
    console.warn('Firestore doc delete error:', err);
  }

  // 3. Update local cache
  const cached = getLocalVideosCache();
  const remaining = cached.filter((v) => v.id !== videoId);
  saveLocalVideosCache(remaining);

  // 4. Record Audit Log
  recordAuditLog({
    userId: adminUser.id,
    userName: adminUser.name,
    action: 'EDUCATIONAL_VIDEO_DELETE',
    description: `Permanently deleted educational video [${video.title}] (ID: ${videoId}) and purged storage assets`,
    ipAddress: '127.0.0.1',
    relatedRecordId: videoId,
    status: 'SUCCESS'
  });

  return { success: true };
}

/**
 * Increment video views count
 */
export async function recordVideoView(videoId: string): Promise<void> {
  try {
    const cached = getLocalVideosCache();
    const updated = cached.map((v) => {
      if (v.id === videoId) {
        return { ...v, viewsCount: (v.viewsCount || 0) + 1 };
      }
      return v;
    });
    saveLocalVideosCache(updated);

    const docRef = doc(db, COLLECTION_NAME, videoId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      const curr = snap.data() as EducationalVideo;
      await updateDoc(docRef, { viewsCount: (curr.viewsCount || 0) + 1 });
    }
  } catch (err) {
    console.warn('Error recording video view:', err);
  }
}

export const incrementEducationalVideoViews = recordVideoView;

/**
 * Filter and Search helper
 */
export function filterEducationalVideos(
  videos: EducationalVideo[],
  filters: EducationalVideoFilterOptions
): EducationalVideo[] {
  return videos.filter((video) => {
    // Status filter
    if (filters.status && filters.status !== 'ALL') {
      if (video.status !== filters.status) return false;
    }

    // Category filter
    if (filters.category && filters.category !== 'ALL') {
      if (video.category !== filters.category) return false;
    }

    // Topic filter
    if (filters.topic && filters.topic !== 'ALL') {
      if (video.topic !== filters.topic) return false;
    }

    // Language filter
    if (filters.language && filters.language !== 'ALL') {
      if (video.language !== filters.language && video.language !== 'all') return false;
    }

    // Target Audience filter
    if (filters.targetAudience && filters.targetAudience !== 'ALL') {
      if (video.targetAudience !== filters.targetAudience && video.targetAudience !== 'All Stakeholders (Bose Hamwe)') {
        return false;
      }
    }

    // District filter
    if (filters.district && filters.district !== 'ALL') {
      if (video.district && video.district !== 'All Rwanda (Igihugu Cyose)' && video.district !== filters.district) {
        return false;
      }
    }

    // Crop filter
    if (filters.crop && filters.crop !== 'ALL') {
      if (video.crop && video.crop !== filters.crop) return false;
    }

    // Search query (title, description, topic, crop, district)
    if (filters.searchQuery && filters.searchQuery.trim() !== '') {
      const q = filters.searchQuery.toLowerCase().trim();
      const matchTitle = video.title.toLowerCase().includes(q);
      const matchDesc = video.description.toLowerCase().includes(q);
      const matchTopic = video.topic.toLowerCase().includes(q);
      const matchCategory = video.category.toLowerCase().includes(q);
      const matchCrop = video.crop ? video.crop.toLowerCase().includes(q) : false;
      const matchLivestock = video.livestock ? video.livestock.toLowerCase().includes(q) : false;
      const matchDistrict = video.district ? video.district.toLowerCase().includes(q) : false;

      if (!matchTitle && !matchDesc && !matchTopic && !matchCategory && !matchCrop && !matchLivestock && !matchDistrict) {
        return false;
      }
    }

    return true;
  });
}
