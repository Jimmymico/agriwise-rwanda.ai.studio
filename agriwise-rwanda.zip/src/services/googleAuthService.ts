import { signInWithPopup, GoogleAuthProvider, User as FirebaseUser } from 'firebase/auth';
import { auth } from './firebase';
import { registerNewUser, authenticateUser } from './authService';
import { User } from '../types';

const provider = new GoogleAuthProvider();

provider.addScope('https://www.googleapis.com/auth/userinfo.email');
provider.addScope('https://www.googleapis.com/auth/userinfo.profile');

let cachedAccessToken: string | null = null;

export const signInWithGoogle = async (): Promise<{ user: User; accessToken: string }> => {
  try {
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const accessToken = credential?.accessToken || '';
    if (accessToken) {
      cachedAccessToken = accessToken;
    }

    const fbUser = result.user;
    const email = fbUser.email || '';
    const fullName = fbUser.displayName || 'Google User';

    // Try authenticating existing user or auto-registering
    let authRes = authenticateUser(email, 'google-oauth-sso');
    if (!authRes.success || !authRes.user) {
      // Register new user via Google
      const regRes = registerNewUser({
        fullName,
        phone: fbUser.phoneNumber || '+250780000000',
        email,
        role: 'farmer',
        district: 'Musanze',
        sector: 'Kinigi',
        password: 'GoogleSSOPassword123!',
        language: 'rw',
      });

      if (regRes.user) {
        return { user: regRes.user, accessToken };
      }
    }

    if (authRes.user) {
      return { user: authRes.user, accessToken };
    }

    // Fallback constructed user
    const fallbackUser: User = {
      id: fbUser.uid,
      name: fullName,
      phone: fbUser.phoneNumber || '+250780000000',
      email: email,
      role: 'farmer',
      district: 'Musanze',
      sector: 'Kinigi',
      language: 'rw',
      creditScore: 700,
      verified: true
    };

    return { user: fallbackUser, accessToken };
  } catch (error: any) {
    console.error('Google Sign-In Error:', error);
    throw error;
  }
};

export const getGoogleAccessToken = (): string | null => {
  return cachedAccessToken;
};
