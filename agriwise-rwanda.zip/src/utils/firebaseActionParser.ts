/**
 * Firebase Action Code URL Parser for AGRIWISE RWANDA
 * Robust parser for Firebase Authentication action links (password reset, email verification, etc.)
 */

export interface FirebaseActionParams {
  firebaseMode: 'resetPassword' | 'verifyEmail' | 'recoverEmail' | 'signIn' | null;
  oobCode: string | null;
  apiKey: string | null;
  continueUrl: string | null;
  lang: string | null;
  isPasswordReset: boolean;
  isEmailVerification: boolean;
  isActionRoute: boolean;
}

export function parseFirebaseActionParams(): FirebaseActionParams {
  let mode: string | null = null;
  let oobCode: string | null = null;
  let apiKey: string | null = null;
  let continueUrl: string | null = null;
  let lang: string | null = null;
  let isActionRoute = false;

  try {
    if (typeof window !== 'undefined' && window.location) {
      const pathname = window.location.pathname.toLowerCase();
      const href = window.location.href;

      isActionRoute =
        pathname.startsWith('/auth/action') ||
        pathname.startsWith('/__/auth/action') ||
        pathname.startsWith('/firebase-action') ||
        pathname.startsWith('/reset-password') ||
        pathname.startsWith('/verify-email') ||
        pathname.startsWith('/forgot-password');

      // 1. Search in window.location.search (?mode=...&oobCode=...)
      if (window.location.search) {
        const searchParams = new URLSearchParams(window.location.search);
        if (!mode) mode = searchParams.get('mode');
        if (!oobCode) oobCode = searchParams.get('oobCode');
        if (!apiKey) apiKey = searchParams.get('apiKey');
        if (!continueUrl) continueUrl = searchParams.get('continueUrl');
        if (!lang) lang = searchParams.get('lang');
      }

      // 2. Search in window.location.hash (#/?mode=... or #mode=... or #/auth/action?...)
      if (window.location.hash) {
        let hashString = window.location.hash;
        if (hashString.includes('?')) {
          hashString = hashString.substring(hashString.indexOf('?'));
          const hashParams = new URLSearchParams(hashString);
          if (!mode) mode = hashParams.get('mode');
          if (!oobCode) oobCode = hashParams.get('oobCode');
          if (!apiKey) apiKey = hashParams.get('apiKey');
          if (!continueUrl) continueUrl = hashParams.get('continueUrl');
          if (!lang) lang = hashParams.get('lang');
        } else if (hashString.includes('=')) {
          // Format like #mode=resetPassword&oobCode=...
          const rawHash = hashString.startsWith('#') ? hashString.substring(1) : hashString;
          const hashParams = new URLSearchParams(rawHash);
          if (!mode) mode = hashParams.get('mode');
          if (!oobCode) oobCode = hashParams.get('oobCode');
          if (!apiKey) apiKey = hashParams.get('apiKey');
          if (!continueUrl) continueUrl = hashParams.get('continueUrl');
          if (!lang) lang = hashParams.get('lang');
        }
      }

      // 3. Fallback: regex search on window.location.href in case query string was nested or mangled
      if (!mode || !oobCode) {
        try {
          const modeMatch = href.match(/[?&#]mode=([^&#]+)/i);
          if (!mode && modeMatch && modeMatch[1]) mode = decodeURIComponent(modeMatch[1]);

          const oobMatch = href.match(/[?&#]oobCode=([^&#]+)/i);
          if (!oobCode && oobMatch && oobMatch[1]) oobCode = decodeURIComponent(oobMatch[1]);

          const apiMatch = href.match(/[?&#]apiKey=([^&#]+)/i);
          if (!apiKey && apiMatch && apiMatch[1]) apiKey = decodeURIComponent(apiMatch[1]);

          const continueMatch = href.match(/[?&#]continueUrl=([^&#]+)/i);
          if (!continueUrl && continueMatch && continueMatch[1]) continueUrl = decodeURIComponent(continueMatch[1]);

          const langMatch = href.match(/[?&#]lang=([^&#]+)/i);
          if (!lang && langMatch && langMatch[1]) lang = decodeURIComponent(langMatch[1]);
        } catch {
          // ignore regex error
        }
      }

      // 4. Check if continueUrl itself contains nested query parameters
      if (continueUrl && (!mode || !oobCode)) {
        try {
          const parsedContinue = new URL(continueUrl, window.location.origin);
          if (!mode) mode = parsedContinue.searchParams.get('mode');
          if (!oobCode) oobCode = parsedContinue.searchParams.get('oobCode');
          if (!apiKey) apiKey = parsedContinue.searchParams.get('apiKey');
        } catch {
          // ignore continueUrl parsing error
        }
      }

      // 5. Pathname clues if mode is missing but oobCode is present
      if (!mode && oobCode) {
        if (pathname.includes('verify') || pathname.includes('email')) {
          mode = 'verifyEmail';
        } else {
          // Default to resetPassword whenever oobCode is present
          mode = 'resetPassword';
        }
      }

      // If oobCode is present, definitely treat as an action route
      if (oobCode) {
        isActionRoute = true;
      }
    }
  } catch (e) {
    console.warn('Error parsing Firebase action parameters:', e);
  }

  // Normalize mode with case-insensitivity
  let normalizedMode: FirebaseActionParams['firebaseMode'] = null;
  const rawModeLower = (mode || '').toLowerCase().trim();

  if (
    rawModeLower === 'resetpassword' ||
    rawModeLower === 'reset_password' ||
    rawModeLower === 'reset-password'
  ) {
    normalizedMode = 'resetPassword';
  } else if (
    rawModeLower === 'verifyemail' ||
    rawModeLower === 'verify_email' ||
    rawModeLower === 'verify-email'
  ) {
    normalizedMode = 'verifyEmail';
  } else if (
    rawModeLower === 'recoveremail' ||
    rawModeLower === 'recover_email' ||
    rawModeLower === 'recover-email'
  ) {
    normalizedMode = 'recoverEmail';
  } else if (
    rawModeLower === 'signin' ||
    rawModeLower === 'sign_in' ||
    rawModeLower === 'sign-in'
  ) {
    normalizedMode = 'signIn';
  } else if (oobCode) {
    // If oobCode is present but mode string was unknown or missing, safely default to resetPassword
    normalizedMode = 'resetPassword';
  }

  const isPasswordReset = normalizedMode === 'resetPassword' && !!oobCode;
  const isEmailVerification = normalizedMode === 'verifyEmail' && !!oobCode;

  return {
    firebaseMode: normalizedMode,
    oobCode,
    apiKey,
    continueUrl,
    lang,
    isPasswordReset,
    isEmailVerification,
    isActionRoute: isActionRoute || !!oobCode,
  };
}
