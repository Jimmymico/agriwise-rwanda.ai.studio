import { BusinessRole, BusinessPermission } from '../types';

/**
 * Centralized Role Permission Engine for AGRIWISE RWANDA Business Members.
 * Ensures consistent permission evaluation across frontend components and services.
 */

export const BUSINESS_ROLE_PERMISSIONS: Record<BusinessRole, BusinessPermission[]> = {
  owner: [
    'manage_business_profile',
    'manage_members',
    'assign_roles',
    'view_business_data',
    'manage_products',
    'manage_inventory',
    'view_sales',
    'create_sales',
    'manage_finances',
    'view_finances',
    'manage_customers',
    'manage_suppliers',
  ],
  manager: [
    'view_business_data',
    'manage_products',
    'manage_inventory',
    'view_sales',
    'create_sales',
    'view_finances',
    'manage_customers',
    'manage_suppliers',
  ],
  finance: [
    'view_business_data',
    'manage_finances',
    'view_finances',
    'view_sales',
  ],
  sales_marketing: [
    'view_business_data',
    'view_sales',
    'create_sales',
    'manage_customers',
  ],
  staff: [
    'view_business_data',
    'create_sales',
  ],
};

/**
 * Check if a given business member role has a specific business permission.
 */
export function hasBusinessPermission(
  memberRole: BusinessRole | undefined | null,
  permission: BusinessPermission,
  customPermissions?: BusinessPermission[]
): boolean {
  if (!memberRole) return false;
  if (memberRole === 'owner') return true;
  if (customPermissions && customPermissions.includes(permission)) return true;
  const rolePerms = BUSINESS_ROLE_PERMISSIONS[memberRole];
  return rolePerms ? rolePerms.includes(permission) : false;
}

/**
 * Get human-readable description for business roles.
 */
export function getBusinessRoleLabel(role: BusinessRole, language: 'rw' | 'en' | 'fr' = 'en'): string {
  const labels: Record<BusinessRole, { rw: string; en: string; fr: string }> = {
    owner: { rw: 'Nyir\'icunguramatsiko (Owner)', en: 'Business Owner', fr: 'Propriétaire' },
    manager: { rw: 'Umuyobozi (Manager)', en: 'Business Manager', fr: 'Gérant' },
    finance: { rw: 'Umunyamutungo (Finance)', en: 'Finance Officer', fr: 'Responsable Financier' },
    staff: { rw: 'Umukozi (Staff)', en: 'Operational Staff', fr: 'Personnel Opérationnel' },
    sales_marketing: { rw: 'Umuguzi/Ubucuruzi (Sales)', en: 'Sales & Marketing', fr: 'Ventes & Marketing' },
  };
  return labels[role]?.[language] || labels[role]?.en || role;
}
