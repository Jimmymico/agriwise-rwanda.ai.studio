export type Language = 'rw' | 'en' | 'fr';

export type NavigationTab =
  | 'home'
  | 'login'
  | 'register'
  | 'forgot_password'
  | 'verify_email'
  | 'dashboard'
  | 'farmer_profile'
  | 'farm_registration'
  | 'activity_tracker'
  | 'farm_documents'
  | 'map_my_farm'
  | 'ai_assistant'
  | 'voice_assistant'
  | 'ussd_voice_gateway'
  | 'disease_detector'
  | 'crop_manager'
  | 'livestock_manager'
  | 'financials'
  | 'marketplace'
  | 'experts'
  | 'cooperative'
  | 'agrodealer'
  | 'logistics'
  | 'government'
  | 'banking_insurance'
  | 'satellite_monitoring'
  | 'iot_smart_farm'
  | 'drone_agriculture'
  | 'academy_training'
  | 'data_marketplace'
  | 'global_expansion'
  | 'cloud_infrastructure'
  | 'qa_testing'
  | 'business_model'
  | 'company_launch'
  | 'credit_score'
  | 'weather'
  | 'training'
  | 'community'
  | 'admin'
  | 'system_admin'
  | 'jimmy_mico_pro';

export type UserRole = 
  | 'system_owner'
  | 'farmer'
  | 'livestock'
  | 'cooperative'
  | 'agrodealer'
  | 'buyer'
  | 'expert'
  | 'transporter'
  | 'bank_insurance'
  | 'government_ngo'
  | 'admin';

export interface UserSubscription {
  planId: 'free' | 'farmer_premium' | 'professional' | 'enterprise';
  planName: string;
  status: 'active' | 'trial' | 'expired' | 'cancelled';
  freeRequestsRemaining: number;
  maxFreeRequests: number;
  usedRequestsCount: number;
  renewsAt?: string;
}

export type IdentityVerificationStatus = 'not_started' | 'pending' | 'verified' | 'failed' | 'manual_review';

export type UserAccountStatus =
  | 'active'
  | 'pending_email'
  | 'pending_verification'
  | 'verification_failed'
  | 'suspended'
  | 'rejected'
  | 'pending'
  | 'blocked'
  | 'deleted';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  phoneNumber?: string;
  role: UserRole;
  province?: string;
  district: string;
  sector: string;
  cell?: string;
  village?: string;
  language: Language;
  avatarUrl?: string;
  verified: boolean;
  accountStatus?: UserAccountStatus;
  userRegistrationStatus?: 'Pending Email Verification' | 'Pending Identity Verification' | 'Verified' | 'Suspended' | 'Rejected';

  // National Identity Verification Fields
  identityStatus?: IdentityVerificationStatus;
  nationalIdMasked?: string;
  nationalIdHash?: string;
  identityProviderReference?: string;
  identityVerifiedAt?: string;
  identityVerificationAttempts?: number;
  dateOfBirth?: string;
  identityReviewNotes?: string;
  identityLastAttemptAt?: string;

  // Email Verification Fields
  emailVerified?: boolean;
  emailVerificationToken?: string;
  emailVerificationTokenExpiresAt?: number;
  emailVerificationTokenCreatedAt?: number;
  emailVerifiedAt?: string;

  // User Notification Preferences
  notificationPreferences?: UserNotificationPreferences;

  subscription?: UserSubscription;
  creditScore: number;
  cooperativeName?: string;
  momoNumber?: string;
  farmSizeHectares?: number;
  primaryCrops?: string[];
  primaryLivestock?: string[];
  businessId?: string;
}

export type BusinessRole = 'owner' | 'manager' | 'finance' | 'staff' | 'sales_marketing';

export type BusinessMemberStatus = 'active' | 'invited' | 'suspended' | 'removed';

export type BusinessPermission =
  | 'manage_business_profile'
  | 'manage_members'
  | 'assign_roles'
  | 'view_business_data'
  | 'manage_products'
  | 'manage_inventory'
  | 'view_sales'
  | 'create_sales'
  | 'manage_finances'
  | 'view_finances'
  | 'manage_customers'
  | 'manage_suppliers';

export interface BusinessMember {
  uid: string;
  businessId: string;
  email: string;
  displayName: string;
  phoneNumber?: string;
  role: BusinessRole;
  platformRole?: UserRole;
  status: BusinessMemberStatus;
  permissions: BusinessPermission[];
  joinedAt: string;
  createdAt: string;
  updatedAt: string;
}

export interface BusinessOrganization {
  businessId: string;
  name: string;
  ownerId: string;
  businessType: string;
  country: string;
  district: string;
  sector: string;
  contactPhone: string;
  contactEmail: string;
  status: 'active' | 'pending_approval' | 'suspended';
  createdAt: string;
  updatedAt: string;
}

export interface IdentityVerificationRecord {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  nationalIdMasked: string;
  nationalIdHash: string;
  dateOfBirth?: string;
  district: string;
  submissionDate: string;
  status: IdentityVerificationStatus;
  verificationResult: 'Verified' | 'Failed' | 'Pending' | 'Unable to Verify' | 'Service Unavailable' | 'Manual Review Required';
  providerReference?: string;
  reviewStatus: 'Pending Review' | 'Approved' | 'Rejected' | 'Correction Requested';
  reviewedBy?: string;
  reviewedAt?: string;
  reviewNotes?: string;
  attemptsCount: number;
  lastAttemptAt: string;
}

export interface EmailVerificationTokenRecord {
  id: string;
  userId: string;
  email: string;
  token: string;
  expiresAt: number;
  createdAt: number;
  used: boolean;
  attempts: number;
  lastResentAt: number;
}

export interface GPSPoint {
  lat: number;
  lng: number;
  accuracy?: number;
  timestamp?: number;
  elevation?: number;
}

export interface SavedFarmBoundary {
  id: string;
  farmName: string;
  district: string;
  sector: string;
  points: GPSPoint[];
  areaSqMeters: number;
  areaHectares: number;
  perimeterMeters: number;
  createdAt: string;
  updatedAt: string;
  syncedToCloud: boolean;
  notes?: string;
  cropType?: string;
}

export interface FarmProfile {
  id: string;
  farmerId: string;
  farmerName: string;
  farmName: string;
  district: string;
  sector: string;
  sizeHectares: number;
  boundaryCoordinates: GPSPoint[];
  soilType: string;
  crops: string[];
  livestock: string[];
  irrigationType: string;
  creditScore: number;
  totalIncomeRwf: number;
  totalExpenseRwf: number;
  verifiedByGovernment: boolean;
}

export interface CropRecord {
  id: string;
  farmerId: string;
  cropName: string;
  variety: string;
  acreageHectares: number;
  plantingDate: string;
  stage: 'germination' | 'vegetative' | 'flowering' | 'fruiting' | 'harvesting';
  expectedHarvestDate: string;
  expectedYieldTons: number;
  status: 'healthy' | 'attention_needed' | 'diseased';
  lastFertilizerDate?: string;
  notes?: string;
}

export interface LivestockRecord {
  id: string;
  farmerId: string;
  tagNumber: string;
  animalType: 'Cattle' | 'Goat' | 'Poultry' | 'Pig' | 'Sheep';
  breed: string;
  gender: 'Female' | 'Male';
  ageMonths: number;
  healthStatus: 'Excellent' | 'Good' | 'Sick' | 'Under Treatment';
  lastVaccinationDate: string;
  dailyYieldLitersOrEggs: number;
}

export interface FinancialTransaction {
  id: string;
  farmerId: string;
  date: string;
  category: 'Fertilizer' | 'Seeds' | 'Labor' | 'Produce Sale' | 'Livestock Sale' | 'Equipment' | 'Consultation Fee';
  type: 'income' | 'expense';
  amountRwf: number;
  description: string;
  paymentMethod: 'MTN Mobile Money' | 'Airtel Money' | 'Bank Transfer' | 'Cash';
  receiptRef?: string;
}

export interface DiseaseDiagnosis {
  id: string;
  farmerId: string;
  cropType: string;
  imageUrl: string;
  diseaseDetected: boolean;
  diseaseName: string;
  confidenceScore: number;
  severity: 'Healthy' | 'Low' | 'Medium' | 'High';
  symptoms: string[];
  organicTreatment: string;
  chemicalTreatment: string;
  preventativeAdvice: string;
  recommendedAgronomist: string;
  createdAt: string;
}

export interface MarketplaceItem {
  id: string;
  sellerId: string;
  sellerName: string;
  sellerRole: UserRole;
  sellerPhone: string;
  district: string;
  title: string;
  category: 'Produce' | 'Inputs' | 'Livestock' | 'Machinery';
  quantity: number;
  unit: 'Kg' | 'Tons' | 'Liters' | 'Bags' | 'Heads' | 'Units';
  pricePerUnitRwf: number;
  imageUrl: string;
  description: string;
  verifiedGrade: 'Grade A1' | 'Grade A2' | 'Standard';
  status: 'available' | 'sold' | 'reserved';
}

export interface MarketplaceOrder {
  id: string;
  itemId: string;
  itemTitle: string;
  sellerName: string;
  buyerId: string;
  buyerName: string;
  quantity: number;
  totalAmountRwf: number;
  deliveryDistrict: string;
  paymentStatus: 'pending' | 'momo_paid' | 'released_escrow';
  orderStatus: 'pending' | 'confirmed' | 'in_transit' | 'delivered';
  transporterName?: string;
  transporterPhone?: string;
  createdAt: string;
}

export interface ExpertConsultant {
  id: string;
  name: string;
  role: 'Agronomist' | 'Veterinarian' | 'Soil Specialist' | 'Irrigation Engineer';
  organization: string;
  district: string;
  rating: number;
  reviewsCount: number;
  consultationFeeRwf: number;
  avatarUrl: string;
  phone: string;
  specialization: string[];
  availableDays: string[];
}

export interface LegacyConsultationBooking {
  id: string;
  expertId: string;
  expertName: string;
  farmerId: string;
  farmerName: string;
  date: string;
  timeSlot: string;
  topic: string;
  status: 'upcoming' | 'completed' | 'cancelled';
  feeRwf: number;
  meetingLink?: string;
}

export interface WeatherData {
  district: string;
  temperatureC: number;
  humidityPct: number;
  rainfallProbabilityPct: number;
  windSpeedKmh: number;
  condition: 'Sunny' | 'Partly Cloudy' | 'Heavy Rain' | 'Scattered Showers';
  alert?: string;
  farmingAdvice: string;
  forecast7Days: {
    day: string;
    tempHighC: number;
    tempLowC: number;
    rainPct: number;
    condition: string;
  }[];
}

export interface CommunityPost {
  id: string;
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  authorDistrict: string;
  authorAvatar: string;
  title: string;
  content: string;
  category: string;
  likes: number;
  commentsCount: number;
  createdAt: string;
  isSolved: boolean;
  verifiedExpertAnswer?: string;
}

export interface Course {
  id: string;
  title: { rw: string; en: string; fr: string };
  category: string;
  durationMinutes: number;
  instructor: string;
  thumbnailUrl: string;
  description: { rw: string; en: string; fr: string };
  enrolledStudents: number;
  rating: number;
  videoUrl?: string;
  audioUrl?: string;
}

// ==========================================
// FARMER CORE PLATFORM ENTITIES (STEP 23)
// ==========================================

export interface FarmerProfileDetails {
  id: string;
  userId: string;
  fullName: string;
  photoUrl: string;
  phone: string;
  email: string;
  district: string;
  sector: string;
  cell: string;
  village: string;
  preferredLanguage: Language;
  farmingExperienceYears: number;
  mainActivities: ('Crop Farming' | 'Livestock Raising' | 'Agro-Forestry' | 'Horticulture' | 'Aquaculture')[];
  totalFarmAreaHectares: number;
  mainCrops: string[];
  livestockTypes: string[];
  farmingGoals: string;
  cooperativeMembership?: string;
  nationalIdNumber?: string;
  notificationPreferences?: UserNotificationPreferences;
}

export interface RegisteredFarm {
  id: string;
  farmerId: string;
  farmName: string;
  district: string;
  sector: string;
  cell?: string;
  gpsCoordinates: GPSPoint[];
  sizeHectares: number;
  landOwnershipType: 'Owned (Title Deed)' | 'Leased / Rented' | 'Customary / Family';
  soilType: 'Volcanic (Rich Organic)' | 'Sandy Loam' | 'Clay Heavy' | 'Lateritic Slopes';
  waterSource: 'Rainfed' | 'Marshland Canal' | 'River Pump' | 'Solar Drip Irrigation';
  farmingMethod: 'Organic Certified' | 'Conventional' | 'Integrated / Mixed';
  photoUrls: string[];
  createdAt: string;
  healthScore: number;
}

export interface FarmActivity {
  id: string;
  farmId: string;
  farmName: string;
  activityType: 'Planting' | 'Fertilizing' | 'Spraying' | 'Irrigation' | 'Harvesting' | 'Animal Vaccination' | 'Feeding' | 'Soil Testing';
  title: string;
  description: string;
  date: string;
  status: 'pending' | 'completed' | 'overdue';
  cropOrAnimalTarget: string;
  inputUsed?: string;
  inputQuantity?: string;
  assignedLaborers?: number;
  costRwf?: number;
}

export interface FarmDocumentRecord {
  id: string;
  farmId: string;
  title: string;
  category: 'Land Title' | 'Organic Certificate' | 'Cooperative License' | 'Input Purchase Receipt' | 'Soil Test Report' | 'Bank Loan Agreement';
  uploadDate: string;
  fileUrl: string;
  fileType: 'pdf' | 'jpg' | 'png';
  fileSizeMb: number;
  verificationStatus: 'Verified by RAB' | 'Pending Review' | 'Self Uploaded';
}

export interface FarmHealthScoreBreakdown {
  overallScore: number; // 0 - 100
  cropVitalityScore: number;
  soilHealthScore: number;
  livestockCareScore: number;
  activityComplianceScore: number;
  documentCompletenessScore: number;
  strengths: { rw: string; en: string; fr: string }[];
  recommendations: { rw: string; en: string; fr: string }[];
}

export type SpecialistAgentType = 'agronomist' | 'veterinarian' | 'business' | 'market' | 'weather';

export interface VoiceMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  audioUrl?: string;
  timestamp: string;
  specialistAgent?: SpecialistAgentType;
  multimodalImage?: string;
  confidenceScore?: number;
  safetyDisclaimer?: string;
  audioDurationSec?: number;
  status?: 'queued' | 'sending' | 'delivered';
  actionableRecommendation?: string;
}

export interface FarmerMemoryItem {
  id: string;
  category: 'crop' | 'livestock' | 'preference' | 'task' | 'disease';
  content: string;
  dateAdded: string;
}

export interface FarmerMemoryBank {
  farmerName: string;
  location: string;
  farmSizeHa: number;
  primaryCrops: string[];
  livestockCount: number;
  memories: FarmerMemoryItem[];
}

export interface MarketplaceProductFull {
  id: string;
  sellerId: string;
  sellerName: string;
  sellerRole: UserRole;
  sellerPhone: string;
  sellerRating: number;
  sellerVerified: boolean;
  district: string;
  sector: string;
  title: string;
  category: 'Produce' | 'Inputs' | 'Livestock' | 'Machinery';
  subcategory: string;
  availableQuantity: number;
  unit: 'Kg' | 'Tons' | 'Liters' | 'Bags' | 'Heads' | 'Units';
  pricePerUnitRwf: number;
  minOrderQuantity: number;
  harvestDate?: string;
  qualityGrade: 'Grade A1 Export' | 'Grade A2 Local' | 'Standard Bulk';
  imageUrl: string;
  description: string;
  cooperativeName?: string;
  status: 'available' | 'sold_out' | 'reserved';
  createdAt: string;
}

export interface MarketplaceOffer {
  id: string;
  productId: string;
  productTitle: string;
  buyerId: string;
  buyerName: string;
  buyerPhone: string;
  sellerId: string;
  sellerName: string;
  offeredPricePerUnitRwf: number;
  offeredQuantity: number;
  totalOfferAmountRwf: number;
  status: 'pending' | 'accepted' | 'rejected' | 'countered';
  notes?: string;
  createdAt: string;
}

export interface MarketplaceOrderFull {
  id: string;
  productId: string;
  productTitle: string;
  category: 'Produce' | 'Inputs' | 'Livestock' | 'Machinery';
  sellerId: string;
  sellerName: string;
  sellerPhone: string;
  buyerId: string;
  buyerName: string;
  buyerPhone: string;
  quantity: number;
  unit: string;
  pricePerUnitRwf: number;
  subtotalAmountRwf: number;
  deliveryFeeRwf: number;
  totalAmountRwf: number;
  deliveryDistrict: string;
  deliveryAddress: string;
  escrowStatus: 'pending_momo' | 'held_in_escrow' | 'released_to_seller' | 'refunded';
  orderStatus: 'pending' | 'accepted' | 'preparing' | 'transporting' | 'delivered' | 'completed' | 'cancelled';
  transporterId?: string;
  transporterName?: string;
  transporterPhone?: string;
  trackingCode: string;
  createdAt: string;
  ratingGiven?: number;
  reviewComment?: string;
}

export interface TransporterJob {
  id: string;
  orderId: string;
  cargoTitle: string;
  pickupDistrict: string;
  deliveryDistrict: string;
  cargoWeightTons: number;
  transportFeeRwf: number;
  status: 'available' | 'assigned' | 'in_transit' | 'completed';
  driverId?: string;
  driverName?: string;
  driverPhone?: string;
  vehicleType: 'Pickup Truck (1-2T)' | 'Medium Canter (3-5T)' | 'Fuso Truck (10T+)' | 'Refrigerated Van';
  assignedDate?: string;
}

export interface MarketPriceRecord {
  id: string;
  commodity: string;
  category: 'Crops' | 'Inputs' | 'Livestock';
  district: string;
  pricePerKgRwf: number;
  priceTrend: 'up' | 'down' | 'stable';
  weeklyChangePct: number;
  highDemandMarket: string;
  recommendedSellTime: string;
  lastUpdated: string;
}

export type ExpertSpecialty = 
  | 'Agronomist (Crops & Pests)'
  | 'Veterinary Officer (Livestock)'
  | 'Soil & Fertilizer Specialist'
  | 'Irrigation & Engineering'
  | 'Agribusiness & Market Finance'
  | 'Organic Farming & Permaculture';

export interface ExpertProfile {
  id: string;
  fullName: string;
  title: string;
  specialty: ExpertSpecialty;
  organization: string; // e.g., 'Rwanda Agriculture Board (RAB)', 'University of Rwanda', 'Private Practice'
  experienceYears: number;
  district: string;
  languages: ('Kinyarwanda' | 'English' | 'French')[];
  rating: number;
  reviewCount: number;
  verifiedBadge: boolean;
  licenseNumber: string;
  avatarUrl: string;
  bio: string;
  chatFeeRwf: number;
  videoFeeRwf: number;
  farmVisitFeeRwf: number;
  availability: 'Online Now' | 'Available Today' | 'Busy';
  phone: string;
  email: string;
}

export interface ConsultationBooking {
  id: string;
  farmerId: string;
  farmerName: string;
  farmerPhone: string;
  farmerDistrict: string;
  expertId: string;
  expertName: string;
  expertSpecialty: ExpertSpecialty;
  type: 'Chat Consultation' | 'Voice Call' | 'Video Call' | 'Farm Visit' | 'AI Vision Escalation Review';
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  feeRwf: number;
  scheduledTime: string;
  problemSummary: string;
  attachedImageUrl?: string;
  prescriptionSlip?: PrescriptionSlip;
  momoPaymentStatus: 'paid_escrow' | 'released_to_expert' | 'refunded';
  createdAt: string;
}

export interface PrescriptionSlip {
  id: string;
  consultationId: string;
  expertName: string;
  licenseNumber: string;
  diagnosis: string;
  recommendedChemicalOrMedicine: string;
  dosageInstructions: string;
  applicationSchedule: string;
  preventativeMeasures: string;
  issuedDate: string;
}

export interface KnowledgeArticle {
  id: string;
  title: string;
  category: 'Crop Production' | 'Livestock Care' | 'Soil & Water' | 'Climate Adaptation' | 'Market & Finance';
  authorName: string;
  authorRole: string;
  organization: string; // e.g. RAB
  readingTimeMinutes: number;
  summary: string;
  contentMarkdown: string;
  imageUrl: string;
  videoUrl?: string;
  likesCount: number;
  verifiedByRab: boolean;
  publishedDate: string;
}

export interface ForumPost {
  id: string;
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  authorAvatar?: string;
  district: string;
  title: string;
  content: string;
  category: 'Crops' | 'Livestock' | 'Pest Outbreak' | 'Equipment' | 'Markets';
  imageUrl?: string;
  upvotes: number;
  commentsCount: number;
  hasExpertAnswer: boolean;
  createdAt: string;
  comments?: ForumComment[];
}

export interface ForumComment {
  id: string;
  postId: string;
  authorName: string;
  authorRole: UserRole;
  isVerifiedExpert: boolean;
  content: string;
  createdAt: string;
}

export interface CooperativeProfile {
  id: string;
  name: string;
  registrationNumber: string; // RCA (Rwanda Cooperative Agency) Reg Code
  district: string;
  sector: string;
  mainCommodity: string;
  totalMembers: number;
  totalLandHectares: number;
  expectedSeasonalHarvestTons: number;
  currentHarvestCollectedTons: number;
  revenueRwf: number;
  expensesRwf: number;
  chairmanName: string;
  managerName: string;
  phone: string;
  email: string;
  verificationStatus: 'Approved' | 'Pending' | 'Rejected';
  establishedYear: number;
}

export interface CooperativeMemberRecord {
  id: string;
  farmerId: string;
  farmerName: string;
  farmerPhone: string;
  district: string;
  farmSizeHectares: number;
  primaryCrop: string;
  seasonDeliveredTons: number;
  payoutEarnedRwf: number;
  payoutStatus: 'Paid via MoMo' | 'Pending Collection Settlement' | 'In Escrow';
  joinedDate: string;
}

export interface CollectionCenterDelivery {
  id: string;
  farmerId: string;
  farmerName: string;
  commodity: string;
  quantityKg: number;
  qualityGrade: 'Grade A1 (Export Spec)' | 'Grade A2 (Standard)' | 'Grade B (Processing)';
  moistureContentPct: number;
  pricePerKgRwf: number;
  totalPayoutRwf: number;
  collectionCenterName: string;
  receivedByOfficer: string;
  timestamp: string;
}

export interface CooperativeBulkContract {
  id: string;
  buyerName: string;
  buyerType: 'Food Processor' | 'Grain Exporter' | 'Government Reserve (MINAGRI/WFP)';
  commodity: string;
  contractQuantityTons: number;
  pricePerTonRwf: number;
  totalContractValueRwf: number;
  fulfilledQuantityTons: number;
  deliveryDeadline: string;
  status: 'Active' | 'Fulfilled' | 'Negotiating' | 'In Transit';
  momoEscrowSecured: boolean;
}

export interface CooperativeTransaction {
  id: string;
  type: 'Bulk Sale Revenue' | 'Member Dividend Payout' | 'Fertilizer Bulk Purchase' | 'Transport & Storage Cost';
  amountRwf: number;
  date: string;
  description: string;
  referenceNumber: string;
}

export interface AgroDealerProfile {
  id: string;
  businessName: string;
  ownerName: string;
  registrationNumber: string; // RAB / RURA Certification Code
  district: string;
  sector: string;
  address: string;
  phone: string;
  email: string;
  rating: number; // e.g. 4.8
  totalReviews: number;
  verificationStatus: 'Approved' | 'Pending' | 'Rejected' | 'Suspended';
  rabCertificationBadge: boolean;
  categoriesHandled: string[];
  totalInventoryItems: number;
  totalStockValueRwf: number;
  monthlySalesRwf: number;
}

export type ProductStatus = 'active' | 'archived';

export interface Product {
  productId: string;
  businessId: string;
  ownerId: string;
  name: string;
  description: string;
  categoryId: string;
  categoryName: string;
  sku: string;
  barcode?: string;
  unit: string; // e.g. 'kg', '50kg Bag', 'Liter', 'Item'
  sellingPrice: number; // in RWF
  costPrice: number; // in RWF
  currency: string; // default 'RWF'
  quantity: number; // in-stock quantity
  minimumStockLevel: number; // reorder threshold
  status: ProductStatus;
  imageUrl?: string;
  supplierId?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export type CategoryStatus = 'active' | 'archived';

export interface Category {
  categoryId: string;
  businessId: string;
  name: string;
  description?: string;
  status: CategoryStatus;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface Inventory {
  inventoryId: string;
  businessId: string;
  ownerId: string;
  productId: string;
  quantity: number;
  reservedQuantity: number;
  availableQuantity: number;
  minimumStockLevel: number;
  maximumStockLevel?: number;
  unit: string;
  location?: string;
  warehouse?: string;
  status: 'In Stock' | 'Low Stock' | 'Out of Stock';
  updatedAt: string;
  updatedBy: string;
}

export type InventoryMovementType = 'STOCK_IN' | 'STOCK_OUT' | 'ADJUSTMENT' | 'RETURN' | 'TRANSFER';

export interface InventoryMovement {
  movementId: string;
  businessId: string;
  productId: string;
  type: InventoryMovementType;
  quantity: number;
  reason?: string;
  referenceId?: string;
  createdBy: string;
  createdAt: string;
}

export interface ProductCatalogStats {
  totalProducts: number;
  activeProducts: number;
  lowStockProducts: number;
  outOfStockProducts: number;
  totalInventoryQuantity: number;
  totalStockValueRwf: number;
}

export interface AgroInputProduct {
  id: string;
  dealerId: string;
  dealerName: string;
  name: string;
  category: 'Seeds' | 'Fertilizers' | 'Crop Protection' | 'Livestock Feed & Pharma' | 'Farm Tools & Equipment';
  subcategory: string;
  brand: string;
  manufacturer: string;
  description: string;
  pricePerUnitRwf: number;
  unit: string; // e.g., '50kg bag', '1L bottle', '10kg seed pack'
  stockQuantity: number;
  reorderLevel: number;
  expiryDate: string;
  rabApproved: boolean;
  rabCertificateNumber: string;
  storageCondition: string;
  recommendedCrops: string[];
  imageUrl: string;
}

export interface AgroInputOrder {
  id: string;
  orderNumber: string;
  dealerId: string;
  dealerName: string;
  buyerName: string;
  buyerPhone: string;
  buyerDistrict: string;
  items: {
    productId: string;
    productName: string;
    quantity: number;
    unitPriceRwf: number;
    totalRwf: number;
  }[];
  totalAmountRwf: number;
  paymentStatus: 'Pending' | 'MoMo Escrow Secured' | 'Paid' | 'Refunded';
  deliveryMethod: 'Pickup at Agro-dealer Hub' | 'Farmgate Logistics Dispatch';
  deliveryStatus: 'Processing' | 'Ready for Pickup' | 'In Transit' | 'Delivered' | 'Cancelled';
  assignedTransporter?: string;
  createdAt: string;
}

export interface SupplyChainStockAlert {
  id: string;
  dealerId: string;
  productId: string;
  productName: string;
  alertType: 'Low Stock Reorder' | 'Near Expiry' | 'High Regional Demand';
  currentStock: number;
  recommendedReorderQty: number;
  message: string;
  date: string;
}

export interface TransporterProfile {
  id: string;
  companyName: string;
  driverName: string;
  phone: string;
  email: string;
  district: string;
  sector: string;
  ruraLicenseNumber: string; // Rwanda Utilities Regulatory Authority License
  vehicleType: 'Fuso 5-Ton Truck' | 'Daihatsu 3-Ton Truck' | 'Coaster Heavy Freight (10T)' | 'Refrigerated Cold-Chain Van (2T)' | 'Motorcycle Cargo Trike (500kg)';
  plateNumber: string;
  maxCapacityTons: number;
  rating: number;
  totalReviews: number;
  completedJobsCount: number;
  verificationStatus: 'Approved' | 'Pending' | 'Suspended';
  coldStorageEquipped: boolean;
  gpsTracked: boolean;
  baseRatePerKmRwf: number;
  totalEarningsRwf: number;
  currentStatus: 'Available' | 'In Transit' | 'Off-Duty' | 'Under Maintenance';
}

export interface TransportFreightJob {
  id: string;
  jobCode: string;
  requesterType: 'Farmer' | 'Cooperative' | 'Agro-dealer' | 'Grain Exporter';
  requesterName: string;
  requesterPhone: string;
  cargoType: 'Maize Grain' | 'Kinigi Seed Potatoes' | 'NPK Fertilizers' | 'Fresh Beans' | 'Dairy Milk Canisters' | 'Raw Coffee Cherries';
  quantityTons: number;
  pickupLocation: string; // e.g., 'Nyagatare Karangazi Silo'
  destination: string; // e.g., 'Kigali Minimex Mill, Kicukiro'
  distanceKm: number;
  requestedDate: string;
  specialRequirements: string[];
  quotedPriceRwf: number;
  assignedTransporterId?: string;
  assignedTransporterName?: string;
  assignedVehiclePlate?: string;
  status: 'Open for Bidding' | 'Assigned' | 'Picked Up' | 'In Transit' | 'Delivered' | 'Cancelled';
  paymentStatus: 'MoMo Escrow Secured' | 'Pending' | 'Released';
  deliveryCode: string; // OTP for delivery confirmation
  currentGps: {
    lat: number;
    lng: number;
    locationName: string;
    speedKmH: number;
  };
  estimatedEtaMinutes: number;
  createdAt: string;
}

export interface AgriculturalWarehouse {
  id: string;
  name: string;
  district: string;
  sector: string;
  managerName: string;
  managerPhone: string;
  totalCapacityTons: number;
  occupiedSpaceTons: number;
  storageFeePerTonDayRwf: number;
  temperatureCelsius: number;
  humidityPercent: number;
  pestControlCertified: boolean;
  rabGradeSupported: string[];
  servicesOffered: string[];
}

export interface LogisticsAiRecommendation {
  recommendedTransporterId: string;
  recommendedTransporterName: string;
  estimatedCostRwf: number;
  optimalRouteSummary: string;
  estimatedDurationMinutes: number;
  fuelCostEstimateRwf: number;
  roadConditionNote: string;
  alternativeRouteSavingsMinutes: number;
  aiConfidencePct: number;
}

export type GovernmentUserRole =
  | 'National Agriculture Administrator'
  | 'District Agriculture Officer'
  | 'Sector Agriculture Officer'
  | 'Research Institution'
  | 'Food Security Analyst';

export interface NationalAgStats {
  totalRegisteredFarmers: number;
  totalMappedFarms: number;
  totalCultivatedHectares: number;
  totalAnnualYieldTons: number;
  totalMarketplaceVolumeRwf: number;
  totalActiveCooperatives: number;
  totalRabAgrodealers: number;
  totalRuraTransporters: number;
  livestockHeadCount: {
    cattle: number;
    goats: number;
    sheep: number;
    poultry: number;
  };
  cropDistributionPct: {
    maize: number;
    beans: number;
    rice: number;
    irishPotatoes: number;
    coffeeTea: number;
    other: number;
  };
}

export interface RegionalAgStats {
  id: string;
  province: string; // e.g. 'Eastern Province', 'Northern Province'
  district: string; // e.g. 'Nyagatare', 'Musanze'
  registeredFarmersCount: number;
  cultivatedHectares: number;
  mainCrops: string[];
  expectedHarvestTons: number;
  droughtRiskLevel: 'Low' | 'Moderate' | 'High' | 'Critical';
  diseaseOutbreakCount: number;
  irrigationCoveragePct: number;
  inputSubsidyUtilizationPct: number;
}

export interface GovDiseaseAlert {
  id: string;
  diseaseName: string;
  cropAffected: string;
  district: string;
  sector: string;
  severity: 'Watch' | 'Warning' | 'Outbreak Alert';
  confirmedCasesCount: number;
  spreadTrend: 'Decreasing' | 'Stable' | 'Rapidly Spreading';
  recommendedAction: string;
  reportedDate: string;
}

export interface GovFoodSecurityAlert {
  id: string;
  province: string;
  district: string;
  riskType: 'Rainfall Shortage' | 'Pest Outbreak' | 'Post-Harvest Losses' | 'Supply Chain Bottleneck';
  impactDescription: string;
  estimatedProductionDeficitPct: number;
  affectedPopulationEstimate: number;
  strategicGrainReserveRequirementTons: number;
  aiConfidencePct: number;
  alertDate: string;
}

export interface GovPolicyScenario {
  id: string;
  policyTitle: string;
  targetProvince: string;
  targetCrop: string;
  fertilizerSubsidyPctChange: number;
  irrigationInvestmentHectares: number;
  projectedYieldIncreasePct: number;
  projectedEconomicReturnRwf: number;
  farmerIncomeImpactPct: number;
  aiAnalysisSummary: string;
}

// ==========================================
// STEP 35: FINTECH, BANKING & INSURANCE TYPES
// ==========================================

export type FinOrgType = 'Bank' | 'Microfinance' | 'Insurance' | 'Investor Organization';

export interface FinancialInstitution {
  id: string;
  name: string;
  type: FinOrgType;
  licenseNumber: string;
  contactEmail: string;
  contactPhone: string;
  servicesOffered: string[];
  regionsServed: string[];
  verificationStatus: 'Approved' | 'Pending' | 'Rejected';
  totalCapitalDeployedRwf: number;
  activePortfoliosCount: number;
}

export type LoanPurposeType = 'Seeds' | 'Fertilizer' | 'Equipment' | 'Livestock' | 'Irrigation' | 'Expansion';

export interface AgriLoanApplication {
  id: string;
  farmerId: string;
  farmerName: string;
  district: string;
  institutionId: string;
  institutionName: string;
  loanType: LoanPurposeType;
  requestedAmountRwf: number;
  approvedAmountRwf?: number;
  interestRatePct: number;
  durationMonths: number;
  monthlyRepaymentRwf: number;
  status: 'Submitted' | 'AI Assessed' | 'Bank Review' | 'Approved' | 'Disbursed' | 'Rejected' | 'Repaid';
  aiCreditScore: number; // 0-100
  aiEligibilityRecommendation: string;
  repaymentStatusPct: number;
  appliedDate: string;
}

export type InsuranceType = 'Crop Insurance' | 'Livestock Insurance' | 'Weather Index Insurance';

export interface InsuranceProduct {
  id: string;
  providerId: string;
  providerName: string;
  insuranceType: InsuranceType;
  productName: string;
  coveragePerHectareRwf: number;
  annualPremiumRwf: number;
  subsidizedPremiumRwf: number; // Government 50% subsidy
  coveredRiskEvents: string[];
  minimumLossThresholdPct: number;
  termsSummary: string;
}

export interface InsurancePolicy {
  id: string;
  farmerId: string;
  farmerName: string;
  productId: string;
  productName: string;
  providerName: string;
  insuranceType: InsuranceType;
  insuredHectaresOrHeads: number;
  totalPremiumRwf: number;
  farmerPaidRwf: number;
  govSubsidyPaidRwf: number;
  startDate: string;
  endDate: string;
  status: 'Active' | 'Claim Filed' | 'Payout Processed' | 'Expired';
}

export interface InsuranceClaim {
  id: string;
  policyId: string;
  farmerId: string;
  farmerName: string;
  claimReason: string;
  affectedHectaresOrHeads: number;
  estimatedLossRwf: number;
  approvedPayoutRwf: number;
  status: 'Submitted' | 'AI Verified' | 'Insurer Review' | 'Approved' | 'Paid' | 'Rejected';
  evidenceType: 'Photos' | 'AI Vision Report' | 'Satellite NDVI Loss Data' | 'Weather Station Records';
  evidenceSummary: string;
  submissionDate: string;
}

export interface AgriInvestmentProject {
  id: string;
  cooperativeOrFarmerName: string;
  projectTitle: string;
  category: 'Irrigation Dam' | 'Cold Storage Hub' | 'Coffee Processing Expansion' | 'Commercial Poultry Scale';
  targetFundingRwf: number;
  raisedFundingRwf: number;
  minInvestmentRwf: number;
  projectedReturnPct: number;
  tenureMonths: number;
  riskRating: 'Low Risk' | 'Moderate Risk' | 'High Growth';
  summary: string;
  investorCount: number;
  status: 'Funding Open' | 'Fully Funded' | 'In Execution' | 'Dividends Disbursed';
}

// ==========================================
// STEP 36: SATELLITE MONITORING & REMOTE SENSING TYPES
// ==========================================

export type SatelliteConstellation = 'Sentinel-2 Multispectral' | 'Landsat-9 Operational Land Imager' | 'PlanetScope High-Res';

export interface FarmSatelliteMonitoringRecord {
  id: string;
  farmId: string;
  farmName: string;
  farmerName: string;
  district: string;
  province: string;
  cropType: string;
  farmAreaHectares: number;
  lastSatellitePassDate: string;
  constellation: SatelliteConstellation;
  ndviScore: number; // -1.0 to +1.0 (e.g. 0.74 = Healthy)
  ndwiWaterStressIndex: number; // Moisture level
  soilMoisturePct: number;
  canopyChlorophyllMgM2: number;
  cropHealthStatus: 'Optimal Growth' | 'Moderate Vegetation Stress' | 'High Drought Stress' | 'Severe Pest/Disease Decay';
  droughtRiskLevel: 'Low' | 'Moderate' | 'High' | 'Critical';
  historicalNdviComparisonPct: number; // vs previous season
  predictedYieldTonsPerHa: number;
  aiYieldConfidencePct: number;
  cloudCoverPct: number;
  recommendedAction: string;
}

export interface SatelliteNdviTimelinePoint {
  date: string;
  ndviScore: number;
  rainfallMm: number;
  temperatureC: number;
}

// ==========================================
// STEP 37: IOT SMART FARMING & AUTOMATION TYPES
// ==========================================

export type IoTDeviceType = 'Soil Sensor Node' | 'Weather Station' | 'Smart Irrigation Controller' | 'Greenhouse Controller' | 'Livestock Collar Tag';

export type DeviceConnectionStatus = 'Online' | 'Offline' | 'Warning' | 'Maintenance Required';

export interface IoTDevice {
  id: string;
  deviceName: string;
  farmId: string;
  farmName: string;
  deviceType: IoTDeviceType;
  status: DeviceConnectionStatus;
  batteryPct: number;
  signalStrengthDbm: number; // e.g. -78 dBm (LoRaWAN / GSM)
  lastTelemetryTimestamp: string;
  firmwareVersion: string;
  macAddressOrDevEui: string;
  fieldLocation: string;
}

export interface SoilSensorTelemetry {
  moisturePct: number;
  temperatureC: number;
  phLevel: number;
  nitrogenMgKg: number;
  phosphorusMgKg: number;
  potassiumMgKg: number;
  electricalConductivityDsM: number;
}

export interface WeatherStationTelemetry {
  ambientTempC: number;
  humidityPct: number;
  rainfall24hMm: number;
  windSpeedKmH: number;
  solarRadiationWM2: number;
  evapotranspirationMmDay: number;
}

export interface IrrigationControllerTelemetry {
  valveState: 'OPEN (Watering)' | 'CLOSED (Idle)' | 'MAINTENANCE';
  controlMode: 'AI Autonomous' | 'Scheduled' | 'Manual Override';
  waterFlowRateLitersMin: number;
  totalWaterDeliveredTodayLiters: number;
  nextScheduledWatering: string;
}

export interface GreenhouseTelemetry {
  insideTempC: number;
  insideHumidityPct: number;
  co2Ppm: number;
  photosyntheticLightLux: number;
  roofVentPositionPct: number;
  mistingSystemStatus: 'ACTIVE' | 'OFF';
}

export interface LivestockCollarTelemetry {
  animalId: string;
  animalName: string;
  species: 'Dairy Friesian Cow' | 'Boer Goat';
  bodyTempC: number;
  heartRateBpm: number;
  dailyRuminationHours: number;
  gpsLatitude: number;
  gpsLongitude: number;
  healthAlertStatus: 'Healthy' | 'Potential Fever Risk' | 'Low Rumination Alert';
}

export interface IoTAutomationRule {
  id: string;
  ruleName: string;
  sensorTriggerCondition: string; // e.g., "Soil Moisture < 30% AND Rain Forecast < 2mm"
  actionToExecute: string; // e.g., "Open Solenoid Valve #2 for 45 Minutes"
  isActive: boolean;
  lastTriggeredTimestamp: string;
}

export interface IoTAlertNotification {
  id: string;
  deviceId: string;
  deviceName: string;
  severity: 'Info' | 'Warning' | 'Critical';
  title: string;
  message: string;
  timestamp: string;
  isAcknowledged: boolean;
}

// ==========================================
// STEP 38: DRONE AGRICULTURE & AERIAL FARM ANALYSIS TYPES
// ==========================================

export type DroneServiceType =
  | 'High-Res RGB & Boundary Mapping'
  | 'Multispectral Crop Health Scan (NDVI/RE)'
  | 'Plant Stand Density & Counting'
  | 'Targeted Precision Bio-Spraying'
  | 'Thermal Soil Moisture Inspection';

export type FlightStatus = 'Planned' | 'Weather Approved' | 'Active Flight' | 'Completed' | 'Cancelled';

export interface DroneOperator {
  id: string;
  operatorName: string;
  companyName: string;
  rcaaLicenseNumber: string; // Rwanda Civil Aviation Authority License
  certificationStatus: 'RCAA Certified' | 'Pending Audit' | 'RAB Approved';
  phoneContact: string;
  districtBase: string;
  ratingScore: number;
  completedFlightsCount: number;
  fleetSizeCount: number;
  hourlyServiceRateRwf: number;
}

export interface DroneHardware {
  id: string;
  operatorId: string;
  modelName: string; // e.g., 'DJI Agras T40', 'Mavic 3 Multispectral', 'WingtraOne GEN II'
  droneType: 'Quadcopter Sprayer' | 'Multispectral Scout' | 'Fixed-Wing VTOL Mapper';
  payloadSensors: string[]; // e.g., ['5-Band Multispectral', '40L Spray Tank', 'Thermal FLIR']
  maxFlightTimeMins: number;
  maxAreaPerFlightHa: number;
  batteryStatusPct: number;
  rcaaRegistrationNumber: string;
  isAvailable: boolean;
}

export interface DroneFlightRequest {
  id: string;
  farmerName: string;
  farmName: string;
  district: string;
  farmAreaHa: number;
  serviceRequested: DroneServiceType;
  scheduledDate: string;
  offeredFeeRwf: number;
  status: FlightStatus;
  assignedOperatorName: string;
  assignedDroneModel: string;
  flightBoundaryCoordinates: string; // WKT / GeoJSON summary
}

export interface DroneAerialInspectionReport {
  id: string;
  flightRequestId: string;
  farmName: string;
  flightDate: string;
  averageNdviScore: number; // 0.00 - 1.00
  plantStandCountEstimated: number;
  emergedPlantsCountExpected: number;
  emergentRatePct: number;
  detectedStressZonesCount: number;
  pestDiseaseRiskLevel: 'Low' | 'Moderate' | 'Severe (Lethal Necrosis Warning)';
  weedInfestationRatePct: number;
  orthomosaicMapUrl: string;
  aiDiagnosticSummary: string;
  recommendedPrescription: string;
}

export interface PrecisionSprayingPrescription {
  id: string;
  farmName: string;
  targetZoneName: string;
  areaHa: number;
  chemicalOrBioInput: string; // e.g. 'Organic Neem Bio-Pesticide + Liquid Foliar NPK'
  dosagePerHaLiters: number;
  totalLiquidVolumeLiters: number;
  droneFlightAltitudeMeters: number;
  swathWidthMeters: number;
  nozzleFlowRateLmin: number;
  environmentalSafetyStatus: 'Safe Wind (<12km/h) & 50m Water Buffer Compliant';
}

export interface TriDataFusionMatrix {
  farmName: string;
  satelliteData: {
    sensor: string;
    ndviVigor: number;
    droughtIndex: string;
  };
  droneData: {
    resolutionCmPixel: number;
    plantHealthScore: number;
    diseaseHotspotFound: boolean;
  };
  iotSensorData: {
    soilMoisturePct: number;
    soilTempC: number;
    phLevel: number;
  };
  unifiedAiRecommendation: string;
}

// ==========================================
// STEP 39: AGRICULTURAL EDUCATION & FARMER TRAINING ACADEMY TYPES
// ==========================================

export type CourseCategory =
  | 'Crop Production'
  | 'Livestock & Poultry'
  | 'Smart Tech & Drones'
  | 'Agribusiness & Finance'
  | 'Soil & Climate Resilience';

export type CourseDifficulty = 'Beginner' | 'Intermediate' | 'Advanced';

export interface QuizQuestion {
  id: string;
  questionText: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export interface AcademyLesson {
  id: string;
  courseId: string;
  lessonTitle: string;
  durationMins: number;
  videoUrl?: string;
  summaryText: string;
  isCompleted: boolean;
  quiz?: QuizQuestion;
}

export interface AcademyCourse {
  id: string;
  title: string;
  category: CourseCategory;
  instructorName: string;
  instructorTitle: string;
  difficulty: CourseDifficulty;
  totalDurationHours: number;
  totalLessonsCount: number;
  ratingScore: number;
  enrolledStudentsCount: number;
  thumbnailUrl: string;
  description: string;
  skillsLearned: string[];
  isRabCertified: boolean;
  lessons: AcademyLesson[];
}

export interface FarmerCertificate {
  id: string;
  certificateNumber: string; // e.g., 'RAB-CERT-2026-8942'
  farmerName: string;
  courseTitle: string;
  issueDate: string;
  verifiableQrCodeUrl: string;
  rabSealApproved: boolean;
  skillBadgeTitle: string;
}

export interface FarmerGamificationProfile {
  farmerName: string;
  totalLearningPoints: number;
  currentRankBadge: string; // e.g., 'Master Agro-Innovator'
  coursesCompletedCount: number;
  quizzesPassedCount: number;
  districtRankPosition: number;
  districtName: string;
  earnedBadges: { title: string; icon: string; dateEarned: string }[];
}

export interface GovernmentTrainingProgram {
  id: string;
  programTitle: string;
  sponsoringAgency: string; // e.g., 'MINAGRI / RAB / RYAF'
  targetAudience: string;
  enrolledCount: number;
  completionRatePct: number;
  startDate: string;
  endDate: string;
  status: 'Registration Open' | 'In Progress' | 'Completed';
}

export interface CommunityDiscussionPost {
  id: string;
  authorName: string;
  authorRole: string; // e.g. 'Coffee Cooperative Lead'
  postTitle: string;
  postContent: string;
  likesCount: number;
  commentsCount: number;
  createdTime: string;
  topicTag: string;
}

// ==========================================
// STEP 40: AGRICULTURAL DATA MARKETPLACE & AI RESEARCH PLATFORM TYPES
// ==========================================

export type DatasetCategory =
  | 'Crop Yield & Remote Sensing'
  | 'IoT Soil & Telemetry'
  | 'Market Price & Trade'
  | 'AI Vision & Pathology'
  | 'Agri-Credit & Financial';

export type AccessLicenseTier = 'Open Research (Free)' | 'Commercial Enterprise' | 'Government Policy';

export interface AgriculturalDataset {
  id: string;
  title: string;
  category: DatasetCategory;
  providerOrganization: string; // e.g. 'RAB / AGRIWISE Open Data Initiative'
  description: string;
  fileFormat: 'CSV / GeoJSON' | 'Parquet / NetCDF' | 'JSON API' | 'Raster TIFF';
  totalRecordsCount: number;
  dataSizeMb: number;
  licenseTier: AccessLicenseTier;
  priceUsdOrRwf: string; // e.g. 'Free for Academic / $250 API'
  anonymizationStatus: 'Differential Privacy Verified' | 'Aggregated Regional';
  lastUpdatedDate: string;
  samplePreviewSnippet: string;
  downloadUrl?: string;
  tags: string[];
}

export interface FarmerConsentSettings {
  farmerId: string;
  farmerName: string;
  district: string;
  allowAnonymizedYieldSharing: boolean;
  allowIoTTelemetryResearch: boolean;
  allowMarketplaceTradeInsights: boolean;
  optInMonetizationDividend: boolean; // Earn micro-royalties when research datasets sell
  accumulatedDataRoyaltiesRwf: number;
}

export interface DataAccessRequest {
  id: string;
  researcherName: string;
  organizationName: string; // e.g. 'University of Rwanda / ICRISAT'
  projectTitle: string;
  datasetId: string;
  requestedLicense: AccessLicenseTier;
  requestDate: string;
  status: 'Approved' | 'Pending Review' | 'Rejected';
  approvalToken?: string;
}

export interface ResearchPublication {
  id: string;
  paperTitle: string;
  authors: string[];
  institution: string;
  publishedDate: string;
  datasetUsedId: string;
  abstract: string;
  doiOrUrl: string;
  citationCount: number;
}

export interface DeveloperApiKey {
  id: string;
  keyName: string;
  apiKeyString: string; // e.g., 'agriwise_live_8942a7f...'
  organization: string;
  createdDate: string;
  dailyQueryLimit: number;
  queriesUsedToday: number;
  status: 'Active' | 'Revoked';
}

export interface AiModelRetrainingLog {
  id: string;
  modelName: string; // e.g., 'AGRIWISE Vision Pathology Net'
  currentVersion: string; // e.g. 'v4.2.0'
  trainingSampleCount: number;
  accuracyScorePct: number;
  lastRetrainedDate: string;
  expertFeedbacksProcessed: number;
  status: 'Deployed in Production' | 'Training in Progress';
}

// STEP 41: Global Expansion & Multi-Country Architecture Types
export interface CountryConfig {
  id: string;
  code: string; // 'RW' | 'KE' | 'UG' | 'TZ' | 'ET' | 'NG' | 'GH' | 'CI'
  name: string;
  flagEmoji: string;
  currencyCode: string;
  currencySymbol: string;
  exchangeRateToUsd: number; // e.g. 1 USD = 1350 RWF
  officialLanguages: string[];
  primaryCrops: string[];
  agriMinistryName: string;
  totalFarmersRegistered: number;
  totalHectaresMapped: number;
  activeCooperativesCount: number;
  paymentGateways: string[];
  dataResidencyRegion: string;
  status: 'Active Node' | 'Pilot Phase' | 'Planned Node';
}

export interface CrossBorderTradeListing {
  id: string;
  originCountryCode: string;
  destinationCountryCode: string;
  exporterName: string;
  importerName: string;
  cropName: string;
  quantityTons: number;
  unitPriceUsd: number;
  totalValueUsd: number;
  currencyLocal: string;
  phytosanitaryCertified: boolean;
  eacCustomsCleared: boolean;
  shipmentStatus: 'In Transit' | 'Customs Verification' | 'Delivered' | 'Pending Escrow';
  estimatedArrivalDate: string;
}

export interface InternationalPartner {
  id: string;
  name: string; // e.g. 'FAO', 'WFP', 'AfDB', 'AGRA', 'World Bank'
  type: 'Multilateral NGO' | 'Development Bank' | 'Government Agency' | 'Research Institute';
  participatingCountries: string[];
  activeProgramsCount: number;
  grantFundingUsd: number;
  beneficiaryFarmersCount: number;
  focusArea: string;
  status: 'Strategic Partner' | 'Funding Partner' | 'Implementation Partner';
}

export interface GlobalRegionalAnalytics {
  regionName: string; // e.g. 'East Africa (EAC)', 'West Africa (ECOWAS)'
  memberCountriesCount: number;
  totalSmallholderFarmers: number;
  totalArableLandHectares: number;
  annualGrainProductionTons: number;
  crossBorderTradeVolumeUsd: number;
  dominantClimateZones: string[];
  droughtRiskAlertLevel: 'Low' | 'Moderate' | 'Severe' | 'Critical';
}

// STEP 46: Performance Optimization & Cloud Infrastructure Types
export interface MicroserviceHealth {
  id: string;
  name: string; // e.g. 'auth-service', 'ai-vision-service', 'gis-service'
  status: 'Healthy' | 'Degraded' | 'Down' | 'Autoscaling';
  replicas: number;
  cpuUsagePct: number;
  memoryUsageMb: number;
  latencyP95Ms: number;
  requestsPerSec: number;
  region: string;
}

export interface DatabasePartitionMetric {
  partitionName: string; // e.g. 'rwanda_district_nodes', 'satellite_raster_index'
  totalRecords: number;
  storageGb: number;
  readReplicaCount: number;
  avgQueryTimeMs: number;
  cacheHitRatioPct: number;
}

export interface CacheClusterMetric {
  clusterName: string;
  type: 'Redis L2 Distributed' | 'CDN Edge Cache' | 'In-Memory L1';
  totalKeys: number;
  memoryUsedMb: number;
  hitRatioPct: number;
  evictionCount: number;
}

export interface OfflineSyncQueueStatus {
  totalPendingDeltas: number;
  activeRuralNodesSyncing: number;
  avgCompressionRatioPct: number; // e.g. 92% bandwidth saved
  syncSuccessRatePct: number;
  failedConflictsCount: number;
}

export interface CloudInfrastructureSummary {
  clusterStatus: 'Operational (99.99% Uptime SLA)';
  totalActiveContainers: number;
  globalRps: number;
  p50LatencyMs: number;
  p95LatencyMs: number;
  p99LatencyMs: number;
  monthlyCloudCostUsd: number;
  spotSavingsPercentage: number;
  dataResidencyRegions: string[];
}

// STEP 47: Testing, Quality Assurance & Product Validation Types
export interface TestCaseItem {
  id: string;
  module: 'Auth' | 'Farmer' | 'Marketplace' | 'Finance' | 'AI System' | 'GIS Satellite' | 'IoT & Drone' | 'Government' | 'Security';
  title: string;
  description: string;
  type: 'Unit' | 'Integration' | 'E2E' | 'Regression' | 'Security' | 'UAT';
  status: 'PASSED' | 'FAILED' | 'IN_PROGRESS' | 'BLOCKED';
  executionTimeMs: number;
  automated: boolean;
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  lastRunTimestamp: string;
}

export interface AiModelValidationMetric {
  modelName: string; // e.g. 'Gemini Crop Disease Vision', 'Yield Predictor', 'Kinyarwanda Speech Copilot'
  accuracyPct: number;
  precisionPct: number;
  recallPct: number;
  f1ScorePct: number;
  falsePositiveRatePct: number;
  avgInferenceLatencyMs: number;
  validationDatasetSize: number;
  status: 'RELEASE_READY' | 'NEEDS_RETRAINING' | 'DEGRADED';
}

export interface SecurityVulnerabilityScan {
  scanCategory: 'OWASP Top 10' | 'OAuth 2.0 & JWT' | 'SQLi & PostGIS Injection' | 'XSS & CSRF' | 'Rate Limiting' | 'GDPR & AfCFTA Privacy';
  status: 'CLEAN' | 'WARNING' | 'CRITICAL';
  passedChecks: number;
  totalChecks: number;
  lastAuditDate: string;
  vulnerabilityDetails: string;
}

export interface LoadTestBenchmark {
  simulatedConcurrentUsers: number;
  targetCategory: '1k Baseline' | '10k Regional Peak' | '100k Harvest Spike' | '1M Enterprise Scale';
  p95LatencyMs: number;
  errorRatePct: number;
  throughputRps: number;
  cpuUtilizationPct: number;
  memoryUtilizationPct: number;
  status: 'PASSED_SLA' | 'WARNING' | 'FAILED';
}

export interface ReleaseReadinessChecklist {
  moduleName: string;
  unitTestPassRatePct: number;
  e2eTestPassRatePct: number;
  securityAuditPassed: boolean;
  uatApprovalCount: number;
  goNoGoStatus: 'GO_FOR_PRODUCTION' | 'PENDING_SIGN_OFF' | 'HOLD';
  ownerSignoff: string;
}

// STEP 50: Company Launch & Product Release Types
export interface ReleaseFeatureHighlight {
  moduleNumber: string;
  featureName: string;
  category: 'Core AI' | 'FinTech & Escrow' | 'GIS & Satellite' | 'Supply Chain' | 'Enterprise SaaS';
  status: 'Production Ready' | 'Certified';
  description: string;
}

export interface LaunchChecklistItem {
  category: string; // e.g. 'Production Infrastructure', 'Security & Compliance', 'Legal & Terms', 'Mobile Apps', 'Marketing & Media'
  itemTitle: string;
  owner: string;
  isCompleted: boolean;
}

export interface ProductRoadmapMilestone {
  version: string; // 'v1.0 (Current)', 'v1.1 (Q4 2026)', 'v2.0 (2027)', 'v3.0 (2028-2030)'
  targetDate: string;
  focusArea: string;
  keyDeliverables: string[];
}

export interface PricingTierPlan {
  id: string;
  name: string; // e.g. 'Farmer Free', 'Coop Starter', 'Commercial Pro', 'Enterprise Agribusiness', 'Government Sovereign'
  priceMonthlyUsd: number;
  priceAnnualUsd: number;
  targetAudience: string;
  includedAiQueriesPerMonth: number | 'Unlimited';
  maxMappedFarms: number | 'Unlimited';
  storageLimitGb: number | 'Unlimited';
  features: string[];
  recommendedBadge?: string;
}

export interface RevenueStreamBreakdown {
  streamName: string; // e.g. 'SaaS Subscriptions', 'Marketplace Commissions (2.5%)', 'MoMo Loan Referral Fee (1.5%)', 'Pay-per-Scan Drone/Lab', 'Enterprise Data API'
  mrrContributionUsd: number;
  percentageOfTotal: number;
  annualGrowthRatePct: number;
  description: string;
}

export interface PlatformFinancialKpi {
  mrrUsd: number;
  arrUsd: number;
  cacUsd: number;
  ltvUsd: number;
  ltvToCacRatio: number;
  monthlyChurnRatePct: number;
  arpuUsd: number;
  grossMarginPct: number;
  paybackPeriodMonths: number;
}

export interface FiveYearFinancialProjection {
  year: number; // e.g. 2026, 2027, 2028, 2029, 2030
  activeFarmersCount: number;
  activeCooperativesCount: number;
  annualRevenueUsd: number;
  grossProfitUsd: number;
  ebitdaUsd: number;
  expansionCountries: number;
}

export interface USSDUser {
  phoneNumber: string;
  name?: string;
  language: 'rw' | 'en' | 'fr';
  district?: string;
  sector?: string;
  village?: string;
  farmSizeHa?: number;
  mainCrops?: string[];
  livestockType?: string;
  registeredAt: string;
}

export interface USSDSession {
  sessionId: string;
  phoneNumber: string;
  currentMenuPath: string; // e.g., 'main', 'register_name', 'market_crop'
  language: 'rw' | 'en' | 'fr';
  tempData: Record<string, any>;
  lastActive: string;
}

export interface USSDRequestLog {
  id: string;
  sessionId: string;
  phoneNumber: string;
  rawInput: string;
  responseText: string;
  responseType: 'CON' | 'END';
  timestamp: string;
  operator: 'MTN' | 'Airtel';
}

export interface VoiceCallLog {
  callId: string;
  phoneNumber: string;
  farmerName?: string;
  language: 'rw' | 'en' | 'fr';
  durationSeconds: number;
  status: 'completed' | 'transferred' | 'failed' | 'in-progress';
  transcriptSummary: string;
  aiSentiment: 'positive' | 'neutral' | 'urgent' | 'distressed';
  transferredToExpert: boolean;
  expertName?: string;
  timestamp: string;
  smsFollowupSent: boolean;
}

export interface VoiceTranscriptTurn {
  id: string;
  callId: string;
  speaker: 'user' | 'ai' | 'expert';
  text: string;
  timestamp: string;
  confidenceScore?: number;
}

export interface SMSMessageLog {
  id: string;
  phoneNumber: string;
  messageBody: string;
  status: 'delivered' | 'pending' | 'failed';
  gateway: 'MTN SMS API' | 'Airtel SMS Gateway';
  type: 'USSD_RECEIPT' | 'VOICE_SUMMARY' | 'MARKET_ALERT' | 'WEATHER_WARNING';
  timestamp: string;
}

export interface ExpertTransferTicket {
  id: string;
  callId: string;
  phoneNumber: string;
  farmerName: string;
  district: string;
  issueTopic: string;
  urgency: 'low' | 'medium' | 'critical';
  assignedExpert: string;
  status: 'pending' | 'connected' | 'resolved';
  createdAt: string;
}

// ==========================================
// OWNER IDENTITY & NOTIFICATION SYSTEM TYPES
// ==========================================

export interface OwnerConfig {
  ownerUserId: string;
  ownerName: string;
  ownerEmail: string;
  ownerPhone: string;
  smsE164Phone: string;
  emailProvider: string;
  smsProvider: string;
  lastUpdated: string;
}

export type NotificationType =
  | 'user'
  | 'transaction'
  | 'marketplace'
  | 'message'
  | 'support'
  | 'security'
  | 'system';

export type NotificationPriority = 'low' | 'medium' | 'high' | 'critical';

export type EmailDeliveryStatus = 'SENT' | 'FAILED' | 'SIMULATED' | 'QUEUED' | 'IN_APP_ONLY';

export interface OwnerNotification {
  id: string;
  recipientUserId: string;
  type: NotificationType;
  title: string;
  message: string;
  relatedUserId?: string;
  relatedUserName?: string;
  relatedUserPhone?: string;
  relatedUserEmail?: string;
  relatedUserRole?: UserRole;
  relatedRecordId?: string;
  relatedRecordType?: 'farm' | 'order' | 'registration' | 'support_ticket' | 'complaint' | 'security_event' | 'listing' | 'verification';
  priority: NotificationPriority;
  isRead: boolean;
  createdAt: string;
  activitySubtype?: string;
  emailDeliveryStatus?: EmailDeliveryStatus;
  emailSentAt?: string;
  emailRecipient?: string;
  emailMessageId?: string;
  channelsDelivered?: ('in_app' | 'email' | 'sms')[];
}

export interface UserNotificationPreferences {
  emailNotifications: boolean;
  systemNotifications: boolean;
  salesNotifications: boolean;
  paymentNotifications: boolean;
  securityAlerts: boolean; // Must always remain true
  updatedAt?: string;
}

export interface NotificationPreferenceItem {
  eventCategory: string;
  label: string;
  dashboardEnabled: boolean;
  emailEnabled: boolean;
  smsEnabled: boolean;
}

export interface OwnerNotificationPreferences {
  userId: string;
  preferences: NotificationPreferenceItem[];
  updatedAt: string;
}

export interface AuditLogRecord {
  id: string;
  userId: string;
  userName: string;
  action: string;
  description: string;
  ipAddress: string;
  timestamp: string;
  relatedRecordId?: string;
  status: 'SUCCESS' | 'FAILED' | 'BLOCKED' | 'WARNING';
}

// ==========================================
// PHASE 4: SALES, CUSTOMER & TRANSACTION ENGINE
// ==========================================

export type CustomerType = 'individual' | 'business' | 'cooperative' | 'institution';
export type CustomerStatus = 'active' | 'archived';

export interface CustomerDoc {
  customerId: string;
  businessId: string;
  ownerId?: string;
  name: string;
  phone?: string;
  email?: string;
  address?: string;
  customerType: CustomerType;
  status: CustomerStatus;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export type SaleStatus = 'draft' | 'completed' | 'cancelled' | 'refunded';
export type SalePaymentStatus = 'unpaid' | 'pending' | 'paid' | 'partial' | 'refunded';
export type SalePaymentMethod = 'Cash' | 'Bank' | 'Mobile Money' | 'Credit' | 'Other';

export interface SaleDoc {
  saleId: string;
  businessId: string;
  ownerId?: string;
  customerId?: string;
  customerName?: string;
  saleNumber: string; // e.g., 'AGR-000001'
  status: SaleStatus;
  subtotal: number;
  discount: number;
  tax: number; // default: 0
  total: number;
  currency: string; // 'RWF'
  paymentStatus: SalePaymentStatus;
  paymentMethod: SalePaymentMethod;
  createdBy: string;
  createdByName?: string;
  createdAt: string;
  updatedAt: string;

  // Cancellation & Refund tracking
  cancelledBy?: string;
  cancelledAt?: string;
  cancelReason?: string;
}

export interface SaleItemDoc {
  saleItemId: string;
  saleId: string;
  businessId: string;
  ownerId?: string;
  productId: string;
  productName: string;
  sku?: string;
  quantity: number;
  unitPrice: number; // selling unit price in RWF at time of sale
  costPrice: number; // cost unit price in RWF at time of sale
  discount: number;
  subtotal: number;
  createdAt: string;
}

export interface SalesDashboardStats {
  todaysSalesCount: number;
  todaysRevenueRwf: number;
  totalSalesCount: number;
  totalRevenueRwf: number;
  completedSalesCount: number;
  unpaidSalesCount: number;
  cancelledSalesCount: number;
}

export interface CustomerSummary {
  customer: CustomerDoc;
  totalPurchasesRwf: number;
  salesCount: number;
  lastPurchaseDate?: string;
}

// ===================================================
// AGRICULTURAL EDUCATIONAL VIDEO MANAGEMENT TYPES
// ===================================================

export type EducationalVideoStatus = 'DRAFT' | 'PENDING_REVIEW' | 'APPROVED' | 'PUBLISHED' | 'REJECTED';
export type VideoCertificationStatus = 'NONE' | 'RAB_CERTIFIED' | 'MINAGRI_CERTIFIED';

export interface EducationalVideo {
  id: string;
  title: string;
  description: string;
  category: string;
  topic: string;
  language: 'rw' | 'en' | 'fr' | 'all';
  targetAudience: string;
  district?: string;
  crop?: string;
  livestock?: string;
  videoUrl: string;
  videoStoragePath?: string;
  thumbnailUrl: string;
  thumbnailStoragePath?: string;
  duration: number; // in seconds
  fileSize: number; // in bytes
  status: EducationalVideoStatus;
  certificationStatus?: VideoCertificationStatus;
  uploadedBy: {
    id: string;
    name: string;
    role: string;
    email?: string;
  };
  uploadedAt: string; // ISO format
  updatedAt: string; // ISO format
  publishedAt?: string | null;
  viewsCount?: number;
  featured?: boolean;
}

export interface EducationalVideoFilterOptions {
  searchQuery?: string;
  category?: string;
  topic?: string;
  language?: string;
  targetAudience?: string;
  status?: 'ALL' | EducationalVideoStatus;
  district?: string;
  crop?: string;
}


