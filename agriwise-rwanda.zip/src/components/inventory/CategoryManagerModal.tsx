import React, { useState, useEffect } from 'react';
import { Tag, Plus, Check, Loader2, Sparkles, FolderPlus, Trash2, X } from 'lucide-react';
import { Category } from '../../types';
import { getCategoriesDoc, createCategoryDoc, archiveCategoryDoc, seedRecommendedCategoriesDoc } from '../../services/firestoreService';

interface CategoryManagerModalProps {
  businessId: string;
  userId: string;
  isOpen: boolean;
  onClose: () => void;
  onCategoryAdded?: () => void;
}

export const CategoryManagerModal: React.FC<CategoryManagerModalProps> = ({
  businessId,
  userId,
  isOpen,
  onClose,
  onCategoryAdded,
}) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [newCatName, setNewCatName] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const loadCategories = async () => {
    if (!businessId) return;
    setLoading(true);
    try {
      const list = await getCategoriesDoc(businessId);
      setCategories(list);
    } catch (e) {
      console.error('Error loading categories:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && businessId) {
      loadCategories();
    }
  }, [isOpen, businessId]);

  if (!isOpen) return null;

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) {
      setError('Category name is required');
      return;
    }
    setSubmitting(true);
    setError(null);
    setSuccess(null);
    try {
      await createCategoryDoc({
        businessId,
        name: newCatName.trim(),
        description: newCatDesc.trim(),
        createdByUid: userId,
      });
      setNewCatName('');
      setNewCatDesc('');
      setSuccess('Category created successfully');
      await loadCategories();
      if (onCategoryAdded) onCategoryAdded();
    } catch (err: any) {
      setError(err.message || 'Failed to create category');
    } finally {
      setSubmitting(false);
    }
  };

  const handleArchive = async (catId: string) => {
    try {
      await archiveCategoryDoc(catId, businessId, userId);
      await loadCategories();
      if (onCategoryAdded) onCategoryAdded();
    } catch (err: any) {
      setError('Failed to remove category');
    }
  };

  const handleSeedRecommended = async () => {
    if (!window.confirm('Do you want to add 15 recommended business & agriculture categories to your account catalog?')) {
      return;
    }
    setSeeding(true);
    setError(null);
    setSuccess(null);
    try {
      await seedRecommendedCategoriesDoc(businessId, userId);
      setSuccess('Recommended categories added!');
      await loadCategories();
      if (onCategoryAdded) onCategoryAdded();
    } catch (err: any) {
      setError('Failed to seed categories');
    } finally {
      setSeeding(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-6 text-white shadow-2xl space-y-6 relative">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-2xl border border-emerald-500/20">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Category Management</h2>
              <p className="text-xs text-slate-400">Manage product categories for your catalog</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notifications */}
        {error && (
          <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs p-3 rounded-xl">
            {error}
          </div>
        )}
        {success && (
          <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs p-3 rounded-xl flex items-center space-x-2">
            <Check className="w-4 h-4" />
            <span>{success}</span>
          </div>
        )}

        {/* Create Category Form */}
        <form onSubmit={handleCreate} className="space-y-3 bg-slate-800/50 p-4 rounded-2xl border border-slate-700/50">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
            <FolderPlus className="w-4 h-4 text-emerald-400" />
            <span>Add Custom Category</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-medium text-slate-400">Category Name *</label>
              <input
                type="text"
                placeholder="e.g. Certified Hybrid Seeds"
                value={newCatName}
                onChange={e => setNewCatName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 mt-1"
                required
              />
            </div>
            <div>
              <label className="text-[11px] font-medium text-slate-400">Description (Optional)</label>
              <input
                type="text"
                placeholder="e.g. Maize, Bean & Potato seeds"
                value={newCatDesc}
                onChange={e => setNewCatDesc(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 mt-1"
              />
            </div>
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={submitting}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2 rounded-xl flex items-center space-x-1.5 transition disabled:opacity-50"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              <span>Save Category</span>
            </button>
          </div>
        </form>

        {/* Recommended Action */}
        <div className="flex items-center justify-between bg-emerald-950/30 border border-emerald-500/20 p-3.5 rounded-2xl">
          <div>
            <h4 className="text-xs font-bold text-emerald-300 flex items-center space-x-1.5">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Recommended Agricultural Categories</span>
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">Quickly add 15 standard Rwanda agriculture & trade categories.</p>
          </div>
          <button
            onClick={handleSeedRecommended}
            disabled={seeding}
            className="bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 border border-emerald-500/30 font-bold text-xs px-3 py-2 rounded-xl flex items-center space-x-1.5 transition disabled:opacity-50"
          >
            {seeding ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>Add Recommended</span>
          </button>
        </div>

        {/* Categories List */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Active Business Categories ({categories.length})
          </h3>
          {loading ? (
            <div className="flex items-center justify-center p-8 text-slate-400 text-xs">
              <Loader2 className="w-5 h-5 animate-spin mr-2" />
              <span>Loading categories...</span>
            </div>
          ) : categories.length === 0 ? (
            <div className="bg-slate-800/40 border border-slate-800 rounded-2xl p-6 text-center text-slate-400 text-xs">
              No custom categories yet. Click "Add Recommended" or create one above.
            </div>
          ) : (
            <div className="max-h-60 overflow-y-auto space-y-2 pr-1">
              {categories.map(cat => (
                <div
                  key={cat.categoryId}
                  className="flex items-center justify-between bg-slate-800/60 border border-slate-700/50 rounded-xl p-3 text-xs"
                >
                  <div>
                    <span className="font-bold text-white">{cat.name}</span>
                    {cat.description && <p className="text-[11px] text-slate-400 mt-0.5">{cat.description}</p>}
                  </div>
                  <button
                    onClick={() => handleArchive(cat.categoryId)}
                    className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition"
                    title="Archive Category"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="pt-2 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs px-5 py-2.5 rounded-xl transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
