import React, { useState, useEffect } from 'react';
import { Package, X, Loader2, DollarSign, Tag, Check } from 'lucide-react';
import { Product, Category } from '../../types';
import { createProductDoc, updateProductDoc, getCategoriesDoc } from '../../services/firestoreService';

interface ProductFormModalProps {
  businessId: string;
  userId: string;
  userName: string;
  editingProduct?: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const ProductFormModal: React.FC<ProductFormModalProps> = ({
  businessId,
  userId,
  userName,
  editingProduct,
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [categoryName, setCategoryName] = useState('');
  const [sku, setSku] = useState('');
  const [barcode, setBarcode] = useState('');
  const [unit, setUnit] = useState('50kg Bag');
  const [sellingPrice, setSellingPrice] = useState<number | ''>(0);
  const [costPrice, setCostPrice] = useState<number | ''>(0);
  const [initialQuantity, setInitialQuantity] = useState<number | ''>(10);
  const [minimumStockLevel, setMinimumStockLevel] = useState<number | ''>(5);
  const [imageUrl, setImageUrl] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && businessId) {
      loadCategories();
      if (editingProduct) {
        setName(editingProduct.name);
        setDescription(editingProduct.description || '');
        setCategoryId(editingProduct.categoryId);
        setCategoryName(editingProduct.categoryName);
        setSku(editingProduct.sku || '');
        setBarcode(editingProduct.barcode || '');
        setUnit(editingProduct.unit);
        setSellingPrice(editingProduct.sellingPrice);
        setCostPrice(editingProduct.costPrice);
        setInitialQuantity(editingProduct.quantity);
        setMinimumStockLevel(editingProduct.minimumStockLevel);
        setImageUrl(editingProduct.imageUrl || '');
      } else {
        setName('');
        setDescription('');
        setSku('');
        setBarcode('');
        setUnit('50kg Bag');
        setSellingPrice('');
        setCostPrice('');
        setInitialQuantity('');
        setMinimumStockLevel(5);
        setImageUrl('');
      }
    }
  }, [isOpen, businessId, editingProduct]);

  const loadCategories = async () => {
    try {
      const list = await getCategoriesDoc(businessId);
      setCategories(list);
      if (list.length > 0 && !editingProduct) {
        setCategoryId(list[0].categoryId);
        setCategoryName(list[0].name);
      }
    } catch (e) {
      console.error('Failed to load categories:', e);
    }
  };

  if (!isOpen) return null;

  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedId = e.target.value;
    setCategoryId(selectedId);
    const cat = categories.find(c => c.categoryId === selectedId);
    if (cat) setCategoryName(cat.name);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError('Product name is required');
      return;
    }
    if (!categoryId) {
      setError('Please select or create a category');
      return;
    }
    if (sellingPrice === '' || Number(sellingPrice) < 0) {
      setError('Selling price must be a non-negative number');
      return;
    }
    if (costPrice === '' || Number(costPrice) < 0) {
      setError('Cost price must be a non-negative number');
      return;
    }

    setLoading(true);

    try {
      if (editingProduct) {
        await updateProductDoc({
          productId: editingProduct.productId,
          businessId,
          name: name.trim(),
          description: description.trim(),
          categoryId,
          categoryName: categoryName || 'General',
          sku,
          barcode,
          unit,
          sellingPrice: Number(sellingPrice),
          costPrice: Number(costPrice),
          minimumStockLevel: Number(minimumStockLevel || 5),
          imageUrl,
          updatedByUid: userId,
          updatedByName: userName,
        });
      } else {
        await createProductDoc({
          businessId,
          ownerId: userId,
          name: name.trim(),
          description: description.trim(),
          categoryId,
          categoryName: categoryName || 'General',
          sku,
          barcode,
          unit,
          sellingPrice: Number(sellingPrice),
          costPrice: Number(costPrice),
          initialQuantity: Number(initialQuantity || 0),
          minimumStockLevel: Number(minimumStockLevel || 5),
          imageUrl,
          createdByUid: userId,
          createdByName: userName,
        });
      }

      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save product');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 text-white shadow-2xl space-y-6 my-8">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-2xl border border-emerald-500/20">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold">
                {editingProduct ? 'Edit Stock SKU' : 'Add New Product SKU'}
              </h2>
              <p className="text-xs text-slate-400">
                {editingProduct ? 'Update product pricing and properties' : 'Register product SKU in Firestore inventory'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs p-3.5 rounded-2xl">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Row 1: Name & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-slate-400 font-medium block mb-1">Product Name *</label>
              <input
                type="text"
                placeholder="e.g. NPK 17-17-17 Premium Fertilizer"
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="text-slate-400 font-medium block mb-1">Category *</label>
              <select
                value={categoryId}
                onChange={handleCategoryChange}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-emerald-300 font-medium focus:outline-none focus:border-emerald-500"
                required
              >
                {categories.length === 0 && <option value="">No Categories Available</option>}
                {categories.map(c => (
                  <option key={c.categoryId} value={c.categoryId}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="text-slate-400 font-medium block mb-1">Description</label>
            <textarea
              placeholder="RAB certified agricultural fertilizer suitable for Irish Potato and Maize..."
              value={description}
              onChange={e => setDescription(e.target.value)}
              rows={2}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Row 2: Prices */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-800/40 p-4 rounded-2xl border border-slate-700/50">
            <div>
              <label className="text-emerald-400 font-bold block mb-1 flex items-center justify-between">
                <span>Selling Price (RWF) *</span>
                <span className="text-[10px] text-slate-400 font-normal">Customer Price</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  placeholder="e.g. 48000"
                  value={sellingPrice}
                  onChange={e => setSellingPrice(e.target.value === '' ? '' : Number(e.target.value))}
                  min={0}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-3.5 pr-12 py-2.5 text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
                  required
                />
                <span className="absolute right-3 top-3 text-[10px] font-bold text-emerald-400">RWF</span>
              </div>
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-1 flex items-center justify-between">
                <span>Cost Price (RWF) *</span>
                <span className="text-[10px] text-slate-400 font-normal">Wholesale Purchase Price</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  placeholder="e.g. 42000"
                  value={costPrice}
                  onChange={e => setCostPrice(e.target.value === '' ? '' : Number(e.target.value))}
                  min={0}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-3.5 pr-12 py-2.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                  required
                />
                <span className="absolute right-3 top-3 text-[10px] font-bold text-slate-400">RWF</span>
              </div>
            </div>
          </div>

          {/* Row 3: Unit, Stock, Min Reorder */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-slate-400 font-medium block mb-1">Unit of Measure *</label>
              <select
                value={unit}
                onChange={e => setUnit(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="50kg Bag">50kg Bag</option>
                <option value="25kg Bag">25kg Bag</option>
                <option value="10kg Pack">10kg Pack</option>
                <option value="2kg Pack">2kg Pack</option>
                <option value="1L Bottle">1L Bottle</option>
                <option value="500ml Bottle">500ml Bottle</option>
                <option value="Kilogram (kg)">Kilogram (kg)</option>
                <option value="Piece / Item">Piece / Item</option>
                <option value="Dose / Vial">Dose / Vial</option>
              </select>
            </div>

            {!editingProduct && (
              <div>
                <label className="text-slate-400 font-medium block mb-1">Initial Stock Qty *</label>
                <input
                  type="number"
                  placeholder="10"
                  value={initialQuantity}
                  onChange={e => setInitialQuantity(e.target.value === '' ? '' : Number(e.target.value))}
                  min={0}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>
            )}

            <div>
              <label className="text-slate-400 font-medium block mb-1">Low Stock Alert Level *</label>
              <input
                type="number"
                placeholder="5"
                value={minimumStockLevel}
                onChange={e => setMinimumStockLevel(e.target.value === '' ? '' : Number(e.target.value))}
                min={0}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                required
              />
            </div>
          </div>

          {/* Row 4: SKU & Image URL */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 font-medium block mb-1">SKU / Code (Optional)</label>
              <input
                type="text"
                placeholder="Auto-generated if empty"
                value={sku}
                onChange={e => setSku(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-white font-mono placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-slate-400 font-medium block mb-1">Image URL (Optional)</label>
              <input
                type="text"
                placeholder="https://..."
                value={imageUrl}
                onChange={e => setImageUrl(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Form Controls */}
          <div className="pt-4 border-t border-slate-800 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-4 py-2.5 rounded-xl transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-6 py-2.5 rounded-xl shadow-lg flex items-center space-x-2 transition disabled:opacity-50"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              <span>{editingProduct ? 'Save Changes' : 'Create Product SKU'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
