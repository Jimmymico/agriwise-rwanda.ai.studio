import React, { useState } from 'react';
import { Box, ArrowUpRight, ArrowDownRight, RefreshCw, X, Loader2, AlertTriangle, CheckCircle } from 'lucide-react';
import { Product } from '../../types';
import {
  performStockInTransaction,
  performStockAdjustmentTransaction,
  performStockOutTransaction
} from '../../services/firestoreService';

interface StockOperationModalProps {
  product: Product | null;
  businessId: string;
  userId: string;
  userName: string;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

type Mode = 'STOCK_IN' | 'ADJUSTMENT' | 'STOCK_OUT';

export const StockOperationModal: React.FC<StockOperationModalProps> = ({
  product,
  businessId,
  userId,
  userName,
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [mode, setMode] = useState<Mode>('STOCK_IN');
  const [quantity, setQuantity] = useState<number | ''>('');
  const [targetQuantity, setTargetQuantity] = useState<number | ''>('');
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen || !product) return null;

  const currentQty = product.quantity || 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    setLoading(true);

    try {
      if (mode === 'STOCK_IN') {
        const addQty = Number(quantity);
        if (!addQty || addQty <= 0) {
          throw new Error('Stock-in quantity must be greater than zero.');
        }
        await performStockInTransaction({
          businessId,
          productId: product.productId,
          addQuantity: addQty,
          reason: reason.trim() || 'Restock Shipment Deposit',
          createdByUid: userId,
          createdByName: userName,
        });
      } else if (mode === 'ADJUSTMENT') {
        const target = Number(targetQuantity);
        if (targetQuantity === '' || isNaN(target)) {
          throw new Error('Target inventory quantity is required.');
        }
        if (target < 0) {
          throw new Error('Negative stock protection: Stock quantity cannot be negative.');
        }
        if (!reason.trim()) {
          throw new Error('Reason is required for inventory stock audit adjustments.');
        }
        await performStockAdjustmentTransaction({
          businessId,
          productId: product.productId,
          targetQuantity: target,
          reason: reason.trim(),
          createdByUid: userId,
          createdByName: userName,
        });
      } else if (mode === 'STOCK_OUT') {
        const deductQty = Number(quantity);
        if (!deductQty || deductQty <= 0) {
          throw new Error('Deduction quantity must be greater than zero.');
        }
        if (deductQty > currentQty) {
          throw new Error(`Negative stock protection: Cannot deduct ${deductQty} from available stock of ${currentQty}.`);
        }
        await performStockOutTransaction({
          businessId,
          productId: product.productId,
          deductQuantity: deductQty,
          reason: reason.trim() || 'Stock Removal / Loss',
          createdByUid: userId,
          createdByName: userName,
        });
      }

      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Stock operation failed.');
    } finally {
      setLoading(false);
    }
  };

  const delta = targetQuantity !== '' ? Number(targetQuantity) - currentQty : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 text-white shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-2xl border border-emerald-500/20">
              <Box className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">{product.name}</h2>
              <p className="text-xs text-slate-400">
                SKU: <span className="text-emerald-400 font-mono">{product.sku}</span> • Current Stock: <span className="text-white font-mono font-bold">{currentQty} {product.unit}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector */}
        <div className="grid grid-cols-3 gap-2 bg-slate-800/80 p-1.5 rounded-2xl border border-slate-700 text-xs font-bold">
          <button
            type="button"
            onClick={() => { setMode('STOCK_IN'); setError(null); }}
            className={`py-2 px-3 rounded-xl flex items-center justify-center space-x-1.5 transition ${
              mode === 'STOCK_IN'
                ? 'bg-emerald-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ArrowUpRight className="w-4 h-4 text-emerald-300" />
            <span>Add Stock</span>
          </button>

          <button
            type="button"
            onClick={() => { setMode('ADJUSTMENT'); setError(null); }}
            className={`py-2 px-3 rounded-xl flex items-center justify-center space-x-1.5 transition ${
              mode === 'ADJUSTMENT'
                ? 'bg-amber-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <RefreshCw className="w-4 h-4 text-amber-200" />
            <span>Adjust Total</span>
          </button>

          <button
            type="button"
            onClick={() => { setMode('STOCK_OUT'); setError(null); }}
            className={`py-2 px-3 rounded-xl flex items-center justify-center space-x-1.5 transition ${
              mode === 'STOCK_OUT'
                ? 'bg-rose-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ArrowDownRight className="w-4 h-4 text-rose-300" />
            <span>Remove Stock</span>
          </button>
        </div>

        {error && (
          <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs p-3.5 rounded-2xl flex items-start space-x-2">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {mode === 'STOCK_IN' && (
            <div>
              <label className="text-slate-300 font-bold block mb-1">
                Quantity to Deposit ({product.unit}) *
              </label>
              <input
                type="number"
                placeholder="e.g. 20"
                value={quantity}
                onChange={e => setQuantity(e.target.value === '' ? '' : Number(e.target.value))}
                min={1}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-mono font-bold text-sm focus:outline-none focus:border-emerald-500"
                required
              />
              <p className="text-[11px] text-emerald-400 mt-1">
                Resulting stock total will be: <strong className="font-mono">{currentQty + (Number(quantity) || 0)} {product.unit}</strong>
              </p>
            </div>
          )}

          {mode === 'ADJUSTMENT' && (
            <div className="space-y-3 bg-amber-950/20 border border-amber-500/30 p-4 rounded-2xl">
              <div>
                <label className="text-amber-300 font-bold block mb-1">
                  Target Inventory Stock Count ({product.unit}) *
                </label>
                <input
                  type="number"
                  placeholder={`Current: ${currentQty}`}
                  value={targetQuantity}
                  onChange={e => setTargetQuantity(e.target.value === '' ? '' : Number(e.target.value))}
                  min={0}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-mono font-bold text-sm focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              {targetQuantity !== '' && (
                <div className="text-[11px] font-mono flex items-center justify-between bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Calculated Audit Delta:</span>
                  <span className={`font-bold ${delta >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {delta >= 0 ? `+${delta}` : delta} {product.unit}
                  </span>
                </div>
              )}
            </div>
          )}

          {mode === 'STOCK_OUT' && (
            <div>
              <label className="text-slate-300 font-bold block mb-1">
                Quantity to Deduct ({product.unit}) *
              </label>
              <input
                type="number"
                placeholder="e.g. 5"
                value={quantity}
                onChange={e => setQuantity(e.target.value === '' ? '' : Number(e.target.value))}
                min={1}
                max={currentQty}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-mono font-bold text-sm focus:outline-none focus:border-rose-500"
                required
              />
              <p className="text-[11px] text-rose-300 mt-1">
                Remaining stock after deduction: <strong className="font-mono">{Math.max(0, currentQty - (Number(quantity) || 0))} {product.unit}</strong>
              </p>
            </div>
          )}

          <div>
            <label className="text-slate-400 font-medium block mb-1">
              Reason / Notes {mode === 'ADJUSTMENT' ? '*' : '(Optional)'}
            </label>
            <input
              type="text"
              placeholder={
                mode === 'ADJUSTMENT'
                  ? 'e.g. Monthly physical inventory audit count'
                  : mode === 'STOCK_IN'
                  ? 'e.g. Supplier delivery PO-2026-88'
                  : 'e.g. Damaged packaging disposal'
              }
              value={reason}
              onChange={e => setReason(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              required={mode === 'ADJUSTMENT'}
            />
          </div>

          <div className="pt-3 border-t border-slate-800 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-4 py-2.5 rounded-xl transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className={`font-bold px-5 py-2.5 rounded-xl shadow-lg flex items-center space-x-2 transition disabled:opacity-50 ${
                mode === 'STOCK_IN'
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  : mode === 'ADJUSTMENT'
                  ? 'bg-amber-600 hover:bg-amber-500 text-white'
                  : 'bg-rose-600 hover:bg-rose-500 text-white'
              }`}
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
              <span>
                {mode === 'STOCK_IN'
                  ? 'Deposit Stock'
                  : mode === 'ADJUSTMENT'
                  ? 'Apply Adjustment'
                  : 'Deduct Stock'}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
