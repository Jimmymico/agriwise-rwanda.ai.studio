import React from 'react';
import { Language } from '../types';
import { Globe } from 'lucide-react';

interface LanguageSelectorProps {
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
}

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({
  currentLanguage,
  onLanguageChange,
}) => {
  return (
    <div className="inline-flex items-center bg-slate-800/80 hover:bg-slate-800 border border-emerald-500/30 rounded-lg p-1 text-xs text-slate-200 transition-colors">
      <Globe className="w-3.5 h-3.5 text-emerald-400 ml-1.5 mr-1" />
      <div className="flex space-x-1">
        <button
          onClick={() => onLanguageChange('rw')}
          className={`px-2 py-1 rounded font-medium transition-all ${
            currentLanguage === 'rw'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-300 hover:text-white'
          }`}
          title="Kinyarwanda"
        >
          🇷🇼 RW
        </button>
        <button
          onClick={() => onLanguageChange('en')}
          className={`px-2 py-1 rounded font-medium transition-all ${
            currentLanguage === 'en'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-300 hover:text-white'
          }`}
          title="English"
        >
          🇬🇧 EN
        </button>
        <button
          onClick={() => onLanguageChange('fr')}
          className={`px-2 py-1 rounded font-medium transition-all ${
            currentLanguage === 'fr'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-300 hover:text-white'
          }`}
          title="Français"
        >
          🇫🇷 FR
        </button>
      </div>
    </div>
  );
};
