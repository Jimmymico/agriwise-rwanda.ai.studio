import React, { useState } from 'react';
import { User, Language, UserRole } from '../types';
import { translations } from '../data/translations';
import { LanguageSelector } from './LanguageSelector';
import { ProfileAvatar } from './profile/ProfileAvatar';
import {
  Sprout,
  Bell,
  Wallet,
  UserCheck,
  ChevronDown,
  LogOut,
  ShieldCheck,
  Menu,
  PhoneCall,
  Crown,
  LogIn,
  UserPlus
} from 'lucide-react';

interface HeaderProps {
  currentUser?: User;
  isAuthenticated?: boolean;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenMobileMenu?: () => void;
  onOpenMomoModal?: () => void;
  onOpenNotifications?: () => void;
  onOpenSubscriptionModal?: () => void;
  onInitiateMomoPayment?: (amountRwf: number, title: string) => void;
  onLogout?: () => void;
  onOpenLogin?: () => void;
  onOpenRegister?: () => void;
  onOpenHome?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  isAuthenticated = true,
  language,
  onLanguageChange,
  onOpenMobileMenu,
  onOpenMomoModal,
  onOpenNotifications,
  onOpenSubscriptionModal,
  onInitiateMomoPayment,
  onLogout,
  onOpenLogin,
  onOpenRegister,
  onOpenHome,
}) => {
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const t = translations[language];

  const handleMomoClick = () => {
    if (onOpenMomoModal) {
      onOpenMomoModal();
    } else if (onInitiateMomoPayment) {
      onInitiateMomoPayment(500000, 'MoMo Wallet Top-Up');
    }
  };

  const userName = currentUser?.name || 'User';
  const userRole = currentUser?.role || 'farmer';
  const userDistrict = currentUser?.district || 'Musanze';
  const userSector = currentUser?.sector || 'Kinigi';
  const userEmail = currentUser?.email || 'user@agriwise.rw';

  const roleOptions: { role: UserRole; name: string }[] = [
    { role: 'farmer', name: t.role_farmer },
    { role: 'livestock', name: t.role_livestock },
    { role: 'cooperative', name: t.role_cooperative },
    { role: 'agrodealer', name: t.role_agrodealer },
    { role: 'buyer', name: t.role_buyer },
    { role: 'expert', name: t.role_expert },
    { role: 'transporter', name: t.role_transporter },
    { role: 'bank_insurance', name: t.role_bank_insurance },
    { role: 'government_ngo', name: t.role_government_ngo },
    { role: 'admin', name: t.role_admin },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur border-b border-emerald-500/20 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Left Side: Mobile Menu Button & Brand */}
        <div className="flex items-center space-x-3">
          <button
            onClick={onOpenMobileMenu}
            className="md:hidden p-2 rounded-lg text-slate-300 hover:bg-slate-800 hover:text-white"
          >
            <Menu className="w-6 h-6" />
          </button>

          <div
            onClick={onOpenHome}
            className="flex items-center space-x-2.5 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-blue-600 p-0.5 shadow-md flex items-center justify-center group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Sprout className="w-6 h-6 text-emerald-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="font-black text-lg tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-blue-400">
                  AGRIWISE
                </span>
                <span className="text-xs px-1.5 py-0.5 rounded font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  RWANDA
                </span>
              </div>
              <p className="hidden sm:block text-[10px] text-emerald-400/80 font-medium tracking-wide">
                "{t.appTagline}"
              </p>
            </div>
          </div>
        </div>

        {/* Right Side Tools & Controls */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          
          {/* Hotline Button */}
          <a
            href="tel:1111"
            className="hidden lg:flex items-center space-x-1.5 bg-rose-950/40 hover:bg-rose-900/50 border border-rose-500/40 text-rose-300 text-xs px-2.5 py-1.5 rounded-lg transition-colors"
            title="RAB Agriculture Emergency Hotline"
          >
            <PhoneCall className="w-3.5 h-3.5 text-rose-400" />
            <span className="font-semibold">RAB Hotline: 1111</span>
          </a>

          {/* Language Switcher */}
          <LanguageSelector
            currentLanguage={language}
            onLanguageChange={onLanguageChange}
          />

          {!isAuthenticated ? (
            /* Visitor Navigation: Login & Register Buttons */
            <div className="flex items-center space-x-2">
              <button
                onClick={onOpenLogin}
                className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30 px-3 py-1.5 rounded-xl text-xs font-bold transition-all"
              >
                <LogIn className="w-4 h-4 text-emerald-400" />
                <span>{t.login || 'Injira (Login)'}</span>
              </button>

              <button
                onClick={onOpenRegister}
                className="flex items-center space-x-1.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 px-3 py-1.5 rounded-xl text-xs font-black transition-all shadow-md"
              >
                <UserPlus className="w-4 h-4" />
                <span className="hidden sm:inline">{t.register || 'Iyandikishe (Register)'}</span>
              </button>
            </div>
          ) : (
            /* Authenticated User Navigation: Subscriptions, Wallet, Notifications & User Dropdown */
            <>
              {/* Premium Subscription Status Button */}
              {onOpenSubscriptionModal && (
                <button
                  onClick={onOpenSubscriptionModal}
                  className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    currentUser?.subscription?.planId === 'free'
                      ? 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 animate-pulse'
                      : 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/50'
                  }`}
                  title="AGRIWISE SaaS Premium Subscription"
                >
                  <Crown className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="hidden xl:inline">
                    {currentUser?.subscription?.planId === 'free'
                      ? `Free (${currentUser.subscription.freeRequestsRemaining} left)`
                      : currentUser?.subscription?.planName || 'Premium'}
                  </span>
                </button>
              )}

              {/* MoMo Balance Widget */}
              <button
                onClick={handleMomoClick}
                className="flex items-center space-x-1.5 bg-amber-950/40 hover:bg-amber-900/60 border border-amber-500/40 px-2.5 py-1.5 rounded-lg text-xs transition-colors"
              >
                <Wallet className="w-4 h-4 text-amber-400" />
                <span className="hidden sm:inline text-slate-300">{t.momoBalance}:</span>
                <span className="font-bold text-amber-300">1,250,000 RWF</span>
              </button>

              {/* Notification Trigger */}
              <button
                onClick={onOpenNotifications}
                className="relative p-2 rounded-lg text-slate-300 hover:bg-slate-800 hover:text-emerald-400 transition-colors"
                title={t.notifications}
              >
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
              </button>

              {/* Role Switcher & User Profile Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setShowRoleDropdown(!showRoleDropdown)}
                  className="flex items-center space-x-2 bg-slate-800 hover:bg-slate-700/80 border border-slate-700 px-2.5 py-1.5 rounded-xl transition-all"
                >
                  <ProfileAvatar
                    photoUrl={currentUser?.avatarUrl}
                    name={userName}
                    size="sm"
                    showVerifiedBadge={false}
                  />
                  <div className="text-left hidden md:block max-w-[130px]">
                    <p className="text-xs font-bold text-slate-100 truncate">{userName}</p>
                    <div className="flex items-center space-x-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-400" />
                      <p className="text-[10px] text-emerald-400 font-medium truncate capitalize">
                        {userRole.replace('_', ' ')}
                      </p>
                    </div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-slate-400" />
                </button>

                {/* Dropdown Menu */}
                {showRoleDropdown && (
                  <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-2 z-50 text-xs">
                    <div className="p-2 border-b border-slate-800 flex items-center space-x-3">
                      <ProfileAvatar
                        photoUrl={currentUser?.avatarUrl}
                        name={userName}
                        size="md"
                        showVerifiedBadge={true}
                        verified={true}
                      />
                      <div className="min-w-0 flex-1">
                        <p className="font-bold text-white truncate">{userName}</p>
                        <p className="text-slate-400 text-[11px] truncate">{userEmail}</p>
                        <p className="text-emerald-400 font-medium text-[11px] mt-0.5">
                          📍 {userDistrict}, {userSector}
                        </p>
                      </div>
                    </div>

                    {/* Strict Single-Role Account Security Badge */}
                    <div className="p-2 bg-slate-950 rounded-xl my-2 border border-slate-800">
                      <div className="flex items-center justify-between text-[11px] mb-1">
                        <span className="text-slate-400 font-bold">Assigned Role:</span>
                        <span className="bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded font-black text-[10px] uppercase">
                          {userRole.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-500 leading-tight">
                        🔒 Strict Single-Role Account Policy Active. To operate under another role, log out and sign in with that account.
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800 space-y-1">
                      <button
                        onClick={() => {
                          setShowRoleDropdown(false);
                          if (onLogout) onLogout();
                        }}
                        className="w-full text-left px-2.5 py-2 rounded-xl text-rose-400 hover:bg-rose-950/40 border border-transparent hover:border-rose-500/30 flex items-center space-x-2 font-bold transition-all"
                      >
                        <LogOut className="w-4 h-4 text-rose-400" />
                        <span>{t.logout || 'Sohoka (Logout)'}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}

        </div>

      </div>
    </header>
  );
};
