import React, { useState } from 'react';
import { User as UserIcon, ShieldCheck } from 'lucide-react';

interface ProfileAvatarProps {
  photoUrl?: string;
  name?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
  showVerifiedBadge?: boolean;
  verified?: boolean;
  bordered?: boolean;
  onClick?: () => void;
  id?: string;
}

const sizeClasses = {
  xs: 'w-6 h-6 text-[10px]',
  sm: 'w-8 h-8 text-xs',
  md: 'w-10 h-10 text-sm',
  lg: 'w-16 h-16 text-xl',
  xl: 'w-24 h-24 text-2xl',
  '2xl': 'w-32 h-32 text-4xl',
};

const badgeSizeClasses = {
  xs: 'w-2.5 h-2.5',
  sm: 'w-3 h-3',
  md: 'w-3.5 h-3.5',
  lg: 'w-5 h-5',
  xl: 'w-6 h-6',
  '2xl': 'w-8 h-8',
};

export const ProfileAvatar: React.FC<ProfileAvatarProps> = ({
  photoUrl,
  name = 'User',
  size = 'md',
  className = '',
  showVerifiedBadge = false,
  verified = false,
  bordered = false,
  onClick,
  id,
}) => {
  const [imageError, setImageError] = useState(false);

  const getInitials = (n: string) => {
    if (!n) return 'U';
    const parts = n.trim().split(/\s+/);
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return n.slice(0, 2).toUpperCase();
  };

  const hasValidPhoto = photoUrl && !imageError && photoUrl.trim() !== '';

  return (
    <div
      id={id}
      onClick={onClick}
      className={`relative inline-flex items-center justify-center shrink-0 rounded-2xl select-none ${
        onClick ? 'cursor-pointer transition-transform hover:scale-105 active:scale-95' : ''
      } ${className}`}
    >
      <div
        className={`${sizeClasses[size]} rounded-2xl flex items-center justify-center font-bold overflow-hidden shadow-inner ${
          bordered ? 'border-2 border-emerald-500/80' : 'border border-slate-700/60'
        } ${
          hasValidPhoto
            ? 'bg-slate-950'
            : 'bg-gradient-to-br from-emerald-600 via-teal-600 to-emerald-800 text-white'
        }`}
      >
        {hasValidPhoto ? (
          <img
            src={photoUrl}
            alt={name}
            onError={() => setImageError(true)}
            className="w-full h-full object-cover transition-opacity duration-300"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="flex items-center justify-center w-full h-full">
            {name ? (
              <span className="tracking-wider">{getInitials(name)}</span>
            ) : (
              <UserIcon className="w-1/2 h-1/2 opacity-80" />
            )}
          </div>
        )}
      </div>

      {/* Optional RAB Verified Badge */}
      {showVerifiedBadge && (
        <span
          className={`absolute -bottom-1 -right-1 bg-emerald-600 text-white p-0.5 rounded-full shadow-md border-2 border-slate-900 flex items-center justify-center ${
            verified ? 'text-amber-300' : 'text-white'
          }`}
          title={verified ? 'RAB Verified Identity' : 'Registered Member'}
        >
          <ShieldCheck className={badgeSizeClasses[size]} />
        </span>
      )}
    </div>
  );
};
