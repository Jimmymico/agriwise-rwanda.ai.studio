import React, { useState, useRef, useEffect } from 'react';
import {
  Upload,
  Camera,
  Trash2,
  RefreshCw,
  Check,
  X,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  Sparkles,
  SwitchCamera,
  Sliders,
} from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../data/translations';
import { ProfileAvatar } from './ProfileAvatar';
import {
  validateImageFile,
  uploadUserProfilePhoto,
  removeUserProfilePhoto,
} from '../../services/profilePhotoService';

interface ProfilePhotoUploaderProps {
  userId: string;
  userName?: string;
  currentPhotoUrl?: string;
  onPhotoChange: (newUrl: string) => void;
  language: Language;
  size?: 'md' | 'lg' | 'xl' | '2xl';
  showVerifiedBadge?: boolean;
  verified?: boolean;
  className?: string;
  variant?: 'card' | 'inline' | 'compact';
  id?: string;
}

export const ProfilePhotoUploader: React.FC<ProfilePhotoUploaderProps> = ({
  userId,
  userName = 'User',
  currentPhotoUrl = '',
  onPhotoChange,
  language,
  size = 'xl',
  showVerifiedBadge = false,
  verified = false,
  className = '',
  variant = 'card',
  id = 'profile-photo-uploader',
}) => {
  const t = translations[language] || translations.rw;

  // File input refs
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mobileCameraInputRef = useRef<HTMLInputElement>(null);

  // Video & Stream refs for in-app webcam capture
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Component states
  const [selectedFile, setSelectedFile] = useState<File | Blob | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [showCameraModal, setShowCameraModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Camera states
  const [cameraFacingMode, setCameraFacingMode] = useState<'user' | 'environment'>('user');
  const [isCameraLoading, setIsCameraLoading] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Action states
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Clean up camera stream when camera modal closes
  const stopCameraStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  };

  useEffect(() => {
    return () => {
      stopCameraStream();
    };
  }, []);

  // Handle native file selection from disk
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    await processSelectedImage(file);

    // Reset input so same file can be re-selected if cancelled
    e.target.value = '';
  };

  // Common image processor & validator
  const processSelectedImage = async (file: File | Blob) => {
    setErrorMessage(null);

    // Validate
    const validation = await validateImageFile(file);
    if (!validation.valid) {
      const errorKey = validation.errorKey;
      const localizedError = (errorKey && (t as any)[errorKey]) || validation.errorMessage || t.photoInvalidImage;
      setErrorMessage(localizedError);
      return;
    }

    // Set preview
    const objectUrl = URL.createObjectURL(file);
    setSelectedFile(file);
    setPreviewUrl(objectUrl);
    setShowPreviewModal(true);
  };

  // Start in-app camera stream
  const startCamera = async (facing: 'user' | 'environment' = cameraFacingMode) => {
    setIsCameraLoading(true);
    setCameraError(null);
    stopCameraStream();

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('MediaDevices API not supported on this browser');
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facing,
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setIsCameraLoading(false);
    } catch (err: any) {
      console.warn('In-app camera stream initialization warning:', err);
      setIsCameraLoading(false);
      setCameraError(t.photoCameraError || 'Camera not accessible or permission denied.');
    }
  };

  const handleOpenLiveCamera = async () => {
    setShowCameraModal(true);
    // Give DOM time to render video tag
    setTimeout(() => {
      startCamera(cameraFacingMode);
    }, 100);
  };

  const handleFlipCamera = () => {
    const nextMode = cameraFacingMode === 'user' ? 'environment' : 'user';
    setCameraFacingMode(nextMode);
    startCamera(nextMode);
  };

  const handleCaptureSnapshot = () => {
    if (!videoRef.current) return;

    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Flip horizontal if front camera for natural mirror view
    if (cameraFacingMode === 'user') {
      ctx.translate(canvas.width, 0);
      ctx.scale(-1, 1);
    }

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob(
      async (blob) => {
        if (blob) {
          stopCameraStream();
          setShowCameraModal(false);
          await processSelectedImage(blob);
        }
      },
      'image/jpeg',
      0.9
    );
  };

  // Confirm photo and trigger upload to Firebase Storage
  const handleConfirmUpload = async () => {
    if (!selectedFile || !userId) return;

    setIsUploading(true);
    setUploadProgress(15);
    setErrorMessage(null);

    const result = await uploadUserProfilePhoto(userId, selectedFile, (prog) => {
      setUploadProgress(prog);
    });

    setIsUploading(false);

    if (result.success && result.photoUrl) {
      onPhotoChange(result.photoUrl);
      setShowPreviewModal(false);
      setSelectedFile(null);
      setPreviewUrl(null);
      setSuccessMessage(t.photoUpdatedSuccess || 'Photo updated successfully!');
      setTimeout(() => setSuccessMessage(null), 4000);
    } else {
      const errKey = result.errorKey;
      const localizedError = (errKey && (t as any)[errKey]) || result.error || t.photoUploadFailed;
      setErrorMessage(localizedError);
    }
  };

  // Cancel preview
  const handleCancelPreview = () => {
    if (previewUrl && previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(previewUrl);
    }
    setSelectedFile(null);
    setPreviewUrl(null);
    setShowPreviewModal(false);
    setErrorMessage(null);
  };

  // Remove photo
  const handleConfirmRemove = async () => {
    setIsUploading(true);
    setErrorMessage(null);

    const result = await removeUserProfilePhoto(userId, currentPhotoUrl);
    setIsUploading(false);
    setShowDeleteConfirm(false);

    if (result.success) {
      onPhotoChange('');
      setSuccessMessage(t.photoRemovedSuccess || 'Photo removed successfully.');
      setTimeout(() => setSuccessMessage(null), 4000);
    } else {
      setErrorMessage(result.error || t.photoUploadFailed);
    }
  };

  const hasPhoto = !!currentPhotoUrl && currentPhotoUrl.trim() !== '';

  return (
    <div id={id} className={`relative select-none ${className}`}>
      {/* Hidden native file input (Desktop & Generic File Picker) */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelect}
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        aria-label="Upload profile image"
      />

      {/* Hidden direct camera input for mobile fallback */}
      <input
        type="file"
        ref={mobileCameraInputRef}
        onChange={handleFileSelect}
        accept="image/jpeg,image/png,image/webp"
        capture="user"
        className="hidden"
        aria-label="Take profile photo with camera"
      />

      {/* Main Avatar & Actions layout */}
      {variant === 'card' && (
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 p-4 bg-slate-900/90 border border-slate-800 rounded-2xl shadow-md">
          {/* Avatar Display */}
          <div className="relative group">
            <ProfileAvatar
              photoUrl={currentPhotoUrl}
              name={userName}
              size={size}
              showVerifiedBadge={showVerifiedBadge}
              verified={verified}
              bordered={true}
            />

            {/* Quick Hover Overlay for Desktop */}
            <div className="absolute inset-0 bg-slate-950/70 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1.5 p-1">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[10px] font-bold shadow transition-all"
                title={t.photoUpload}
              >
                <Upload className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={handleOpenLiveCamera}
                className="p-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-lg text-[10px] font-bold shadow transition-all"
                title={t.photoTake}
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Action Buttons & Text */}
          <div className="flex-1 text-center sm:text-left space-y-2">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center justify-center sm:justify-start gap-1.5">
                <span>{userName}</span>
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              </h4>
              <p className="text-[11px] text-slate-400">
                {t.photoDropzoneHint || 'JPG, PNG, WEBP (Max 5MB)'}
              </p>
            </div>

            {/* Buttons Group */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
              {/* Upload Photo Button */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all shadow-sm"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{hasPhoto ? (t.photoChange || 'Change Photo') : (t.photoUpload || 'Upload Photo')}</span>
              </button>

              {/* Take Photo Button */}
              <button
                type="button"
                onClick={handleOpenLiveCamera}
                disabled={isUploading}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-emerald-300 border border-slate-700 rounded-xl text-xs font-bold transition-all"
              >
                <Camera className="w-3.5 h-3.5 text-emerald-400" />
                <span>{t.photoTake || 'Take a Photo'}</span>
              </button>

              {/* Remove Photo Button */}
              {hasPhoto && (
                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(true)}
                  disabled={isUploading}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 bg-rose-950/40 hover:bg-rose-900/60 disabled:opacity-50 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-bold transition-all"
                  title={t.photoRemove}
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                  <span className="hidden md:inline">{t.photoRemove || 'Remove'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Inline / Compact Variant */}
      {variant !== 'card' && (
        <div className="flex items-center gap-3">
          <div className="relative group">
            <ProfileAvatar
              photoUrl={currentPhotoUrl}
              name={userName}
              size={size}
              showVerifiedBadge={showVerifiedBadge}
              verified={verified}
              bordered={true}
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="p-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow transition-all"
              title={hasPhoto ? t.photoChange : t.photoUpload}
            >
              <Upload className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={handleOpenLiveCamera}
              disabled={isUploading}
              className="p-2 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 rounded-xl text-xs font-bold transition-all"
              title={t.photoTake}
            >
              <Camera className="w-4 h-4 text-emerald-400" />
            </button>

            {hasPhoto && (
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(true)}
                disabled={isUploading}
                className="p-2 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-bold transition-all"
                title={t.photoRemove}
              >
                <Trash2 className="w-4 h-4 text-rose-400" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Success Notification Banner */}
      {successMessage && (
        <div className="mt-2.5 p-2.5 bg-emerald-950/80 border border-emerald-500/60 rounded-xl flex items-center gap-2 text-emerald-200 text-xs font-medium animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Error Notification Banner */}
      {errorMessage && (
        <div className="mt-2.5 p-2.5 bg-rose-950/80 border border-rose-500/60 rounded-xl flex items-center justify-between gap-2 text-rose-200 text-xs font-medium animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setErrorMessage(null)}
            className="text-rose-400 hover:text-rose-200 p-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: PREVIEW & CONFIRM PHOTO MODAL */}
      {/* ========================================================================= */}
      {showPreviewModal && previewUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-emerald-500/40 rounded-3xl p-6 shadow-2xl space-y-5">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>{t.photoPreviewTitle || 'Photo Preview'}</span>
              </h3>
              <button
                type="button"
                onClick={handleCancelPreview}
                disabled={isUploading}
                className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Preview Image Stage */}
            <div className="flex flex-col items-center justify-center py-2">
              <div className="relative w-48 h-48 rounded-3xl overflow-hidden border-4 border-emerald-500/80 shadow-xl bg-slate-950">
                <img
                  src={previewUrl}
                  alt="Profile Preview"
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="text-[11px] text-slate-400 mt-3 text-center">
                {t.photoDropzoneHint || 'Verify your new profile photo before saving.'}
              </p>
            </div>

            {/* Upload Progress Bar */}
            {isUploading && (
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs text-emerald-300 font-bold">
                  <span>{t.photoSaving || 'Uploading & Saving...'}</span>
                  <span>{uploadProgress}%</span>
                </div>
                <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={handleCancelPreview}
                disabled={isUploading}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition-all"
              >
                {t.photoCancel || 'Cancel'}
              </button>

              <button
                type="button"
                onClick={handleConfirmUpload}
                disabled={isUploading}
                className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 disabled:opacity-50 text-slate-950 rounded-xl text-xs font-black transition-all shadow-lg"
              >
                {isUploading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>{t.loading || 'Saving...'}</span>
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    <span>{t.photoConfirm || 'Confirm Photo'}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: INTERACTIVE LIVE CAMERA CAPTURE */}
      {/* ========================================================================= */}
      {showCameraModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg bg-slate-900 border border-emerald-500/40 rounded-3xl p-6 shadow-2xl space-y-4">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Camera className="w-5 h-5 text-emerald-400" />
                <span>{t.photoCameraModalTitle || 'Capture Profile Photo'}</span>
              </h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleFlipCamera}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs transition-colors"
                  title="Flip Camera"
                >
                  <SwitchCamera className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    stopCameraStream();
                    setShowCameraModal(false);
                  }}
                  className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Video Viewfinder Stage */}
            <div className="relative aspect-square sm:aspect-video w-full rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center">
              {isCameraLoading && (
                <div className="flex flex-col items-center gap-2 text-emerald-400">
                  <Loader2 className="w-8 h-8 animate-spin" />
                  <span className="text-xs font-bold">{t.loading || 'Starting Camera...'}</span>
                </div>
              )}

              {cameraError && (
                <div className="p-4 text-center space-y-3">
                  <AlertTriangle className="w-8 h-8 text-amber-400 mx-auto" />
                  <p className="text-xs text-rose-300 font-medium max-w-xs">{cameraError}</p>
                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        stopCameraStream();
                        setShowCameraModal(false);
                        mobileCameraInputRef.current?.click();
                      }}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold"
                    >
                      Use Native Mobile Camera
                    </button>
                  </div>
                </div>
              )}

              <video
                ref={videoRef}
                playsInline
                muted
                autoPlay
                className={`w-full h-full object-cover ${
                  cameraFacingMode === 'user' ? '-scale-x-100' : ''
                } ${isCameraLoading || cameraError ? 'hidden' : 'block'}`}
              />

              {/* Framing target overlay */}
              {!isCameraLoading && !cameraError && (
                <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                  <div className="w-48 h-48 rounded-full border-2 border-dashed border-emerald-400/60 shadow-[0_0_0_9999px_rgba(15,23,42,0.45)]" />
                </div>
              )}
            </div>

            {/* Camera Controls */}
            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={() => {
                  stopCameraStream();
                  setShowCameraModal(false);
                  mobileCameraInputRef.current?.click();
                }}
                className="text-xs text-slate-400 hover:text-emerald-400 underline font-medium"
              >
                Mobile File/Camera
              </button>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    stopCameraStream();
                    setShowCameraModal(false);
                  }}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition-all"
                >
                  {t.photoCancel || 'Cancel'}
                </button>

                <button
                  type="button"
                  onClick={handleCaptureSnapshot}
                  disabled={isCameraLoading || !!cameraError}
                  className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 disabled:opacity-50 text-slate-950 font-black rounded-xl text-xs transition-all shadow-lg shadow-emerald-950"
                >
                  <Camera className="w-4 h-4" />
                  <span>{t.photoSnapButton || 'Capture Photo'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: CONFIRM PHOTO REMOVAL */}
      {/* ========================================================================= */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm bg-slate-900 border border-rose-500/40 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-white">
                {t.photoRemove || 'Remove Profile Photo'}
              </h3>
              <p className="text-xs text-slate-400">
                {t.photoRemoveConfirm || 'Are you sure you want to remove your profile photo? Your account will display the default avatar.'}
              </p>
            </div>

            <div className="flex items-center justify-center gap-3 pt-3">
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(false)}
                disabled={isUploading}
                className="flex-1 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition-all"
              >
                {t.photoCancel || 'Cancel'}
              </button>

              <button
                type="button"
                onClick={handleConfirmRemove}
                disabled={isUploading}
                className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all shadow-lg"
              >
                {isUploading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Trash2 className="w-4 h-4" />
                )}
                <span>{t.photoRemove || 'Remove'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
