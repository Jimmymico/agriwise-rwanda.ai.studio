import React, { useState, useEffect } from 'react';
import { CustomerDoc, CustomerType } from '../../types';
import { getCustomersDoc, createCustomerDoc, archiveCustomerDoc } from '../../services/firestoreService';
import { Users, UserPlus, X, Loader2, Trash2, Phone, Mail, MapPin, CheckCircle } from 'lucide-react';

interface CustomerManagerModalProps {
  businessId: string;
  userId: string;
  userName?: string;
  isOpen: boolean;
  onClose: () => void;
  onCustomerAdded?: () => void;
}

export const CustomerManagerModal: React.FC<CustomerManagerModalProps> = ({
  businessId,
  userId,
  userName = 'User',
  isOpen,
  onClose,
  onCustomerAdded,
}) => {
  const [customers, setCustomers] = useState<CustomerDoc[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [customerType, setCustomerType] = useState<CustomerType>('individual');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const loadCustomers = async () => {
    if (!businessId) return;
    setLoading(true);
    try {
      const list = await getCustomersDoc(businessId);
      setCustomers(list);
    } catch (e) {
      console.error('Failed to load customers:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && businessId) {
      loadCustomers();
    }
  }, [isOpen, businessId]);

  if (!isOpen) return null;

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!name.trim()) {
      setError('Customer name is required.');
      return;
    }

    setSubmitting(true);
    try {
      await createCustomerDoc({
        businessId,
        name: name.trim(),
        phone: phone.trim(),
        email: email.trim(),
        address: address.trim(),
        customerType,
        createdByUid: userId,
        createdByName: userName,
      });

      setName('');
      setPhone('');
      setEmail('');
      setAddress('');
      setSuccess('Customer record registered in Firestore.');
      await loadCustomers();
      if (onCustomerAdded) onCustomerAdded();
    } catch (err: any) {
      setError(err.message || 'Failed to create customer.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleArchive = async (customerId: string) => {
    try {
      await archiveCustomerDoc({
        customerId,
        businessId,
        updatedByUid: userId,
        updatedByName: userName,
      });
      await loadCustomers();
      if (onCustomerAdded) onCustomerAdded();
    } catch (err: any) {
      setError('Failed to archive customer.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-6 text-white shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-2xl border border-emerald-500/20">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Business Customer Directory</h2>
              <p className="text-xs text-slate-400">Manage individual, cooperative & business client records</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs p-3.5 rounded-2xl">
            {error}
          </div>
        )}
        {success && (
          <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs p-3.5 rounded-2xl flex items-center space-x-2">
            <CheckCircle className="w-4 h-4" />
            <span>{success}</span>
          </div>
        )}

        {/* Create Customer Form */}
        <form onSubmit={handleCreate} className="space-y-3 bg-slate-800/40 p-4 rounded-2xl border border-slate-700/50 text-xs">
          <h3 className="font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5 text-[11px]">
            <UserPlus className="w-4 h-4 text-emerald-400" />
            <span>Register New Customer</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 font-medium block mb-1">Customer Name / Title *</label>
              <input
                type="text"
                placeholder="e.g. Jean-Luc Mugisha / Abahuzi Coop"
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="text-slate-400 font-medium block mb-1">Customer Type *</label>
              <select
                value={customerType}
                onChange={e => setCustomerType(e.target.value as CustomerType)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-emerald-300 font-medium focus:outline-none focus:border-emerald-500"
              >
                <option value="individual">Individual Farmer</option>
                <option value="business">Business / Commercial</option>
                <option value="cooperative">Farmer Cooperative</option>
                <option value="institution">Government / Institution</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-slate-400 font-medium block mb-1">Phone Number</label>
              <input
                type="text"
                placeholder="+250 78X XXX XXX"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-slate-400 font-medium block mb-1">Email</label>
              <input
                type="email"
                placeholder="client@agri.rw"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-slate-400 font-medium block mb-1">District / Location</label>
              <input
                type="text"
                placeholder="Musanze, Northern Prov."
                value={address}
                onChange={e => setAddress(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="flex justify-end pt-1">
            <button
              type="submit"
              disabled={submitting}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded-xl flex items-center space-x-1.5 transition disabled:opacity-50"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4" />}
              <span>Save Customer</span>
            </button>
          </div>
        </form>

        {/* Customer Directory List */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Active Customers ({customers.length})
          </h3>
          {loading ? (
            <div className="flex items-center justify-center p-8 text-slate-400 text-xs">
              <Loader2 className="w-5 h-5 animate-spin mr-2" />
              <span>Loading customer directory...</span>
            </div>
          ) : customers.length === 0 ? (
            <div className="bg-slate-800/40 border border-slate-800 rounded-2xl p-6 text-center text-slate-400 text-xs">
              No customers registered yet. Add a customer above to associate sales records.
            </div>
          ) : (
            <div className="max-h-60 overflow-y-auto space-y-2 pr-1">
              {customers.map(c => (
                <div
                  key={c.customerId}
                  className="flex items-center justify-between bg-slate-800/60 border border-slate-700/50 rounded-xl p-3 text-xs"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-white">{c.name}</span>
                      <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] px-2 py-0.5 rounded-full capitalize">
                        {c.customerType}
                      </span>
                    </div>
                    <div className="flex items-center space-x-3 text-[11px] text-slate-400">
                      {c.phone && <span className="flex items-center space-x-1"><Phone className="w-3 h-3 text-slate-500" /><span>{c.phone}</span></span>}
                      {c.address && <span className="flex items-center space-x-1"><MapPin className="w-3 h-3 text-slate-500" /><span>{c.address}</span></span>}
                    </div>
                  </div>
                  <button
                    onClick={() => handleArchive(c.customerId)}
                    className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition"
                    title="Archive Customer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="pt-2 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs px-5 py-2.5 rounded-xl transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
