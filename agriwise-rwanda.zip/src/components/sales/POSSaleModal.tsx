import React, { useState, useEffect } from 'react';
import { Product, CustomerDoc, SalePaymentMethod, SalePaymentStatus, SaleDoc, SaleItemDoc } from '../../types';
import { getCustomersDoc, getProductsDoc, createAndCompleteSaleTransaction } from '../../services/firestoreService';
import { ShoppingCart, Plus, Trash2, ShieldCheck, AlertCircle, Loader2, X, CheckCircle, Calculator, User } from 'lucide-react';
import { ReceiptModal } from './ReceiptModal';

interface POSSaleModalProps {
  businessId: string;
  userId: string;
  userName: string;
  userPermissions?: string[];
  products?: Product[];
  isOpen: boolean;
  onClose: () => void;
  onSaleCompleted?: (sale: SaleDoc, items: SaleItemDoc[]) => void;
}

interface CartItem {
  product: Product;
  quantity: number;
  discount: number;
}

export const POSSaleModal: React.FC<POSSaleModalProps> = ({
  businessId,
  userId,
  userName,
  userPermissions = [],
  products: initialProducts,
  isOpen,
  onClose,
  onSaleCompleted,
}) => {
  const [customers, setCustomers] = useState<CustomerDoc[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingCatalog, setLoadingCatalog] = useState(true);

  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('walk_in');
  const [selectedCustomerName, setSelectedCustomerName] = useState<string>('Walk-in Customer');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<SalePaymentMethod>('Cash');
  const [paymentStatus, setPaymentStatus] = useState<SalePaymentStatus>('paid');
  const [overallDiscount, setOverallDiscount] = useState<number>(0);
  const [taxRate, setTaxRate] = useState<number>(0); // Default 0 as required

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Completed sale state for receipt modal
  const [completedSale, setCompletedSale] = useState<{ sale: SaleDoc; items: SaleItemDoc[] } | null>(null);

  const loadData = async () => {
    if (!businessId) return;
    setLoadingCatalog(true);
    setError(null);
    try {
      const [custs, prods] = await Promise.all([
        getCustomersDoc(businessId),
        initialProducts ? Promise.resolve(initialProducts) : getProductsDoc(businessId),
      ]);
      setCustomers(custs);
      setProducts(prods.filter(p => p.status === 'active'));
    } catch (err: any) {
      console.error('Error loading POS catalog:', err);
      setError('Failed to load products or customers directory.');
    } finally {
      setLoadingCatalog(false);
    }
  };

  useEffect(() => {
    if (isOpen && businessId) {
      loadData();
      setCart([]);
      setSelectedCustomerId('walk_in');
      setSelectedCustomerName('Walk-in Customer');
      setOverallDiscount(0);
      setError(null);
      setCompletedSale(null);
    }
  }, [isOpen, businessId]);

  if (!isOpen) return null;

  const handleCustomerChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    setSelectedCustomerId(val);
    if (val === 'walk_in') {
      setSelectedCustomerName('Walk-in Customer');
    } else {
      const found = customers.find(c => c.customerId === val);
      setSelectedCustomerName(found ? found.name : 'Walk-in Customer');
    }
  };

  const handleAddToCart = (product: Product) => {
    setError(null);
    const existingIndex = cart.findIndex(ci => ci.product.productId === product.productId);

    if (existingIndex > -1) {
      const currentQty = cart[existingIndex].quantity;
      if (currentQty + 1 > product.quantity) {
        setError(`Cannot add more. Stock limit reached for "${product.name}" (${product.quantity} available).`);
        return;
      }
      const updated = [...cart];
      updated[existingIndex].quantity += 1;
      setCart(updated);
    } else {
      if (product.quantity < 1) {
        setError(`Product "${product.name}" is currently out of stock.`);
        return;
      }
      setCart([...cart, { product, quantity: 1, discount: 0 }]);
    }
  };

  const handleQuantityChange = (productId: string, newQty: number) => {
    setError(null);
    const item = cart.find(ci => ci.product.productId === productId);
    if (!item) return;

    if (newQty > item.product.quantity) {
      setError(`Requested quantity (${newQty}) exceeds available stock (${item.product.quantity}) for "${item.product.name}".`);
      return;
    }

    if (newQty <= 0) {
      handleRemoveFromCart(productId);
      return;
    }

    setCart(cart.map(ci => (ci.product.productId === productId ? { ...ci, quantity: newQty } : ci)));
  };

  const handleItemDiscountChange = (productId: string, discount: number) => {
    setCart(cart.map(ci => (ci.product.productId === productId ? { ...ci, discount: Math.max(0, discount) } : ci)));
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(cart.filter(ci => ci.product.productId !== productId));
  };

  // Financial calculations
  const rawSubtotal = cart.reduce((acc, item) => acc + item.quantity * item.product.sellingPrice, 0);
  const totalItemDiscounts = cart.reduce((acc, item) => acc + item.discount, 0);
  const totalDiscounts = overallDiscount + totalItemDiscounts;
  const taxAmount = (rawSubtotal - totalDiscounts) * (taxRate / 100);
  const grandTotal = Math.max(0, rawSubtotal - totalDiscounts + taxAmount);

  const handleCompleteSale = async () => {
    setError(null);
    if (cart.length === 0) {
      setError('Please add at least one product item to cart.');
      return;
    }

    // Double check stock availability
    for (const item of cart) {
      if (item.quantity > item.product.quantity) {
        setError(`Insufficient stock for "${item.product.name}". Requested: ${item.quantity}, Available: ${item.product.quantity}`);
        return;
      }
    }

    setSubmitting(true);
    try {
      const result = await createAndCompleteSaleTransaction({
        businessId,
        customerId: selectedCustomerId,
        customerName: selectedCustomerName,
        items: cart.map(item => ({
          productId: item.product.productId,
          quantity: item.quantity,
          discount: item.discount,
        })),
        overallDiscount,
        tax: taxAmount,
        paymentMethod,
        paymentStatus,
        createdByUid: userId,
        createdByName: userName,
      });

      setCompletedSale(result);
      if (onSaleCompleted) onSaleCompleted(result.sale, result.items);
    } catch (err: any) {
      console.error('POS Checkout failed:', err);
      setError(err.message || 'Transaction failed. Negative stock or concurrency protection triggered.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-5xl w-full text-white shadow-2xl flex flex-col md:flex-row overflow-hidden max-h-[90vh]">
        {/* Left Column: Product Selection Catalog */}
        <div className="w-full md:w-3/5 p-6 border-b md:border-b-0 md:border-r border-slate-800 flex flex-col space-y-4 overflow-y-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-2xl border border-emerald-500/20">
                <ShoppingCart className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-bold">New Sales POS Checkout</h2>
                <p className="text-xs text-slate-400">Atomic inventory deduction & real-time pricing</p>
              </div>
            </div>
          </div>

          {/* Customer Selection Dropdown */}
          <div className="bg-slate-800/40 p-3 rounded-2xl border border-slate-700/50 space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1.5">
              <User className="w-3.5 h-3.5 text-emerald-400" />
              <span>Select Customer</span>
            </label>
            <select
              value={selectedCustomerId}
              onChange={handleCustomerChange}
              className="w-full bg-slate-900 border border-slate-700 text-xs rounded-xl px-3 py-2 text-emerald-300 font-bold focus:outline-none focus:border-emerald-500"
            >
              <option value="walk_in">Walk-in Customer (General Public)</option>
              {customers.map(c => (
                <option key={c.customerId} value={c.customerId}>
                  {c.name} ({c.customerType}) - {c.phone || 'No phone'}
                </option>
              ))}
            </select>
          </div>

          {/* Product Grid */}
          <div className="flex-1 space-y-2 overflow-y-auto pr-1">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Available Inventory Products ({products.length})
            </h3>

            {loadingCatalog ? (
              <div className="flex items-center justify-center p-12 text-slate-400 text-xs">
                <Loader2 className="w-5 h-5 animate-spin mr-2" />
                <span>Loading products...</span>
              </div>
            ) : products.length === 0 ? (
              <div className="bg-slate-800/40 border border-slate-800 rounded-2xl p-8 text-center text-slate-400 text-xs">
                No active products in inventory. Please add products in the Agro-Dealer Supply Chain module first.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {products.map(p => {
                  const isOutOfStock = p.quantity <= 0;
                  const inCart = cart.find(ci => ci.product.productId === p.productId);

                  return (
                    <div
                      key={p.productId}
                      onClick={() => !isOutOfStock && handleAddToCart(p)}
                      className={`p-3.5 rounded-2xl border text-xs transition-all cursor-pointer flex flex-col justify-between space-y-2 ${
                        isOutOfStock
                          ? 'bg-slate-950/40 border-slate-800/80 opacity-50 cursor-not-allowed'
                          : inCart
                          ? 'bg-emerald-950/40 border-emerald-500/50 shadow-lg shadow-emerald-950/20'
                          : 'bg-slate-800/50 border-slate-700/60 hover:border-emerald-500/40 hover:bg-slate-800'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex justify-between items-start">
                          <span className="font-bold text-white text-sm line-clamp-1">{p.name}</span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            isOutOfStock
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                              : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          }`}>
                            {isOutOfStock ? '0 Available' : `${p.quantity} ${p.unit || 'units'}`}
                          </span>
                        </div>
                        {p.sku && <p className="text-[10px] text-slate-400 font-mono">SKU: {p.sku}</p>}
                      </div>

                      <div className="flex justify-between items-center pt-2 border-t border-slate-700/40">
                        <span className="font-black text-amber-400 text-sm">{p.sellingPrice.toLocaleString()} RWF</span>
                        <button
                          disabled={isOutOfStock}
                          className="bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold px-2.5 py-1 rounded-lg flex items-center space-x-1"
                        >
                          <Plus className="w-3 h-3" />
                          <span>{inCart ? `In Cart (${inCart.quantity})` : 'Add'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Cart & Checkout Summary */}
        <div className="w-full md:w-2/5 p-6 bg-slate-950 flex flex-col justify-between space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-slate-800">
            <h3 className="font-bold text-sm text-slate-200 flex items-center space-x-2">
              <Calculator className="w-4 h-4 text-emerald-400" />
              <span>Cart & Total Calculation</span>
            </h3>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {error && (
            <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs p-3 rounded-xl flex items-start space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Cart Items List */}
          <div className="flex-1 space-y-2 overflow-y-auto pr-1 max-h-56">
            {cart.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs border border-dashed border-slate-800 rounded-2xl">
                Cart is empty. Click on products on the left to add items.
              </div>
            ) : (
              cart.map(item => (
                <div
                  key={item.product.productId}
                  className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs space-y-2"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-bold text-white">{item.product.name}</p>
                      <p className="text-[10px] text-slate-400">{item.product.sellingPrice.toLocaleString()} RWF / {item.product.unitOfMeasure}</p>
                    </div>
                    <button
                      onClick={() => handleRemoveFromCart(item.product.productId)}
                      className="text-slate-500 hover:text-rose-400 transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex justify-between items-center pt-1 border-t border-slate-800/60">
                    <div className="flex items-center space-x-1.5">
                      <span className="text-[10px] text-slate-400">Qty:</span>
                      <input
                        type="number"
                        min="1"
                        max={item.product.quantity}
                        value={item.quantity}
                        onChange={e => handleQuantityChange(item.product.productId, parseInt(e.target.value) || 1)}
                        className="w-14 bg-slate-950 border border-slate-700 rounded-lg text-center text-white py-0.5 focus:border-emerald-500"
                      />
                    </div>
                    <span className="font-bold text-emerald-400">
                      {(item.quantity * item.product.sellingPrice - item.discount).toLocaleString()} RWF
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Payment Settings & Totals */}
          <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-400 font-bold block mb-1">Payment Method</label>
                <select
                  value={paymentMethod}
                  onChange={e => setPaymentMethod(e.target.value as SalePaymentMethod)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1.5 text-white font-medium"
                >
                  <option value="Cash">Cash</option>
                  <option value="Mobile Money">Mobile Money (Record)</option>
                  <option value="Bank">Bank Transfer</option>
                  <option value="Credit">Credit / Account</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 font-bold block mb-1">Payment Status</label>
                <select
                  value={paymentStatus}
                  onChange={e => setPaymentStatus(e.target.value as SalePaymentStatus)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1.5 text-emerald-300 font-medium"
                >
                  <option value="paid">Paid</option>
                  <option value="pending">Pending</option>
                  <option value="unpaid">Unpaid</option>
                </select>
              </div>
            </div>

            <div className="border-t border-slate-800 pt-2 space-y-1 text-slate-300">
              <div className="flex justify-between text-slate-400">
                <span>Subtotal</span>
                <span>{rawSubtotal.toLocaleString()} RWF</span>
              </div>
              {totalDiscounts > 0 && (
                <div className="flex justify-between text-amber-400">
                  <span>Discount</span>
                  <span>-{totalDiscounts.toLocaleString()} RWF</span>
                </div>
              )}
              <div className="flex justify-between items-center text-slate-200 font-black text-sm pt-2 border-t border-slate-800">
                <span>Grand Total</span>
                <span className="text-emerald-400 text-base">{grandTotal.toLocaleString()} RWF</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleCompleteSale}
            disabled={submitting || cart.length === 0}
            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3.5 rounded-2xl flex items-center justify-center space-x-2 shadow-lg shadow-emerald-950/40 transition disabled:opacity-50"
          >
            {submitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Processing Atomic Checkout...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-5 h-5" />
                <span>Confirm Sale & Deduct Inventory</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Official Receipt Modal Triggered On Successful Checkout */}
      {completedSale && (
        <ReceiptModal
          sale={completedSale.sale}
          items={completedSale.items}
          isOpen={true}
          onClose={() => {
            setCompletedSale(null);
            onClose();
          }}
          language="EN"
        />
      )}
    </div>
  );
};
