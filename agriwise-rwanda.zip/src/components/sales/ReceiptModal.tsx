import React, { useState } from 'react';
import { SaleDoc, SaleItemDoc, Language } from '../../types';
import { Printer, X, CheckCircle2, ShieldCheck, Building, User, Calendar, Tag, CreditCard, Mail, Loader2, Send } from 'lucide-react';

interface ReceiptModalProps {
  sale: SaleDoc | null;
  items: SaleItemDoc[];
  isOpen: boolean;
  onClose: () => void;
  language?: Language;
  businessName?: string;
  businessPhone?: string;
  businessAddress?: string;
  customerEmailDefault?: string;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  sale,
  items,
  isOpen,
  onClose,
  language = 'en',
  businessName = 'AGRIWISE RWANDA',
  businessPhone,
  businessAddress = 'Rwanda',
  customerEmailDefault = '',
}) => {
  const [recipientEmail, setRecipientEmail] = useState(customerEmailDefault);
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [emailStatus, setEmailStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  if (!isOpen || !sale) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleSendEmailReceipt = async () => {
    if (!recipientEmail || !recipientEmail.includes('@')) {
      setEmailStatus({ type: 'error', message: 'Please enter a valid customer email address.' });
      return;
    }

    setIsSendingEmail(true);
    setEmailStatus(null);

    try {
      const response = await fetch('/api/sales/send-receipt-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerEmail: recipientEmail.trim().toLowerCase(),
          customerName: sale.customerName || 'Valued Customer',
          receiptNumber: sale.saleNumber,
          totalAmount: sale.total,
          date: new Date(sale.createdAt).toLocaleDateString('en-GB'),
          businessName: businessName || 'AGRIWISE RWANDA',
          items: items.map(it => ({
            productName: it.productName,
            quantity: it.quantity,
            unitPrice: it.unitPrice,
            totalPrice: it.subtotal,
          })),
        }),
      });

      const data = await response.json();
      if (data.success) {
        setEmailStatus({ type: 'success', message: `Receipt sent to ${recipientEmail}!` });
      } else {
        setEmailStatus({ type: 'error', message: data.error || 'Failed to dispatch email receipt.' });
      }
    } catch (err: any) {
      console.warn('Email receipt dispatch warning:', err);
      setEmailStatus({ type: 'error', message: 'Network error sending receipt email.' });
    } finally {
      setIsSendingEmail(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 text-white shadow-2xl relative">
        {/* Header Actions */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 print:hidden">
          <div className="flex items-center space-x-2 text-emerald-400 font-bold text-sm">
            <ShieldCheck className="w-4 h-4" />
            <span>Official Business Sales Receipt</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-3 py-2 rounded-xl flex items-center space-x-1 transition-all"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Receipt</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Email Receipt Bar (Screen only) */}
        <div className="pt-3 pb-1 border-b border-slate-800 print:hidden space-y-2">
          <div className="flex items-center space-x-2">
            <div className="relative flex-1">
              <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                placeholder="customer@example.com"
                value={recipientEmail}
                onChange={(e) => setRecipientEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
            <button
              onClick={handleSendEmailReceipt}
              disabled={isSendingEmail}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center space-x-1 transition shadow"
            >
              {isSendingEmail ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              <span>{isSendingEmail ? 'Sending...' : 'Email Invoice'}</span>
            </button>
          </div>
          {emailStatus && (
            <p className={`text-[11px] font-medium ${emailStatus.type === 'success' ? 'text-emerald-400' : 'text-rose-400'}`}>
              {emailStatus.message}
            </p>
          )}
        </div>

        {/* Printable Area */}
        <div className="py-4 space-y-5 print:text-black print:bg-white text-slate-200">
          {/* Business Banner */}
          <div className="text-center space-y-1 pb-4 border-b border-slate-800">
            <div className="inline-flex items-center space-x-2 text-emerald-400 font-black text-lg">
              <span>{businessName}</span>
            </div>
            <p className="text-xs text-slate-400">Agricultural Commerce & Supply Chain Platform</p>
            {businessPhone && <p className="text-xs text-slate-400">Tel: {businessPhone} | {businessAddress}</p>}
            <p className="text-[11px] text-slate-500">Official Tax & Transaction Receipt</p>
          </div>

          {/* Sale Header Info */}
          <div className="grid grid-cols-2 gap-3 text-xs bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-500">Receipt No.</p>
              <p className="font-mono font-bold text-amber-400 text-sm">{sale.saleNumber}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-500">Date & Time</p>
              <p className="font-medium text-slate-300">
                {new Date(sale.createdAt).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' })}
              </p>
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-500">Customer</p>
              <p className="font-bold text-emerald-300">{sale.customerName || 'Walk-in Customer'}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-500">Cashier / Staff</p>
              <p className="font-medium text-slate-300">{sale.createdByName || 'Authorized Staff'}</p>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="space-y-2">
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Itemized Products</p>
            <div className="border border-slate-800 rounded-2xl overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="p-2.5">Item</th>
                    <th className="p-2.5 text-center">Qty</th>
                    <th className="p-2.5 text-right">Unit Price</th>
                    <th className="p-2.5 text-right">Subtotal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/30">
                      <td className="p-2.5">
                        <p className="font-bold text-white">{item.productName}</p>
                        {item.sku && <p className="text-[10px] font-mono text-slate-400">SKU: {item.sku}</p>}
                      </td>
                      <td className="p-2.5 text-center font-bold text-amber-300">{item.quantity}</td>
                      <td className="p-2.5 text-right text-slate-300">{item.unitPrice.toLocaleString()} RWF</td>
                      <td className="p-2.5 text-right font-bold text-emerald-400">{item.subtotal.toLocaleString()} RWF</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Financial Totals Summary */}
          <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs">
            <div className="flex justify-between text-slate-400">
              <span>Subtotal</span>
              <span>{sale.subtotal.toLocaleString()} RWF</span>
            </div>
            {sale.discount > 0 && (
              <div className="flex justify-between text-amber-400 font-medium">
                <span>Total Discount Applied</span>
                <span>-{sale.discount.toLocaleString()} RWF</span>
              </div>
            )}
            <div className="flex justify-between text-slate-400">
              <span>VAT / Tax (0%)</span>
              <span>0 RWF</span>
            </div>
            <div className="pt-2 border-t border-slate-800 flex justify-between items-center font-black text-base text-emerald-400">
              <span>Total Amount</span>
              <span>{sale.total.toLocaleString()} RWF</span>
            </div>
          </div>

          {/* Payment Status & Method */}
          <div className="flex items-center justify-between bg-emerald-950/40 border border-emerald-500/30 p-3 rounded-2xl text-xs">
            <div className="flex items-center space-x-2">
              <CreditCard className="w-4 h-4 text-emerald-400" />
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase">Payment Method</p>
                <p className="font-bold text-white">{sale.paymentMethod}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-slate-400 font-bold uppercase">Payment Status</p>
              <span className="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 uppercase">
                {sale.paymentStatus}
              </span>
            </div>
          </div>

          {/* Verification Footer */}
          <div className="text-center pt-2 space-y-1 text-[11px] text-slate-500 border-t border-slate-800">
            <p className="font-medium text-slate-400">Thank you for doing business with us!</p>
            <p>AGRIWISE RWANDA Digital Audit Secured • {sale.saleId}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
