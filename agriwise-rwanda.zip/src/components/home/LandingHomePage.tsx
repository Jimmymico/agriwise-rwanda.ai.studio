import React from 'react';
import { Language, UserRole } from '../../types';
import { translations } from '../../data/translations';
import {
  Sprout,
  LogIn,
  UserPlus,
  ShieldCheck,
  Sparkles,
  MapPin,
  Bot,
  Globe,
  Radio,
  Plane,
  Coins,
  Award,
  Users,
  Building2,
  ChevronRight,
  TrendingUp,
  Cpu,
  PhoneCall,
  Activity,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';

interface LandingHomePageProps {
  language: Language;
  onOpenLogin: () => void;
  onOpenRegister: () => void;
}

export const LandingHomePage: React.FC<LandingHomePageProps> = ({
  language,
  onOpenLogin,
  onOpenRegister,
}) => {
  const t = translations[language] || translations['rw'];

  return (
    <div className="space-y-8 pb-16">
      
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden bg-gradient-to-br from-slate-950 via-emerald-950 to-slate-900 border border-emerald-500/30 rounded-3xl p-6 sm:p-10 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-12 -mr-12 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-12 -ml-12 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 bg-emerald-500/15 border border-emerald-400/30 px-3.5 py-1.5 rounded-full text-xs font-bold text-emerald-300">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{t.homeHeroBadge || 'AGRIWISE RWANDA • MINAGRI & RAB AI PLATFORM'}</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
            {t.homeHeroTitle || "Umutagatifu w'Ubuhinzi N'Ubworozi Mu Rwanda"}{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300">
              {t.homeHeroTitleHighlight || 'Hifashishijwe AI'}
            </span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 font-medium leading-relaxed max-w-2xl">
            {t.homeHeroDescription || "Sistemu Nyarwanda y'ubuhinzi n'ubworozi igezweho. Pima isambu yawe na GPS, kura indwara ku bihingwa n'ifoto ya AI, bona amakuru y'ikirere, bona inguzanyo ya Banki, kandi ugurishe umusaruro kuri Mobile Money."}
          </p>

          {/* Primary Action Buttons */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={onOpenLogin}
              className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black px-6 py-3.5 rounded-2xl shadow-xl transition-all transform hover:-translate-y-0.5 text-sm"
            >
              <LogIn className="w-5 h-5" />
              <span>{t.homeHeroLogin || t.login || 'Injira (Login)'}</span>
            </button>

            <button
              onClick={onOpenRegister}
              className="flex items-center gap-2 bg-slate-900/90 hover:bg-slate-800 text-emerald-300 border border-emerald-400/40 px-6 py-3.5 rounded-2xl font-black transition-all transform hover:-translate-y-0.5 text-sm"
            >
              <UserPlus className="w-5 h-5 text-emerald-400" />
              <span>{t.homeHeroRegister || t.register || 'Iyandikishe (Register)'}</span>
            </button>

            <a
              href="tel:1111"
              className="hidden sm:flex items-center gap-2 bg-rose-950/50 hover:bg-rose-900/60 text-rose-300 border border-rose-500/40 px-4 py-3.5 rounded-2xl font-bold transition-all text-xs"
            >
              <PhoneCall className="w-4 h-4 text-rose-400" />
              <span>{t.homeHeroHotline || 'RAB Hotline: 1111'}</span>
            </a>
          </div>

          {/* Platform Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-emerald-500/20 text-xs">
            <div>
              <span className="text-emerald-400 font-black text-lg font-mono">15,000+</span>
              <p className="text-slate-400 font-medium">{t.homeMetricFarmers || 'Abahinzi Banditswe'}</p>
            </div>
            <div>
              <span className="text-emerald-400 font-black text-lg font-mono">42,500 Ha</span>
              <p className="text-slate-400 font-medium">{t.homeMetricHectares || 'Amasambu Yapimwe'}</p>
            </div>
            <div>
              <span className="text-emerald-400 font-black text-lg font-mono">98.4%</span>
              <p className="text-slate-400 font-medium">{t.homeMetricAccuracy || "Izipimo z'Indwara AI"}</p>
            </div>
            <div>
              <span className="text-emerald-400 font-black text-lg font-mono">{language === 'fr' ? '30 Districts' : language === 'en' ? '30 Districts' : '30 Turere'}</span>
              <p className="text-slate-400 font-medium">{t.homeMetricDistricts || "Uturere Twose tw'u Rwanda"}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Feature Capabilities Grid */}
      <div className="space-y-4">
        <div className="flex justify-between items-end">
          <div>
            <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
              {t.homeFeaturesBadge || 'Ubushobozi Bwa AGRIWISE'}
            </span>
            <h2 className="text-xl font-bold text-white">
              {t.homeFeaturesTitle || "Gutsinda Ubuhinzi & Ubworozi N'Ikoranabuhanga"}
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {[
            {
              icon: Bot,
              title: t.homeFeature1Title || "Muganga w'Ubuhinzi (AI Pathology & Assistant)",
              desc: t.homeFeature1Desc || "Fata ifoto y'iriba ry'igihingwa gikiragazwa urebemo indwara, umuti w'umwimerere cyangwa uwo mu ruganda n'inzobere za RAB.",
              badge: t.homeFeature1Badge || "AI Vision 3.6",
            },
            {
              icon: MapPin,
              title: t.homeFeature2Title || "Gupima Isambu (GPS Mapping & Soil Health)",
              desc: t.homeFeature2Desc || "Pima imbibi z'isambu yawe n'agafoto ka satellite, ubone ubuso mu ma hekitari, n'inyongeramusaruro zikwiye.",
              badge: t.homeFeature2Badge || "GIS Satellite",
            },
            {
              icon: Coins,
              title: t.homeFeature3Title || "Isoko & Mobile Money (MTN & Airtel MoMo)",
              desc: t.homeFeature3Desc || "Gurishe umusaruro w'isambu yawe bitagusabye abamotsi, kandi wakire amafaranga kuri Mobile Money ako kanya.",
              badge: t.homeFeature3Badge || "MoMo Direct",
            },
            {
              icon: Award,
              title: t.homeFeature4Title || "Amanota y'Inguzanyo (AgriCredit Score)",
              desc: t.homeFeature4Desc || "Amanota y'inguzanyo ashingiye ku musaruro w'isambu yakoreshwa na Bank of Kigali, BRD, na BDF mu gutanga inguzanyo.",
              badge: t.homeFeature4Badge || "Bank Credit",
            },
            {
              icon: Radio,
              title: t.homeFeature5Title || "Sensors & Telemetry (IoT Smart Farming)",
              desc: t.homeFeature5Desc || "Bona ubuhuhe n'ubushyuhe bw'ubutaka buri munota 15 binyuze mu byuma bya LoRaWAN bimanitse mu murima.",
              badge: t.homeFeature5Badge || "IoT Probes",
            },
            {
              icon: Plane,
              title: t.homeFeature6Title || "Drones & Aerial GIS (Drone Sprayers)",
              desc: t.homeFeature6Desc || "Tegura icyerekezo cy'indege zidafite abapilote (drones) mu gutera imiti no gupima umusaruro ku ma hekitari menshi.",
              badge: t.homeFeature6Badge || "Aerial Drone",
            },
          ].map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 rounded-2xl p-5 shadow-lg transition-all hover:translate-y-[-2px] space-y-3"
              >
                <div className="flex justify-between items-start">
                  <div className="p-3 bg-emerald-950/80 border border-emerald-500/30 rounded-xl text-emerald-400">
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] bg-slate-800 text-emerald-300 font-bold px-2.5 py-1 rounded-full border border-slate-700">
                    {item.badge}
                  </span>
                </div>

                <h3 className="font-bold text-white text-base">{item.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">{item.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
