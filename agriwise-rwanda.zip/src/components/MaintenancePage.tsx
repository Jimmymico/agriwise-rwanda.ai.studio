import React from 'react';
import { Wrench, Shield, Phone, Mail, Clock, RefreshCw } from 'lucide-react';
import { Language } from '../types';
import { getSystemContact, getMaintenanceMode } from '../services/systemSettingsService';

interface MaintenancePageProps {
  language: Language;
  onOpenLogin?: () => void;
}

export const MaintenancePage: React.FC<MaintenancePageProps> = ({ language, onOpenLogin }) => {
  const contact = getSystemContact();
  const maintenanceInfo = getMaintenanceMode();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-6 relative overflow-hidden font-sans">
      {/* Background Glowing Ambient Orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-emerald-500/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-teal-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative z-10 max-w-2xl w-full bg-slate-900/90 border border-emerald-500/30 rounded-3xl p-8 sm:p-12 shadow-2xl text-center space-y-8 backdrop-blur-xl">
        
        {/* Animated Maintenance Icon */}
        <div className="relative w-20 h-20 mx-auto">
          <div className="absolute inset-0 bg-emerald-500/20 rounded-3xl animate-ping" />
          <div className="relative w-20 h-20 bg-gradient-to-br from-emerald-500 to-teal-700 rounded-3xl border border-emerald-400/40 flex items-center justify-center shadow-2xl">
            <Wrench className="w-10 h-10 text-white animate-pulse" />
          </div>
        </div>

        {/* Header Text */}
        <div className="space-y-3">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 text-amber-400 border border-amber-500/30 px-3.5 py-1 rounded-full text-xs font-black uppercase tracking-wider">
            <Clock className="w-3.5 h-3.5" />
            <span>SCHEDULED SYSTEM MAINTENANCE</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            AGRIWISE RWANDA
          </h1>

          <p className="text-sm sm:text-base text-slate-300 max-w-lg mx-auto leading-relaxed">
            {maintenanceInfo.message || 'AGRIWISE RWANDA is currently undergoing scheduled maintenance. Please check back soon.'}
          </p>
        </div>

        {/* Status Indicator */}
        <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-2 text-xs font-mono text-slate-400">
          <div className="flex justify-between items-center text-slate-300">
            <span>System Core:</span>
            <span className="text-amber-400 font-bold">Database Optimization In Progress</span>
          </div>
          <div className="flex justify-between items-center text-slate-300">
            <span>Expected Duration:</span>
            <span className="text-emerald-400 font-bold">~15 - 30 Minutes</span>
          </div>
          <div className="flex justify-between items-center text-slate-300">
            <span>USSD *111# / Voice 1111:</span>
            <span className="text-emerald-400 font-bold">Emergency Mode Active</span>
          </div>
        </div>

        {/* Contact Info Footer */}
        <div className="pt-4 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-left">
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 flex items-center gap-3">
            <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <span className="text-[10px] text-slate-400 block font-medium">Official System Contact</span>
              <span className="font-bold text-white font-mono">{contact.officialPhone}</span>
            </div>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 flex items-center gap-3">
            <Mail className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <span className="text-[10px] text-slate-400 block font-medium">Official Support Email</span>
              <span className="font-bold text-white font-mono">{contact.officialEmail}</span>
            </div>
          </div>
        </div>

        {/* Admin Secret Login Link */}
        <div className="pt-2 flex justify-between items-center text-xs">
          <button
            onClick={() => window.location.reload()}
            className="text-slate-400 hover:text-white flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
            <span>Check Status Again</span>
          </button>

          {onOpenLogin && (
            <button
              onClick={onOpenLogin}
              className="text-slate-500 hover:text-emerald-400 flex items-center gap-1 text-[11px] font-mono transition-colors"
            >
              <Shield className="w-3 h-3 text-emerald-500" />
              <span>Admin Portal Login</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
