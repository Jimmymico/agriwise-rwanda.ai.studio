import React from 'react';
import { User, Language, NavigationTab } from '../types';
import { translations } from '../data/translations';
import { isTabAllowedForRole } from '../utils/rolePermissions';
import { ProfileAvatar } from './profile/ProfileAvatar';
import {
  LayoutDashboard,
  UserCheck,
  Tractor,
  CalendarCheck,
  FileText,
  MapPin,
  Bot,
  Mic,
  Sprout,
  Beef,
  Scan,
  Store,
  Package,
  Truck,
  DollarSign,
  Award,
  CloudSun,
  Stethoscope,
  GraduationCap,
  Users,
  Building2,
  Landmark,
  Umbrella,
  Globe,
  Globe2,
  Radio,
  Plane,
  Database,
  Server,
  ShieldCheck,
  Briefcase,
  Rocket,
  Settings,
  X,
  PhoneCall
} from 'lucide-react';

interface SidebarProps {
  currentUser: User;
  activeTab: string;
  onTabChange: (tab: string) => void;
  language: Language;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentUser,
  activeTab,
  onTabChange,
  language,
  isOpenMobile,
  onCloseMobile,
}) => {
  const t = translations[language];

  const menuItems = [
    { id: 'dashboard', label: t.navDashboard, icon: LayoutDashboard },
    { id: 'farmer_profile', label: t.navFarmerProfile || 'Farmer Profile', icon: UserCheck, badge: 'Core' },
    { id: 'farm_registration', label: t.navFarmRegistration || 'Digital Farms', icon: Tractor, badge: 'New' },
    { id: 'activity_tracker', label: t.navActivityTracker || 'Activity Log', icon: CalendarCheck },
    { id: 'farm_documents', label: t.navFarmDocuments || 'Documents & Vault', icon: FileText },
    { id: 'map_my_farm', label: t.navMapMyFarm, icon: MapPin, badge: 'GPS AI' },
    { id: 'ai_assistant', label: t.navAiAssistant, icon: Bot, badge: 'Smart' },
    { id: 'voice_assistant', label: t.navVoiceAssistant, icon: Mic, badge: 'Audio' },
    { id: 'ussd_voice_gateway', label: 'USSD (*111#) & 1111 Voice AI', icon: PhoneCall, badge: '*111# Telecom' },
    { id: 'crop_manager', label: t.navCropManager, icon: Sprout },
    { id: 'livestock_manager', label: t.navLivestockManager, icon: Beef },
    { id: 'disease_detector', label: t.navDiseaseDetector, icon: Scan, badge: 'Vision' },
    { id: 'marketplace', label: t.navMarketplace, icon: Store },
    { id: 'agrodealer', label: t.navAgrodealer || 'Agro-dealer Hub', icon: Package, badge: 'RAB Supply' },
    { id: 'logistics', label: t.navLogistics || 'Transport & Logistics', icon: Truck, badge: 'RURA Fleet' },
    { id: 'cooperative', label: t.navCooperative || 'Cooperative Hub', icon: Building2, badge: 'RCA Co-Op' },
    { id: 'government', label: t.navGovernment || 'Government & Policy', icon: Landmark, badge: 'MINAGRI' },
    { id: 'banking_insurance', label: 'Banking & Insurance', icon: Umbrella, badge: 'NAIS' },
    { id: 'satellite_monitoring', label: 'Satellite Remote Sensing', icon: Globe, badge: 'GIS Space' },
    { id: 'iot_smart_farm', label: 'IoT Smart Farm System', icon: Radio, badge: 'LoRaWAN' },
    { id: 'drone_agriculture', label: 'Drone Agriculture', icon: Plane, badge: 'Aerial GIS' },
    { id: 'data_marketplace', label: 'Data Marketplace & AI Research', icon: Database, badge: 'Open Data' },
    { id: 'global_expansion', label: 'Global Expansion & Multi-Country', icon: Globe2, badge: 'AfCFTA SaaS' },
    { id: 'cloud_infrastructure', label: 'Cloud Infrastructure & DevOps', icon: Server, badge: 'SLA 99.99%' },
    { id: 'qa_testing', label: 'QA & Product Validation', icon: ShieldCheck, badge: '99.8% Pass' },
    { id: 'business_model', label: 'Business & Monetization', icon: Briefcase, badge: 'PLG & ARR' },
    { id: 'company_launch', label: 'Official Release & Launch', icon: Rocket, badge: 'v1.0 Live' },
    { id: 'financials', label: t.navFinancials, icon: DollarSign },
    { id: 'credit_score', label: t.navCreditScore, icon: Award, badge: 'Credit' },
    { id: 'weather', label: t.navWeather, icon: CloudSun },
    { id: 'experts', label: t.navExperts, icon: Stethoscope },
    { id: 'training', label: 'Farmer Training Academy', icon: GraduationCap, badge: 'RAB Cert' },
    { id: 'community', label: t.navCommunity, icon: Users },
    { id: 'system_admin', label: 'Super Admin & Control Center', icon: ShieldCheck, badge: 'Enterprise' },
  ];

  if (currentUser?.role === 'admin' || currentUser?.role === 'system_owner') {
    menuItems.push({ id: 'admin', label: t.navAdmin, icon: Settings });
  }

  const userRole = currentUser?.role || 'farmer';
  const visibleMenuItems = menuItems.filter((item) =>
    isTabAllowedForRole(userRole, item.id as NavigationTab)
  );

  const sidebarContent = (
    <div className="h-full flex flex-col justify-between bg-slate-900 border-r border-slate-800 text-slate-200">
      <div className="p-4 overflow-y-auto space-y-6">
        
        {/* User Card */}
        <div
          onClick={() => {
            onTabChange('farmer_profile');
            onCloseMobile();
          }}
          className="p-3 bg-gradient-to-br from-slate-800/80 to-slate-900 hover:from-slate-800 hover:to-slate-850 border border-slate-700/80 rounded-2xl shadow-inner flex items-center space-x-3 cursor-pointer transition-all group"
          title="Click to view & update profile"
        >
          <ProfileAvatar
            photoUrl={currentUser?.avatarUrl}
            name={currentUser?.name || 'User'}
            size="md"
            showVerifiedBadge={true}
            verified={true}
          />
          <div className="flex-1 min-w-0">
            <h4 className="text-xs font-bold text-white group-hover:text-emerald-400 transition-colors truncate">
              {currentUser?.name || 'User'}
            </h4>
            <p className="text-[11px] text-emerald-400 font-medium truncate capitalize">
              {currentUser?.role ? currentUser.role.replace('_', ' ') : 'Farmer'}
            </p>
            <p className="text-[10px] text-slate-400 truncate">
              📍 {currentUser?.district || 'Musanze'}, Rwanda
            </p>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="space-y-1">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider px-3 mb-2">
            Main Features
          </p>
          {visibleMenuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onTabChange(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all group ${
                  isActive
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-950'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center space-x-2.5 min-w-0">
                  <Icon
                    className={`w-4 h-4 flex-shrink-0 ${
                      isActive ? 'text-white' : 'text-emerald-400 group-hover:text-emerald-300'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full border ${
                      isActive
                        ? 'bg-white/20 text-white border-white/30'
                        : 'bg-emerald-950 text-emerald-400 border-emerald-500/30'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Support Hotline Widget */}
        <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-2xl">
          <div className="flex items-center space-x-2 text-emerald-400 mb-1">
            <PhoneCall className="w-4 h-4" />
            <span className="text-xs font-bold">RAB Agribiz Helpline</span>
          </div>
          <p className="text-[10px] text-slate-300 leading-tight">
            Free advice & emergency agronomy support for farmers in Rwanda.
          </p>
          <a
            href="tel:1111"
            className="mt-2 block text-center bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold py-1.5 rounded-lg transition-colors"
          >
            Call 1111 (Toll Free)
          </a>
        </div>
      </div>

      {/* Footer info */}
      <div className="p-4 border-t border-slate-800 text-center text-[10px] text-slate-500">
        <p className="font-semibold text-slate-400">AGRIWISE RWANDA v2.4</p>
        <p>Republic of Rwanda • MINAGRI / RAB</p>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden md:block w-64 flex-shrink-0 h-[calc(100vh-4rem)] sticky top-16 z-30">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer Overlay */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm"
            onClick={onCloseMobile}
          ></div>
          <div className="relative w-72 max-w-xs h-full z-10">
            <button
              onClick={onCloseMobile}
              className="absolute top-3 right-3 p-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
