import React, { useState, useEffect } from 'react';
import { Language, NavigationTab } from '../types';
import { translations } from '../data/translations';
import {
  FooterConfig,
  getFooterConfig,
  subscribeToFooterConfig,
  DEFAULT_FOOTER_CONFIG,
} from '../services/footerConfigService';
import {
  Sprout,
  MapPin,
  Mail,
  Phone,
  Clock,
  ExternalLink,
  ShieldCheck,
  FileText,
  HelpCircle,
  Globe2,
  Heart,
  ChevronRight,
  Send,
  CheckCircle2,
  X,
  Lock,
  Sparkles,
  BookOpen,
  Award,
} from 'lucide-react';

interface FooterProps {
  language: Language;
  onNavigate?: (tab: NavigationTab) => void;
  onOpenLogin?: () => void;
  onOpenRegister?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  language,
  onNavigate,
  onOpenLogin,
  onOpenRegister,
}) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);
  const [activeModal, setActiveModal] = useState<'privacy' | 'terms' | 'help' | null>(null);
  const [footerConfig, setFooterConfig] = useState<FooterConfig>(() => getFooterConfig());

  useEffect(() => {
    const unsubscribe = subscribeToFooterConfig((newConfig) => {
      setFooterConfig(newConfig);
    });
    return () => unsubscribe();
  }, []);

  const t = translations[language] || translations['rw'];

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail.trim()) {
      setNewsletterSubscribed(true);
      setNewsletterEmail('');
      setTimeout(() => setNewsletterSubscribed(false), 5000);
    }
  };

  const activeSocialLinks = (footerConfig.socialLinks || DEFAULT_FOOTER_CONFIG.socialLinks).filter(
    (link) => link.enabled
  );

  return (
    <footer className="bg-slate-950 border-t border-slate-800/80 text-slate-100 font-sans relative overflow-hidden mt-12">
      {/* Subtle Background Glow Elements */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Main Footer Container */}
      <div className="max-w-[1600px] mx-auto px-4 sm:px-8 lg:px-12 pt-12 pb-8 relative z-10 space-y-12">
        
        {/* Top Newsletter & Brand Banner */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-950 to-emerald-950/80 border border-slate-800 p-6 sm:p-8 rounded-3xl shadow-2xl flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400">
                <Sprout className="w-5 h-5" />
              </div>
              <span className="text-xl font-black text-white tracking-tight">AGRIWISE</span>
              <span className="text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full uppercase">
                Version 1.0 Live
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-300 font-medium leading-relaxed">
              {t.footerTagline || "Rwanda & East Africa's premier AI-powered agricultural intelligence, MoMo escrow marketplace, and satellite farm management ecosystem."}
            </p>
          </div>

          {/* Newsletter Form */}
          <div className="w-full lg:w-auto min-w-[320px]">
            <form onSubmit={handleSubscribe} className="space-y-2">
              <span className="text-xs font-bold text-emerald-400 block uppercase tracking-wider">
                {t.footerNewsletterTitle || (language === 'rw' ? 'Kwakira Amakuru y\'Ubuhinzi' : language === 'fr' ? 'Abonnez-vous au bulletin' : 'Subscribe to Agronomic Bulletin')}
              </span>
              <div className="flex items-center gap-2">
                <input
                  type="email"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder={t.footerNewsletterPlaceholder || "name@farm.rw"}
                  className="bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none flex-1 transition-all"
                  required
                />
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-all shadow-lg flex items-center gap-1.5 shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>
                    {t.footerNewsletterButton || (language === 'rw' ? 'Kwandika' : language === 'fr' ? 'S\'abonner' : 'Subscribe')}
                  </span>
                </button>
              </div>
              {newsletterSubscribed && (
                <p className="text-[11px] text-emerald-400 font-bold flex items-center gap-1 animate-in fade-in">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {t.footerNewsletterSuccess || (language === 'rw'
                    ? 'Murakoze! Mwanditswe mu banyamakuru ba AGRIWISE.'
                    : 'Thank you! You are now subscribed to AGRIWISE updates.')}
                </p>
              )}
            </form>
          </div>
        </div>

        {/* 5-Column Responsive Footer Links Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8 text-xs">
          
          {/* Column 1: About AGRIWISE */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-2">
              <Globe2 className="w-4 h-4 text-emerald-400" />
              {t.footerAboutTitle || (language === 'rw' ? 'Ibyo Wamenya' : language === 'fr' ? 'À propos d\'AGRIWISE' : 'About AGRIWISE')}
            </h3>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              {t.footerAboutDesc || "Empowering smallholder farmers, cooperatives, and agribusinesses across Africa with offline GIS mapping, Gemini 3.6 AI vision, and instant mobile money escrow."}
            </p>
            <div className="pt-2 space-y-1.5 text-[11px]">
              <div className="flex items-center gap-2 text-slate-300">
                <Award className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>{t.footerAboutRAB || 'RAB & MINAGRI Aligned Platform'}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <ShieldCheck className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                <span>{t.footerAboutGDPR || 'GDPR & NPSA Data Sovereignty'}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>{t.footerAboutAfCFTA || 'AfCFTA Regional Commodity Corridor'}</span>
              </div>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-2">
              <ChevronRight className="w-4 h-4 text-emerald-400" />
              {t.footerQuickLinksTitle || (language === 'rw' ? 'Imiyoboro Yihuta' : language === 'fr' ? 'Liens Rapides' : 'Quick Links')}
            </h3>
            <ul className="space-y-2 text-slate-300">
              {[
                { label: t.navDashboard || 'Dashboard Overview', tab: 'dashboard' },
                { label: t.navMapMyFarm || 'Farm Polygon Mapping', tab: 'map_my_farm' },
                { label: t.navAiAssistant || 'Gemini AI Agronomist', tab: 'ai_assistant' },
                { label: t.navDiseaseDetector || 'Plant Disease Detector', tab: 'disease_detector' },
                { label: t.navMarketplace || 'Marketplace & MoMo Escrow', tab: 'marketplace' },
                { label: t.navWeather || 'Weather & Climate Alerts', tab: 'weather' },
                { label: t.navTraining || 'Farmer Training Academy', tab: 'training' },
              ].map((link) => (
                <li key={link.tab}>
                  <button
                    onClick={() => onNavigate?.(link.tab as NavigationTab)}
                    className="hover:text-emerald-400 transition-colors flex items-center gap-1.5 group text-left"
                  >
                    <span className="text-emerald-500 opacity-0 group-hover:opacity-100 transition-opacity">›</span>
                    <span>{link.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Portals & Governance */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-2">
              <BookOpen className="w-4 h-4 text-emerald-400" />
              {t.footerPortalsTitle || (language === 'rw' ? 'Inshingano & Portals' : language === 'fr' ? 'Portails & Services' : 'Portals & Services')}
            </h3>
            <ul className="space-y-2 text-slate-300">
              {[
                { label: t.navCooperative || 'Cooperative Management', tab: 'cooperative' },
                { label: t.navAgrodealer || 'Agro-Dealer Supply Chain', tab: 'agrodealer' },
                { label: t.navGovernment || 'Government & Policy Portal', tab: 'government' },
                { label: t.navCreditScore || 'Bank Credit Underwriting', tab: 'credit_score' },
                { label: 'Satellite & IoT Monitoring', tab: 'satellite_monitoring' },
                { label: 'Data Marketplace Platform', tab: 'data_marketplace' },
                { label: 'Global Trade & AfCFTA', tab: 'global_expansion' },
              ].map((link) => (
                <li key={link.tab}>
                  <button
                    onClick={() => onNavigate?.(link.tab as NavigationTab)}
                    className="hover:text-emerald-400 transition-colors flex items-center gap-1.5 group text-left"
                  >
                    <span className="text-emerald-500 opacity-0 group-hover:opacity-100 transition-opacity">›</span>
                    <span>{link.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Contact & Operations */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-2">
              <MapPin className="w-4 h-4 text-emerald-400" />
              {t.footerContactTitle || (language === 'rw' ? 'Twandikire' : language === 'fr' ? 'Contact & Siège' : 'Contact & HQ')}
            </h3>
            <div className="space-y-2.5 text-slate-300 text-[11px]">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{footerConfig.address || t.footerContactAddress || "Kigali Innovation City, KG 7 Ave, Kigali, Rwanda"}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-teal-400 shrink-0" />
                <a
                  href={`mailto:${footerConfig.mailtoEmail || footerConfig.displayEmail || "info@agriwise.rw"}`}
                  className="hover:text-emerald-400 transition-colors"
                >
                  {footerConfig.displayEmail || "info@agriwise.rw"}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  {footerConfig.primaryPhone || "+250 788 000 000"}
                  {footerConfig.secondaryPhone ? ` / ${footerConfig.secondaryPhone}` : ' / +250 788 123 456'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{footerConfig.openingHours || t.footerContactHours || "Mon - Sat: 7:00 AM - 7:00 PM (CAT)"}</span>
              </div>
            </div>

            {/* Quick Auth Buttons */}
            <div className="pt-2 flex flex-wrap gap-2">
              <button
                onClick={onOpenLogin}
                className="bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white px-3 py-1.5 rounded-xl font-bold text-[11px] transition-all"
              >
                {t.footerSignIn || t.login || 'Sign In'}
              </button>
              <button
                onClick={onOpenRegister}
                className="bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-xl font-bold text-[11px] transition-all"
              >
                {t.footerRegisterFarm || t.register || 'Register Farm'}
              </button>
            </div>
          </div>

          {/* Column 5: Social Media & Legal Links */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-2">
              <Heart className="w-4 h-4 text-emerald-400" />
              {footerConfig.connectHeading || t.footerConnectTitle || (language === 'rw' ? 'Tukurikire' : language === 'fr' ? 'Nous Suivre' : 'Connect & Support')}
            </h3>
            <p className="text-slate-400 text-[11px]">
              {footerConfig.connectDescription || t.footerConnectDesc || "Follow AGRIWISE on official social networks for real-time agronomic advisories."}
            </p>

            {/* Social Icons */}
            <div className="flex items-center gap-2 pt-1">
              {activeSocialLinks.map((soc, i) => (
                <a
                  key={i}
                  href={soc.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 rounded-xl bg-slate-900 hover:bg-emerald-950 border border-slate-800 hover:border-emerald-500/50 flex items-center justify-center text-slate-300 hover:text-emerald-400 font-mono font-bold text-xs transition-all shadow-md"
                  title={soc.name}
                >
                  {soc.icon}
                </a>
              ))}
            </div>

            {/* Legal Links Trigger */}
            <div className="pt-2 space-y-1.5">
              {footerConfig.privacyPolicyUrl ? (
                <a
                  href={footerConfig.privacyPolicyUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-400 hover:text-emerald-400 text-[11px] flex items-center gap-1.5 transition-colors"
                >
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{t.footerPrivacy || 'Privacy Policy'}</span>
                </a>
              ) : (
                <button
                  onClick={() => setActiveModal('privacy')}
                  className="text-slate-400 hover:text-emerald-400 text-[11px] flex items-center gap-1.5 transition-colors"
                >
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{t.footerPrivacy || 'Privacy Policy'}</span>
                </button>
              )}

              {footerConfig.termsOfServiceUrl ? (
                <a
                  href={footerConfig.termsOfServiceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-400 hover:text-emerald-400 text-[11px] flex items-center gap-1.5 transition-colors"
                >
                  <FileText className="w-3.5 h-3.5 text-teal-400" />
                  <span>{t.footerTerms || 'Terms of Service'}</span>
                </a>
              ) : (
                <button
                  onClick={() => setActiveModal('terms')}
                  className="text-slate-400 hover:text-emerald-400 text-[11px] flex items-center gap-1.5 transition-colors"
                >
                  <FileText className="w-3.5 h-3.5 text-teal-400" />
                  <span>{t.footerTerms || 'Terms of Service'}</span>
                </button>
              )}

              <button
                onClick={() => setActiveModal('help')}
                className="text-slate-400 hover:text-emerald-400 text-[11px] flex items-center gap-1.5 transition-colors"
              >
                <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
                <span>{t.footerHelp || 'Help Center & FAQ'}</span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom Copyright Bar */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-400">
          
          {/* REQUIRED COPYRIGHT TEXT */}
          <div className="text-center md:text-left">
            <p className="font-bold text-slate-200">
              {t.footerCopyright || "© 2026 AGRIWISE. Designed & Developed by Jimmy Mico. All Rights Reserved."}
            </p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {t.footerPoweredBy || "Powered by Gemini 3.6 Flash AI • MTN Mobile Money Escrow Engine • Rwanda Agriculture Board (RAB) Certified"}
            </p>
          </div>

          {/* Quick Legal Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-4 text-[11px]">
            <button
              onClick={() => setActiveModal('privacy')}
              className="hover:text-emerald-400 transition-colors"
            >
              {t.footerPrivacy || 'Privacy Policy'}
            </button>
            <span className="text-slate-700">•</span>
            <button
              onClick={() => setActiveModal('terms')}
              className="hover:text-emerald-400 transition-colors"
            >
              {t.footerTerms || 'Terms of Service'}
            </button>
            <span className="text-slate-700">•</span>
            <button
              onClick={() => setActiveModal('help')}
              className="hover:text-emerald-400 transition-colors"
            >
              {t.footerHelp || 'Help Center'}
            </button>
          </div>

        </div>

      </div>

      {/* Interactive Modal for Privacy / Terms / Help Center */}
      {activeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative text-slate-100 space-y-5 max-h-[85vh] overflow-y-auto">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2">
                {activeModal === 'privacy' && <Lock className="w-5 h-5 text-emerald-400" />}
                {activeModal === 'terms' && <FileText className="w-5 h-5 text-teal-400" />}
                {activeModal === 'help' && <HelpCircle className="w-5 h-5 text-amber-400" />}
                <h3 className="font-bold text-lg text-white">
                  {activeModal === 'privacy' && 'AGRIWISE Data Protection & Privacy Policy'}
                  {activeModal === 'terms' && 'AGRIWISE Platform Terms of Service'}
                  {activeModal === 'help' && 'AGRIWISE Support & Help Center'}
                </h3>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body Content */}
            <div className="text-xs text-slate-300 space-y-4 leading-relaxed">
              {activeModal === 'privacy' && (
                <>
                  <p className="font-bold text-emerald-300">Data Sovereignty & Privacy Commitment (GDPR & Rwanda NPSA Compliant):</p>
                  <p>AGRIWISE respects farmer data sovereignty. All spatial GIS boundaries, crop health imagery, and financial transaction records collected through offline CRDT synchronization are stored in encrypted regional nodes (Kigali and Nairobi) with residency pins.</p>
                  <p>Farmer personal identity records are anonymized prior to any differential privacy research analysis on the Open Data Marketplace. No farmer data is ever sold or shared with unverified third parties without explicit multi-factor authorization.</p>
                </>
              )}

              {activeModal === 'terms' && (
                <>
                  <p className="font-bold text-teal-300">Commercial Platform Usage Terms:</p>
                  <p>By using AGRIWISE, cooperative admins, commercial farms, and buyers agree to transact produce sales and bulk input orders through the integrated MoMo Escrow Lockbox system with a 2.5% platform transaction fee.</p>
                  <p>All agronomic advice generated by Gemini 3.6 Flash models is verified against ground-truth RAB disease datasets. Users are encouraged to combine AI diagnostics with extension officer recommendations.</p>
                </>
              )}

              {activeModal === 'help' && (
                <>
                  <p className="font-bold text-amber-300">24/7 Support Channels:</p>
                  <div className="space-y-2 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                    <p>• <strong>Free Toll-Free Hotline:</strong> Call 8000 (Rwanda) for Kinyarwanda voice assistance.</p>
                    <p>• <strong>WhatsApp Agronomist Bot:</strong> +250 788 000 000</p>
                    <p>• <strong>Email Support:</strong> support@agriwise.rw</p>
                    <p>• <strong>In-App AI Chat:</strong> Navigate to the "Gemini AI Agronomist" tab in the sidebar anytime!</p>
                  </div>
                </>
              )}
            </div>

            <div className="pt-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setActiveModal(null)}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2 rounded-xl text-xs transition-colors"
              >
                I Understand & Accept
              </button>
            </div>

          </div>
        </div>
      )}

    </footer>
  );
};
