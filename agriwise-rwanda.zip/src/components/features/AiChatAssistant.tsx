import React, { useState } from 'react';
import { User, Language } from '../../types';
import { translations } from '../../data/translations';
import {
  Bot,
  Send,
  User as UserIcon,
  Sparkles,
  Loader2,
  Sprout,
  HelpCircle,
  Lightbulb
} from 'lucide-react';

interface AiChatAssistantProps {
  currentUser: User;
  language: Language;
  onUseFreeRequest?: () => boolean;
  onOpenUpgradeModal?: () => void;
}

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}

export const AiChatAssistant: React.FC<AiChatAssistantProps> = ({
  currentUser,
  language,
  onUseFreeRequest,
  onOpenUpgradeModal,
}) => {
  const t = translations[language];

  const sub = currentUser.subscription;
  const isFreeTrial = sub?.planId === 'free';
  const remainingCount = sub?.freeRequestsRemaining ?? 2;

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg_0',
      sender: 'ai',
      text:
        language === 'rw'
          ? `Muraho Mwalimu ${currentUser.name}! Ndi Muganga w'Ubuhinzi (AGRIWISE AI). Nkurikiranira hafi ibihingwa n'amatungo yawe i ${currentUser.district}. Nshobora kugufasha iki uyu munsi?`
          : language === 'fr'
          ? `Bonjour ${currentUser.name} ! Je suis votre Assistant Agricole AGRIWISE IA à ${currentUser.district}. Comment puis-je vous aider aujourd'hui ?`
          : `Hello ${currentUser.name}! I am your AGRIWISE AI Agricultural Assistant in ${currentUser.district}. How can I assist your farm today?`,
      timestamp: 'Just now',
    },
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const quickPrompts =
    language === 'rw'
      ? [
          'Ibigori byanjye bifite amababi y\'umuhondo, nkorere iki?',
          'Ni iyihe mbewu y\'ibirayi iboneye i Musanze?',
          'Nfite amahekitari 2, nkoze nte ifumbire ya NPK na Urea?',
          'Nshobora gute kurinda inka zanjye indwara y\'amabele?',
        ]
      : language === 'fr'
      ? [
          'Pourquoi les feuilles de mon maïs jaunissent-elles ?',
          'Quelle est la meilleure variété de pomme de terre pour Musanze ?',
          'Comment doser l\'engrais NPK pour 2 hectares ?',
          'Comment prévenir la mastite chez mes vaches laitières ?',
        ]
      : [
          'Why are my maize leaves turning yellow?',
          'What is the best potato seed variety for Musanze?',
          'How much NPK 17-17-17 fertilizer should I apply per hectare?',
          'How can I prevent mastitis in my dairy cows?',
        ];

  const handleSendMessage = async (textToSend?: string) => {
    const prompt = textToSend || inputPrompt;
    if (!prompt.trim() || isLoading) return;

    if (onUseFreeRequest) {
      const allowed = onUseFreeRequest();
      if (!allowed) {
        setMessages((prev) => [
          ...prev,
          {
            id: `usr_${Date.now()}`,
            sender: 'user',
            text: prompt,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
          {
            id: `quota_${Date.now()}`,
            sender: 'ai',
            text:
              language === 'rw'
                ? '⚠️ Wabyaje umusaruro ibibazo byose by\'ubuntu (0 remaining). Komeza uze uze kuri AGRIWISE Farmer Premium kugira ngo ukoreshe AI ntampamyabushobozi!'
                : '⚠️ You have used all your free trial AI requests. Upgrade to AGRIWISE Premium to continue enjoying unlimited AI consultations & disease diagnosis.',
            timestamp: 'Just now',
          },
        ]);
        if (onOpenUpgradeModal) onOpenUpgradeModal();
        return;
      }
    }

    const userMsg: Message = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text: prompt,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputPrompt('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          language,
          context: {
            role: currentUser.role,
            district: currentUser.district,
            sector: currentUser.sector,
            crops: currentUser.primaryCrops?.join(', '),
            farmSize: `${currentUser.farmSizeHectares || 1.5} Ha`,
          },
        }),
      });

      const data = await response.json();
      const aiMsg: Message = {
        id: `ai_${Date.now()}`,
        sender: 'ai',
        text: data.text || 'Nyamuneka subira ugerageze.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      console.error(err);
      const errorMsg: Message = {
        id: `err_${Date.now()}`,
        sender: 'ai',
        text:
          language === 'rw'
            ? 'Mu kanya gato serivisi irimo kuvugururwa. Baza ukoresheje amatsinda z\'abahinzi.'
            : 'Service temporarily busy. Please try again in a few moments.',
        timestamp: 'Just now',
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      
      {/* Title */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl flex items-center justify-between text-white">
        <div className="flex items-center space-x-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow-lg">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-black">{t.aiAssistantTitle}</h2>
            <p className="text-xs text-slate-400">{t.aiAssistantDesc}</p>
          </div>
        </div>

        <div className="hidden sm:flex items-center space-x-2 text-xs bg-emerald-950 border border-emerald-500/30 text-emerald-300 px-3 py-1.5 rounded-xl font-medium">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <span>Gemini 3.6 Flash • {currentUser.district} District</span>
        </div>
      </div>

      {/* Subscription Quota Status Banner */}
      {isFreeTrial ? (
        <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-3.5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-200">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>
              Free Trial Access:{' '}
              <strong className="text-emerald-400">{remainingCount} request(s) remaining</strong> out of {sub?.maxFreeRequests || 2}
            </span>
          </div>

          <button
            onClick={onOpenUpgradeModal}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-xl text-xs shadow transition-colors"
          >
            Upgrade to Premium (Unlimited)
          </button>
        </div>
      ) : (
        <div className="bg-slate-900 border border-emerald-500/40 rounded-2xl p-3 flex items-center justify-between text-xs">
          <span className="text-emerald-300 font-bold flex items-center gap-2">
            ✓ AGRIWISE {sub?.planName || 'Premium'} Active (Unlimited AI Consultations)
          </span>
          <span className="text-[10px] text-slate-400 font-mono">Renews: {sub?.renewsAt || '2026-12-31'}</span>
        </div>
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
        {quickPrompts.map((qp, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(qp)}
            disabled={isLoading}
            className="p-3 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-emerald-500/40 rounded-2xl text-left text-slate-300 hover:text-white transition-all flex items-start space-x-2 group"
          >
            <Lightbulb className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
            <span className="truncate">{qp}</span>
          </button>
        ))}
      </div>

      {/* Chat Messages Container */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-6 shadow-2xl h-[420px] sm:h-[480px] flex flex-col justify-between space-y-4">
        
        {/* Messages List */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start space-x-3 ${
                msg.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''
              }`}
            >
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 text-white font-bold text-xs shadow ${
                  msg.sender === 'user'
                    ? 'bg-blue-600'
                    : 'bg-gradient-to-tr from-emerald-600 to-teal-500'
                }`}
              >
                {msg.sender === 'user' ? <UserIcon className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[82%] sm:max-w-[75%] p-4 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-md ${
                  msg.sender === 'user'
                    ? 'bg-blue-600 text-white rounded-tr-none'
                    : 'bg-slate-800 text-slate-100 border border-slate-700/80 rounded-tl-none whitespace-pre-line'
                }`}
              >
                <p>{msg.text}</p>
                <span className="block text-[10px] text-slate-400 mt-2 text-right">
                  {msg.timestamp}
                </span>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center space-x-3 text-slate-400 text-xs py-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-600/30 flex items-center justify-center">
                <Loader2 className="w-4 h-4 animate-spin text-emerald-400" />
              </div>
              <p className="animate-pulse">AI Inzobere irimo gusesengura ikibazo mu Kinyarwanda...</p>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="pt-3 border-t border-slate-800 flex items-center space-x-2">
          <input
            type="text"
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder={t.typeMessage}
            className="flex-1 bg-slate-950 border border-slate-700/80 rounded-2xl px-4 py-3 text-white text-xs sm:text-sm focus:outline-none focus:border-emerald-500"
          />
          <button
            onClick={() => handleSendMessage()}
            disabled={isLoading || !inputPrompt.trim()}
            className="bg-emerald-600 hover:bg-emerald-500 text-white p-3 rounded-2xl shadow-lg transition-all disabled:opacity-50"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>

      </div>

    </div>
  );
};
