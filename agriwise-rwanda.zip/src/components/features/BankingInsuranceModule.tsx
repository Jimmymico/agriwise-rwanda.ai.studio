import React, { useState } from 'react';
import {
  User,
  Language,
  FinancialInstitution,
  AgriLoanApplication,
  InsuranceProduct,
  InsurancePolicy,
  InsuranceClaim,
  AgriInvestmentProject,
  FinOrgType,
  LoanPurposeType
} from '../../types';
import {
  MOCK_FINANCIAL_INSTITUTIONS,
  MOCK_LOAN_APPLICATIONS,
  MOCK_INSURANCE_PRODUCTS,
  MOCK_INSURANCE_POLICIES,
  MOCK_INSURANCE_CLAIMS,
  MOCK_INVESTMENT_PROJECTS
} from '../../data/mockFinTechData';
import { translations } from '../../data/translations';
import {
  Landmark,
  ShieldCheck,
  Building,
  CreditCard,
  DollarSign,
  TrendingUp,
  Award,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  FileText,
  UserCheck,
  PlusCircle,
  Send,
  Download,
  Umbrella,
  PieChart,
  Layers,
  Search,
  Lock,
  PhoneCall,
  Activity,
  ChevronRight,
  ArrowUpRight
} from 'lucide-react';

interface BankingInsuranceModuleProps {
  currentUser: User;
  language: Language;
}

export const BankingInsuranceModule: React.FC<BankingInsuranceModuleProps> = ({
  currentUser,
  language,
}) => {
  const t = translations[language];

  // Active Tab State
  const [activeTab, setActiveTab] = useState<'profile_score' | 'loans' | 'insurance' | 'claims' | 'investments' | 'onboarding' | 'bank_dashboard'>('profile_score');

  // Datasets
  const [institutions, setInstitutions] = useState<FinancialInstitution[]>(MOCK_FINANCIAL_INSTITUTIONS);
  const [loans, setLoans] = useState<AgriLoanApplication[]>(MOCK_LOAN_APPLICATIONS);
  const [insuranceProducts] = useState<InsuranceProduct[]>(MOCK_INSURANCE_PRODUCTS);
  const [userPolicies, setUserPolicies] = useState<InsurancePolicy[]>(MOCK_INSURANCE_POLICIES);
  const [userClaims, setUserClaims] = useState<InsuranceClaim[]>(MOCK_INSURANCE_CLAIMS);
  const [investments, setInvestments] = useState<AgriInvestmentProject[]>(MOCK_INVESTMENT_PROJECTS);

  // New Loan Form State
  const [loanPurpose, setLoanPurpose] = useState<LoanPurposeType>('Irrigation');
  const [loanAmountRwf, setLoanAmountRwf] = useState<number>(1800000);
  const [selectedInstId, setSelectedInstId] = useState<string>('inst-bk-01');

  // New Onboarding Institution Form State
  const [orgName, setOrgName] = useState('');
  const [orgType, setOrgType] = useState<FinOrgType>('Bank');
  const [licenseNo, setLicenseNo] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');

  // AI Credit Assessment & Advisor State
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<any>(null);

  // New Insurance Claim Form State
  const [claimReason, setClaimReason] = useState('Mid-season drought dry spell damage to maize crops');
  const [claimHectares, setClaimHectares] = useState(1.2);
  const [claimEvidenceType, setClaimEvidenceType] = useState<'Photos' | 'AI Vision Report' | 'Satellite NDVI Loss Data' | 'Weather Station Records'>('Satellite NDVI Loss Data');

  // Toast State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Run AI Credit Scoring Model
  const runAiCreditScoring = async () => {
    setAiLoading(true);
    try {
      const res = await fetch('/api/ai/credit-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          farmerName: currentUser.name || 'Jean De Dieu Hakizimana',
          farmSizeHectares: 2.5,
          cropType: 'Hybrid Maize Grain',
          district: currentUser.location || 'Nyagatare',
          monthlySalesRwf: 450000,
          requestedLoanAmountRwf: loanAmountRwf,
          loanPurpose: loanPurpose,
          language
        }),
      });
      const data = await res.json();
      setAiResult(data);
    } catch (e) {
      console.error('AI Credit Advisor call error:', e);
    } finally {
      setAiLoading(false);
    }
  };

  // Apply for Loan Pipeline
  const handleApplyLoan = () => {
    const inst = institutions.find(i => i.id === selectedInstId);
    const newLoan: AgriLoanApplication = {
      id: `loan-${Date.now().toString().slice(-4)}`,
      farmerId: currentUser.id,
      farmerName: currentUser.name || 'Jean De Dieu Hakizimana',
      district: currentUser.location || 'Nyagatare',
      institutionId: selectedInstId,
      institutionName: inst ? inst.name : 'Bank of Kigali (BK)',
      loanType: loanPurpose,
      requestedAmountRwf: loanAmountRwf,
      interestRatePct: 12.5,
      durationMonths: 18,
      monthlyRepaymentRwf: Math.round((loanAmountRwf * 1.125) / 18),
      status: 'AI Assessed',
      aiCreditScore: aiResult ? aiResult.agriScore : 84,
      aiEligibilityRecommendation: aiResult ? aiResult.aiDecisionSummary : 'Recommended for Instant MoMo Agricultural Disbursement.',
      repaymentStatusPct: 0,
      appliedDate: new Date().toISOString().split('T')[0]
    };

    setLoans([newLoan, ...loans]);
    triggerToast(`Loan application of ${loanAmountRwf.toLocaleString()} RWF submitted to ${newLoan.institutionName}. Sent for automated Mobile Money escrow review.`);
  };

  // Submit Insurance Claim
  const handleSubmitClaim = () => {
    const newClaim: InsuranceClaim = {
      id: `clm-${Date.now().toString().slice(-4)}`,
      policyId: 'pol-8801',
      farmerId: currentUser.id,
      farmerName: currentUser.name || 'Jean De Dieu Hakizimana',
      claimReason: claimReason,
      affectedHectaresOrHeads: claimHectares,
      estimatedLossRwf: claimHectares * 600000,
      approvedPayoutRwf: claimHectares * 560000,
      status: 'AI Verified',
      evidenceType: claimEvidenceType,
      evidenceSummary: `${claimEvidenceType} verified loss across ${claimHectares} Ha. Approved payout processing.`,
      submissionDate: new Date().toISOString().split('T')[0]
    };

    setUserClaims([newClaim, ...userClaims]);
    triggerToast(`Insurance claim filed! ${claimEvidenceType} automatically verified loss. Payout pending insurer Mobile Money release.`);
  };

  // Onboard Financial Institution
  const handleOnboardInstitution = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orgName || !licenseNo) return;

    const newOrg: FinancialInstitution = {
      id: `inst-${Date.now().toString().slice(-4)}`,
      name: orgName,
      type: orgType,
      licenseNumber: licenseNo,
      contactEmail: contactEmail || 'info@partner.rw',
      contactPhone: contactPhone || '+250 788 000 000',
      servicesOffered: ['Agricultural Loans', 'Mobile Escrow Credit'],
      regionsServed: ['Eastern Province', 'Northern Province'],
      verificationStatus: 'Approved',
      totalCapitalDeployedRwf: 1000000000,
      activePortfoliosCount: 10
    };

    setInstitutions([...institutions, newOrg]);
    setOrgName('');
    setLicenseNo('');
    triggerToast(`Institution "${newOrg.name}" successfully registered and verified on AGRIWISE FinTech network!`);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-emerald-600 text-white font-bold text-xs px-4 py-3 rounded-2xl shadow-2xl flex items-center space-x-2 animate-bounce">
          <CheckCircle2 className="w-5 h-5 text-white" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* FinTech Module Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden text-white">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center space-x-2 bg-blue-500/20 text-blue-300 border border-blue-500/30 px-3 py-1 rounded-full text-xs font-bold mb-2">
              <Landmark className="w-4 h-4 text-blue-400" />
              <span>BNR / BDF Licensed Agricultural FinTech & NAIS Insurance Network</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Banking, Insurance & Agricultural Financial Services
            </h1>

            <p className="text-xs sm:text-sm text-slate-400 max-w-3xl mt-1">
              Connect smallholders, co-ops, commercial banks, microfinance institutions, and insurers with AI-driven credit scoring, NAIS 50% subsidized crop insurance, and Mobile Money escrow disbursements.
            </p>
          </div>

          <div className="flex items-center space-x-3 bg-slate-800 border border-slate-700 p-3 rounded-2xl">
            <Award className="w-8 h-8 text-amber-400" />
            <div>
              <span className="text-[10px] text-slate-400 block font-bold">AGRIWISE FARM SCORE</span>
              <span className="text-xl font-black text-emerald-400 font-mono">84 / 100</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2 flex flex-wrap items-center gap-2 text-xs">
        <button
          onClick={() => setActiveTab('profile_score')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'profile_score'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Award className="w-4 h-4 text-amber-300" />
          <span>Financial Profile & Score</span>
        </button>

        <button
          onClick={() => setActiveTab('loans')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'loans'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <CreditCard className="w-4 h-4 text-emerald-300" />
          <span>Digital Loans & MoMo</span>
        </button>

        <button
          onClick={() => setActiveTab('insurance')}
          className={`flex-1 min-w-[150px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'insurance'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Umbrella className="w-4 h-4 text-teal-300" />
          <span>NAIS Insurance Shield</span>
        </button>

        <button
          onClick={() => setActiveTab('claims')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'claims'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-rose-300" />
          <span>Claims Management</span>
        </button>

        <button
          onClick={() => setActiveTab('investments')}
          className={`flex-1 min-w-[150px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'investments'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <TrendingUp className="w-4 h-4 text-amber-300" />
          <span>Agri-Investment Hub</span>
        </button>

        <button
          onClick={() => setActiveTab('bank_dashboard')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'bank_dashboard'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Building className="w-4 h-4 text-blue-300" />
          <span>Bank & Insurer Dashboard</span>
        </button>

        <button
          onClick={() => setActiveTab('onboarding')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'onboarding'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <PlusCircle className="w-4 h-4 text-emerald-300" />
          <span>Partner Onboarding</span>
        </button>
      </div>

      {/* TAB 1: FARMER FINANCIAL PROFILE & AGRIWISE CREDIT SCORE */}
      {activeTab === 'profile_score' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Credit Score Gauge Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4 lg:col-span-1 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <h3 className="text-base font-black flex items-center space-x-2">
                    <Award className="w-5 h-5 text-amber-400" />
                    <span>AGRIWISE FARM SCORE</span>
                  </h3>
                  <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                    Low Credit Risk
                  </span>
                </div>

                <div className="text-center my-6 space-y-2">
                  <div className="text-5xl font-black text-emerald-400 font-mono tracking-tight">84 <span className="text-xl text-slate-500">/ 100</span></div>
                  <p className="text-xs text-slate-300 font-medium">Eligible for up to 2,500,000 RWF Unsecured Working Capital</p>
                </div>

                <div className="space-y-2 text-xs bg-slate-800/80 p-4 rounded-2xl border border-slate-700">
                  <span className="text-slate-400 font-bold block">Positive Credit Drivers (+):</span>
                  <ul className="space-y-1 text-slate-300 text-[11px]">
                    <li className="flex items-center space-x-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>3 Consecutive years of verified Digital Twin maize yields.</span>
                    </li>
                    <li className="flex items-center space-x-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Regular Mobile Money harvest payments from Nyagatare Co-Op.</span>
                    </li>
                    <li className="flex items-center space-x-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Active NAIS 50% Subsidized Crop Insurance Policy.</span>
                    </li>
                  </ul>
                </div>
              </div>

              <button
                onClick={runAiCreditScoring}
                disabled={aiLoading}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-3 rounded-2xl shadow transition-all flex items-center justify-center space-x-2 mt-4"
              >
                {aiLoading ? (
                  <span>Recalculating Score...</span>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>Re-Run AI Financial Assessment</span>
                  </>
                )}
              </button>
            </div>

            {/* Financial History Breakdown & AI Advice */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-6 lg:col-span-2">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-black">Smallholder Agronomic Financial Records</h3>
                <p className="text-xs text-slate-400">Aggregated digital twin sales, input expenses, and co-op dividends.</p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="bg-slate-800 p-3.5 rounded-2xl border border-slate-700 space-y-1">
                  <span className="text-slate-400 block font-bold">Land Size Mapped</span>
                  <span className="text-lg font-black text-white font-mono">2.5 Ha</span>
                  <span className="text-[10px] text-emerald-400 block">Maize & Beans</span>
                </div>

                <div className="bg-slate-800 p-3.5 rounded-2xl border border-slate-700 space-y-1">
                  <span className="text-slate-400 block font-bold">Avg Monthly Sales</span>
                  <span className="text-lg font-black text-emerald-400 font-mono">450,000 RWF</span>
                  <span className="text-[10px] text-slate-400 block">Via MoMo Escrow</span>
                </div>

                <div className="bg-slate-800 p-3.5 rounded-2xl border border-slate-700 space-y-1">
                  <span className="text-slate-400 block font-bold">Active Debt Outstanding</span>
                  <span className="text-lg font-black text-amber-300 font-mono">630,000 RWF</span>
                  <span className="text-[10px] text-slate-400 block">18-Month Term</span>
                </div>

                <div className="bg-slate-800 p-3.5 rounded-2xl border border-slate-700 space-y-1">
                  <span className="text-slate-400 block font-bold">Repayment On-Time Rate</span>
                  <span className="text-lg font-black text-blue-300 font-mono">100%</span>
                  <span className="text-[10px] text-teal-400 block">0 Days Overdue</span>
                </div>
              </div>

              {/* AI Result Card */}
              {aiResult && (
                <div className="bg-slate-800 border border-blue-500/30 rounded-2xl p-5 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-blue-300 flex items-center space-x-1.5">
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>Gemini 3.6 Flash FinTech Credit Assessment</span>
                    </span>
                    <span className="text-xs font-mono font-bold text-emerald-400">Score: {aiResult.agriScore}/100</span>
                  </div>

                  <p className="text-xs text-slate-200 leading-relaxed">{aiResult.aiDecisionSummary}</p>

                  <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                    <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-700">
                      <span className="text-slate-400 block">MAX CREDIT CAP:</span>
                      <span className="text-emerald-400 font-bold">{aiResult.maxCreditCapRwf?.toLocaleString()} RWF</span>
                    </div>

                    <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-700">
                      <span className="text-slate-400 block">SUGGESTED RATE:</span>
                      <span className="text-amber-300 font-bold">{aiResult.suggestedInterestRatePct}% p.a.</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DIGITAL LOAN APPLICATIONS & MOMO DISBURSEMENT */}
      {activeTab === 'loans' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Apply For Agricultural Loan Form */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4 lg:col-span-1">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-black flex items-center space-x-2">
                  <CreditCard className="w-5 h-5 text-emerald-400" />
                  <span>Apply for Agricultural Loan</span>
                </h3>
                <p className="text-xs text-slate-400">Directly backed by BK & Umutanguha Finance via Mobile Money.</p>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-400 font-bold mb-1">Select Lending Partner:</label>
                  <select
                    value={selectedInstId}
                    onChange={(e) => setSelectedInstId(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                  >
                    {institutions.filter(i => i.type === 'Bank' || i.type === 'Microfinance').map((inst) => (
                      <option key={inst.id} value={inst.id}>{inst.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-bold mb-1">Loan Purpose:</label>
                  <select
                    value={loanPurpose}
                    onChange={(e) => setLoanPurpose(e.target.value as LoanPurposeType)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                  >
                    <option value="Seeds">Hybrid Certified Seeds</option>
                    <option value="Fertilizer">RAB Subsidized Fertilizer (DAP/NPK)</option>
                    <option value="Equipment">Farm Machinery & Mechanization</option>
                    <option value="Livestock">Girinka Cattle & Feed</option>
                    <option value="Irrigation">Solar Valley Dam Irrigation</option>
                    <option value="Expansion">Land Lease & Farm Expansion</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-bold mb-1">Requested Loan Amount (RWF):</label>
                  <input
                    type="number"
                    value={loanAmountRwf}
                    onChange={(e) => setLoanAmountRwf(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono font-bold"
                  />
                </div>

                <div className="bg-slate-800 p-3.5 rounded-2xl border border-slate-700 space-y-1 text-[11px] font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Estimated Interest Rate:</span>
                    <span className="text-emerald-400 font-bold">12.5% p.a.</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Duration Term:</span>
                    <span className="text-white">18 Months</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-700 pt-1">
                    <span className="text-slate-400">Monthly Repayment:</span>
                    <span className="text-amber-300 font-bold">{Math.round((loanAmountRwf * 1.125) / 18).toLocaleString()} RWF</span>
                  </div>
                </div>

                <button
                  onClick={handleApplyLoan}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-2xl shadow transition-all flex items-center justify-center space-x-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit Digital Loan Request</span>
                </button>
              </div>
            </div>

            {/* Active Loan Pipeline Table */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4 lg:col-span-2">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-black">Active Agricultural Loan Applications</h3>
                <p className="text-xs text-slate-400">Real-time status tracking from submission to MoMo disbursement and repayment schedules.</p>
              </div>

              <div className="space-y-4">
                {loans.map((loan) => (
                  <div key={loan.id} className="bg-slate-800 border border-slate-700 rounded-2xl p-5 space-y-3 shadow-lg">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <span className="text-xs font-black text-emerald-400">{loan.institutionName}</span>
                        <h4 className="text-sm font-bold text-white">{loan.loanType} Financing — {loan.requestedAmountRwf.toLocaleString()} RWF</h4>
                      </div>

                      <span className={`px-3 py-1 rounded-full text-xs font-bold border ${
                        loan.status === 'Disbursed' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                        loan.status === 'Approved' ? 'bg-blue-500/20 text-blue-300 border-blue-500/30' :
                        'bg-amber-500/20 text-amber-300 border-amber-500/30'
                      }`}>
                        Status: {loan.status}
                      </span>
                    </div>

                    <p className="text-xs text-slate-300 bg-slate-900/80 p-3 rounded-xl border border-slate-700">
                      💡 <strong>AI Assessment:</strong> {loan.aiEligibilityRecommendation}
                    </p>

                    <div className="grid grid-cols-3 gap-2 text-xs font-mono">
                      <div>
                        <span className="text-slate-400 block text-[10px]">CREDIT SCORE:</span>
                        <span className="text-emerald-400 font-bold">{loan.aiCreditScore}/100</span>
                      </div>

                      <div>
                        <span className="text-slate-400 block text-[10px]">MONTHLY DEDUCT:</span>
                        <span className="text-white font-bold">{loan.monthlyRepaymentRwf.toLocaleString()} RWF</span>
                      </div>

                      <div>
                        <span className="text-slate-400 block text-[10px]">REPAYMENT PROGRESS:</span>
                        <span className="text-blue-300 font-bold">{loan.repaymentStatusPct}% Repaid</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: NAIS CROP & LIVESTOCK INSURANCE MARKETPLACE */}
      {activeTab === 'insurance' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-6">
            <div className="border-b border-slate-800 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-base font-black flex items-center space-x-2">
                  <Umbrella className="w-5 h-5 text-teal-400" />
                  <span>National Agricultural Insurance Scheme (NAIS) Marketplace</span>
                </h3>
                <p className="text-xs text-slate-400">Government subsidizes 50% of all smallholder crop and livestock insurance premiums in Rwanda.</p>
              </div>

              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold">
                50% MINAGRI Subsidy Active
              </span>
            </div>

            {/* Insurance Catalog Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {insuranceProducts.map((prod) => (
                <div key={prod.id} className="bg-slate-800 border border-slate-700 rounded-3xl p-6 space-y-4 shadow-xl flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="flex justify-between items-start">
                      <span className="bg-slate-900 text-teal-300 font-mono text-[10px] font-bold px-2.5 py-1 rounded-full border border-slate-700">
                        {prod.insuranceType}
                      </span>
                      <span className="text-xs text-slate-400">{prod.providerName}</span>
                    </div>

                    <h4 className="text-base font-black text-white">{prod.productName}</h4>
                    <p className="text-xs text-slate-300 leading-relaxed">{prod.termsSummary}</p>

                    <div className="bg-slate-900 p-4 rounded-2xl border border-slate-700 space-y-2 text-xs font-mono">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Coverage per Ha/Head:</span>
                        <span className="text-white font-bold">{prod.coveragePerHectareRwf.toLocaleString()} RWF</span>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-slate-400">Full Standard Premium:</span>
                        <span className="text-slate-400 line-through">{prod.annualPremiumRwf.toLocaleString()} RWF</span>
                      </div>

                      <div className="flex justify-between text-emerald-400 font-bold border-t border-slate-800 pt-1">
                        <span>Farmer Pays (50% Subsidized):</span>
                        <span className="text-sm">{prod.subsidizedPremiumRwf.toLocaleString()} RWF / Year</span>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <span className="text-xs font-bold text-slate-300 block">Covered Risk Events:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {prod.coveredRiskEvents.map((risk, idx) => (
                          <span key={idx} className="bg-slate-700 text-slate-200 text-[10px] px-2 py-0.5 rounded-md">
                            • {risk}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => triggerToast(`Enrolled in ${prod.productName}! Premium of ${prod.subsidizedPremiumRwf.toLocaleString()} RWF paid via MoMo.`)}
                    className="w-full bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs py-3 rounded-2xl shadow transition-all flex items-center justify-center space-x-2 mt-4"
                  >
                    <Umbrella className="w-4 h-4" />
                    <span>Enroll with 50% Subsidized Premium</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: CLAIMS MANAGEMENT SYSTEM & SATELLITE EVIDENCE */}
      {activeTab === 'claims' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Submit New Claim Form */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4 lg:col-span-1">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-black flex items-center space-x-2">
                  <ShieldCheck className="w-5 h-5 text-rose-400" />
                  <span>Submit Insurance Loss Claim</span>
                </h3>
                <p className="text-xs text-slate-400">Upload AI Vision photos or link Sentinel-2 satellite drought data.</p>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-400 font-bold mb-1">Loss Reason & Description:</label>
                  <textarea
                    rows={3}
                    value={claimReason}
                    onChange={(e) => setClaimReason(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-bold mb-1">Affected Area (Hectares):</label>
                  <input
                    type="number"
                    step="0.1"
                    value={claimHectares}
                    onChange={(e) => setClaimHectares(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-bold mb-1">Verification Evidence Source:</label>
                  <select
                    value={claimEvidenceType}
                    onChange={(e) => setClaimEvidenceType(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                  >
                    <option value="Satellite NDVI Loss Data">Satellite Sentinel-2 NDVI Loss Index</option>
                    <option value="AI Vision Report">AI Vision Photo Crop Scan</option>
                    <option value="Weather Station Records">Automatic Weather Station Telemetry</option>
                    <option value="Photos">Geotagged Field Photos</option>
                  </select>
                </div>

                <button
                  onClick={handleSubmitClaim}
                  className="w-full bg-rose-600 hover:bg-rose-500 text-white font-bold py-3 rounded-2xl shadow transition-all flex items-center justify-center space-x-2"
                >
                  <Send className="w-4 h-4" />
                  <span>File Automated Loss Claim</span>
                </button>
              </div>
            </div>

            {/* Claims History Table */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4 lg:col-span-2">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-black">Insurance Claims Verification Pipeline</h3>
                <p className="text-xs text-slate-400">Automated AI evidence validation and Mobile Money claim payouts.</p>
              </div>

              <div className="space-y-4">
                {userClaims.map((claim) => (
                  <div key={claim.id} className="bg-slate-800 border border-slate-700 rounded-2xl p-5 space-y-3 shadow-lg">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <span className="text-xs text-rose-400 font-bold">{claim.claimReason}</span>
                        <h4 className="text-sm font-black text-white">{claim.affectedHectaresOrHeads} Hectares Affected</h4>
                      </div>

                      <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold">
                        Status: {claim.status}
                      </span>
                    </div>

                    <p className="text-xs text-slate-300 bg-slate-900 p-3 rounded-xl border border-slate-700">
                      📡 <strong>Evidence ({claim.evidenceType}):</strong> {claim.evidenceSummary}
                    </p>

                    <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                      <div>
                        <span className="text-slate-400 block text-[10px]">ESTIMATED LOSS:</span>
                        <span className="text-slate-300 font-bold">{claim.estimatedLossRwf.toLocaleString()} RWF</span>
                      </div>

                      <div>
                        <span className="text-slate-400 block text-[10px]">APPROVED PAYOUT:</span>
                        <span className="text-emerald-400 font-bold">{claim.approvedPayoutRwf.toLocaleString()} RWF</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: AGRI-INVESTMENT MARKETPLACE & CO-OP PROJECTS */}
      {activeTab === 'investments' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-6">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-base font-black flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-amber-400" />
                <span>Agricultural Co-Op & Farm Infrastructure Investment Opportunities</span>
              </h3>
              <p className="text-xs text-slate-400">Crowdfund strategic solar valley dams and cold-chain vaults with guaranteed seasonal returns.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {investments.map((proj) => (
                <div key={proj.id} className="bg-slate-800 border border-slate-700 rounded-3xl p-6 space-y-4 shadow-xl flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="bg-slate-900 text-amber-300 font-mono text-[10px] font-bold px-2.5 py-1 rounded-full border border-slate-700">
                        {proj.riskRating}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">{proj.investorCount} Investors</span>
                    </div>

                    <h4 className="text-base font-black text-white">{proj.projectTitle}</h4>
                    <p className="text-xs text-slate-300">{proj.summary}</p>

                    {/* Progress Bar */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs font-mono">
                        <span className="text-slate-400">Raised: {proj.raisedFundingRwf.toLocaleString()} RWF</span>
                        <span className="text-emerald-400 font-bold">Target: {proj.targetFundingRwf.toLocaleString()} RWF</span>
                      </div>
                      <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-500 h-full rounded-full"
                          style={{ width: `${Math.min(100, (proj.raisedFundingRwf / proj.targetFundingRwf) * 100)}%` }}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-900 p-3 rounded-xl border border-slate-700">
                      <div>
                        <span className="text-slate-400 block text-[10px]">PROJECTED RETURN:</span>
                        <span className="text-amber-300 font-bold text-sm">+{proj.projectedReturnPct}% p.a.</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">TENURE PERIOD:</span>
                        <span className="text-white font-bold text-sm">{proj.tenureMonths} Months</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => triggerToast(`Invested 100,000 RWF in ${proj.projectTitle}! Mobile Money escrow receipt issued.`)}
                    className="w-full bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs py-3 rounded-2xl shadow transition-all flex items-center justify-center space-x-2 mt-4"
                  >
                    <DollarSign className="w-4 h-4" />
                    <span>Invest via Mobile Money Escrow</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: PARTNER ONBOARDING (BANKS / INSURERS) */}
      {activeTab === 'onboarding' && (
        <div className="space-y-6 max-w-2xl mx-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-base font-black">Register Financial Institution or Insurer</h3>
              <p className="text-xs text-slate-400">Onboard your Bank, Microfinance, or Insurance company to AGRIWISE network.</p>
            </div>

            <form onSubmit={handleOnboardInstitution} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-bold mb-1">Organization Name:</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Equity Bank Rwanda Agribusiness Division"
                  value={orgName}
                  onChange={(e) => setOrgName(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">Institution Type:</label>
                <select
                  value={orgType}
                  onChange={(e) => setOrgType(e.target.value as FinOrgType)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                >
                  <option value="Bank">Commercial Bank</option>
                  <option value="Microfinance">Microfinance Institution (MFI)</option>
                  <option value="Insurance">Agricultural Insurance Company</option>
                  <option value="Investor Organization">Investor / Green Fund</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">BNR / RDB License Number:</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. BNK-BNR-2026-044"
                  value={licenseNo}
                  onChange={(e) => setLicenseNo(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 font-bold mb-1">Contact Email:</label>
                  <input
                    type="email"
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-bold mb-1">Contact Phone:</label>
                  <input
                    type="text"
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-2xl shadow transition-all flex items-center justify-center space-x-2 mt-4"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Submit Verification Request</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* TAB 7: BANK & INSURER ENTERPRISE DASHBOARD */}
      {activeTab === 'bank_dashboard' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-6">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-base font-black flex items-center space-x-2">
                <Building className="w-5 h-5 text-blue-400" />
                <span>Enterprise Lenders & Insurers Portfolio Command Center</span>
              </h3>
              <p className="text-xs text-slate-400">Manage capital allocation, active debt portfolios, and risk mitigation across Rwanda.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 space-y-1">
                <span className="text-slate-400 font-bold block">Total Capital Deployed</span>
                <span className="text-2xl font-black text-emerald-400 font-mono">40.4B RWF</span>
                <span className="text-[10px] text-slate-400 block">Across 4 Verified Partners</span>
              </div>

              <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 space-y-1">
                <span className="text-slate-400 font-bold block">Active Smallholder Portfolios</span>
                <span className="text-2xl font-black text-blue-300 font-mono">9,480</span>
                <span className="text-[10px] text-teal-400 block">Loans & NAIS Policies</span>
              </div>

              <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 space-y-1">
                <span className="text-slate-400 font-bold block">Portfolio Non-Performing Rate</span>
                <span className="text-2xl font-black text-emerald-400 font-mono">1.8%</span>
                <span className="text-[10px] text-slate-400 block">BNR Benchmark Target &lt; 5%</span>
              </div>

              <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 space-y-1">
                <span className="text-slate-400 font-bold block">NAIS Government Subsidy Disbursed</span>
                <span className="text-2xl font-black text-amber-300 font-mono">2.4B RWF</span>
                <span className="text-[10px] text-slate-400 block">50% MINAGRI Match</span>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
