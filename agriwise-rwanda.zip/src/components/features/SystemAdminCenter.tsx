import React, { useState, useEffect } from 'react';
import {
  Language,
  User,
  RegisteredFarm,
  OwnerNotification,
  NotificationType,
  NotificationPriority,
  OwnerNotificationPreferences,
  IdentityVerificationRecord
} from '../../types';
import { translations } from '../../data/translations';
import {
  getOwnerConfig,
  updateOwnerConfig,
  getOwnerNotifications,
  markNotificationAsRead,
  markAllNotificationsAsRead,
  deleteNotification,
  clearAllNotifications,
  getOwnerNotificationPreferences,
  updateOwnerNotificationPreferences,
  triggerOwnerNotification,
  getAuditLogs,
  recordAuditLog
} from '../../services/ownerNotificationService';
import {
  getSystemContact,
  updateSystemContact,
  getGeneralSettings,
  updateGeneralSettings,
  getRegistrationSettings,
  updateRegistrationSettings,
  getSecuritySettings,
  updateSecuritySettings,
  getMaintenanceMode,
  setMaintenanceMode,
  getEmailConfig,
  updateEmailConfig,
  getSmsConfig,
  updateSmsConfig,
  getSystemCategories,
  addSystemCategory,
  updateSystemCategory,
  deleteSystemCategory,
  getSupportTickets,
  updateSupportTicket,
  getBackups,
  triggerSystemBackup,
  SystemContactInfo,
  SystemCategoryItem,
  SupportTicket
} from '../../services/systemSettingsService';
import { getRegisteredUsers, getSecurityAuditLogs } from '../../services/authService';
import {
  ShieldAlert,
  Users,
  Tractor,
  MapPin,
  Bot,
  PhoneCall,
  DollarSign,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Search,
  Filter,
  UserCheck,
  UserX,
  FileText,
  Lock,
  Globe2,
  Server,
  Layers,
  Settings,
  PieChart,
  BarChart3,
  TrendingUp,
  Store,
  Radio,
  Send,
  Download,
  Eye,
  RefreshCw,
  Sliders,
  Cpu,
  Database,
  ShieldCheck,
  BadgeCheck,
  Sparkles,
  ChevronRight,
  ChevronDown,
  Plus,
  Trash2,
  Edit,
  Building2,
  Award,
  Bell,
  Mail,
  Phone,
  Clock,
  Check,
  Smartphone,
  Volume2,
  Shield,
  HelpCircle,
  HardDrive,
  LogOut,
  X,
  MessageSquare,
  Package,
  ShoppingCart,
  Receipt,
  FileSpreadsheet,
  ToggleLeft,
  ToggleRight,
  Key,
  KeyRound,
  Laptop,
  Video
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { AdminVideoManager } from './AdminVideoManager';
import { JimmyMicoPro } from './JimmyMicoPro';
import { UserRole } from '../../types';

interface SystemAdminCenterProps {
  currentUser?: User;
  language: Language;
  registeredFarms?: RegisteredFarm[];
}

export const SystemAdminCenter: React.FC<SystemAdminCenterProps> = ({
  currentUser,
  language,
  registeredFarms = [],
}) => {
  const t = translations[language] || translations['rw'];

  // Admin Active Main Tab State
  const [activeTab, setActiveTab] = useState<string>('overview');

  // Sidebar Sub-category Collapsibles
  const [openSubMenus, setOpenSubMenus] = useState<Record<string, boolean>>({
    users: true,
    marketplace: true,
    communication: true,
    analytics: true,
    educational: true,
    system: true,
    security: true,
    data: true,
    profile: true
  });

  const toggleSubMenu = (menuKey: string) => {
    setOpenSubMenus((prev) => ({ ...prev, [menuKey]: !prev[menuKey] }));
  };

  // Central System Settings & Contact State
  const [systemContact, setSystemContact] = useState<SystemContactInfo>(getSystemContact());
  const [generalSettings, setGeneralSettings] = useState(getGeneralSettings());
  const [registrationSettings, setRegistrationSettings] = useState(getRegistrationSettings());
  const [securitySettings, setSecuritySettings] = useState(getSecuritySettings());
  const [maintenanceMode, setMaintenanceModeState] = useState(getMaintenanceMode());
  const [emailConfig, setEmailConfigState] = useState(getEmailConfig());
  const [smsConfig, setSmsConfigState] = useState(getSmsConfig());
  const [categoriesList, setCategoriesList] = useState<SystemCategoryItem[]>(getSystemCategories());
  const [ticketsList, setTicketsList] = useState<SupportTicket[]>(getSupportTickets());
  const [backupsList, setBackupsList] = useState(getBackups());

  // Owner Notifications, Preferences & Audit Logs
  const [notificationsList, setNotificationsList] = useState<OwnerNotification[]>(getOwnerNotifications());
  const [ownerPreferences, setOwnerPreferences] = useState<OwnerNotificationPreferences>(getOwnerNotificationPreferences());
  const [auditLogList, setAuditLogList] = useState(getAuditLogs());

  // Search & Filter States
  const [userSearch, setUserSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [userStatusFilter, setUserStatusFilter] = useState('all');
  const [notifSearch, setNotifSearch] = useState('');
  const [notifTypeFilter, setNotifTypeFilter] = useState('all');
  const [notifPriorityFilter, setNotifPriorityFilter] = useState('all');
  const [ticketStatusFilter, setTicketStatusFilter] = useState('all');

  // Feedback Messages
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [testNotifMsg, setTestNotifMsg] = useState<string | null>(null);

  // User Profile Modal State
  const [selectedUserModal, setSelectedUserModal] = useState<any | null>(null);

  // Category Add Form Modal State
  const [showAddCategoryModal, setShowAddCategoryModal] = useState(false);
  const [newCatType, setNewCatType] = useState<SystemCategoryItem['type']>('product');
  const [newCatNameRw, setNewCatNameRw] = useState('');
  const [newCatNameEn, setNewCatNameEn] = useState('');
  const [newCatCode, setNewCatCode] = useState('');

  // Ticket Response Modal State
  const [selectedTicketModal, setSelectedTicketModal] = useState<SupportTicket | null>(null);
  const [ticketReplyText, setTicketReplyText] = useState('');

  // Backup Password Confirmation Modal State
  const [showBackupConfirmModal, setShowBackupConfirmModal] = useState(false);
  const [adminPasswordConfirm, setAdminPasswordConfirm] = useState('');

  // Identity Verification Admin State
  const [identityRecords, setIdentityRecords] = useState<IdentityVerificationRecord[]>([]);
  const [identitySearch, setIdentitySearch] = useState('');
  const [identityStatusFilter, setIdentityStatusFilter] = useState('all');
  const [selectedIdentityRecord, setSelectedIdentityRecord] = useState<IdentityVerificationRecord | null>(null);
  const [adminNotesInput, setAdminNotesInput] = useState('');
  const [isReviewingRecord, setIsReviewingRecord] = useState(false);

  // Registration & Verification Settings State
  const [verificationSettings, setVerificationSettings] = useState({
    requireEmailVerification: true,
    requireIdentityVerification: true,
    identityDataRetentionDays: 90
  });

  const loadIdentityRecords = async () => {
    try {
      const res = await fetch('/api/admin/identity/records');
      if (res.ok) {
        const data = await res.json();
        if (data.records) setIdentityRecords(data.records);
      }
    } catch (e) {
      console.error('Failed to fetch identity records:', e);
    }
  };

  const loadVerificationSettings = async () => {
    try {
      const res = await fetch('/api/admin/verification-settings');
      if (res.ok) {
        const data = await res.json();
        if (data.settings) setVerificationSettings(data.settings);
      }
    } catch (e) {
      console.error('Failed to fetch verification settings:', e);
    }
  };

  useEffect(() => {
    loadIdentityRecords();
    loadVerificationSettings();
  }, [activeTab]);

  const handleAdminIdentityReview = async (recordId: string, adminAction: 'approve' | 'reject' | 'request_correction' | 'mark_review') => {
    try {
      setIsReviewingRecord(true);
      const res = await fetch('/api/admin/identity/review', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recordId,
          adminAction,
          adminNotes: adminNotesInput,
          adminUserId: currentUser?.id || 'usr_admin'
        })
      });

      if (res.ok) {
        handleShowToast(`✓ Identity Verification decision saved: ${adminAction.toUpperCase()}`);
        setSelectedIdentityRecord(null);
        setAdminNotesInput('');
        loadIdentityRecords();
      }
    } catch (e) {
      handleShowToast('Error executing admin decision.');
    } finally {
      setIsReviewingRecord(false);
    }
  };

  const handleSaveVerificationSettings = async () => {
    try {
      const res = await fetch('/api/admin/verification-settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(verificationSettings)
      });
      if (res.ok) {
        handleShowToast('✓ Registration & Privacy Verification Settings updated');
      }
    } catch (e) {
      handleShowToast('Failed to save settings');
    }
  };

  // Sample User Database
  const [userList, setUserList] = useState([
    {
      id: 'USR-001',
      name: 'Jean-Paul Nsengiyumva',
      phone: '+250 788 123 456',
      email: 'jean.paul@agriwise.rw',
      role: 'farmer',
      district: 'Musanze',
      status: 'verified',
      registeredAt: '2026-01-15',
      lastLogin: '2026-08-11 09:30',
      activitiesCount: 24
    },
    {
      id: 'USR-002',
      name: 'Claire Uwera (Musanze Potato Coop)',
      phone: '+250 788 654 321',
      email: 'claire@musanzecoop.rw',
      role: 'cooperative',
      district: 'Musanze',
      status: 'verified',
      registeredAt: '2026-02-01',
      lastLogin: '2026-08-11 10:15',
      activitiesCount: 88
    },
    {
      id: 'USR-003',
      name: 'Dr. Emmanuel Hakizimana',
      phone: '+250 788 999 888',
      email: 'emmanuel.rab@gov.rw',
      role: 'expert',
      district: 'Kigali',
      status: 'verified',
      registeredAt: '2025-11-20',
      lastLogin: '2026-08-10 16:45',
      activitiesCount: 142
    },
    {
      id: 'USR-004',
      name: 'Eric Kwizera Agrovet Inputs',
      phone: '+250 788 444 333',
      email: 'kwizera.inputs@gmail.com',
      role: 'agrodealer',
      district: 'Nyagatare',
      status: 'pending',
      registeredAt: '2026-03-04',
      lastLogin: '2026-08-09 11:20',
      activitiesCount: 12
    },
    {
      id: 'USR-005',
      name: 'Inyange Industries Logistics',
      phone: '+250 788 222 111',
      email: 'procurement@inyange.rw',
      role: 'buyer',
      district: 'Kigali',
      status: 'verified',
      registeredAt: '2026-01-10',
      lastLogin: '2026-08-11 08:00',
      activitiesCount: 65
    },
    {
      id: 'USR-006',
      name: 'Tharcisse Mugabo Transporters',
      phone: '+250 788 555 777',
      email: 'tharcisse.trans@gmail.com',
      role: 'transporter',
      district: 'Huye',
      status: 'verified',
      registeredAt: '2026-02-18',
      lastLogin: '2026-08-10 14:10',
      activitiesCount: 38
    },
    {
      id: 'USR-007',
      name: 'MINAGRI District Agronomist Officer',
      phone: '+250 788 000 999',
      email: 'agronomy.musanze@gov.rw',
      role: 'government',
      district: 'Musanze',
      status: 'verified',
      registeredAt: '2025-10-01',
      lastLogin: '2026-08-11 07:45',
      activitiesCount: 210
    },
    {
      id: 'USR-008',
      name: 'Inkingi Cattle Farmers Association',
      phone: '+250 788 333 222',
      email: 'info@inkingi.rw',
      role: 'livestock_farmer',
      district: 'Nyagatare',
      status: 'verified',
      registeredAt: '2026-01-28',
      lastLogin: '2026-08-10 18:30',
      activitiesCount: 52
    }
  ]);

  // Sample Products Oversight List
  const [productList, setProductList] = useState([
    { id: 'PRD-101', name: 'Irish Potatoes (Kinigi Grade A)', category: 'Produce', seller: 'Musanze Potato Coop', priceRwf: 450, unit: 'Kg', status: 'approved', stock: '25,000 Kg' },
    { id: 'PRD-102', name: 'NPK 17-17-17 Fertilizer 50kg', category: 'Inputs', seller: 'Eric Kwizera Agrovet', priceRwf: 38000, unit: 'Bags', status: 'approved', stock: '120 Bags' },
    { id: 'PRD-103', name: 'Fresh Whole Milk (Inyange Grade)', category: 'Livestock', seller: 'Inkingi Cattle Association', priceRwf: 300, unit: 'Liters', status: 'approved', stock: '1,500 Liters' },
    { id: 'PRD-104', name: 'Unregistered Crop Pesticide Formula X', category: 'Inputs', seller: 'Unknown Trader', priceRwf: 12000, unit: 'Liters', status: 'flagged', stock: '50 Liters' }
  ]);

  // Sample Marketplace Orders List
  const [orderList, setOrderList] = useState([
    { id: 'ORD-9901', buyer: 'Inyange Industries', seller: 'Musanze Potato Coop', product: 'Irish Potatoes', totalRwf: 11250000, escrowStatus: 'payout_ready', date: '2026-08-10' },
    { id: 'ORD-9902', buyer: 'Bralirwa Grain Buyer', seller: 'Nyagatare Maize Union', product: 'Dry Maize Grain', totalRwf: 8400000, escrowStatus: 'in_transit', date: '2026-08-11' },
    { id: 'ORD-9903', buyer: 'Jean-Paul Nsengiyumva', seller: 'Kwizera Agrovet', product: 'NPK Fertilizer', totalRwf: 190000, escrowStatus: 'settled', date: '2026-08-09' }
  ]);

  // Analytics Chart Data
  const userGrowthData = [
    { month: 'Jan', Farmers: 820, Cooperatives: 40, Buyers: 25 },
    { month: 'Feb', Farmers: 950, Cooperatives: 55, Buyers: 42 },
    { month: 'Mar', Farmers: 1100, Cooperatives: 68, Buyers: 60 },
    { month: 'Apr', Farmers: 1240, Cooperatives: 85, Buyers: 80 },
    { month: 'May', Farmers: 1420, Cooperatives: 102, Buyers: 95 },
    { month: 'Jun', Farmers: 1680, Cooperatives: 120, Buyers: 110 }
  ];

  const transactionVolumeData = [
    { week: 'Wk 1', VolumeRwf: 12500000 },
    { week: 'Wk 2', VolumeRwf: 18400000 },
    { week: 'Wk 3', VolumeRwf: 24100000 },
    { week: 'Wk 4', VolumeRwf: 29500000 }
  ];

  const refreshAllData = () => {
    setSystemContact(getSystemContact());
    setGeneralSettings(getGeneralSettings());
    setRegistrationSettings(getRegistrationSettings());
    setSecuritySettings(getSecuritySettings());
    setMaintenanceModeState(getMaintenanceMode());
    setEmailConfigState(getEmailConfig());
    setSmsConfigState(getSmsConfig());
    setCategoriesList(getSystemCategories());
    setTicketsList(getSupportTickets());
    setBackupsList(getBackups());
    setNotificationsList(getOwnerNotifications());
    setAuditLogList(getAuditLogs());
  };

  useEffect(() => {
    refreshAllData();
  }, [activeTab]);

  const handleShowToast = (msg: string) => {
    setSaveSuccessMsg(msg);
    setTimeout(() => setSaveSuccessMsg(null), 4000);
  };

  // User Management Actions
  const handleUserStatusToggle = (userId: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'verified' ? 'suspended' : 'verified';
    setUserList((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, status: nextStatus } : u))
    );
    recordAuditLog({
      userId: currentUser?.id || 'owner',
      userName: currentUser?.name || 'System Owner',
      action: 'USER_STATUS_CHANGE',
      description: `User ${userId} status changed from ${currentStatus} to ${nextStatus}`,
      ipAddress: '127.0.0.1',
      status: 'SUCCESS'
    });
    handleShowToast(`✓ Account ${userId} status updated to ${nextStatus.toUpperCase()}`);
    refreshAllData();
  };

  const handleDeleteUser = (userId: string) => {
    setUserList((prev) => prev.filter((u) => u.id !== userId));
    recordAuditLog({
      userId: currentUser?.id || 'owner',
      userName: currentUser?.name || 'System Owner',
      action: 'USER_DELETE',
      description: `Account ${userId} deleted by Administrator`,
      ipAddress: '127.0.0.1',
      status: 'SUCCESS'
    });
    handleShowToast(`✓ Account ${userId} deleted successfully`);
    refreshAllData();
  };

  // Maintenance Mode Toggle
  const handleToggleMaintenanceMode = (enabled: boolean) => {
    const updated = setMaintenanceMode(enabled, maintenanceMode.message);
    setMaintenanceModeState(updated);
    handleShowToast(`✓ Maintenance Mode ${enabled ? 'ENABLED' : 'DISABLED'}`);
    refreshAllData();
  };

  // Contact Info Save
  const handleSaveContactInfo = () => {
    const updated = updateSystemContact(systemContact);
    setSystemContact(updated);
    handleShowToast('✓ Official System Contact Information saved successfully');
    refreshAllData();
  };

  // Add System Category
  const handleCreateCategory = () => {
    if (!newCatNameRw || !newCatNameEn) return;
    addSystemCategory({
      type: newCatType,
      nameRw: newCatNameRw,
      nameEn: newCatNameEn,
      code: newCatCode || newCatNameEn.toUpperCase().replace(/\s+/g, '_'),
      isActive: true,
      itemCount: 0
    });
    setShowAddCategoryModal(false);
    setNewCatNameRw('');
    setNewCatNameEn('');
    setNewCatCode('');
    setCategoriesList(getSystemCategories());
    handleShowToast('✓ New System Category created');
  };

  // Support Ticket Reply
  const handleReplyTicket = () => {
    if (!selectedTicketModal) return;
    updateSupportTicket(selectedTicketModal.id, 'resolved', ticketReplyText);
    setSelectedTicketModal(null);
    setTicketReplyText('');
    setTicketsList(getSupportTickets());
    handleShowToast('✓ Support Ticket resolved and reply sent to user');
  };

  // Trigger Manual Backup
  const handleCreateBackup = () => {
    if (!adminPasswordConfirm) {
      alert('Please enter Admin Authorization Password');
      return;
    }
    triggerSystemBackup();
    setShowBackupConfirmModal(false);
    setAdminPasswordConfirm('');
    setBackupsList(getBackups());
    handleShowToast('✓ Manual System Database Backup created successfully');
  };

  // Test Notification Dispatch
  const handleSendTestNotification = async () => {
    setTestNotifMsg('Dispatched test alert to System Phone (0792426760) & Email (support@agriwise.rw)...');
    const res = await triggerOwnerNotification({
      type: 'security',
      activitySubtype: 'security_event',
      title: 'TEST DISPATCH: Admin Control Gateway Active',
      message: 'Automated check verifying system phone 0792426760 and official email support@agriwise.rw.',
      priority: 'high',
      relatedUserId: currentUser?.id || 'owner-001',
      relatedUserName: currentUser?.name || 'System Owner',
      relatedUserPhone: '0792426760',
      relatedUserEmail: 'support@agriwise.rw',
      relatedUserRole: 'system_owner'
    });
    setTestNotifMsg(`✓ Dispatch result: Email Delivered: ${res.emailDelivered}, WASP SMS Delivered: ${res.smsDelivered}`);
    setTimeout(() => setTestNotifMsg(null), 5000);
    refreshAllData();
  };

  const unreadNotifCount = notificationsList.filter((n) => !n.isRead).length;

  // Filter Users
  const filteredUsers = userList.filter((u) => {
    const matchesSearch =
      u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.phone.includes(userSearch) ||
      u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.district.toLowerCase().includes(userSearch.toLowerCase());
    const matchesRole = roleFilter === 'all' || u.role === roleFilter;
    const matchesStatus = userStatusFilter === 'all' || u.status === userStatusFilter;
    return matchesSearch && matchesRole && matchesStatus;
  });

  return (
    <div className="flex flex-col lg:flex-row gap-6 max-w-[1600px] mx-auto pb-16 font-sans text-slate-100">
      
      {/* Toast Alert Banner */}
      {saveSuccessMsg && (
        <div className="fixed top-20 right-6 z-50 bg-emerald-950 border border-emerald-500/60 text-emerald-300 px-5 py-3.5 rounded-2xl shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top duration-300">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="font-bold text-xs">{saveSuccessMsg}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SECTION 27: RESPONSIVE ADMIN SIDEBAR STRUCTURE */}
      {/* ========================================================================= */}
      <aside className="w-full lg:w-72 shrink-0 bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4">
        
        {/* Sidebar Header */}
        <div className="border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-gradient-to-br from-emerald-500 to-teal-700 rounded-xl text-white shadow-lg">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-black text-white text-sm tracking-tight uppercase">ADMIN CONTROL CENTER</h2>
              <p className="text-[10px] text-emerald-400 font-mono font-bold">AGRIWISE RWANDA SYSTEM</p>
            </div>
          </div>
        </div>

        {/* Sidebar Navigation Tree */}
        <nav className="space-y-1.5 text-xs">
          
          {/* Overview */}
          <button
            onClick={() => setActiveTab('overview')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl font-bold transition-all ${
              activeTab === 'overview'
                ? 'bg-emerald-600 text-white shadow-lg'
                : 'hover:bg-slate-950 text-slate-300'
            }`}
          >
            <Activity className="w-4 h-4 text-emerald-400" />
            <span>Overview & Telemetry</span>
          </button>

          {/* Users Group */}
          <div>
            <button
              onClick={() => toggleSubMenu('users')}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold hover:bg-slate-950 text-slate-300"
            >
              <div className="flex items-center gap-3">
                <Users className="w-4 h-4 text-teal-400" />
                <span>Users ({userList.length})</span>
              </div>
              {openSubMenus.users ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>

            {openSubMenus.users && (
              <div className="ml-7 mt-1 space-y-1 border-l-2 border-slate-800 pl-3">
                {[
                  { id: 'users_all', label: 'All Users', role: 'all' },
                  { id: 'users_identity_verification', label: 'Identity Verification', role: 'identity_verification' },
                  { id: 'users_farmer', label: 'Farmers', role: 'farmer' },
                  { id: 'users_livestock', label: 'Livestock Farmers', role: 'livestock_farmer' },
                  { id: 'users_coop', label: 'Cooperatives', role: 'cooperative' },
                  { id: 'users_dealer', label: 'Agro-dealers', role: 'agrodealer' },
                  { id: 'users_buyer', label: 'Buyers', role: 'buyer' },
                  { id: 'users_expert', label: 'Experts', role: 'expert' },
                  { id: 'users_transporter', label: 'Transporters', role: 'transporter' },
                  { id: 'users_gov', label: 'Government', role: 'government' },
                  { id: 'roles_matrix', label: 'Role & Permission Matrix', role: 'matrix' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      if (item.role !== 'matrix') setRoleFilter(item.role);
                    }}
                    className={`w-full text-left py-1.5 px-2.5 rounded-xl font-medium transition-colors ${
                      activeTab === item.id ? 'bg-slate-950 text-emerald-400 font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Marketplace Group */}
          <div>
            <button
              onClick={() => toggleSubMenu('marketplace')}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold hover:bg-slate-950 text-slate-300"
            >
              <div className="flex items-center gap-3">
                <Store className="w-4 h-4 text-amber-400" />
                <span>Marketplace</span>
              </div>
              {openSubMenus.marketplace ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>

            {openSubMenus.marketplace && (
              <div className="ml-7 mt-1 space-y-1 border-l-2 border-slate-800 pl-3">
                {[
                  { id: 'mp_products', label: 'Products Oversight' },
                  { id: 'mp_categories', label: 'System Categories' },
                  { id: 'mp_orders', label: 'Orders & Escrow' },
                  { id: 'mp_transactions', label: 'Financial Transactions' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full text-left py-1.5 px-2.5 rounded-xl font-medium transition-colors ${
                      activeTab === item.id ? 'bg-slate-950 text-amber-400 font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Communication Group */}
          <div>
            <button
              onClick={() => toggleSubMenu('communication')}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold hover:bg-slate-950 text-slate-300"
            >
              <div className="flex items-center gap-3 relative">
                <Bell className="w-4 h-4 text-purple-400" />
                <span>Communication</span>
                {unreadNotifCount > 0 && (
                  <span className="bg-rose-500 text-white text-[9px] font-black px-1.5 py-0.2 rounded-full animate-pulse">
                    {unreadNotifCount}
                  </span>
                )}
              </div>
              {openSubMenus.communication ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>

            {openSubMenus.communication && (
              <div className="ml-7 mt-1 space-y-1 border-l-2 border-slate-800 pl-3">
                {[
                  { id: 'comm_notifs', label: `Notifications (${unreadNotifCount})` },
                  { id: 'comm_email', label: 'Email Settings' },
                  { id: 'comm_sms', label: 'SMS WASP Settings' },
                  { id: 'comm_support', label: 'Support & Tickets' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full text-left py-1.5 px-2.5 rounded-xl font-medium transition-colors ${
                      activeTab === item.id ? 'bg-slate-950 text-purple-400 font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Analytics Group */}
          <div>
            <button
              onClick={() => toggleSubMenu('analytics')}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold hover:bg-slate-950 text-slate-300"
            >
              <div className="flex items-center gap-3">
                <BarChart3 className="w-4 h-4 text-blue-400" />
                <span>Analytics & Reports</span>
              </div>
              {openSubMenus.analytics ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>

            {openSubMenus.analytics && (
              <div className="ml-7 mt-1 space-y-1 border-l-2 border-slate-800 pl-3">
                {[
                  { id: 'analytics_reports', label: 'Executive Reports' },
                  { id: 'analytics_platform', label: 'Platform Analytics' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full text-left py-1.5 px-2.5 rounded-xl font-medium transition-colors ${
                      activeTab === item.id ? 'bg-slate-950 text-blue-400 font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Educational Content Group */}
          <div>
            <button
              onClick={() => toggleSubMenu('educational')}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold hover:bg-slate-950 text-slate-300"
            >
              <div className="flex items-center gap-3">
                <Video className="w-4 h-4 text-emerald-400" />
                <span>Educational Content</span>
              </div>
              {openSubMenus.educational ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>

            {openSubMenus.educational && (
              <div className="ml-7 mt-1 space-y-1 border-l-2 border-slate-800 pl-3">
                {[
                  { id: 'edu_videos', label: 'Agricultural Videos' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full text-left py-1.5 px-2.5 rounded-xl font-medium transition-colors ${
                      activeTab === item.id ? 'bg-slate-950 text-emerald-400 font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* System Management Group */}
          <div>
            <button
              onClick={() => toggleSubMenu('system')}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold hover:bg-slate-950 text-slate-300"
            >
              <div className="flex items-center gap-3">
                <Settings className="w-4 h-4 text-emerald-400" />
                <span>System Management</span>
              </div>
              {openSubMenus.system ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>

            {openSubMenus.system && (
              <div className="ml-7 mt-1 space-y-1 border-l-2 border-slate-800 pl-3">
                {[
                  { id: 'sys_settings', label: 'System Settings' },
                  { id: 'sys_contact', label: 'Contact Information' },
                  { id: 'jimmy_mico_pro', label: 'Jimmy MICO PRO (Footer)' },
                  { id: 'sys_registration', label: 'Registration Settings' },
                  { id: 'sys_integrations', label: 'Integrations Center' },
                  { id: 'sys_maintenance', label: 'Maintenance Mode' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full text-left py-1.5 px-2.5 rounded-xl font-medium transition-colors ${
                      activeTab === item.id ? 'bg-slate-950 text-emerald-400 font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Security Group */}
          <div>
            <button
              onClick={() => toggleSubMenu('security')}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold hover:bg-slate-950 text-slate-300"
            >
              <div className="flex items-center gap-3">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                <span>Security</span>
              </div>
              {openSubMenus.security ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>

            {openSubMenus.security && (
              <div className="ml-7 mt-1 space-y-1 border-l-2 border-slate-800 pl-3">
                {[
                  { id: 'sec_center', label: 'Security Center' },
                  { id: 'sec_sessions', label: 'Active Sessions' },
                  { id: 'sec_audit', label: 'Audit Logs' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full text-left py-1.5 px-2.5 rounded-xl font-medium transition-colors ${
                      activeTab === item.id ? 'bg-slate-950 text-rose-400 font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Data & Backup Group */}
          <div>
            <button
              onClick={() => toggleSubMenu('data')}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold hover:bg-slate-950 text-slate-300"
            >
              <div className="flex items-center gap-3">
                <Database className="w-4 h-4 text-teal-400" />
                <span>Data & Backup</span>
              </div>
              {openSubMenus.data ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>

            {openSubMenus.data && (
              <div className="ml-7 mt-1 space-y-1 border-l-2 border-slate-800 pl-3">
                {[
                  { id: 'data_backup', label: 'Database Backup' },
                  { id: 'data_mgmt', label: 'Data Management' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full text-left py-1.5 px-2.5 rounded-xl font-medium transition-colors ${
                      activeTab === item.id ? 'bg-slate-950 text-teal-400 font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Admin Profile */}
          <button
            onClick={() => setActiveTab('admin_profile')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl font-bold transition-all ${
              activeTab === 'admin_profile' ? 'bg-emerald-600 text-white shadow-lg' : 'hover:bg-slate-950 text-slate-300'
            }`}
          >
            <UserCheck className="w-4 h-4 text-emerald-400" />
            <span>Admin Profile</span>
          </button>

        </nav>

        {/* Maintenance Status Widget */}
        <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-2 text-xs">
          <div className="flex justify-between items-center">
            <span className="text-slate-400 font-medium">Maintenance Mode:</span>
            <span className={`font-black text-[10px] px-2 py-0.5 rounded-full ${
              maintenanceMode.enabled ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
            }`}>
              {maintenanceMode.enabled ? 'ACTIVE' : 'OFF'}
            </span>
          </div>
          <p className="text-[10px] text-slate-500 line-clamp-2">{maintenanceMode.message}</p>
        </div>

      </aside>

      {/* ========================================================================= */}
      {/* MAIN WORKSPACE AREA */}
      {/* ========================================================================= */}
      <main className="flex-1 min-w-0 space-y-6">

        {/* Header Strip */}
        <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950 border border-slate-800 rounded-3xl p-6 shadow-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-[10px] font-extrabold uppercase">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>SUPER ADMIN AUTHORITY • LEVEL 1</span>
            </div>
            <h1 className="text-2xl font-black text-white tracking-tight">
              AGRIWISE RWANDA Control Center
            </h1>
            <p className="text-xs text-slate-300 font-medium">
              Official System Phone: <strong className="text-emerald-400">{systemContact.officialPhone}</strong> | Email: <strong className="text-emerald-400">{systemContact.officialEmail}</strong>
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <button
              onClick={handleSendTestNotification}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3.5 py-2 rounded-2xl flex items-center gap-1.5 shadow"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Test Broadcast</span>
            </button>
            <button
              onClick={() => setActiveTab('sys_maintenance')}
              className={`px-3.5 py-2 rounded-2xl font-bold border transition-colors flex items-center gap-1.5 ${
                maintenanceMode.enabled ? 'bg-rose-950 text-rose-300 border-rose-500/40' : 'bg-slate-900 text-slate-300 border-slate-800'
              }`}
            >
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              <span>Maintenance Mode ({maintenanceMode.enabled ? 'ON' : 'OFF'})</span>
            </button>
          </div>
        </div>

        {testNotifMsg && (
          <div className="p-3.5 bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 rounded-2xl text-xs font-medium animate-fade-in">
            {testNotifMsg}
          </div>
        )}

        {/* ------------------------------------------------------------------------- */}
        {/* TAB 1: OVERVIEW & TELEMETRY */}
        {/* ------------------------------------------------------------------------- */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            
            {/* 18 System Overview Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5 text-xs">
              {[
                { label: 'Total Users', val: '148,250', icon: Users, color: 'text-emerald-400' },
                { label: 'Active Users', val: '124,100', icon: UserCheck, color: 'text-teal-400' },
                { label: 'New Today', val: '14', icon: Plus, color: 'text-blue-400' },
                { label: 'New This Week', val: '82', icon: TrendingUp, color: 'text-purple-400' },
                { label: 'Farmers', val: '112,400', icon: Tractor, color: 'text-emerald-400' },
                { label: 'Livestock Farmers', val: '18,500', icon: Shield, color: 'text-amber-400' },
                { label: 'Cooperatives', val: '85', icon: Building2, color: 'text-cyan-400' },
                { label: 'Agro-dealers', val: '42', icon: Store, color: 'text-emerald-400' },
                { label: 'Buyers', val: '110', icon: ShoppingCart, color: 'text-indigo-400' },
                { label: 'Experts', val: '38', icon: Award, color: 'text-teal-400' },
                { label: 'Transporters', val: '56', icon: Radio, color: 'text-amber-400' },
                { label: 'Government', val: '12', icon: Building2, color: 'text-blue-400' },
                { label: 'Pending Verif.', val: '7', icon: AlertTriangle, color: 'text-rose-400' },
                { label: 'New Orders Today', val: '28', icon: Package, color: 'text-emerald-400' },
                { label: 'Total Transactions', val: '84.5M Frw', icon: DollarSign, color: 'text-teal-400' },
                { label: 'Unread Alerts', val: String(unreadNotifCount), icon: Bell, color: 'text-rose-400' },
                { label: 'Open Support Tckts', val: String(ticketsList.filter((t) => t.status !== 'resolved').length), icon: HelpCircle, color: 'text-amber-400' },
                { label: 'Security Events', val: '3', icon: ShieldAlert, color: 'text-rose-400' }
              ].map((card, idx) => {
                const Icon = card.icon;
                return (
                  <div key={idx} className="bg-slate-900 border border-slate-800 p-3.5 rounded-2xl space-y-1.5 shadow-lg">
                    <div className="flex justify-between items-center text-slate-400">
                      <span className="text-[10px] font-medium leading-tight">{card.label}</span>
                      <Icon className={`w-3.5 h-3.5 ${card.color}`} />
                    </div>
                    <div className="text-xl font-black text-white font-mono">{card.val}</div>
                  </div>
                );
              })}
            </div>

            {/* Growth & Financial Analytics Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* User Growth Line Chart */}
              <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl space-y-4 shadow-xl">
                <h3 className="font-bold text-white text-sm flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                  <span>Platform User Registration Growth Trends</span>
                </h3>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={userGrowthData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis dataKey="month" stroke="#64748b" />
                      <YAxis stroke="#64748b" />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155' }} />
                      <Line type="monotone" dataKey="Farmers" stroke="#10b981" strokeWidth={3} />
                      <Line type="monotone" dataKey="Cooperatives" stroke="#06b6d4" strokeWidth={2} />
                      <Line type="monotone" dataKey="Buyers" stroke="#8b5cf6" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Transaction Volume Bar Chart */}
              <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl space-y-4 shadow-xl">
                <h3 className="font-bold text-white text-sm flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-teal-400" />
                  <span>Marketplace Escrow Volume (RWF)</span>
                </h3>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={transactionVolumeData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis dataKey="week" stroke="#64748b" />
                      <YAxis stroke="#64748b" />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155' }} />
                      <Bar dataKey="VolumeRwf" fill="#0d9488" radius={[8, 8, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

            </div>

            {/* Recent Platform Activity Stream */}
            <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4 shadow-xl">
              <h3 className="font-bold text-white text-base flex items-center gap-2 border-b border-slate-800 pb-3">
                <Clock className="w-5 h-5 text-emerald-400" />
                <span>Recent System-Wide Activity Stream</span>
              </h3>
              <div className="space-y-3 text-xs">
                {[
                  { text: 'New Cooperative registered: Musanze Potato Producers (450 Members)', time: '10 mins ago', type: 'user' },
                  { text: 'High-value order created: Inyange Industries ordered 25 Tons Irish Potatoes', time: '25 mins ago', type: 'marketplace' },
                  { text: 'RAB Agronomist Dr. Emmanuel Hakizimana issued Late Blight Advisory', time: '1 hour ago', type: 'expert' },
                  { text: 'System Backup SNAP_20260811.sql.gz generated automatically', time: '2 hours ago', type: 'system' }
                ].map((act, idx) => (
                  <div key={idx} className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex justify-between items-center text-slate-300">
                    <span className="font-medium text-white">{act.text}</span>
                    <span className="text-[10px] text-slate-500 font-mono">{act.time}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* ------------------------------------------------------------------------- */}
        {/* TAB 2: USER MANAGEMENT */}
        {/* ------------------------------------------------------------------------- */}
        {(activeTab.startsWith('users_') || activeTab === 'users') && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
            
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="font-bold text-white text-base flex items-center gap-2">
                  <Users className="w-5 h-5 text-emerald-400" />
                  <span>User Account & Role Management</span>
                </h3>
                <p className="text-xs text-slate-400">Search, filter, inspect, activate, suspend, or delete accounts across Rwanda.</p>
              </div>

              {/* Filters Bar */}
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Search name, phone, district..."
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-white outline-none w-48 text-xs"
                  />
                </div>

                <select
                  value={roleFilter}
                  onChange={(e) => setRoleFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-slate-300 outline-none text-xs capitalize"
                >
                  <option value="all">All Roles</option>
                  <option value="farmer">Farmer</option>
                  <option value="livestock_farmer">Livestock Farmer</option>
                  <option value="cooperative">Cooperative</option>
                  <option value="agrodealer">Agro-dealer</option>
                  <option value="buyer">Buyer</option>
                  <option value="expert">Expert</option>
                  <option value="transporter">Transporter</option>
                  <option value="government">Government</option>
                </select>

                <select
                  value={userStatusFilter}
                  onChange={(e) => setUserStatusFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-slate-300 outline-none text-xs"
                >
                  <option value="all">All Statuses</option>
                  <option value="verified">Verified</option>
                  <option value="pending">Pending</option>
                  <option value="suspended">Suspended</option>
                </select>
              </div>
            </div>

            {/* Users Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-mono uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="p-3">User ID & Name</th>
                    <th className="p-3">Contact (Phone / Email)</th>
                    <th className="p-3">Role</th>
                    <th className="p-3">District</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Reg. Date</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {filteredUsers.map((user) => (
                    <tr key={user.id} className="hover:bg-slate-950/60 transition-colors">
                      <td className="p-3 font-bold text-white">
                        <div>{user.name}</div>
                        <span className="text-[10px] text-slate-500 font-mono">{user.id}</span>
                      </td>
                      <td className="p-3 font-mono text-[11px]">
                        <div>{user.phone}</div>
                        <div className="text-slate-400">{user.email}</div>
                      </td>
                      <td className="p-3">
                        <span className="bg-slate-950 px-2.5 py-1 rounded-full text-[10px] font-bold border border-slate-800 capitalize text-emerald-400">
                          {user.role.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="p-3">{user.district}</td>
                      <td className="p-3">
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                            user.status === 'verified'
                              ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                              : user.status === 'pending'
                              ? 'bg-amber-950/80 text-amber-300 border-amber-500/40'
                              : 'bg-rose-950/80 text-rose-300 border-rose-500/40'
                          }`}
                        >
                          {user.status.toUpperCase()}
                        </span>
                      </td>
                      <td className="p-3 font-mono text-slate-400">{user.registeredAt}</td>
                      <td className="p-3 text-right space-x-1.5">
                        <button
                          onClick={() => setSelectedUserModal(user)}
                          className="px-2.5 py-1 bg-slate-950 hover:bg-slate-800 border border-slate-700 text-slate-200 rounded-xl text-[10px] font-bold"
                        >
                          View Profile
                        </button>
                        <button
                          onClick={() => handleUserStatusToggle(user.id, user.status)}
                          className="px-2.5 py-1 bg-slate-950 hover:bg-slate-800 border border-slate-700 text-amber-300 rounded-xl text-[10px] font-bold"
                        >
                          {user.status === 'verified' ? 'Suspend' : 'Activate'}
                        </button>
                        <button
                          onClick={() => handleDeleteUser(user.id)}
                          className="px-2.5 py-1 bg-rose-950 hover:bg-rose-900 border border-rose-500/30 text-rose-300 rounded-xl text-[10px] font-bold"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* ------------------------------------------------------------------------- */}
        {/* TAB: IDENTITY VERIFICATION MANAGEMENT */}
        {/* ------------------------------------------------------------------------- */}
        {activeTab === 'users_identity_verification' && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
            
            {/* Header */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="font-bold text-white text-base flex items-center gap-2">
                  <BadgeCheck className="w-5 h-5 text-emerald-400" />
                  <span>National Identity Verification Management (NIDA Gateway)</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Monitor, verify, approve, or reject user National ID verification requests in accordance with MINAGRI regulations.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={loadIdentityRecords}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Refresh Records</span>
                </button>
              </div>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-2xl space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase">Total Submissions</span>
                <div className="text-xl font-black text-white font-mono">{identityRecords.length}</div>
              </div>
              <div className="bg-emerald-950/50 border border-emerald-500/30 p-3.5 rounded-2xl space-y-1">
                <span className="text-[10px] text-emerald-300 font-bold uppercase">Verified Identities</span>
                <div className="text-xl font-black text-emerald-400 font-mono">
                  {identityRecords.filter(r => r.identityStatus === 'verified').length}
                </div>
              </div>
              <div className="bg-amber-950/50 border border-amber-500/30 p-3.5 rounded-2xl space-y-1">
                <span className="text-[10px] text-amber-300 font-bold uppercase">Pending Manual Review</span>
                <div className="text-xl font-black text-amber-400 font-mono">
                  {identityRecords.filter(r => r.identityStatus === 'manual_review' || r.reviewStatus === 'pending_review').length}
                </div>
              </div>
              <div className="bg-rose-950/50 border border-rose-500/30 p-3.5 rounded-2xl space-y-1">
                <span className="text-[10px] text-rose-300 font-bold uppercase">Failed / Rejected</span>
                <div className="text-xl font-black text-rose-400 font-mono">
                  {identityRecords.filter(r => r.identityStatus === 'failed' || r.reviewStatus === 'rejected').length}
                </div>
              </div>
            </div>

            {/* Filters */}
            <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search user name, masked ID..."
                  value={identitySearch}
                  onChange={(e) => setIdentitySearch(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-white outline-none w-64 text-xs font-mono"
                />
              </div>

              <select
                value={identityStatusFilter}
                onChange={(e) => setIdentityStatusFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-slate-300 outline-none text-xs"
              >
                <option value="all">All Verification Statuses</option>
                <option value="verified">Verified</option>
                <option value="manual_review">Manual Review Required</option>
                <option value="pending">Pending Verification</option>
                <option value="failed">Failed / Rejected</option>
              </select>
            </div>

            {/* Records Table */}
            <div className="overflow-x-auto text-xs">
              <table className="w-full text-left text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-mono uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="p-3">User & Role</th>
                    <th className="p-3">Masked National ID</th>
                    <th className="p-3">Submission Date</th>
                    <th className="p-3">Verification Result</th>
                    <th className="p-3">Review Status</th>
                    <th className="p-3">Last Attempt</th>
                    <th className="p-3 text-right">Admin Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {identityRecords
                    .filter((rec) => {
                      const matchesSearch =
                        !identitySearch ||
                        rec.userName.toLowerCase().includes(identitySearch.toLowerCase()) ||
                        rec.nationalIdMasked.includes(identitySearch);
                      const matchesStatus =
                        identityStatusFilter === 'all' || rec.identityStatus === identityStatusFilter;
                      return matchesSearch && matchesStatus;
                    })
                    .map((rec) => (
                      <tr key={rec.id} className="hover:bg-slate-950/60 transition-colors">
                        <td className="p-3">
                          <div className="font-bold text-white">{rec.userName}</div>
                          <span className="text-[10px] text-emerald-400 font-mono uppercase">{rec.userRole}</span>
                        </td>
                        <td className="p-3 font-mono font-bold text-slate-200">
                          {rec.nationalIdMasked}
                        </td>
                        <td className="p-3 font-mono text-slate-400">
                          {new Date(rec.submissionDate).toLocaleDateString()}
                        </td>
                        <td className="p-3">
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border uppercase font-mono ${
                            rec.identityStatus === 'verified'
                              ? 'bg-emerald-950 text-emerald-300 border-emerald-500/40'
                              : rec.identityStatus === 'manual_review'
                              ? 'bg-amber-950 text-amber-300 border-amber-500/40'
                              : 'bg-rose-950 text-rose-300 border-rose-500/40'
                          }`}>
                            {rec.identityStatus}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className="bg-slate-950 border border-slate-800 px-2 py-0.5 rounded text-[10px] uppercase font-mono font-bold text-slate-300">
                            {rec.reviewStatus}
                          </span>
                        </td>
                        <td className="p-3 font-mono text-[10px] text-slate-400">
                          {new Date(rec.lastAttemptAt).toLocaleString()}
                        </td>
                        <td className="p-3 text-right space-x-1">
                          <button
                            onClick={() => setSelectedIdentityRecord(rec)}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-bold shadow"
                          >
                            Review / Approve
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* ------------------------------------------------------------------------- */}
        {/* TAB 3: ROLE & PERMISSION MATRIX */}
        {/* ------------------------------------------------------------------------- */}
        {activeTab === 'roles_matrix' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
              <h3 className="font-bold text-white text-base flex items-center gap-2 border-b border-slate-800 pb-3">
                <Award className="w-5 h-5 text-emerald-400" />
                <span>AGRIWISE System Roles & Permission Matrix</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                {[
                  { role: 'Farmer', desc: 'Smallholder farmer managing crop fields, yields, and marketplace sales.', dashboard: '/farmer' },
                  { role: 'Livestock Farmer', desc: 'Livestock breeder managing cattle, vaccination logs, and dairy outputs.', dashboard: '/livestock' },
                  { role: 'Cooperative', desc: 'Cooperative lead managing member registries, bulk aggregations, and loans.', dashboard: '/cooperative' },
                  { role: 'Agro-dealer', desc: 'Licensed supplier managing fertilizer stocks, seeds, and sales points.', dashboard: '/agrodealer' },
                  { role: 'Buyer', desc: 'Commercial commodity trader placing escrow harvest purchase orders.', dashboard: '/buyer' },
                  { role: 'Agricultural Expert', desc: 'Certified RAB extension worker offering advisory and field diagnostics.', dashboard: '/expert' },
                  { role: 'Transporter', desc: 'Logistics provider transporting harvest cargoes with GPS tracking.', dashboard: '/logistics' },
                  { role: 'Bank / Insurance', desc: 'Financial officer evaluating credit scores and crop insurance coverage.', dashboard: '/banking' },
                  { role: 'Government', desc: 'MINAGRI / RAB official monitoring national yield predictions.', dashboard: '/government' },
                  { role: 'Administrator / Owner', desc: 'Super admin with complete system-wide management rights.', dashboard: '/system_admin' }
                ].map((item, idx) => (
                  <div key={idx} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                    <div className="flex justify-between items-center text-white font-bold">
                      <span className="text-sm text-emerald-400">{item.role}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{item.dashboard}</span>
                    </div>
                    <p className="text-slate-300">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------------------- */}
        {/* TAB 4: MARKETPLACE MANAGEMENT */}
        {/* ------------------------------------------------------------------------- */}
        {activeTab.startsWith('mp_') && (
          <div className="space-y-6">
            
            {/* Products Oversight */}
            {activeTab === 'mp_products' && (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                  <h3 className="font-bold text-white text-base flex items-center gap-2">
                    <Store className="w-5 h-5 text-amber-400" />
                    <span>Marketplace Product Listings Moderation</span>
                  </h3>
                </div>

                <div className="overflow-x-auto text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-mono border-b border-slate-800">
                      <tr>
                        <th className="p-3">Product Name</th>
                        <th className="p-3">Category</th>
                        <th className="p-3">Seller</th>
                        <th className="p-3">Price</th>
                        <th className="p-3">Status</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {productList.map((prd) => (
                        <tr key={prd.id} className="hover:bg-slate-950/60">
                          <td className="p-3 font-bold text-white">{prd.name}</td>
                          <td className="p-3 text-slate-400">{prd.category}</td>
                          <td className="p-3 font-medium text-emerald-400">{prd.seller}</td>
                          <td className="p-3 font-mono">{prd.priceRwf} RWF / {prd.unit}</td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              prd.status === 'approved' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30' : 'bg-rose-950 text-rose-300 border border-rose-500/30'
                            }`}>
                              {prd.status.toUpperCase()}
                            </span>
                          </td>
                          <td className="p-3 text-right space-x-2">
                            <button className="px-2.5 py-1 bg-slate-950 border border-slate-800 text-slate-200 rounded-xl font-bold">
                              {prd.status === 'approved' ? 'Flag' : 'Approve'}
                            </button>
                            <button className="px-2.5 py-1 bg-rose-950 border border-rose-500/30 text-rose-300 rounded-xl font-bold">
                              Remove
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Categories Management */}
            {activeTab === 'mp_categories' && (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="font-bold text-white text-base flex items-center gap-2">
                      <Layers className="w-5 h-5 text-teal-400" />
                      <span>System Agricultural Categories Management</span>
                    </h3>
                    <p className="text-xs text-slate-400">Manage crop, product, livestock, service, and unit categories.</p>
                  </div>
                  <button
                    onClick={() => setShowAddCategoryModal(true)}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Category</span>
                  </button>
                </div>

                <div className="overflow-x-auto text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-mono border-b border-slate-800">
                      <tr>
                        <th className="p-3">Type</th>
                        <th className="p-3">Name (English)</th>
                        <th className="p-3">Name (Kinyarwanda)</th>
                        <th className="p-3">Code</th>
                        <th className="p-3">Status</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {categoriesList.map((cat) => (
                        <tr key={cat.id} className="hover:bg-slate-950/60">
                          <td className="p-3 uppercase text-emerald-400 font-mono text-[10px] font-bold">{cat.type}</td>
                          <td className="p-3 font-bold text-white">{cat.nameEn}</td>
                          <td className="p-3 text-slate-300">{cat.nameRw}</td>
                          <td className="p-3 font-mono text-slate-400">{cat.code}</td>
                          <td className="p-3">
                            <span className="bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded text-[10px] font-bold border border-emerald-500/30">
                              ACTIVE
                            </span>
                          </td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => {
                                deleteSystemCategory(cat.id);
                                setCategoriesList(getSystemCategories());
                              }}
                              className="px-2 py-1 text-rose-400 hover:bg-rose-950 rounded-lg"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Orders & Escrow */}
            {activeTab === 'mp_orders' && (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                <h3 className="font-bold text-white text-base flex items-center gap-2 border-b border-slate-800 pb-3">
                  <Package className="w-5 h-5 text-emerald-400" />
                  <span>Marketplace Escrow Orders Oversight</span>
                </h3>
                <div className="overflow-x-auto text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-mono border-b border-slate-800">
                      <tr>
                        <th className="p-3">Order ID</th>
                        <th className="p-3">Buyer</th>
                        <th className="p-3">Seller</th>
                        <th className="p-3">Product</th>
                        <th className="p-3">Total (RWF)</th>
                        <th className="p-3">Escrow Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {orderList.map((ord) => (
                        <tr key={ord.id} className="hover:bg-slate-950/60">
                          <td className="p-3 font-mono font-bold text-emerald-400">{ord.id}</td>
                          <td className="p-3 text-white">{ord.buyer}</td>
                          <td className="p-3 text-slate-300">{ord.seller}</td>
                          <td className="p-3 font-medium">{ord.product}</td>
                          <td className="p-3 font-mono font-bold">{ord.totalRwf.toLocaleString()} RWF</td>
                          <td className="p-3 uppercase text-[10px] font-bold text-amber-300">{ord.escrowStatus.replace('_', ' ')}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

          </div>
        )}

        {/* ------------------------------------------------------------------------- */}
        {/* TAB 5: COMMUNICATION CENTER (NOTIFICATIONS, EMAIL, SMS, SUPPORT) */}
        {/* ------------------------------------------------------------------------- */}
        {activeTab.startsWith('comm_') && (
          <div className="space-y-6">
            
            {/* Notifications Hub */}
            {activeTab === 'comm_notifs' && (
              <div className="space-y-6">
                {/* Pipeline Flow Architecture Banner */}
                <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-mono uppercase font-bold text-emerald-400 flex items-center gap-2">
                      <Activity className="w-4 h-4 text-emerald-400" />
                      <span>AGRIWISE Live Notification Dispatch Flow</span>
                    </h4>
                    <span className="text-[10px] bg-emerald-950 border border-emerald-500/30 text-emerald-300 font-mono px-2 py-0.5 rounded">
                      PIPELINE ACTIVE
                    </span>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-6 gap-2 text-center text-[10px] font-mono">
                    <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl">
                      <div className="text-slate-400">1. AGRIWISE Event</div>
                      <div className="text-emerald-400 font-bold mt-1">User / System</div>
                    </div>
                    <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl">
                      <div className="text-slate-400">2. Firestore Doc</div>
                      <div className="text-teal-400 font-bold mt-1">notifications/*</div>
                    </div>
                    <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl">
                      <div className="text-slate-400">3. Category Check</div>
                      <div className="text-cyan-400 font-bold mt-1">Activity Subtype</div>
                    </div>
                    <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl">
                      <div className="text-slate-400">4. Email Preference</div>
                      <div className="text-purple-400 font-bold mt-1">User Rules</div>
                    </div>
                    <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl">
                      <div className="text-slate-400">5. Dispatch Route</div>
                      <div className="text-amber-400 font-bold mt-1">SMTP vs In-App</div>
                    </div>
                    <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl">
                      <div className="text-slate-400">6. Delivery Status</div>
                      <div className="text-emerald-300 font-bold mt-1">Recorded & Audited</div>
                    </div>
                  </div>
                </div>

                {/* Channel Preferences Matrix */}
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                  <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                    <div>
                      <h3 className="font-bold text-white text-base flex items-center gap-2">
                        <Sliders className="w-5 h-5 text-emerald-400" />
                        <span>Notification Category Channel Rules</span>
                      </h3>
                      <p className="text-xs text-slate-400">Configure whether events trigger In-App Dashboard, SMTP Email, or SMS alerts.</p>
                    </div>
                    <button
                      onClick={() => {
                        updateOwnerNotificationPreferences(ownerPreferences.preferences);
                        handleShowToast('✓ Notification Channel Preferences saved');
                      }}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded-xl text-xs shadow"
                    >
                      Save Preferences
                    </button>
                  </div>

                  <div className="divide-y divide-slate-800 text-xs">
                    {ownerPreferences.preferences.map((pref, idx) => (
                      <div key={pref.eventCategory} className="py-3 flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <div className="font-bold text-white">{pref.label}</div>
                          <div className="text-[11px] font-mono text-slate-400">Category: {pref.eventCategory}</div>
                        </div>
                        <div className="flex items-center gap-4">
                          <label className="flex items-center gap-1.5 cursor-pointer text-slate-300">
                            <input
                              type="checkbox"
                              checked={pref.dashboardEnabled}
                              onChange={(e) => {
                                const next = [...ownerPreferences.preferences];
                                next[idx] = { ...pref, dashboardEnabled: e.target.checked };
                                setOwnerPreferences({ ...ownerPreferences, preferences: next });
                              }}
                              className="accent-emerald-500 rounded"
                            />
                            <span>Dashboard</span>
                          </label>
                          <label className="flex items-center gap-1.5 cursor-pointer text-slate-300">
                            <input
                              type="checkbox"
                              checked={pref.emailEnabled}
                              onChange={(e) => {
                                const next = [...ownerPreferences.preferences];
                                next[idx] = { ...pref, emailEnabled: e.target.checked };
                                setOwnerPreferences({ ...ownerPreferences, preferences: next });
                              }}
                              className="accent-emerald-500 rounded"
                            />
                            <span>SMTP Email</span>
                          </label>
                          <label className="flex items-center gap-1.5 cursor-pointer text-slate-300">
                            <input
                              type="checkbox"
                              checked={pref.smsEnabled}
                              onChange={(e) => {
                                const next = [...ownerPreferences.preferences];
                                next[idx] = { ...pref, smsEnabled: e.target.checked };
                                setOwnerPreferences({ ...ownerPreferences, preferences: next });
                              }}
                              className="accent-emerald-500 rounded"
                            />
                            <span>SMS</span>
                          </label>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Notifications List & Live Dispatch Test */}
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                  <div className="flex flex-wrap justify-between items-center border-b border-slate-800 pb-3 gap-3">
                    <h3 className="font-bold text-white text-base flex items-center gap-2">
                      <Bell className="w-5 h-5 text-purple-400" />
                      <span>Notifications Inbox & Delivery Logs ({notificationsList.length})</span>
                    </h3>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={async () => {
                          const res = await triggerOwnerNotification({
                            type: 'system',
                            activitySubtype: 'system_event',
                            title: 'Live Notification Pipeline Test',
                            message: 'This test verifies event ingestion, Firestore doc write, category check, user email preference check, SMTP dispatch, and audit logging.',
                            priority: 'medium'
                          });
                          setNotificationsList(getOwnerNotifications());
                          setAuditLogList(getAuditLogs());
                          handleShowToast(`✓ Test Dispatched: ${res.notification.emailDeliveryStatus || 'IN_APP_ONLY'}`);
                        }}
                        className="bg-purple-950 hover:bg-purple-900 text-purple-300 border border-purple-500/30 font-bold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1"
                      >
                        <Send className="w-3 h-3" />
                        <span>Send Test Dispatch</span>
                      </button>
                      <button
                        onClick={() => {
                          markAllNotificationsAsRead();
                          setNotificationsList(getOwnerNotifications());
                        }}
                        className="bg-slate-950 text-emerald-400 border border-slate-800 font-bold px-3 py-1.5 rounded-xl text-xs"
                      >
                        Mark All Read
                      </button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {notificationsList.map((n) => (
                      <div key={n.id} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-3 text-xs">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white text-sm">{n.title}</span>
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono border ${
                              n.priority === 'critical' ? 'bg-rose-950 text-rose-300 border-rose-500/40' :
                              n.priority === 'high' ? 'bg-amber-950 text-amber-300 border-amber-500/40' :
                              'bg-emerald-950 text-emerald-300 border-emerald-500/40'
                            }`}>
                              {n.priority}
                            </span>
                          </div>
                          <p className="text-slate-300">{n.message}</p>
                          <div className="flex flex-wrap items-center gap-2 text-[11px] pt-1">
                            <span className="text-slate-500 font-mono">Category: <strong className="text-slate-400">{n.activitySubtype || n.type}</strong></span>
                            {n.relatedUserName && (
                              <span className="text-slate-500 font-mono">User: <strong className="text-slate-400">{n.relatedUserName}</strong></span>
                            )}
                          </div>
                        </div>

                        <div className="flex flex-col md:items-end gap-1.5 shrink-0 font-mono">
                          <div className="flex items-center gap-1.5">
                            <span className="bg-slate-900 border border-slate-800 text-slate-400 px-2 py-0.5 rounded text-[10px]">
                              IN-APP
                            </span>
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                              n.emailDeliveryStatus === 'SENT' ? 'bg-emerald-950 text-emerald-300 border-emerald-500/40' :
                              n.emailDeliveryStatus === 'SIMULATED' ? 'bg-teal-950 text-teal-300 border-teal-500/40' :
                              n.emailDeliveryStatus === 'FAILED' ? 'bg-rose-950 text-rose-300 border-rose-500/40' :
                              'bg-slate-900 text-slate-400 border-slate-800'
                            }`}>
                              EMAIL: {n.emailDeliveryStatus || 'IN_APP_ONLY'}
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-500">{new Date(n.createdAt).toLocaleString()}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Email Settings */}
            {activeTab === 'comm_email' && (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 max-w-2xl">
                <h3 className="font-bold text-white text-base flex items-center gap-2 border-b border-slate-800 pb-3">
                  <Mail className="w-5 h-5 text-emerald-400" />
                  <span>Email Notification Settings</span>
                </h3>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-300 font-bold mb-1">Configured System Email Address:</label>
                    <input
                      type="email"
                      value={emailConfig.systemEmailAddress}
                      onChange={(e) => setEmailConfigState({ ...emailConfig, systemEmailAddress: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-bold mb-1">Sender Name:</label>
                    <input
                      type="text"
                      value={emailConfig.senderName}
                      onChange={(e) => setEmailConfigState({ ...emailConfig, senderName: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-bold mb-1">Email Provider:</label>
                    <input
                      type="text"
                      value={emailConfig.emailProvider}
                      disabled
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-400 font-mono"
                    />
                  </div>

                  <button
                    onClick={() => {
                      updateEmailConfig(emailConfig);
                      handleShowToast('✓ Email Settings updated');
                    }}
                    className="bg-emerald-600 text-white font-bold px-4 py-2.5 rounded-xl text-xs shadow"
                  >
                    Save Email Configuration
                  </button>
                </div>
              </div>
            )}

            {/* SMS Settings */}
            {activeTab === 'comm_sms' && (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 max-w-2xl">
                <h3 className="font-bold text-white text-base flex items-center gap-2 border-b border-slate-800 pb-3">
                  <Smartphone className="w-5 h-5 text-teal-400" />
                  <span>SMS Notification Settings (0792426760)</span>
                </h3>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-300 font-bold mb-1">System Official Phone Number:</label>
                    <input
                      type="text"
                      value={smsConfig.systemPhoneNumber}
                      onChange={(e) => setSmsConfigState({ ...smsConfig, systemPhoneNumber: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-bold mb-1">WASP Provider:</label>
                    <input
                      type="text"
                      value={smsConfig.smsProvider}
                      disabled
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-400 font-mono"
                    />
                  </div>

                  <button
                    onClick={() => {
                      updateSmsConfig(smsConfig);
                      handleShowToast('✓ SMS WASP Settings updated');
                    }}
                    className="bg-emerald-600 text-white font-bold px-4 py-2.5 rounded-xl text-xs shadow"
                  >
                    Save SMS Configuration
                  </button>
                </div>
              </div>
            )}

            {/* Support Center */}
            {activeTab === 'comm_support' && (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                <h3 className="font-bold text-white text-base flex items-center gap-2 border-b border-slate-800 pb-3">
                  <HelpCircle className="w-5 h-5 text-amber-400" />
                  <span>Support Tickets & Complaints Center</span>
                </h3>

                <div className="overflow-x-auto text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-mono border-b border-slate-800">
                      <tr>
                        <th className="p-3">Ticket ID</th>
                        <th className="p-3">User</th>
                        <th className="p-3">Subject</th>
                        <th className="p-3">Priority</th>
                        <th className="p-3">Status</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {ticketsList.map((tck) => (
                        <tr key={tck.id} className="hover:bg-slate-950/60">
                          <td className="p-3 font-mono text-emerald-400 font-bold">{tck.ticketNumber}</td>
                          <td className="p-3 font-bold text-white">{tck.userName} ({tck.userRole})</td>
                          <td className="p-3 text-slate-300">{tck.subject}</td>
                          <td className="p-3 font-bold uppercase text-[10px] text-amber-400">{tck.priority}</td>
                          <td className="p-3">
                            <span className="bg-slate-950 border border-slate-800 px-2 py-0.5 rounded text-[10px] uppercase font-bold text-emerald-300">
                              {tck.status}
                            </span>
                          </td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => setSelectedTicketModal(tck)}
                              className="px-2.5 py-1 bg-emerald-600 text-white rounded-xl font-bold"
                            >
                              Reply
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

          </div>
        )}

        {/* ------------------------------------------------------------------------- */}
        {/* TAB 6: SYSTEM MANAGEMENT (SETTINGS, CONTACT, MAINTENANCE, INTEGRATIONS) */}
        {/* ------------------------------------------------------------------------- */}
        {(activeTab.startsWith('sys_') || activeTab === 'system') && (
          <div className="space-y-6">
            
            {/* System Contact Information */}
            {activeTab === 'sys_contact' && (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5 max-w-2xl">
                <div className="border-b border-slate-800 pb-3">
                  <h3 className="font-bold text-white text-base flex items-center gap-2">
                    <Phone className="w-5 h-5 text-emerald-400" />
                    <span>Official System Contact & Communication Settings</span>
                  </h3>
                  <p className="text-xs text-slate-400">Configure central system contact info used publicly across the platform.</p>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-300 font-bold mb-1">Official System Name:</label>
                    <input
                      type="text"
                      value={systemContact.officialName}
                      onChange={(e) => setSystemContact({ ...systemContact, officialName: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-bold mb-1">Official System Email:</label>
                    <input
                      type="email"
                      value={systemContact.officialEmail}
                      onChange={(e) => setSystemContact({ ...systemContact, officialEmail: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-bold mb-1">Official System Phone Number:</label>
                    <input
                      type="text"
                      value={systemContact.officialPhone}
                      onChange={(e) => setSystemContact({ ...systemContact, officialPhone: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white font-mono"
                    />
                    <span className="text-[10px] text-slate-500 mt-1 block">Current System Phone: <strong className="text-emerald-400">0792426760</strong></span>
                  </div>

                  <div>
                    <label className="block text-slate-300 font-bold mb-1">WhatsApp Business Number:</label>
                    <input
                      type="text"
                      value={systemContact.whatsappNumber}
                      onChange={(e) => setSystemContact({ ...systemContact, whatsappNumber: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-bold mb-1">Physical Address:</label>
                    <input
                      type="text"
                      value={systemContact.physicalAddress}
                      onChange={(e) => setSystemContact({ ...systemContact, physicalAddress: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white"
                    />
                  </div>

                  <button
                    onClick={handleSaveContactInfo}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2.5 rounded-xl shadow"
                  >
                    Save System Contact Info
                  </button>
                </div>
              </div>
            )}

            {/* Maintenance Mode */}
            {activeTab === 'sys_maintenance' && (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5 max-w-2xl">
                <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
                  <div>
                    <h3 className="font-bold text-white text-base flex items-center gap-2">
                      <Lock className="w-5 h-5 text-rose-400" />
                      <span>System Maintenance Mode Control</span>
                    </h3>
                    <p className="text-xs text-slate-400">When enabled, ordinary users see a maintenance page while Admins retain full control.</p>
                  </div>

                  <button
                    onClick={() => handleToggleMaintenanceMode(!maintenanceMode.enabled)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                      maintenanceMode.enabled ? 'bg-rose-600 text-white' : 'bg-slate-950 text-slate-300 border border-slate-800'
                    }`}
                  >
                    {maintenanceMode.enabled ? 'DISABLE MAINTENANCE' : 'ENABLE MAINTENANCE'}
                  </button>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-300 font-bold mb-1">Public Maintenance Message:</label>
                    <textarea
                      rows={3}
                      value={maintenanceMode.message}
                      onChange={(e) => setMaintenanceModeState({ ...maintenanceMode, message: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white outline-none resize-none"
                    />
                  </div>

                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-400 font-mono">
                    Status: <strong className={maintenanceMode.enabled ? 'text-rose-400' : 'text-emerald-400'}>{maintenanceMode.enabled ? 'MAINTENANCE MODE ACTIVE' : 'NORMAL OPERATION'}</strong>
                  </div>
                </div>
              </div>
            )}

            {/* General System Settings */}
            {activeTab === 'sys_settings' && (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 max-w-2xl">
                <h3 className="font-bold text-white text-base flex items-center gap-2 border-b border-slate-800 pb-3">
                  <Settings className="w-5 h-5 text-emerald-400" />
                  <span>General System Configuration</span>
                </h3>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-300 font-bold mb-1">System Name:</label>
                    <input
                      type="text"
                      value={generalSettings.systemName}
                      onChange={(e) => setGeneralSettings({ ...generalSettings, systemName: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-bold mb-1">Default Currency:</label>
                    <input
                      type="text"
                      value={generalSettings.defaultCurrency}
                      disabled
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-400 font-mono font-bold"
                    />
                  </div>

                  <button
                    onClick={() => {
                      updateGeneralSettings(generalSettings);
                      handleShowToast('✓ General Settings updated');
                    }}
                    className="bg-emerald-600 text-white font-bold px-4 py-2.5 rounded-xl text-xs shadow"
                  >
                    Save General Settings
                  </button>
                </div>

                {/* Registration & Identity Verification Security Settings */}
                <div className="border-t border-slate-800 pt-5 space-y-4">
                  <h4 className="font-bold text-white text-sm flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Registration Verification & Privacy Controls</span>
                  </h4>

                  <div className="space-y-3">
                    <label className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800 cursor-pointer">
                      <span className="font-bold text-slate-200">Enforce Email Verification on Registration</span>
                      <input
                        type="checkbox"
                        checked={verificationSettings.requireEmailVerification}
                        onChange={(e) => setVerificationSettings({ ...verificationSettings, requireEmailVerification: e.target.checked })}
                        className="w-4 h-4 accent-emerald-500"
                      />
                    </label>

                    <label className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800 cursor-pointer">
                      <span className="font-bold text-slate-200">Enforce NIDA National Identity Check</span>
                      <input
                        type="checkbox"
                        checked={verificationSettings.requireIdentityVerification}
                        onChange={(e) => setVerificationSettings({ ...verificationSettings, requireIdentityVerification: e.target.checked })}
                        className="w-4 h-4 accent-emerald-500"
                      />
                    </label>

                    <div>
                      <label className="block text-slate-300 font-bold mb-1">Identity Data Retention Policy (Days):</label>
                      <input
                        type="number"
                        value={verificationSettings.identityDataRetentionDays}
                        onChange={(e) => setVerificationSettings({ ...verificationSettings, identityDataRetentionDays: Number(e.target.value) })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white font-mono"
                      />
                      <span className="text-[10px] text-slate-500 mt-1 block">Unverified or raw identity data logs auto-expire after specified retention days.</span>
                    </div>

                    <button
                      onClick={handleSaveVerificationSettings}
                      className="bg-teal-600 hover:bg-teal-500 text-white font-bold px-4 py-2.5 rounded-xl text-xs shadow"
                    >
                      Save Verification & Privacy Settings
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Integrations Center */}
            {activeTab === 'sys_integrations' && (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                <h3 className="font-bold text-white text-base flex items-center gap-2 border-b border-slate-800 pb-3">
                  <Cpu className="w-5 h-5 text-teal-400" />
                  <span>Integrations Center</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
                  {[
                    { name: 'MTN / Airtel WASP SMS Gateway', provider: 'MTN WASP', status: 'Active (0792426760)', type: 'SMS' },
                    { name: 'Resend / SMTP Gateway', provider: 'Resend Enterprise', status: 'Active (support@agriwise.rw)', type: 'Email' },
                    { name: 'MTN Mobile Money Escrow API', provider: 'MTN MoMo API', status: 'Connected (RWF)', type: 'Payments' },
                    { name: 'Google Maps GIS Platform', provider: 'Google Maps API', status: 'Active', type: 'Maps/GPS' },
                    { name: 'Google Gemini 3.6 AI Engine', provider: 'Gemini 3.6 Flash', status: 'Operational', type: 'AI' },
                    { name: 'Google Cloud Storage Bucket', provider: 'GCP Storage', status: 'Healthy', type: 'Storage' }
                  ].map((item, idx) => (
                    <div key={idx} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                      <div className="flex justify-between items-center font-bold text-white">
                        <span>{item.name}</span>
                        <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded">
                          {item.type}
                        </span>
                      </div>
                      <p className="text-slate-400 text-[11px] font-mono">{item.status}</p>
                      <button className="w-full bg-slate-900 border border-slate-800 text-slate-300 py-1.5 rounded-xl text-[11px] font-bold">
                        Test Connection
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        )}

        {/* ------------------------------------------------------------------------- */}
        {/* TAB 7: SECURITY & AUDIT LOGS */}
        {/* ------------------------------------------------------------------------- */}
        {(activeTab.startsWith('sec_') || activeTab === 'security') && (
          <div className="space-y-6">
            
            {/* Audit Logs */}
            {activeTab === 'sec_audit' && (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                <h3 className="font-bold text-white text-base flex items-center gap-2 border-b border-slate-800 pb-3">
                  <ShieldAlert className="w-5 h-5 text-emerald-400" />
                  <span>Real-Time System Audit Log</span>
                </h3>

                <div className="overflow-x-auto text-xs">
                  <table className="w-full text-left font-mono">
                    <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                      <tr>
                        <th className="p-3">Log ID</th>
                        <th className="p-3">Timestamp</th>
                        <th className="p-3">Actor</th>
                        <th className="p-3">Action</th>
                        <th className="p-3">Description</th>
                        <th className="p-3">IP Address</th>
                        <th className="p-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {[
                        ...getSecurityAuditLogs().map((resetLog) => ({
                          id: resetLog.id,
                          timestamp: resetLog.timestamp,
                          actorName: resetLog.userName || resetLog.destinationMasked || 'USER_AUTH',
                          eventType: resetLog.action,
                          actionDescription: resetLog.details,
                          ipAddress: resetLog.ipAddress || '197.243.2.14',
                          status: resetLog.status,
                        })),
                        ...auditLogList.map((log) => ({
                          id: log.id,
                          timestamp: log.timestamp,
                          actorName: log.actorName,
                          eventType: log.eventType,
                          actionDescription: log.actionDescription,
                          ipAddress: log.ipAddress,
                          status: log.status,
                        }))
                      ]
                        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                        .map((log) => (
                          <tr key={log.id} className="hover:bg-slate-950/60">
                            <td className="p-3 font-bold text-emerald-400">{log.id}</td>
                            <td className="p-3 text-slate-400">{new Date(log.timestamp).toLocaleString()}</td>
                            <td className="p-3 text-white font-sans font-bold">{log.actorName}</td>
                            <td className="p-3 text-amber-300 font-bold">{log.eventType}</td>
                            <td className="p-3 font-sans text-slate-300">{log.actionDescription}</td>
                            <td className="p-3 text-slate-400">{log.ipAddress}</td>
                            <td className="p-3">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                                  log.status.toUpperCase() === 'SUCCESS'
                                    ? 'bg-emerald-950 text-emerald-300 border-emerald-500/30'
                                    : log.status.toUpperCase() === 'BLOCKED'
                                    ? 'bg-rose-950 text-rose-300 border-rose-500/30'
                                    : 'bg-amber-950 text-amber-300 border-amber-500/30'
                                }`}
                              >
                                {log.status.toUpperCase()}
                              </span>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Security Center */}
            {activeTab === 'sec_center' && (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                <h3 className="font-bold text-white text-base flex items-center gap-2 border-b border-slate-800 pb-3">
                  <ShieldCheck className="w-5 h-5 text-rose-400" />
                  <span>Security Center Overview & Firewall Rules</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                    <span className="text-slate-400 block font-medium">Failed Login Attempts Today</span>
                    <span className="text-2xl font-black text-rose-400 font-mono">0</span>
                  </div>
                  <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                    <span className="text-slate-400 block font-medium">Active Admin Sessions</span>
                    <span className="text-2xl font-black text-emerald-400 font-mono">1 Active</span>
                  </div>
                  <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                    <span className="text-slate-400 block font-medium">Security Alerts</span>
                    <span className="text-2xl font-black text-amber-400 font-mono">0 Pending</span>
                  </div>
                </div>
              </div>
            )}

          </div>
        )}

        {/* ------------------------------------------------------------------------- */}
        {/* TAB 8: DATA & BACKUP MANAGEMENT */}
        {/* ------------------------------------------------------------------------- */}
        {(activeTab.startsWith('data_') || activeTab === 'data') && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
            <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
              <div>
                <h3 className="font-bold text-white text-base flex items-center gap-2">
                  <Database className="w-5 h-5 text-teal-400" />
                  <span>Database Backup & Restoration Management</span>
                </h3>
                <p className="text-xs text-slate-400">Database Size: 142.8 MB | Storage Health: 100% Healthy</p>
              </div>

              <button
                onClick={() => setShowBackupConfirmModal(true)}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Create Backup Now</span>
              </button>
            </div>

            <div className="overflow-x-auto text-xs">
              <table className="w-full text-left">
                <thead className="bg-slate-950 text-slate-400 font-mono uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="p-3">Backup File Name</th>
                    <th className="p-3">Size (MB)</th>
                    <th className="p-3">Created By</th>
                    <th className="p-3">Date</th>
                    <th className="p-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 font-mono text-[11px]">
                  {backupsList.map((bk) => (
                    <tr key={bk.id} className="hover:bg-slate-950/60">
                      <td className="p-3 font-bold text-emerald-400">{bk.backupName}</td>
                      <td className="p-3 text-white">{bk.fileSizeMb} MB</td>
                      <td className="p-3 font-sans text-slate-300">{bk.createdByName}</td>
                      <td className="p-3 text-slate-400">{new Date(bk.createdAt).toLocaleString()}</td>
                      <td className="p-3">
                        <span className="bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded text-[10px] font-bold">
                          {bk.status.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------------------- */}
        {/* TAB 9: ADMIN PROFILE */}
        {/* ------------------------------------------------------------------------- */}
        {activeTab === 'admin_profile' && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5 max-w-xl">
            <div className="flex items-center gap-4 border-b border-slate-800 pb-4">
              <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center font-black text-2xl text-emerald-400">
                SO
              </div>
              <div>
                <h3 className="font-bold text-white text-base">AGRIWISE System Owner</h3>
                <p className="text-xs text-slate-400 font-mono">support@agriwise.rw | Role: system_owner</p>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-extrabold">
                  LEVEL 1 SUPER ADMIN
                </span>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Full Name:</label>
                <input
                  type="text"
                  defaultValue="AGRIWISE System Owner"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">System Phone Line:</label>
                <input
                  type="text"
                  defaultValue="0792426760"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white font-mono"
                />
              </div>

              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={() => handleShowToast('✓ Admin profile updated')}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-xl shadow"
                >
                  Update Profile Details
                </button>

                <button
                  onClick={() => handleShowToast('✓ All other admin sessions terminated')}
                  className="w-full bg-rose-950 hover:bg-rose-900 border border-rose-500/30 text-rose-300 font-bold py-2.5 rounded-xl"
                >
                  Logout From All Other Sessions
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------------------- */}
        {/* TAB: EDUCATIONAL CONTENT - AGRICULTURAL VIDEOS                           */}
        {/* ------------------------------------------------------------------------- */}
        {activeTab === 'edu_videos' && (
          <AdminVideoManager
            language={language}
            currentUser={{
              id: currentUser?.id || 'usr_0_owner',
              name: currentUser?.name || 'Jimmy Mico (System Admin)',
              role: (currentUser?.role as UserRole) || 'admin',
              email: currentUser?.email || 'support@agriwise.rw'
            }}
          />
        )}

        {/* ------------------------------------------------------------------------- */}
        {/* TAB: JIMMY MICO PRO - FOOTER CONTENT MANAGEMENT                          */}
        {/* ------------------------------------------------------------------------- */}
        {activeTab === 'jimmy_mico_pro' && (
          <JimmyMicoPro
            currentUser={currentUser}
            language={language}
          />
        )}

      </main>

      {/* ========================================================================= */}
      {/* MODAL DIALOGS */}
      {/* ========================================================================= */}

      {/* User Profile Inspector Modal */}
      {selectedUserModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-5">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base">User Profile Inspector</h3>
              <button onClick={() => setSelectedUserModal(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                <div className="text-sm font-bold text-white">{selectedUserModal.name}</div>
                <div className="text-slate-400 font-mono">ID: {selectedUserModal.id}</div>
                <div className="text-emerald-400 font-bold capitalize">Role: {selectedUserModal.role}</div>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono text-[11px]">
                <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Phone:</span>
                  <span className="text-white font-bold">{selectedUserModal.phone}</span>
                </div>
                <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">District:</span>
                  <span className="text-white font-bold">{selectedUserModal.district}</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-300">
                Registered: {selectedUserModal.registeredAt} | Last Login: {selectedUserModal.lastLogin || 'Recent'}
              </div>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setSelectedUserModal(null)}
                className="bg-slate-800 text-slate-200 font-bold px-4 py-2 rounded-xl text-xs"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add System Category Modal */}
      {showAddCategoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base">Add System Category</h3>
              <button onClick={() => setShowAddCategoryModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Category Type:</label>
                <select
                  value={newCatType}
                  onChange={(e) => setNewCatType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white capitalize outline-none"
                >
                  <option value="product">Product Category</option>
                  <option value="agricultural">Agricultural Category</option>
                  <option value="livestock">Livestock Category</option>
                  <option value="crop">Crop Category</option>
                  <option value="service">Service Category</option>
                  <option value="unit">Measurement Unit</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Name (Kinyarwanda):</label>
                <input
                  type="text"
                  placeholder="e.g. Ubuhinzi bw'Ibirayi"
                  value={newCatNameRw}
                  onChange={(e) => setNewCatNameRw(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Name (English):</label>
                <input
                  type="text"
                  placeholder="e.g. Irish Potato Farming"
                  value={newCatNameEn}
                  onChange={(e) => setNewCatNameEn(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white outline-none"
                />
              </div>

              <button
                onClick={handleCreateCategory}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl shadow"
              >
                Create Category
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Support Ticket Response Modal */}
      {selectedTicketModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base">Support Ticket #{selectedTicketModal.ticketNumber}</h3>
              <button onClick={() => setSelectedTicketModal(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <div className="font-bold text-white">{selectedTicketModal.userName} ({selectedTicketModal.userPhone})</div>
                <p className="text-slate-300 mt-1">{selectedTicketModal.message}</p>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Admin Official Reply:</label>
                <textarea
                  rows={3}
                  placeholder="Enter response to send via SMS/Email..."
                  value={ticketReplyText}
                  onChange={(e) => setTicketReplyText(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white outline-none resize-none"
                />
              </div>

              <button
                onClick={handleReplyTicket}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl shadow"
              >
                Send Resolution Reply
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Backup Confirmation Password Modal */}
      {showBackupConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-slate-900 border border-emerald-500/40 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base">Admin Database Backup Authorization</h3>
              <button onClick={() => setShowBackupConfirmModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-300">
                Confirm your Administrator password to initiate a full PostgreSQL/SQLite system snapshot.
              </p>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Admin Authorization Password:</label>
                <input
                  type="password"
                  placeholder="Enter password..."
                  value={adminPasswordConfirm}
                  onChange={(e) => setAdminPasswordConfirm(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white outline-none"
                />
              </div>

              <button
                onClick={handleCreateBackup}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl shadow"
              >
                Confirm & Take Backup
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
