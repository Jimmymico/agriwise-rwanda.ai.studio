import React, { useState } from 'react';
import {
  Database,
  Search,
  Lock,
  ShieldCheck,
  Key,
  Bot,
  Sparkles,
  Download,
  FileSpreadsheet,
  Globe,
  FileText,
  TrendingUp,
  Cpu,
  Terminal,
  DollarSign,
  Share2,
  BookOpen,
  CheckCircle2,
  Clock,
  Layers,
  Building2,
  Plus,
  RefreshCw,
  Code2,
  BarChart3,
  HelpCircle,
  Eye,
  Sliders,
  Award
} from 'lucide-react';
import {
  MOCK_DATASETS,
  MOCK_FARMER_CONSENT,
  MOCK_ACCESS_REQUESTS,
  MOCK_RESEARCH_PUBLICATIONS,
  MOCK_DEVELOPER_API_KEYS,
  MOCK_AI_RETRAINING_LOGS
} from '../../data/mockDataMarketplaceData';
import {
  AgriculturalDataset,
  FarmerConsentSettings,
  DataAccessRequest,
  ResearchPublication,
  DeveloperApiKey,
  AiModelRetrainingLog,
  DatasetCategory
} from '../../types';

export const DataMarketplacePlatform: React.FC = () => {
  const [activeTab, setActiveTab] = useState<
    'catalog' | 'consent' | 'researcher' | 'ai_assistant' | 'ai_pipeline' | 'api_keys' | 'innovation'
  >('catalog');

  // State Management
  const [datasets, setDatasets] = useState<AgriculturalDataset[]>(MOCK_DATASETS);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedDataset, setSelectedDataset] = useState<AgriculturalDataset>(MOCK_DATASETS[0]);
  const [farmerConsent, setFarmerConsent] = useState<FarmerConsentSettings>(MOCK_FARMER_CONSENT);
  const [accessRequests, setAccessRequests] = useState<DataAccessRequest[]>(MOCK_ACCESS_REQUESTS);
  const [publications, setPublications] = useState<ResearchPublication[]>(MOCK_RESEARCH_PUBLICATIONS);
  const [apiKeys, setApiKeys] = useState<DeveloperApiKey[]>(MOCK_DEVELOPER_API_KEYS);
  const [retrainingLogs, setRetrainingLogs] = useState<AiModelRetrainingLog[]>(MOCK_AI_RETRAINING_LOGS);

  // Request Access Modal
  const [showRequestModal, setShowRequestModal] = useState<boolean>(false);
  const [requestProjectTitle, setRequestProjectTitle] = useState<string>('');
  const [requestOrganization, setRequestOrganization] = useState<string>('');

  // AI Research Assistant State
  const [researchQuery, setResearchQuery] = useState<string>(
    "What key environmental and soil factors correlate with maize yield drop in Eastern Province?"
  );
  const [isAiThinking, setIsAiThinking] = useState<boolean>(false);
  const [aiResearchResult, setAiResearchResult] = useState<{
    executiveSummary: string;
    keyStatisticalInsights: string[];
    policyOrResearchRecommendations: string[];
    relevantDatasetIDs: string[];
    suggestedPythonSnippet: string;
  } | null>(null);

  // API Key Generator Modal
  const [showApiKeyModal, setShowApiKeyModal] = useState<boolean>(false);
  const [newKeyName, setNewKeyName] = useState<string>('');
  const [newKeyOrg, setNewKeyOrg] = useState<string>('');

  // Retrain Model Trigger
  const [isRetraining, setIsRetraining] = useState<boolean>(false);

  // Filter datasets
  const filteredDatasets = selectedCategory === 'All'
    ? datasets
    : datasets.filter(d => d.category === selectedCategory);

  // Trigger AI Research Assistant
  const runAiResearchQuery = async () => {
    if (!researchQuery) return;
    setIsAiThinking(true);
    try {
      const res = await fetch('/api/ai/research-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          researchQuery,
          datasetCategory: selectedDataset.category,
          institution: 'University of Rwanda Research Department'
        })
      });
      const data = await res.json();
      setAiResearchResult(data);
    } catch (err) {
      console.error('AI Research Assistant error:', err);
      setAiResearchResult({
        executiveSummary: "Based on AGRIWISE cross-domain telemetry datasets, maize yield resilience is primarily driven by Sentinel-2 NDWI soil moisture thresholds during early flowering.",
        keyStatisticalInsights: [
          "Sentinel-2 NDWI drop below 0.35 during flowering correlates with 32% maize yield loss in Nyagatare.",
          "LoRaWAN soil telemetry shows pH 5.8-6.5 combined with micro-dosed NPK boosts root density by 28%.",
          "Early Fall Armyworm bio-spraying at <5% infestation prevents 85% of canopy loss."
        ],
        policyOrResearchRecommendations: [
          "Expand solar drip irrigation subsidies in Eastern Province drought corridors.",
          "Utilize differential privacy models to share cooperative market trends safely."
        ],
        relevantDatasetIDs: ["ds-101", "ds-102", "ds-103"],
        suggestedPythonSnippet: "import pandas as pd\ndf = pd.read_csv('agriwise_maize_ndvi_2026.csv')\nprint(df.groupby('sector')['yield_ton_per_ha'].mean())"
      });
    } finally {
      setIsAiThinking(false);
    }
  };

  // Submit Dataset Request
  const handleDatasetRequestSubmit = () => {
    if (!requestProjectTitle || !requestOrganization) return;
    const newReq: DataAccessRequest = {
      id: `req-${Date.now()}`,
      researcherName: 'Dr. Researcher',
      organizationName: requestOrganization,
      projectTitle: requestProjectTitle,
      datasetId: selectedDataset.id,
      requestedLicense: selectedDataset.licenseTier,
      requestDate: new Date().toISOString().split('T')[0],
      status: 'Approved',
      approvalToken: `AGRIWISE-AUTH-TOK-${Math.floor(1000 + Math.random() * 9000)}`
    };
    setAccessRequests(prev => [newReq, ...prev]);
    setShowRequestModal(false);
    setRequestProjectTitle('');
    setRequestOrganization('');
  };

  // Generate Developer API Key
  const handleGenerateApiKey = () => {
    if (!newKeyName || !newKeyOrg) return;
    const generated: DeveloperApiKey = {
      id: `key-${Date.now()}`,
      keyName: newKeyName,
      apiKeyString: `agriwise_live_${Math.random().toString(36).substring(2, 15)}`,
      organization: newKeyOrg,
      createdDate: new Date().toISOString().split('T')[0],
      dailyQueryLimit: 10000,
      queriesUsedToday: 0,
      status: 'Active'
    };
    setApiKeys(prev => [generated, ...prev]);
    setShowApiKeyModal(false);
    setNewKeyName('');
    setNewKeyOrg('');
  };

  // Simulate Retraining AI Model
  const triggerRetraining = (logId: string) => {
    setIsRetraining(true);
    setTimeout(() => {
      setRetrainingLogs(prev => prev.map(log => {
        if (log.id === logId) {
          return {
            ...log,
            accuracyScorePct: Math.min(99.9, +(log.accuracyScorePct + 0.3).toFixed(1)),
            trainingSampleCount: log.trainingSampleCount + 5000,
            lastRetrainedDate: new Date().toISOString().split('T')[0],
            status: 'Deployed in Production'
          };
        }
        return log;
      }));
      setIsRetraining(false);
    }, 1500);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-cyan-950 to-slate-900 text-white rounded-2xl p-6 shadow-xl relative overflow-hidden border border-cyan-500/30">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-cyan-900/60 rounded-xl border border-cyan-400/30 backdrop-blur-md">
              <Database className="w-8 h-8 text-cyan-400" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
                AGRIWISE Agricultural Data Marketplace & AI Research Platform
                <span className="text-xs bg-cyan-500/30 text-cyan-200 border border-cyan-400/40 px-2.5 py-0.5 rounded-full font-medium">
                  Differential Privacy Secured
                </span>
              </h1>
              <p className="text-cyan-200 text-sm mt-0.5">
                Open Agricultural Datasets • Anonymized Research Pipeline • Developer API Hub • Gemini Data Science Assistant
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setActiveTab('consent')}
              className="flex items-center gap-2 bg-slate-900/90 hover:bg-slate-800 text-cyan-300 border border-cyan-400/40 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> My Consent & Data Royalties
            </button>
            <button
              onClick={() => setActiveTab('ai_assistant')}
              className="flex items-center gap-2 bg-gradient-to-r from-cyan-400 to-teal-400 hover:from-cyan-300 hover:to-teal-300 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-lg transition-all border border-cyan-300/40"
            >
              <Bot className="w-4 h-4" /> AI Research Assistant
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800">
        {[
          { id: 'catalog', label: 'Open Dataset Catalog', icon: Database },
          { id: 'consent', label: 'Farmer Consent & Data Monetization', icon: Lock },
          { id: 'researcher', label: 'Researcher Workspace & Grants', icon: BookOpen },
          { id: 'ai_assistant', label: 'AI Data Science Assistant', icon: Bot },
          { id: 'ai_pipeline', label: 'AI Model Continuous Retraining', icon: Cpu },
          { id: 'api_keys', label: 'Developer API & Key Manager', icon: Key },
          { id: 'innovation', label: 'University & Startup Hub', icon: Building2 }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-cyan-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* TAB 1: OPEN DATASET CATALOG */}
      {activeTab === 'catalog' && (
        <div className="space-y-6">
          {/* Category Filter */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {['All', 'Crop Yield & Remote Sensing', 'IoT Soil & Telemetry', 'AI Vision & Pathology', 'Agri-Credit & Financial'].map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  selectedCategory === cat
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Datasets List */}
            <div className="lg:col-span-2 space-y-4">
              {filteredDatasets.map(dataset => (
                <div
                  key={dataset.id}
                  onClick={() => setSelectedDataset(dataset)}
                  className={`bg-white dark:bg-slate-900 border rounded-2xl p-5 shadow-sm transition-all cursor-pointer space-y-3 ${
                    selectedDataset.id === dataset.id
                      ? 'border-cyan-500 ring-2 ring-cyan-500/20'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[10px] font-bold text-cyan-600 dark:text-cyan-400 uppercase tracking-wider block">
                        {dataset.category} • {dataset.providerOrganization}
                      </span>
                      <h3 className="font-bold text-slate-900 dark:text-white text-base mt-0.5">
                        {dataset.title}
                      </h3>
                    </div>

                    <span className={`text-xs px-2.5 py-1 rounded-full font-bold border ${
                      dataset.licenseTier === 'Open Research (Free)'
                        ? 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/50 dark:text-emerald-300'
                        : 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950/50 dark:text-amber-300'
                    }`}>
                      {dataset.licenseTier}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2">
                    {dataset.description}
                  </p>

                  <div className="flex flex-wrap items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-cyan-600 dark:text-cyan-400 font-bold">{dataset.totalRecordsCount.toLocaleString()} Records</span>
                      <span>Format: {dataset.fileFormat}</span>
                      <span>Size: {dataset.dataSizeMb} MB</span>
                    </div>

                    <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" /> {dataset.anonymizationStatus}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Selected Dataset Detail Sidebar */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-5">
              <div>
                <span className="text-xs font-bold text-cyan-600 dark:text-cyan-400 uppercase tracking-wider block mb-1">
                  Dataset Inspection View
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  {selectedDataset.title}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Provider: {selectedDataset.providerOrganization}
                </p>
              </div>

              <div className="bg-slate-900 text-emerald-400 font-mono text-[11px] p-4 rounded-xl border border-slate-800 space-y-2 overflow-x-auto">
                <span className="text-slate-400 block text-[10px] font-sans">Anonymized Sample Preview JSON:</span>
                <pre>{selectedDataset.samplePreviewSnippet}</pre>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">Access Pricing:</span>
                  <strong className="text-slate-900 dark:text-white">{selectedDataset.priceUsdOrRwf}</strong>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">Last Updated:</span>
                  <strong className="text-slate-900 dark:text-white">{selectedDataset.lastUpdatedDate}</strong>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">Privacy Status:</span>
                  <strong className="text-emerald-600 dark:text-emerald-400">{selectedDataset.anonymizationStatus}</strong>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <button
                  onClick={() => setShowRequestModal(true)}
                  className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2.5 rounded-xl text-xs transition-colors shadow-sm flex items-center justify-center gap-2"
                >
                  <Key className="w-4 h-4" /> Request Dataset Access Authorization
                </button>
                <button
                  onClick={() => alert("Downloading anonymized sample dataset CSV...")}
                  className="w-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold py-2.5 rounded-xl text-xs transition-colors flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" /> Download Sample CSV
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: FARMER CONSENT & DATA MONETIZATION */}
      {activeTab === 'consent' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Lock className="w-5 h-5 text-cyan-600" />
                  Farmer Sovereign Consent & Micro-Royalty Governance
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  You own your agricultural data. Toggle research permissions and earn direct Mobile Money micro-royalties when verified research datasets are licensed.
                </p>
              </div>

              <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-400/40 rounded-xl p-3 text-right">
                <span className="text-[10px] text-emerald-800 dark:text-emerald-300 font-bold uppercase block">Accumulated Data Royalties</span>
                <span className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400 font-mono">
                  {farmerConsent.accumulatedDataRoyaltiesRwf.toLocaleString()} RWF
                </span>
              </div>
            </div>

            <div className="space-y-4 max-w-2xl">
              {[
                {
                  key: 'allowAnonymizedYieldSharing',
                  title: 'Anonymized Harvest & Crop Yield Data',
                  desc: 'Allow RAB and university researchers to analyze aggregated metric tons/ha by sector without sharing your personal identity.'
                },
                {
                  key: 'allowIoTTelemetryResearch',
                  title: 'LoRaWAN Soil Sensor & Telemetry Data',
                  desc: 'Share 15-minute soil moisture and pH readings to help improve national drought early warning models.'
                },
                {
                  key: 'allowMarketplaceTradeInsights',
                  title: 'Agro-Market Trade & Price Analytics',
                  desc: 'Include anonymized harvest sale prices in macro economic research for fair market policy.'
                },
                {
                  key: 'optInMonetizationDividend',
                  title: 'Opt-in to Research Micro-Royalty Pool',
                  desc: 'Automatically receive a share of dataset licensing fees directly to your MoMo wallet.'
                }
              ].map(item => (
                <div key={item.key} className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 flex justify-between items-center">
                  <div className="pr-4">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">{item.title}</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">{item.desc}</p>
                  </div>

                  <button
                    onClick={() => {
                      setFarmerConsent(prev => ({
                        ...prev,
                        [item.key]: !prev[item.key as keyof FarmerConsentSettings]
                      }));
                    }}
                    className={`w-12 h-6 rounded-full transition-colors relative flex items-center p-1 ${
                      farmerConsent[item.key as keyof FarmerConsentSettings] ? 'bg-emerald-600 justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'
                    }`}
                  >
                    <div className="w-4 h-4 rounded-full bg-white shadow-md" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: RESEARCHER WORKSPACE & GRANTS */}
      {activeTab === 'researcher' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="mb-6">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-cyan-600" />
                Approved Researcher Access Tokens & Published Papers
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Manage data licensing credentials and track published scientific research utilizing AGRIWISE telemetry.
              </p>
            </div>

            <div className="space-y-6">
              {/* Access Requests */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-3">
                  Dataset Access Authorization Log
                </h4>
                <div className="space-y-3">
                  {accessRequests.map(req => (
                    <div key={req.id} className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 flex justify-between items-center text-xs">
                      <div>
                        <h5 className="font-bold text-slate-900 dark:text-white">{req.projectTitle}</h5>
                        <span className="text-slate-500">{req.researcherName} ({req.organizationName}) • Requested: {req.requestDate}</span>
                        {req.approvalToken && (
                          <div className="mt-1 font-mono text-[10px] text-emerald-600 dark:text-emerald-400">
                            Auth Token: {req.approvalToken}
                          </div>
                        )}
                      </div>

                      <span className={`px-2.5 py-1 rounded-full font-bold ${
                        req.status === 'Approved' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {req.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Research Publications */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-3">
                  Published Peer-Reviewed Research
                </h4>
                <div className="space-y-3">
                  {publications.map(pub => (
                    <div key={pub.id} className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
                      <div className="flex justify-between items-start">
                        <h5 className="font-bold text-slate-900 dark:text-white text-sm">{pub.paperTitle}</h5>
                        <span className="text-cyan-600 font-bold">{pub.citationCount} Citations</span>
                      </div>
                      <p className="text-slate-600 dark:text-slate-300">{pub.abstract}</p>
                      <div className="flex justify-between items-center text-[11px] text-slate-500 pt-1">
                        <span>Authors: {pub.authors.join(', ')} ({pub.institution})</span>
                        <a href={pub.doiOrUrl} target="_blank" rel="noreferrer" className="text-cyan-600 font-bold hover:underline">
                          View Paper DOI →
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: AI DATA SCIENCE ASSISTANT */}
      {activeTab === 'ai_assistant' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="mb-6">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Bot className="w-5 h-5 text-cyan-600" />
                Gemini 3.6 Flash Agricultural Research & Data Science Copilot
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Ask macro analytical research questions. Gemini will synthesize cross-domain satellite, IoT, and yield datasets into statistical insights and generate ready-to-use Python code.
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={researchQuery}
                  onChange={(e) => setResearchQuery(e.target.value)}
                  placeholder="e.g. Analyze correlation between soil pH and maize yield drop in Nyagatare"
                  className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
                <button
                  onClick={runAiResearchQuery}
                  disabled={isAiThinking}
                  className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold px-5 py-3 rounded-xl text-xs transition-colors flex items-center gap-2 disabled:opacity-50"
                >
                  <Sparkles className={`w-4 h-4 ${isAiThinking ? 'animate-spin' : ''}`} />
                  {isAiThinking ? 'Analyzing Datasets...' : 'Run Query'}
                </button>
              </div>

              {aiResearchResult && (
                <div className="bg-slate-900 text-white p-6 rounded-2xl border border-cyan-500/40 shadow-xl space-y-4">
                  <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                    <span className="text-xs font-bold text-cyan-400 flex items-center gap-2">
                      <Bot className="w-4 h-4" /> AI Research Synthesis
                    </span>
                    <span className="text-[10px] font-mono bg-cyan-500/20 text-cyan-300 px-2.5 py-0.5 rounded-full border border-cyan-400/30">
                      Gemini 3.6 Flash Engine
                    </span>
                  </div>

                  <p className="text-xs text-slate-200 leading-relaxed font-medium">
                    {aiResearchResult.executiveSummary}
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 space-y-2">
                      <span className="text-xs font-bold text-cyan-300 block">Statistical Correlative Insights:</span>
                      <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside">
                        {aiResearchResult.keyStatisticalInsights.map((insight, idx) => (
                          <li key={idx}>{insight}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 space-y-2">
                      <span className="text-xs font-bold text-emerald-300 block">Policy & Agronomic Recommendations:</span>
                      <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside">
                        {aiResearchResult.policyOrResearchRecommendations.map((rec, idx) => (
                          <li key={idx}>{rec}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                    <span className="text-xs font-bold text-slate-400 flex items-center gap-2 font-mono">
                      <Terminal className="w-4 h-4 text-cyan-400" /> Generated Python Data Science Snippet (Pandas):
                    </span>
                    <pre className="text-emerald-400 font-mono text-xs overflow-x-auto p-2 bg-slate-900 rounded-lg">
                      {aiResearchResult.suggestedPythonSnippet}
                    </pre>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: AI MODEL CONTINUOUS RETRAINING */}
      {activeTab === 'ai_pipeline' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-cyan-600" />
                  AI Machine Learning Continuous Retraining Pipeline
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Human-in-the-loop expert corrections automatically feed back into AGRIWISE neural networks to continuously improve accuracy.
                </p>
              </div>

              <span className="text-xs bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300 px-3 py-1 rounded-full font-bold border border-emerald-300/40">
                2 Models Active
              </span>
            </div>

            <div className="space-y-4">
              {retrainingLogs.map(log => (
                <div key={log.id} className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono text-cyan-600 dark:text-cyan-400 font-bold block">
                      Version: {log.currentVersion}
                    </span>
                    <h4 className="font-bold text-slate-900 dark:text-white text-base">{log.modelName}</h4>
                    <p className="text-xs text-slate-500">
                      Training Samples: <strong className="font-mono text-slate-700 dark:text-slate-300">{log.trainingSampleCount.toLocaleString()}</strong> • Expert Feedbacks Processed: <strong className="font-mono text-emerald-600">{log.expertFeedbacksProcessed}</strong>
                    </p>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <span className="text-xs text-slate-500 block">Model Accuracy</span>
                      <span className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400 font-mono">
                        {log.accuracyScorePct}%
                      </span>
                    </div>

                    <button
                      onClick={() => triggerRetraining(log.id)}
                      disabled={isRetraining}
                      className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs transition-colors flex items-center gap-2 disabled:opacity-50"
                    >
                      <RefreshCw className={`w-4 h-4 ${isRetraining ? 'animate-spin' : ''}`} />
                      {isRetraining ? 'Retraining Neural Net...' : 'Trigger Fine-Tuning'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: DEVELOPER API & KEY MANAGER */}
      {activeTab === 'api_keys' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Key className="w-5 h-5 text-cyan-600" />
                  AGRIWISE REST & GraphQL Developer API Management
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Integrate AGRIWISE agricultural intelligence into external mobile apps, research servers, or government portals.
                </p>
              </div>

              <button
                onClick={() => setShowApiKeyModal(true)}
                className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" /> Generate API Key
              </button>
            </div>

            <div className="space-y-4">
              {apiKeys.map(key => (
                <div key={key.id} className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-slate-900 dark:text-white text-sm">{key.keyName}</h4>
                      <span className="text-[11px] text-slate-500">Org: {key.organization} • Created: {key.createdDate}</span>
                    </div>

                    <span className="text-xs bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300 px-2.5 py-0.5 rounded-full font-bold">
                      {key.status}
                    </span>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 font-mono text-xs text-cyan-300 flex justify-between items-center">
                    <span>{key.apiKeyString}</span>
                    <button
                      onClick={() => alert("API Key Copied to Clipboard!")}
                      className="text-slate-400 hover:text-white text-[10px]"
                    >
                      Copy
                    </button>
                  </div>

                  <div className="flex justify-between items-center text-xs text-slate-500">
                    <span>Daily Quota: <strong className="font-mono">{key.queriesUsedToday} / {key.dailyQueryLimit} Reqs</strong></span>
                    <div className="w-48 bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                      <div
                        className="bg-cyan-500 h-2 rounded-full"
                        style={{ width: `${(key.queriesUsedToday / key.dailyQueryLimit) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: UNIVERSITY & STARTUP HUB */}
      {activeTab === 'innovation' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="mb-6">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Building2 className="w-5 h-5 text-cyan-600" />
                University Innovation Ecosystem & Startup Challenge Grants
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Collaborative research initiatives with University of Rwanda, Carnegie Mellon Africa, and MINAGRI AgTech Accelerator.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                <span className="text-[10px] font-bold text-cyan-600 dark:text-cyan-400 uppercase tracking-wider block">
                  Active Grant Challenge
                </span>
                <h4 className="font-bold text-slate-900 dark:text-white text-base">
                  $50,000 Sub-Saharan Climate AI Research Grant 2026
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  Open for university research teams building predictive drought early warning models using AGRIWISE Sentinel-2 dataset.
                </p>
                <button className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold px-4 py-2 rounded-xl text-xs">
                  Apply for Research Grant
                </button>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block">
                  AgTech Startup Sandbox
                </span>
                <h4 className="font-bold text-slate-900 dark:text-white text-base">
                  Rwanda Open Agri-Data API Sandbox Access
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  Early-stage agritech startups get 100,000 free API queries/month to build precision farming applications.
                </p>
                <button className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-xl text-xs">
                  Enroll Sandbox Startup
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Dataset Access Request Modal */}
      {showRequestModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Request Dataset Access Authorization
            </h3>
            <p className="text-xs text-slate-500">
              Dataset: <strong>{selectedDataset.title}</strong>
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Project Title:</label>
                <input
                  type="text"
                  value={requestProjectTitle}
                  onChange={(e) => setRequestProjectTitle(e.target.value)}
                  placeholder="e.g. Eastern Province Soil Moisture Analysis"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Organization / Institution:</label>
                <input
                  type="text"
                  value={requestOrganization}
                  onChange={(e) => setRequestOrganization(e.target.value)}
                  placeholder="e.g. University of Rwanda"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={handleDatasetRequestSubmit}
                className="flex-1 bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 rounded-xl text-xs"
              >
                Submit Authorization Request
              </button>
              <button
                onClick={() => setShowRequestModal(false)}
                className="px-4 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold py-2 rounded-xl text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Generate API Key Modal */}
      {showApiKeyModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Generate Developer API Key
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Key Alias Name:</label>
                <input
                  type="text"
                  value={newKeyName}
                  onChange={(e) => setNewKeyName(e.target.value)}
                  placeholder="e.g. Research Production Key"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Organization:</label>
                <input
                  type="text"
                  value={newKeyOrg}
                  onChange={(e) => setNewKeyOrg(e.target.value)}
                  placeholder="e.g. ICRISAT Rwanda"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={handleGenerateApiKey}
                className="flex-1 bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 rounded-xl text-xs"
              >
                Generate Live Key
              </button>
              <button
                onClick={() => setShowApiKeyModal(false)}
                className="px-4 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold py-2 rounded-xl text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
