import React, { useState, useRef, useEffect } from 'react';
import { User, Language, RegisteredFarm, FarmActivity } from '../../types';
import { translations } from '../../data/translations';
import { DISEASE_PRESETS, DiseasePreset } from '../../data/diseasePresets';
import {
  Scan,
  Upload,
  Camera,
  CheckCircle2,
  AlertTriangle,
  Stethoscope,
  Sparkles,
  Loader2,
  Volume2,
  VolumeX,
  ShoppingCart,
  RefreshCw,
  PlusCircle,
  ShieldCheck,
  ChevronRight,
  Bug,
  Leaf,
  Info,
  Layers,
  ThumbsUp,
  ThumbsDown,
  PhoneCall,
  Check,
  Zap
} from 'lucide-react';

interface DiseaseDetectorProps {
  currentUser: User;
  language: Language;
  registeredFarms?: RegisteredFarm[];
  onUpdateFarmHealth?: (farmId: string, newScore: number) => void;
  onAddFarmActivity?: (activity: Omit<FarmActivity, 'id'>) => void;
  onMakeMoMoPayment?: (amount: number, description: string) => void;
}

export const DiseaseDetector: React.FC<DiseaseDetectorProps> = ({
  currentUser,
  language,
  registeredFarms = [],
  onUpdateFarmHealth,
  onAddFarmActivity,
  onMakeMoMoPayment,
}) => {
  const t = translations[language];

  // Primary mode state
  const [scanCategory, setScanCategory] = useState<'crop' | 'livestock'>('crop');
  const [selectedPreset, setSelectedPreset] = useState<DiseasePreset | null>(DISEASE_PRESETS[0]);
  
  // Image input state
  const [selectedImage, setSelectedImage] = useState<string>(DISEASE_PRESETS[0].imageUrl);
  const [cropOrAnimalName, setCropOrAnimalName] = useState('Maize (Ibigori)');
  const [farmerNotes, setFarmerNotes] = useState('Yellowing spots and worm feeding holes on leaf whorls.');
  const [selectedFarmId, setSelectedFarmId] = useState<string>(registeredFarms[0]?.id || '');

  // Live Camera states
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Analysis state
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [scanProgressStep, setScanProgressStep] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'symptoms' | 'treatment' | 'prevention' | 'expert'>('symptoms');

  // Diagnostic output state
  const [diagnosisResult, setDiagnosisResult] = useState<any>({
    diseaseDetected: true,
    diseaseName: DISEASE_PRESETS[0].diseaseName[language] || DISEASE_PRESETS[0].diseaseName.en,
    scientificName: DISEASE_PRESETS[0].scientificName,
    confidenceScore: DISEASE_PRESETS[0].confidenceScore,
    severity: DISEASE_PRESETS[0].severity,
    symptoms: DISEASE_PRESETS[0].symptoms[language] || DISEASE_PRESETS[0].symptoms.en,
    organicTreatment: DISEASE_PRESETS[0].organicTreatment[language] || DISEASE_PRESETS[0].organicTreatment.en,
    chemicalTreatment: DISEASE_PRESETS[0].chemicalTreatment[language] || DISEASE_PRESETS[0].chemicalTreatment.en,
    preventativeAdvice: DISEASE_PRESETS[0].preventativeAdvice[language] || DISEASE_PRESETS[0].preventativeAdvice.en,
    recommendedAgronomist: `${DISEASE_PRESETS[0].rabAgronomist.name} - ${DISEASE_PRESETS[0].rabAgronomist.station} (${DISEASE_PRESETS[0].rabAgronomist.phone})`,
    momoProductName: DISEASE_PRESETS[0].momoProduct.productName,
    momoProductPriceRwf: DISEASE_PRESETS[0].momoProduct.priceRwf,
    dealerName: DISEASE_PRESETS[0].momoProduct.dealerName,
    audioSummary: DISEASE_PRESETS[0].audioSummary[language] || DISEASE_PRESETS[0].audioSummary.en,
  });

  // UI status feedbacks
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [savedToTwinSuccess, setSavedToTwinSuccess] = useState(false);
  const [momoOrderSuccess, setMomoOrderSuccess] = useState(false);
  const [feedbackGiven, setFeedbackGiven] = useState<'like' | 'dislike' | null>(null);

  // Initialize camera
  const startCamera = async () => {
    try {
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: facingMode }
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.warn('Camera access error:', err);
      alert('Could not access live camera. Please use upload or sample presets.');
      setIsCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  const captureCameraFrame = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg');
      setSelectedImage(dataUrl);
      setSelectedPreset(null);
    }
    stopCamera();
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setSelectedPreset(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSelectPreset = (preset: DiseasePreset) => {
    setSelectedPreset(preset);
    setSelectedImage(preset.imageUrl);
    setScanCategory(preset.category);
    setCropOrAnimalName(preset.targetName[language] || preset.targetName.en);
    setFarmerNotes(`Inspecting ${preset.targetName[language] || preset.targetName.en} symptoms.`);
    
    // Automatically fill diagnostic state for preset
    setDiagnosisResult({
      diseaseDetected: true,
      diseaseName: preset.diseaseName[language] || preset.diseaseName.en,
      scientificName: preset.scientificName,
      confidenceScore: preset.confidenceScore,
      severity: preset.severity,
      symptoms: preset.symptoms[language] || preset.symptoms.en,
      organicTreatment: preset.organicTreatment[language] || preset.organicTreatment.en,
      chemicalTreatment: preset.chemicalTreatment[language] || preset.chemicalTreatment.en,
      preventativeAdvice: preset.preventativeAdvice[language] || preset.preventativeAdvice.en,
      recommendedAgronomist: `${preset.rabAgronomist.name} - ${preset.rabAgronomist.station} (${preset.rabAgronomist.phone})`,
      momoProductName: preset.momoProduct.productName,
      momoProductPriceRwf: preset.momoProduct.priceRwf,
      dealerName: preset.momoProduct.dealerName,
      audioSummary: preset.audioSummary[language] || preset.audioSummary.en,
    });
  };

  // Run AI Vision Analysis
  const handleRunDiagnosis = async () => {
    if (!selectedImage) return;
    setIsAnalyzing(true);
    setSavedToTwinSuccess(false);
    setMomoOrderSuccess(false);
    setFeedbackGiven(null);

    // Progressive loading updates
    const steps = [
      language === 'rw' ? '1/4: Ingingo z\'ifoto zirimo gukusanywa...' : '1/4: Extracting leaf morphology...',
      language === 'rw' ? '2/4: Gusanisha na RAB Plant Pathology Database...' : '2/4: Matching against RAB disease database...',
      language === 'rw' ? '3/4: Kubara ikigereranyo cya AI (Confidence Score)...' : '3/4: Computing AI confidence rating...',
      language === 'rw' ? '4/4: Gukora umuti n\'inama z\'ururimi rwawe...' : '4/4: Generating localized solution plan...'
    ];

    for (let i = 0; i < steps.length; i++) {
      setScanProgressStep(steps[i]);
      await new Promise(res => setTimeout(res, 500));
    }

    try {
      const res = await fetch('/api/ai/diagnose', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: selectedImage,
          cropType: cropOrAnimalName,
          category: scanCategory,
          notes: farmerNotes,
          language,
        }),
      });

      const data = await res.json();
      setDiagnosisResult(data);
    } catch (err) {
      console.error('Diagnosis call failed:', err);
      // Fallback preset if network fails
      const fallbackPreset = DISEASE_PRESETS.find(p => p.category === scanCategory) || DISEASE_PRESETS[0];
      handleSelectPreset(fallbackPreset);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // TTS Read aloud summary
  const toggleSpeech = () => {
    if (!('speechSynthesis' in window)) {
      alert('Audio Speech Synthesis is not supported in this browser.');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const textToSpeak = diagnosisResult?.audioSummary || 
      `${diagnosisResult.diseaseName}. Confidence score ${diagnosisResult.confidenceScore} percent. Severity: ${diagnosisResult.severity}. ${diagnosisResult.organicTreatment}`;

    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.lang = language === 'rw' ? 'rw-RW' : language === 'fr' ? 'fr-FR' : 'en-US';
    utterance.rate = 0.9;

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  // Sync to Digital Farm Twin
  const handleSaveToFarmTwin = () => {
    if (!selectedFarmId) {
      alert('Please select a registered farm first.');
      return;
    }

    const farm = registeredFarms.find(f => f.id === selectedFarmId);
    const farmName = farm ? farm.farmName : 'My Farm';

    // Calculate updated health score (deduct slightly if high severity disease)
    if (onUpdateFarmHealth && farm) {
      const deduction = diagnosisResult.severity === 'Critical' ? 15 : diagnosisResult.severity === 'High' ? 10 : 5;
      const newScore = Math.max(30, farm.healthScore - deduction);
      onUpdateFarmHealth(farm.id, newScore);
    }

    // Add farm activity
    if (onAddFarmActivity) {
      onAddFarmActivity({
        farmId: selectedFarmId,
        farmName,
        activityType: 'Spraying',
        title: `AI Scan: ${diagnosisResult.diseaseName}`,
        description: `Identified ${diagnosisResult.diseaseName} (${diagnosisResult.confidenceScore}% confidence). Recommended: ${diagnosisResult.momoProductName || 'Organic Neem Spray'}.`,
        date: new Date().toISOString().split('T')[0],
        status: 'pending',
        cropOrAnimalTarget: cropOrAnimalName,
        inputUsed: diagnosisResult.momoProductName || 'Organic Spray',
        costRwf: diagnosisResult.momoProductPriceRwf || 4500,
      });
    }

    setSavedToTwinSuccess(true);
    setTimeout(() => setSavedToTwinSuccess(false), 5000);
  };

  // Order treatment via MoMo
  const handleOrderMoMo = () => {
    const price = diagnosisResult.momoProductPriceRwf || 4500;
    const name = diagnosisResult.momoProductName || 'Crop Treatment Input';
    
    if (onMakeMoMoPayment) {
      onMakeMoMoPayment(price, `Order: ${name}`);
    }
    setMomoOrderSuccess(true);
    setTimeout(() => setMomoOrderSuccess(false), 6000);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl text-white">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3.5 py-1 rounded-full text-xs font-bold tracking-wide">
              <Scan className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span>STEP 25 — AI Computer Vision Health Intelligence</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">{t.diseaseTitle}</h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              {t.diseaseSubtitle}
            </p>
          </div>

          {/* Mode Selector Toggle */}
          <div className="flex items-center bg-slate-900/90 p-1.5 rounded-2xl border border-slate-700/80 shadow-inner shrink-0">
            <button
              onClick={() => {
                setScanCategory('crop');
                setCropOrAnimalName('Maize (Ibigori)');
              }}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                scanCategory === 'crop'
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Leaf className="w-4 h-4" />
              <span>Crop Health</span>
            </button>

            <button
              onClick={() => {
                setScanCategory('livestock');
                setCropOrAnimalName('Dairy Cattle (Inka)');
              }}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                scanCategory === 'livestock'
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Bug className="w-4 h-4" />
              <span>Livestock Vision</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Left Camera & Upload / Right Findings */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (5 cols): Camera & Sample Inputs */}
        <div className="lg:col-span-5 space-y-6">
          
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="text-sm font-bold text-white flex items-center space-x-2">
                <Camera className="w-4 h-4 text-emerald-400" />
                <span>
                  {scanCategory === 'crop' ? 'Crop Leaf Camera' : 'Livestock Health Scanner'}
                </span>
              </h2>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/30">
                Gemini 3.6 Multimodal
              </span>
            </div>

            {/* Camera Viewfinder Box */}
            <div className="relative w-full h-72 bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 flex items-center justify-center group shadow-inner">
              
              {/* Live WebRTC Camera Stream */}
              {isCameraActive ? (
                <div className="relative w-full h-full">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    className="w-full h-full object-cover"
                  />
                  {/* Holographic Target Reticle */}
                  <div className="absolute inset-6 border-2 border-dashed border-emerald-400/70 rounded-2xl pointer-events-none flex items-center justify-center">
                    <div className="w-4 h-4 border-t-2 border-l-2 border-emerald-400 absolute top-2 left-2" />
                    <div className="w-4 h-4 border-t-2 border-r-2 border-emerald-400 absolute top-2 right-2" />
                    <div className="w-4 h-4 border-b-2 border-l-2 border-emerald-400 absolute bottom-2 left-2" />
                    <div className="w-4 h-4 border-b-2 border-r-2 border-emerald-400 absolute bottom-2 right-2" />
                    <p className="text-[10px] text-emerald-300 bg-slate-950/80 px-2 py-0.5 rounded font-mono">
                      Align leaf inside frame
                    </p>
                  </div>

                  {/* Shutter Controls */}
                  <div className="absolute bottom-3 inset-x-0 flex items-center justify-center space-x-3">
                    <button
                      onClick={captureCameraFrame}
                      className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black px-5 py-2 rounded-xl text-xs shadow-lg flex items-center space-x-1.5 transition-all transform active:scale-95"
                    >
                      <Camera className="w-4 h-4" />
                      <span>Capture Frame</span>
                    </button>
                    <button
                      onClick={stopCamera}
                      className="bg-rose-950/80 hover:bg-rose-900 text-rose-300 px-3 py-2 rounded-xl text-xs font-bold border border-rose-500/40"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  {/* Photo Preview */}
                  {selectedImage ? (
                    <img
                      src={selectedImage}
                      alt="Crop specimen"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <div className="text-center p-6 text-slate-500 space-y-2">
                      <Upload className="w-10 h-10 mx-auto text-slate-600" />
                      <p className="text-xs font-semibold">No crop image loaded</p>
                    </div>
                  )}

                  {/* Laser Scanning Overlay Animation when Analyzing */}
                  {isAnalyzing && (
                    <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-sm flex flex-col items-center justify-center space-y-3 p-4 text-center">
                      <div className="relative w-16 h-16 rounded-2xl bg-emerald-600/20 border border-emerald-400 flex items-center justify-center shadow-lg">
                        <Loader2 className="w-8 h-8 animate-spin text-emerald-400" />
                        <div className="absolute inset-0 border-t-2 border-emerald-400 animate-pulse rounded-2xl" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-bold text-emerald-300">{t.analyzingImage}</p>
                        <p className="text-[11px] text-slate-400 font-mono animate-pulse">{scanProgressStep}</p>
                      </div>
                    </div>
                  )}

                  {/* Scanning Laser Beam Line */}
                  {!isAnalyzing && selectedImage && (
                    <div className="absolute top-3 right-3 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded-full border border-slate-700 text-[10px] text-emerald-400 font-mono flex items-center space-x-1">
                      <Sparkles className="w-3 h-3 text-emerald-400" />
                      <span>Ready for Scan</span>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Input Trigger Buttons */}
            <div className="grid grid-cols-2 gap-2.5">
              <button
                onClick={startCamera}
                disabled={isCameraActive || isAnalyzing}
                className="bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold py-2.5 px-3 rounded-xl border border-slate-700 flex items-center justify-center space-x-2 transition-colors disabled:opacity-50"
              >
                <Camera className="w-4 h-4 text-emerald-400" />
                <span>{t.takePhoto}</span>
              </button>

              <label className="cursor-pointer bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold py-2.5 px-3 rounded-xl border border-slate-700 flex items-center justify-center space-x-2 transition-colors">
                <Upload className="w-4 h-4 text-teal-400" />
                <span>{t.uploadPhoto}</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>
            </div>

            {/* Secondary Form Inputs */}
            <div className="space-y-3 text-xs pt-2">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  {scanCategory === 'crop' ? 'Target Crop Species:' : 'Livestock Type:'}
                </label>
                <select
                  value={cropOrAnimalName}
                  onChange={(e) => setCropOrAnimalName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-medium focus:border-emerald-500 focus:outline-none"
                >
                  {scanCategory === 'crop' ? (
                    <>
                      <option value="Maize (Ibigori)">Maize (Ibigori)</option>
                      <option value="Irish Potato (Ibirayi)">Irish Potato (Ibirayi)</option>
                      <option value="Banana (Ibitoki)">Banana (Ibitoki)</option>
                      <option value="Coffee (Kahawa)">Coffee (Kahawa)</option>
                      <option value="Beans (Ibibyimba)">Beans (Ibibyimba)</option>
                      <option value="Cassava (Imyumbati)">Cassava (Imyumbati)</option>
                    </>
                  ) : (
                    <>
                      <option value="Dairy Cattle (Inka)">Dairy Cattle (Inka)</option>
                      <option value="Goat (Ihene)">Goat (Ihene)</option>
                      <option value="Poultry / Chicken (Inkoko)">Poultry (Inkoko)</option>
                      <option value="Pig (Ingurube)">Pig (Ingurube)</option>
                    </>
                  )}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Observed Symptoms / Notes:</label>
                <input
                  type="text"
                  value={farmerNotes}
                  onChange={(e) => setFarmerNotes(e.target.value)}
                  placeholder="e.g. Yellow spots, worm damage, udder swelling..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-medium focus:border-emerald-500 focus:outline-none"
                />
              </div>

              {/* Run Diagnosis CTA Button */}
              <button
                onClick={handleRunDiagnosis}
                disabled={isAnalyzing || !selectedImage}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-4 rounded-xl shadow-lg shadow-emerald-600/30 flex items-center justify-center space-x-2 transition-all transform active:scale-98 disabled:opacity-50"
              >
                <Sparkles className="w-4.5 h-4.5 text-amber-300 animate-spin" />
                <span className="text-sm">Run AI Vision Diagnostic Scan</span>
              </button>
            </div>

          </div>

          {/* Quick Demo Rwandan Presets Selector */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>Rwandan Pathology Presets</span>
              </h3>
              <span className="text-[10px] text-slate-500">Quick Test Samples</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {DISEASE_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => handleSelectPreset(preset)}
                  className={`p-2.5 rounded-2xl border text-left transition-all flex items-start space-x-2.5 ${
                    selectedPreset?.id === preset.id
                      ? 'bg-emerald-950/70 border-emerald-500/50 text-white shadow-md'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  <img
                    src={preset.imageUrl}
                    alt={preset.diseaseName.en}
                    className="w-10 h-10 rounded-xl object-cover shrink-0 mt-0.5 border border-slate-800"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-[11px] font-bold text-white truncate">
                      {preset.targetName[language] || preset.targetName.en}
                    </p>
                    <p className="text-[10px] text-slate-400 truncate">
                      {preset.diseaseName[language] || preset.diseaseName.en}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column (7 cols): Full AI Diagnosis Findings & Action Plan */}
        <div className="lg:col-span-7 space-y-6">
          
          {diagnosisResult ? (
            <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 shadow-2xl space-y-6 text-white relative">
              
              {/* Header Title & Confidence Meter */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                      {t.diseaseResults}
                    </span>
                    {diagnosisResult.scientificName && (
                      <span className="text-[11px] text-slate-400 italic">
                        ({diagnosisResult.scientificName})
                      </span>
                    )}
                  </div>
                  <h2 className="text-xl font-black text-white">{diagnosisResult.diseaseName}</h2>
                </div>

                <div className="flex items-center space-x-3 shrink-0">
                  {/* Confidence Score Pill */}
                  <div className="bg-slate-950 border border-slate-800 rounded-2xl px-3.5 py-1.5 text-center">
                    <p className="text-[10px] uppercase text-slate-400 font-bold">AI Confidence</p>
                    <p className="text-sm font-black text-emerald-400">{diagnosisResult.confidenceScore}%</p>
                  </div>

                  {/* Severity Badge */}
                  <div className="text-center">
                    <span
                      className={`text-xs font-bold px-3 py-1.5 rounded-2xl border inline-block ${
                        diagnosisResult.severity === 'Critical' || diagnosisResult.severity === 'High'
                          ? 'bg-rose-950 text-rose-300 border-rose-500/40'
                          : diagnosisResult.severity === 'Medium'
                          ? 'bg-amber-950 text-amber-300 border-amber-500/40'
                          : 'bg-emerald-950 text-emerald-300 border-emerald-500/40'
                      }`}
                    >
                      Severity: {diagnosisResult.severity}
                    </span>
                  </div>
                </div>
              </div>

              {/* TTS Audio Voice Advisor Button */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-3 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <button
                    onClick={toggleSpeech}
                    className={`p-2.5 rounded-xl transition-all ${
                      isSpeaking
                        ? 'bg-amber-500 text-slate-950 shadow-lg animate-pulse'
                        : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    }`}
                  >
                    {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                  <div>
                    <p className="text-xs font-bold text-white">
                      {isSpeaking ? 'Speaking AI Diagnosis...' : 'Listen to Audio Voice Report'}
                    </p>
                    <p className="text-[11px] text-slate-400">
                      Audio translation available in Kinyarwanda, English & French
                    </p>
                  </div>
                </div>

                <span className="text-[10px] font-mono text-slate-500 bg-slate-900 px-2 py-1 rounded-lg">
                  {language.toUpperCase()} Voice
                </span>
              </div>

              {/* Multi-Tab Navigation */}
              <div className="flex border-b border-slate-800 space-x-2">
                <button
                  onClick={() => setActiveTab('symptoms')}
                  className={`pb-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center space-x-1.5 ${
                    activeTab === 'symptoms'
                      ? 'border-emerald-400 text-emerald-400'
                      : 'border-transparent text-slate-400 hover:text-white'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Symptoms & Pathology</span>
                </button>

                <button
                  onClick={() => setActiveTab('treatment')}
                  className={`pb-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center space-x-1.5 ${
                    activeTab === 'treatment'
                      ? 'border-emerald-400 text-emerald-400'
                      : 'border-transparent text-slate-400 hover:text-white'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Treatments & MoMo Store</span>
                </button>

                <button
                  onClick={() => setActiveTab('prevention')}
                  className={`pb-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center space-x-1.5 ${
                    activeTab === 'prevention'
                      ? 'border-emerald-400 text-emerald-400'
                      : 'border-transparent text-slate-400 hover:text-white'
                  }`}
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>Prevention & Agronomy</span>
                </button>
              </div>

              {/* Tab 1: Symptoms */}
              {activeTab === 'symptoms' && (
                <div className="space-y-4 text-xs animate-fadeIn">
                  <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
                    <h3 className="font-bold text-slate-200 flex items-center space-x-2">
                      <Bug className="w-4 h-4 text-amber-400" />
                      <span>Identified Symptoms & Pathology Traits</span>
                    </h3>
                    <ul className="space-y-2 text-slate-300 pt-1">
                      {diagnosisResult.symptoms?.map((symptom: string, idx: number) => (
                        <li key={idx} className="flex items-start space-x-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0 mt-1.5" />
                          <span className="leading-relaxed">{symptom}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-1">
                      <span className="text-[10px] font-bold uppercase text-slate-400">Target Host</span>
                      <p className="font-bold text-white text-sm">{cropOrAnimalName}</p>
                    </div>
                    <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-1">
                      <span className="text-[10px] font-bold uppercase text-slate-400">Scan Status</span>
                      <p className="font-bold text-emerald-400 text-sm">Diagnosis Confirmed</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 2: Treatment & MoMo Store */}
              {activeTab === 'treatment' && (
                <div className="space-y-4 text-xs animate-fadeIn">
                  
                  {/* Organic & Natural Remedy */}
                  <div className="p-4 bg-emerald-950/40 border border-emerald-500/30 rounded-2xl space-y-2">
                    <span className="font-bold text-emerald-400 flex items-center space-x-1.5 text-xs">
                      <Leaf className="w-4 h-4" />
                      <span>{t.organicRemedy}</span>
                    </span>
                    <p className="text-slate-200 text-xs leading-relaxed">
                      {diagnosisResult.organicTreatment}
                    </p>
                  </div>

                  {/* Chemical Treatment */}
                  <div className="p-4 bg-blue-950/40 border border-blue-500/30 rounded-2xl space-y-2">
                    <span className="font-bold text-blue-400 flex items-center space-x-1.5 text-xs">
                      <ShieldCheck className="w-4 h-4" />
                      <span>{t.chemicalRemedy}</span>
                    </span>
                    <p className="text-slate-200 text-xs leading-relaxed">
                      {diagnosisResult.chemicalTreatment}
                    </p>
                  </div>

                  {/* MoMo Direct Purchase Input Store Banner */}
                  <div className="p-4 bg-gradient-to-r from-amber-950/70 via-slate-950 to-emerald-950/70 border border-amber-500/40 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-md border border-amber-500/30">
                          MoMo Store Recommended Product
                        </span>
                      </div>
                      <p className="font-bold text-white text-sm">
                        {diagnosisResult.momoProductName || 'Emamectin Benzoate 5% SG (250g)'}
                      </p>
                      <p className="text-[11px] text-slate-400">
                        Supplier: {diagnosisResult.dealerName || 'AgriPro Agrodealers'}
                      </p>
                    </div>

                    <div className="text-right shrink-0">
                      <p className="text-lg font-black text-amber-400">
                        RWF {(diagnosisResult.momoProductPriceRwf || 4500).toLocaleString()}
                      </p>
                      <button
                        onClick={handleOrderMoMo}
                        className="mt-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-4 py-2 rounded-xl text-xs flex items-center space-x-1.5 shadow-lg transition-all transform active:scale-95"
                      >
                        <ShoppingCart className="w-4 h-4" />
                        <span>Order via MoMo</span>
                      </button>
                    </div>
                  </div>

                  {momoOrderSuccess && (
                    <div className="p-3 bg-emerald-950 border border-emerald-500 rounded-xl text-emerald-300 text-xs flex items-center space-x-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>Order initiated successfully! Payment prompt sent to Mobile Money.</span>
                    </div>
                  )}

                </div>
              )}

              {/* Tab 3: Prevention */}
              {activeTab === 'prevention' && (
                <div className="space-y-4 text-xs animate-fadeIn">
                  <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                    <h3 className="font-bold text-white flex items-center space-x-2">
                      <Info className="w-4 h-4 text-emerald-400" />
                      <span>Long-Term Prevention & Field Sanitation</span>
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      {diagnosisResult.preventativeAdvice}
                    </p>
                  </div>
                </div>
              )}

              {/* RAB Agronomist Contact Box */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-950 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                    <Stethoscope className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-bold text-white">RAB Recommended Agronomist</p>
                    <p className="text-[11px] text-slate-400">{diagnosisResult.recommendedAgronomist}</p>
                  </div>
                </div>

                <a
                  href={`tel:${diagnosisResult.recommendedAgronomist?.split('(')[1]?.replace(')', '') || '+250788123456'}`}
                  className="bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30 font-bold px-4 py-2 rounded-xl text-xs flex items-center justify-center space-x-1.5 transition-colors shrink-0"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Call Agronomist</span>
                </a>
              </div>

              {/* Digital Farm Twin Synchronization Box */}
              <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center space-x-2 text-xs text-slate-300">
                  <Layers className="w-4 h-4 text-emerald-400" />
                  <span>Attach Scan to Digital Farm Twin:</span>
                  <select
                    value={selectedFarmId}
                    onChange={(e) => setSelectedFarmId(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-white font-medium"
                  >
                    {registeredFarms.length > 0 ? (
                      registeredFarms.map(f => (
                        <option key={f.id} value={f.id}>{f.farmName} ({f.district})</option>
                      ))
                    ) : (
                      <option value="">Default Farm Plot</option>
                    )}
                  </select>
                </div>

                <button
                  onClick={handleSaveToFarmTwin}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center justify-center space-x-2 shadow-lg transition-all"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>Save to Digital Twin</span>
                </button>
              </div>

              {savedToTwinSuccess && (
                <div className="p-3 bg-emerald-950 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Scan synced to Digital Farm Twin! Farm health score updated.</span>
                </div>
              )}

              {/* Feedback Loop */}
              <div className="pt-2 flex items-center justify-between text-[11px] text-slate-400">
                <span>Is this AI diagnosis helpful?</span>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setFeedbackGiven('like')}
                    className={`p-1.5 rounded-lg border transition-colors ${
                      feedbackGiven === 'like'
                        ? 'bg-emerald-950 border-emerald-500 text-emerald-400'
                        : 'border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setFeedbackGiven('dislike')}
                    className={`p-1.5 rounded-lg border transition-colors ${
                      feedbackGiven === 'dislike'
                        ? 'bg-rose-950 border-rose-500 text-rose-400'
                        : 'border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <ThumbsDown className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center text-slate-500 space-y-3">
              <Scan className="w-12 h-12 mx-auto text-slate-600 animate-pulse" />
              <p className="text-sm font-bold text-slate-400">No scan performed yet</p>
              <p className="text-xs">Take a photo or choose a preset to generate AI crop diagnosis.</p>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
