import React, { useState, useEffect, useRef } from 'react';
import {
  Video,
  Upload,
  Plus,
  Search,
  Filter,
  Eye,
  Edit2,
  Trash2,
  CheckCircle,
  AlertCircle,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  X,
  FileVideo,
  Image as ImageIcon,
  Sparkles,
  Layers,
  Globe,
  Users,
  MapPin,
  Clock,
  HardDrive,
  RefreshCw,
  LayoutGrid,
  List,
  ChevronRight,
  ShieldCheck,
  Calendar,
  UserCheck,
  Award
} from 'lucide-react';
import { EducationalVideo, EducationalVideoFilterOptions, EducationalVideoStatus, VideoCertificationStatus, Language, UserRole } from '../../types';
import {
  AGRICULTURAL_VIDEO_CATEGORIES,
  TARGET_AUDIENCE_OPTIONS,
  RWANDAN_CROPS_OPTIONS,
  RWANDAN_LIVESTOCK_OPTIONS,
  RWANDAN_DISTRICTS_OPTIONS
} from '../../data/educationalVideoCategories';
import {
  fetchAllEducationalVideos,
  createEducationalVideo,
  updateEducationalVideo,
  togglePublishEducationalVideo,
  updateEducationalVideoStatus,
  deleteEducationalVideo,
  uploadVideoFileToStorage,
  uploadThumbnailFileToStorage,
  filterEducationalVideos
} from '../../services/educationalVideoService';
import { translations } from '../../data/translations';

interface AdminVideoManagerProps {
  language: Language;
  currentUser?: {
    id: string;
    name: string;
    role: UserRole;
    email?: string;
  };
}

export const AdminVideoManager: React.FC<AdminVideoManagerProps> = ({
  language,
  currentUser = {
    id: 'usr_0_owner',
    name: 'Jimmy Mico (System Admin)',
    role: 'admin',
    email: 'jimmymico45@gmail.com'
  }
}) => {
  const t = translations[language] || translations.en;

  // Video data state
  const [videos, setVideos] = useState<EducationalVideo[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // View & Filter states
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedTopic, setSelectedTopic] = useState<string>('ALL');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedAudience, setSelectedAudience] = useState<string>('ALL');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('ALL');

  // Modals state
  const [isUploadModalOpen, setIsUploadModalOpen] = useState<boolean>(false);
  const [editingVideo, setEditingVideo] = useState<EducationalVideo | null>(null);
  const [previewingVideo, setPreviewingVideo] = useState<EducationalVideo | null>(null);
  const [deletingVideo, setDeletingVideo] = useState<EducationalVideo | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Upload Form State
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadThumbnail, setUploadThumbnail] = useState<File | null>(null);
  const [uploadVideoPreviewUrl, setUploadVideoPreviewUrl] = useState<string>('');
  const [uploadThumbnailPreviewUrl, setUploadThumbnailPreviewUrl] = useState<string>('');
  const [videoDurationSeconds, setVideoDurationSeconds] = useState<number>(0);
  const [videoFileSizeBytes, setVideoFileSizeBytes] = useState<number>(0);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: AGRICULTURAL_VIDEO_CATEGORIES[0].name,
    topic: AGRICULTURAL_VIDEO_CATEGORIES[0].topics[0],
    language: 'rw' as 'rw' | 'en' | 'fr' | 'all',
    targetAudience: TARGET_AUDIENCE_OPTIONS[0],
    district: RWANDAN_DISTRICTS_OPTIONS[0],
    crop: '',
    livestock: '',
    status: 'PUBLISHED' as EducationalVideoStatus,
    certificationStatus: 'NONE' as VideoCertificationStatus
  });

  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [uploadStage, setUploadStage] = useState<string>('');
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const videoFileInputRef = useRef<HTMLInputElement>(null);
  const thumbnailFileInputRef = useRef<HTMLInputElement>(null);

  // Toast Helper
  const showToast = (type: 'success' | 'error' | 'info', text: string) => {
    setToastMessage({ type, text });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Load Videos
  const loadVideos = async (silent = false) => {
    if (!silent) setIsLoading(true);
    try {
      const data = await fetchAllEducationalVideos();
      setVideos(data);
    } catch (err) {
      console.error('Failed to load educational videos:', err);
      showToast('error', 'Could not load videos. Please try again.');
    } finally {
      if (!silent) setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    loadVideos();
  }, []);

  // Update topics when category changes in form
  const handleCategoryChange = (newCatName: string) => {
    const cat = AGRICULTURAL_VIDEO_CATEGORIES.find((c) => c.name === newCatName);
    setFormData((prev) => ({
      ...prev,
      category: newCatName,
      topic: cat && cat.topics.length > 0 ? cat.topics[0] : ''
    }));
  };

  // Validate and handle Video File Selection
  const handleVideoFileChange = (file: File | null) => {
    if (!file) return;

    // MIME type check
    const validVideoTypes = ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime', 'video/x-matroska'];
    if (!validVideoTypes.includes(file.type) && !file.name.match(/\.(mp4|webm|ogg|mov|mkv)$/i)) {
      setFormErrors((prev) => ({ ...prev, video: 'Please upload a valid video file (MP4, WebM, OGG, MOV).' }));
      return;
    }

    // Size limit: 100MB
    const MAX_VIDEO_SIZE = 100 * 1024 * 1024;
    if (file.size > MAX_VIDEO_SIZE) {
      setFormErrors((prev) => ({ ...prev, video: 'Video file size exceeds maximum limit of 100MB.' }));
      return;
    }

    setFormErrors((prev) => {
      const copy = { ...prev };
      delete copy.video;
      return copy;
    });

    setUploadFile(file);
    setVideoFileSizeBytes(file.size);

    const objectUrl = URL.createObjectURL(file);
    setUploadVideoPreviewUrl(objectUrl);

    // Extract video duration using HTML5 video probe
    const tempVideo = document.createElement('video');
    tempVideo.preload = 'metadata';
    tempVideo.src = objectUrl;
    tempVideo.onloadedmetadata = () => {
      window.URL.revokeObjectURL(tempVideo.src);
      const dur = Math.round(tempVideo.duration) || 0;
      setVideoDurationSeconds(dur);
    };
  };

  // Validate and handle Thumbnail File Selection
  const handleThumbnailFileChange = (file: File | null) => {
    if (!file) return;

    // Type check
    const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setFormErrors((prev) => ({ ...prev, thumbnail: 'Thumbnail must be a JPG, PNG, or WEBP image.' }));
      return;
    }

    // Size limit: 5MB
    if (file.size > 5 * 1024 * 1024) {
      setFormErrors((prev) => ({ ...prev, thumbnail: 'Thumbnail image cannot exceed 5MB.' }));
      return;
    }

    setFormErrors((prev) => {
      const copy = { ...prev };
      delete copy.thumbnail;
      return copy;
    });

    setUploadThumbnail(file);
    const objectUrl = URL.createObjectURL(file);
    setUploadThumbnailPreviewUrl(objectUrl);
  };

  // Reset Form
  const resetForm = () => {
    setUploadFile(null);
    setUploadThumbnail(null);
    setUploadVideoPreviewUrl('');
    setUploadThumbnailPreviewUrl('');
    setVideoDurationSeconds(0);
    setVideoFileSizeBytes(0);
    setFormData({
      title: '',
      description: '',
      category: AGRICULTURAL_VIDEO_CATEGORIES[0].name,
      topic: AGRICULTURAL_VIDEO_CATEGORIES[0].topics[0],
      language: 'rw',
      targetAudience: TARGET_AUDIENCE_OPTIONS[0],
      district: RWANDAN_DISTRICTS_OPTIONS[0],
      crop: '',
      livestock: '',
      status: 'PUBLISHED',
      certificationStatus: 'NONE'
    });
    setFormErrors({});
    setUploadProgress(0);
    setUploadStage('');
    setIsUploading(false);
  };

  // Open Upload Modal
  const handleOpenUpload = () => {
    resetForm();
    setIsUploadModalOpen(true);
  };

  // Submit Video Upload
  const handleSaveVideo = async (targetStatus: EducationalVideoStatus) => {
    // Validation
    const errors: Record<string, string> = {};
    if (!formData.title.trim()) errors.title = 'Title is required';
    if (!formData.description.trim()) errors.description = 'Description is required';
    if (!uploadFile && !editingVideo) errors.video = 'A video file is required';
    if (!uploadThumbnail && !uploadThumbnailPreviewUrl && !editingVideo) {
      errors.thumbnail = 'A thumbnail image is required';
    }

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    setIsUploading(true);
    setUploadProgress(5);
    setUploadStage('Initializing upload process...');

    try {
      const videoId = editingVideo ? editingVideo.id : `vid-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      let finalVideoUrl = editingVideo ? editingVideo.videoUrl : '';
      let finalVideoStoragePath = editingVideo ? editingVideo.videoStoragePath : '';
      let finalThumbUrl = editingVideo ? editingVideo.thumbnailUrl : '';
      let finalThumbStoragePath = editingVideo ? editingVideo.thumbnailStoragePath : '';

      // 1. Upload Video if new file selected
      if (uploadFile) {
        setUploadStage('Uploading high-definition video to Firebase Storage...');
        const videoRes = await uploadVideoFileToStorage(videoId, uploadFile, (progress) => {
          // Video upload contributes to 60% of total progress
          setUploadProgress(5 + Math.round(progress * 0.6));
        });
        finalVideoUrl = videoRes.downloadUrl;
        finalVideoStoragePath = videoRes.storagePath;
      }

      // 2. Upload Thumbnail if new thumbnail selected
      if (uploadThumbnail) {
        setUploadStage('Uploading thumbnail image...');
        const thumbRes = await uploadThumbnailFileToStorage(videoId, uploadThumbnail, (progress) => {
          // Thumbnail upload contributes to 25% of total progress
          setUploadProgress(65 + Math.round(progress * 0.25));
        });
        finalThumbUrl = thumbRes.downloadUrl;
        finalThumbStoragePath = thumbRes.storagePath;
      } else if (!finalThumbUrl) {
        // Default fallback banner
        finalThumbUrl = 'https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=800&auto=format&fit=crop&q=80';
      }

      setUploadStage('Persisting educational metadata to Firestore database...');
      setUploadProgress(92);

      const finalStatus = targetStatus || formData.status || 'PUBLISHED';

      if (editingVideo) {
        await updateEducationalVideo(
          videoId,
          {
            title: formData.title.trim(),
            description: formData.description.trim(),
            category: formData.category,
            topic: formData.topic,
            language: formData.language,
            targetAudience: formData.targetAudience,
            district: formData.district,
            crop: formData.crop || undefined,
            livestock: formData.livestock || undefined,
            videoUrl: finalVideoUrl,
            videoStoragePath: finalVideoStoragePath,
            thumbnailUrl: finalThumbUrl,
            thumbnailStoragePath: finalThumbStoragePath,
            status: finalStatus,
            certificationStatus: formData.certificationStatus || 'NONE',
            duration: videoDurationSeconds || editingVideo.duration,
            fileSize: videoFileSizeBytes || editingVideo.fileSize
          },
          currentUser
        );
        showToast('success', `Video "${formData.title}" updated successfully!`);
      } else {
        await createEducationalVideo(
          {
            id: videoId,
            title: formData.title.trim(),
            description: formData.description.trim(),
            category: formData.category,
            topic: formData.topic,
            language: formData.language,
            targetAudience: formData.targetAudience,
            district: formData.district,
            crop: formData.crop || undefined,
            livestock: formData.livestock || undefined,
            videoUrl: finalVideoUrl,
            videoStoragePath: finalVideoStoragePath,
            thumbnailUrl: finalThumbUrl,
            thumbnailStoragePath: finalThumbStoragePath,
            status: finalStatus,
            certificationStatus: formData.certificationStatus || 'NONE',
            duration: videoDurationSeconds || 300,
            fileSize: videoFileSizeBytes || 15000000,
            uploadedBy: {
              id: currentUser.id,
              name: currentUser.name,
              role: currentUser.role,
              email: currentUser.email
            }
          },
          currentUser
        );
        showToast('success', `Educational video "${formData.title}" saved as ${finalStatus}!`);
      }

      setUploadProgress(100);
      setUploadStage('Complete!');

      // Close modal and refresh list
      setTimeout(() => {
        setIsUploadModalOpen(false);
        setEditingVideo(null);
        resetForm();
        loadVideos(true);
      }, 600);
    } catch (err) {
      console.error('Error during video save/upload:', err);
      showToast('error', 'Upload failed. Please check your connection and try again.');
      setIsUploading(false);
    }
  };

  // Open Edit Modal
  const handleOpenEdit = (video: EducationalVideo) => {
    setEditingVideo(video);
    setFormData({
      title: video.title,
      description: video.description,
      category: video.category,
      topic: video.topic,
      language: video.language,
      targetAudience: video.targetAudience,
      district: video.district || RWANDAN_DISTRICTS_OPTIONS[0],
      crop: video.crop || '',
      livestock: video.livestock || '',
      status: video.status,
      certificationStatus: video.certificationStatus || 'NONE'
    });
    setUploadThumbnailPreviewUrl(video.thumbnailUrl);
    setUploadVideoPreviewUrl(video.videoUrl);
    setVideoDurationSeconds(video.duration);
    setVideoFileSizeBytes(video.fileSize);
    setIsUploadModalOpen(true);
  };

  // Change Lifecycle Status (DRAFT / PENDING_REVIEW / APPROVED / PUBLISHED / REJECTED)
  const handleChangeStatus = async (video: EducationalVideo, nextStatus: EducationalVideoStatus) => {
    try {
      await updateEducationalVideoStatus(video.id, nextStatus, currentUser);
      setVideos((prev) =>
        prev.map((v) => (v.id === video.id ? { ...v, status: nextStatus, publishedAt: nextStatus === 'PUBLISHED' ? (v.publishedAt || new Date().toISOString()) : v.publishedAt } : v))
      );
      showToast(
        'success',
        `Video "${video.title}" status updated to ${nextStatus}.`
      );
    } catch (err) {
      console.error('Error updating video status:', err);
      showToast('error', 'Failed to update video status.');
    }
  };

  // Toggle Publish Status
  const handleTogglePublish = async (video: EducationalVideo) => {
    const nextStatus: EducationalVideoStatus = video.status === 'PUBLISHED' ? 'DRAFT' : 'PUBLISHED';
    try {
      await togglePublishEducationalVideo(video.id, nextStatus, currentUser);
      setVideos((prev) =>
        prev.map((v) => (v.id === video.id ? { ...v, status: nextStatus, publishedAt: nextStatus === 'PUBLISHED' ? new Date().toISOString() : null } : v))
      );
      showToast(
        'success',
        nextStatus === 'PUBLISHED'
          ? `Video "${video.title}" is now PUBLISHED and visible to Rwandan farmers.`
          : `Video "${video.title}" unpublished and moved to DRAFTS.`
      );
    } catch (err) {
      console.error('Error toggling publish status:', err);
      showToast('error', 'Failed to update video status.');
    }
  };

  // Confirm Delete
  const handleConfirmDelete = async () => {
    if (!deletingVideo) return;
    setIsDeleting(true);
    try {
      await deleteEducationalVideo(deletingVideo, currentUser);
      setVideos((prev) => prev.filter((v) => v.id !== deletingVideo.id));
      showToast('success', `Video "${deletingVideo.title}" permanently deleted.`);
      setDeletingVideo(null);
    } catch (err) {
      console.error('Error deleting video:', err);
      showToast('error', 'Failed to delete video.');
    } finally {
      setIsDeleting(false);
    }
  };

  // Formatting helpers
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs < 10 ? '0' : ''}${secs}s`;
  };

  const formatFileSize = (bytes: number) => {
    if (!bytes) return '0 MB';
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  // Filtered list
  const filterOptions: EducationalVideoFilterOptions = {
    searchQuery,
    category: selectedCategory,
    topic: selectedTopic,
    language: selectedLanguage,
    status: selectedStatus as any,
    targetAudience: selectedAudience,
    district: selectedDistrict
  };

  const filteredVideos = filterEducationalVideos(videos, filterOptions);

  // Statistics
  const totalCount = videos.length;
  const publishedCount = videos.filter((v) => v.status === 'PUBLISHED').length;
  const draftCount = videos.filter((v) => v.status === 'DRAFT').length;
  const totalViews = videos.reduce((acc, v) => acc + (v.viewsCount || 0), 0);

  return (
    <div id="admin-educational-video-manager" className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div
          id="video-manager-toast"
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-3.5 rounded-xl shadow-2xl border text-sm font-medium transition-all transform duration-300 animate-in fade-in slide-in-from-bottom-5 ${
            toastMessage.type === 'success'
              ? 'bg-emerald-950/90 text-emerald-200 border-emerald-500/30'
              : toastMessage.type === 'error'
              ? 'bg-rose-950/90 text-rose-200 border-rose-500/30'
              : 'bg-slate-900/90 text-slate-200 border-slate-700'
          }`}
        >
          {toastMessage.type === 'success' ? (
            <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
          ) : toastMessage.type === 'error' ? (
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
          ) : (
            <Sparkles className="w-5 h-5 text-sky-400 shrink-0" />
          )}
          <span>{toastMessage.text}</span>
          <button
            onClick={() => setToastMessage(null)}
            className="ml-2 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-950 border border-emerald-800/40 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-xs font-semibold uppercase tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{t.videoAgriwiseLearning || 'AGRIWISE Learning Content'}</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight flex items-center gap-3">
              <Video className="w-8 h-8 text-emerald-400" />
              {t.videoManagementCenter || 'Agricultural Educational Video Management'}
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl">
              {t.videoManagementSubtitle ||
                'Upload, configure, publish and manage high-definition instructional video content for Rwandan farmers and cooperatives.'}
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              id="refresh-videos-btn"
              onClick={() => {
                setIsRefreshing(true);
                loadVideos(false);
              }}
              disabled={isRefreshing}
              className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition flex items-center gap-2 text-sm"
              title="Refresh video list"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-emerald-400' : ''}`} />
              <span className="hidden sm:inline">Refresh</span>
            </button>

            <button
              id="open-upload-video-modal-btn"
              onClick={handleOpenUpload}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-sm shadow-lg shadow-emerald-900/40 hover:shadow-emerald-900/60 transition flex items-center gap-2 border border-emerald-400/30"
            >
              <Plus className="w-4 h-4" />
              <span>{t.uploadVideo || 'Upload Video'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">{t.videoTotalCount || 'Total Videos'}</span>
            <FileVideo className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-bold text-white">{totalCount}</div>
          <div className="mt-1 text-xs text-slate-500">In educational catalog</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">{t.videoPublishedCount || 'Published'}</span>
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-bold text-emerald-400">{publishedCount}</div>
          <div className="mt-1 text-xs text-slate-500">Live in Farmer Academy</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">{t.videoDraftCount || 'Drafts'}</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 text-2xl font-bold text-amber-400">{draftCount}</div>
          <div className="mt-1 text-xs text-slate-500">Pending review / publishing</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">{t.videoTotalViews || 'Total Views'}</span>
            <Eye className="w-4 h-4 text-sky-400" />
          </div>
          <div className="mt-2 text-2xl font-bold text-sky-400">{totalViews.toLocaleString()}</div>
          <div className="mt-1 text-xs text-slate-500">Farmer watch interactions</div>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3 shadow-md">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              id="video-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.videoSearchPlaceholder || 'Search videos by title, crop, district, or topic...'}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl border border-slate-700 shrink-0 self-end lg:self-auto">
            <button
              id="view-mode-grid-btn"
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
                viewMode === 'grid' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
              <span className="hidden sm:inline">Grid</span>
            </button>
            <button
              id="view-mode-table-btn"
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
                viewMode === 'table' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
              title="Table View"
            >
              <List className="w-4 h-4" />
              <span className="hidden sm:inline">Table</span>
            </button>
          </div>
        </div>

        {/* Dropdown Filters */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 pt-2 border-t border-slate-800">
          {/* Category Filter */}
          <div>
            <label className="block text-[11px] font-medium text-slate-400 mb-1">{t.videoCategory || 'Category'}</label>
            <select
              id="filter-category-select"
              value={selectedCategory}
              onChange={(e) => {
                setSelectedCategory(e.target.value);
                setSelectedTopic('ALL');
              }}
              className="w-full py-1.5 px-2.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="ALL">{t.videoFilterAllCategories || 'All Categories'}</option>
              {AGRICULTURAL_VIDEO_CATEGORIES.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <label className="block text-[11px] font-medium text-slate-400 mb-1">{t.videoStatus || 'Status'}</label>
            <select
              id="filter-status-select"
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full py-1.5 px-2.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="ALL">{t.videoFilterAllStatuses || 'All Statuses'}</option>
              <option value="PUBLISHED">{t.videoPublished || 'Published'}</option>
              <option value="APPROVED">{t.videoApproved || 'Approved'}</option>
              <option value="PENDING_REVIEW">{t.videoPendingReview || 'Pending Review'}</option>
              <option value="DRAFT">{t.videoDraft || 'Draft'}</option>
              <option value="REJECTED">{t.videoRejected || 'Rejected'}</option>
            </select>
          </div>

          {/* Language Filter */}
          <div>
            <label className="block text-[11px] font-medium text-slate-400 mb-1">{t.videoLanguage || 'Language'}</label>
            <select
              id="filter-language-select"
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="w-full py-1.5 px-2.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="ALL">{t.videoFilterAllLanguages || 'All Languages'}</option>
              <option value="rw">Kinyarwanda (rw)</option>
              <option value="en">English (en)</option>
              <option value="fr">Français (fr)</option>
            </select>
          </div>

          {/* Target Audience Filter */}
          <div>
            <label className="block text-[11px] font-medium text-slate-400 mb-1">{t.videoTargetAudience || 'Audience'}</label>
            <select
              id="filter-audience-select"
              value={selectedAudience}
              onChange={(e) => setSelectedAudience(e.target.value)}
              className="w-full py-1.5 px-2.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="ALL">All Audiences</option>
              {TARGET_AUDIENCE_OPTIONS.map((aud) => (
                <option key={aud} value={aud}>
                  {aud}
                </option>
              ))}
            </select>
          </div>

          {/* District Filter */}
          <div>
            <label className="block text-[11px] font-medium text-slate-400 mb-1">{t.videoDistrict || 'District'}</label>
            <select
              id="filter-district-select"
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              className="w-full py-1.5 px-2.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="ALL">All Regions / Districts</option>
              {RWANDAN_DISTRICTS_OPTIONS.map((dst) => (
                <option key={dst} value={dst}>
                  {dst}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Video Content Grid / Table */}
      {isLoading ? (
        <div className="py-20 flex flex-col items-center justify-center space-y-4 text-center">
          <RefreshCw className="w-10 h-10 text-emerald-400 animate-spin" />
          <p className="text-sm text-slate-400">Loading educational videos from database...</p>
        </div>
      ) : filteredVideos.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-12 text-center space-y-4">
          <FileVideo className="w-12 h-12 text-slate-600 mx-auto" />
          <h3 className="text-lg font-semibold text-slate-300">
            {t.videoNoVideosFound || 'No educational videos match your filter criteria'}
          </h3>
          <p className="text-sm text-slate-400 max-w-md mx-auto">
            Try adjusting your search terms or filters, or upload a new agricultural instructional video.
          </p>
          <button
            onClick={handleOpenUpload}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-medium transition"
          >
            <Plus className="w-4 h-4" />
            <span>Upload First Video</span>
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        /* GRID VIEW */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVideos.map((video) => (
            <div
              key={video.id}
              id={`video-card-${video.id}`}
              className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-lg hover:border-slate-700 transition flex flex-col group"
            >
              {/* Thumbnail Container */}
              <div className="relative aspect-video bg-slate-950 overflow-hidden cursor-pointer" onClick={() => setPreviewingVideo(video)}>
                <img
                  src={video.thumbnailUrl}
                  alt={video.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src =
                      'https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=800&auto=format&fit=crop&q=80';
                  }}
                />
                <div className="absolute inset-0 bg-slate-950/40 group-hover:bg-slate-950/20 transition flex items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-emerald-600/90 group-hover:bg-emerald-500 text-white flex items-center justify-center shadow-xl transform group-hover:scale-110 transition">
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  </div>
                </div>

                {/* Status Badge */}
                <div className="absolute top-3 left-3 flex flex-col gap-1 items-start">
                  <span
                    className={`px-2.5 py-1 rounded-full text-xs font-semibold uppercase tracking-wider backdrop-blur-md shadow-md ${
                      video.status === 'PUBLISHED'
                        ? 'bg-emerald-950/90 text-emerald-300 border border-emerald-500/40'
                        : video.status === 'APPROVED'
                        ? 'bg-teal-950/90 text-teal-300 border border-teal-500/40'
                        : video.status === 'PENDING_REVIEW'
                        ? 'bg-sky-950/90 text-sky-300 border border-sky-500/40'
                        : video.status === 'REJECTED'
                        ? 'bg-rose-950/90 text-rose-300 border border-rose-500/40'
                        : 'bg-amber-950/90 text-amber-300 border border-amber-500/40'
                    }`}
                  >
                    {video.status === 'PUBLISHED'
                      ? t.videoPublished || 'Published'
                      : video.status === 'APPROVED'
                      ? t.videoApproved || 'Approved'
                      : video.status === 'PENDING_REVIEW'
                      ? t.videoPendingReview || 'Pending Review'
                      : video.status === 'REJECTED'
                      ? t.videoRejected || 'Rejected'
                      : t.videoDraft || 'Draft'}
                  </span>

                  {(video.certificationStatus === 'RAB_CERTIFIED' || video.certificationStatus === 'MINAGRI_CERTIFIED') &&
                    (video.status === 'APPROVED' || video.status === 'PUBLISHED') && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-900/90 text-emerald-200 border border-emerald-400/50 shadow flex items-center gap-1 backdrop-blur-md">
                        <Award className="w-3 h-3" />
                        {video.certificationStatus === 'RAB_CERTIFIED'
                          ? t.videoCertifiedRab || 'RAB Certified'
                          : t.videoCertifiedMinagri || 'MINAGRI Certified'}
                      </span>
                    )}
                </div>

                {/* Duration Badge */}
                <div className="absolute bottom-3 right-3 px-2 py-1 rounded-lg bg-black/80 backdrop-blur-md text-white text-xs font-medium flex items-center gap-1.5">
                  <Clock className="w-3 h-3 text-slate-400" />
                  <span>{formatDuration(video.duration)}</span>
                </div>

                {/* Language Badge */}
                <div className="absolute top-3 right-3 px-2 py-0.5 rounded-md bg-slate-900/80 backdrop-blur-md text-slate-200 text-[11px] font-bold uppercase border border-slate-700">
                  {video.language}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-xs font-medium text-emerald-400">
                    <Layers className="w-3.5 h-3.5" />
                    <span>{video.category}</span>
                    <span className="text-slate-600">•</span>
                    <span className="text-slate-400 truncate">{video.topic}</span>
                  </div>

                  <h3 className="font-semibold text-white text-base line-clamp-2 leading-snug hover:text-emerald-300 transition cursor-pointer" onClick={() => setPreviewingVideo(video)}>
                    {video.title}
                  </h3>

                  <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                    {video.description}
                  </p>
                </div>

                {/* Metadata Tags */}
                <div className="space-y-3 pt-3 border-t border-slate-800/80">
                  <div className="flex flex-wrap items-center gap-2 text-[11px]">
                    <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700/60 flex items-center gap-1">
                      <Users className="w-3 h-3 text-slate-400" />
                      <span className="truncate max-w-[130px]">{video.targetAudience}</span>
                    </span>

                    {video.district && (
                      <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700/60 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        <span className="truncate max-w-[110px]">{video.district.split(' ')[0]}</span>
                      </span>
                    )}

                    {video.crop && (
                      <span className="px-2 py-0.5 rounded-md bg-emerald-950/60 text-emerald-300 border border-emerald-800/40">
                        {video.crop.split(' ')[0]}
                      </span>
                    )}

                    {video.livestock && (
                      <span className="px-2 py-0.5 rounded-md bg-blue-950/60 text-blue-300 border border-blue-800/40">
                        {video.livestock.split(' ')[0]}
                      </span>
                    )}
                  </div>

                  {/* Views & Uploader Info */}
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <Eye className="w-3.5 h-3.5 text-slate-500" />
                      <span>{video.viewsCount || 0} views</span>
                    </span>

                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-slate-500" />
                      <span>{new Date(video.uploadedAt).toLocaleDateString()}</span>
                    </span>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 pt-2">
                    <button
                      id={`preview-video-btn-${video.id}`}
                      onClick={() => setPreviewingVideo(video)}
                      className="flex-1 py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition flex items-center justify-center gap-1.5 border border-slate-700"
                    >
                      <Play className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Preview</span>
                    </button>

                    <button
                      id={`publish-toggle-btn-${video.id}`}
                      onClick={() => handleTogglePublish(video)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center justify-center gap-1 border ${
                        video.status === 'PUBLISHED'
                          ? 'bg-amber-950/50 hover:bg-amber-900/70 text-amber-300 border-amber-800/50'
                          : 'bg-emerald-950/50 hover:bg-emerald-900/70 text-emerald-300 border-emerald-800/50'
                      }`}
                      title={video.status === 'PUBLISHED' ? 'Unpublish to draft' : 'Publish to farmer learning center'}
                    >
                      {video.status === 'PUBLISHED' ? t.videoUnpublish || 'Unpublish' : t.videoPublish || 'Publish'}
                    </button>

                    <button
                      id={`edit-video-btn-${video.id}`}
                      onClick={() => handleOpenEdit(video)}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition"
                      title="Edit video metadata"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      id={`delete-video-btn-${video.id}`}
                      onClick={() => setDeletingVideo(video)}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/50 text-slate-400 hover:text-rose-300 border border-slate-700 hover:border-rose-700/50 transition"
                      title="Delete video"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* TABLE VIEW */
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-3.5 px-4">Video</th>
                  <th className="py-3.5 px-4">Category & Topic</th>
                  <th className="py-3.5 px-4">Audience / Region</th>
                  <th className="py-3.5 px-4">Language</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4">Duration & Size</th>
                  <th className="py-3.5 px-4">Views</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredVideos.map((video) => (
                  <tr key={video.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-16 h-10 bg-slate-950 rounded-lg overflow-hidden shrink-0 relative cursor-pointer group"
                          onClick={() => setPreviewingVideo(video)}
                        >
                          <img
                            src={video.thumbnailUrl}
                            alt={video.title}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src =
                                'https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=800&auto=format&fit=crop&q=80';
                            }}
                          />
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                            <Play className="w-4 h-4 text-white fill-current" />
                          </div>
                        </div>
                        <div className="max-w-xs">
                          <p
                            className="font-medium text-white line-clamp-1 hover:text-emerald-300 cursor-pointer"
                            onClick={() => setPreviewingVideo(video)}
                          >
                            {video.title}
                          </p>
                          <p className="text-[11px] text-slate-500">
                            Uploaded by {video.uploadedBy?.name || 'Admin'}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-emerald-400">{video.category}</div>
                      <div className="text-[11px] text-slate-400 truncate max-w-[160px]">{video.topic}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-slate-300">{video.targetAudience.split(' ')[0]}</div>
                      <div className="text-[11px] text-slate-500">{video.district || 'All Rwanda'}</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded uppercase font-bold bg-slate-800 text-slate-300 border border-slate-700 text-[10px]">
                        {video.language}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex flex-col gap-1 items-start">
                        <span
                          className={`inline-flex px-2 py-0.5 rounded-full text-[11px] font-semibold uppercase ${
                            video.status === 'PUBLISHED'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/50'
                              : video.status === 'APPROVED'
                              ? 'bg-teal-950 text-teal-300 border border-teal-700/50'
                              : video.status === 'PENDING_REVIEW'
                              ? 'bg-sky-950 text-sky-300 border border-sky-700/50'
                              : video.status === 'REJECTED'
                              ? 'bg-rose-950 text-rose-300 border border-rose-700/50'
                              : 'bg-amber-950 text-amber-300 border border-amber-700/50'
                          }`}
                        >
                          {video.status}
                        </span>
                        {(video.certificationStatus === 'RAB_CERTIFIED' || video.certificationStatus === 'MINAGRI_CERTIFIED') &&
                          (video.status === 'APPROVED' || video.status === 'PUBLISHED') && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase bg-emerald-950 text-emerald-300 border border-emerald-600/40 flex items-center gap-1">
                              <Award className="w-2.5 h-2.5" />
                              {video.certificationStatus === 'RAB_CERTIFIED' ? 'RAB' : 'MINAGRI'}
                            </span>
                          )}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-400">
                      <div>{formatDuration(video.duration)}</div>
                      <div className="text-[11px] text-slate-500">{formatFileSize(video.fileSize)}</div>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-300">
                      {video.viewsCount || 0}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          onClick={() => setPreviewingVideo(video)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                          title="Preview video"
                        >
                          <Play className="w-3.5 h-3.5 text-emerald-400" />
                        </button>
                        <button
                          onClick={() => handleTogglePublish(video)}
                          className={`p-1.5 rounded-lg border ${
                            video.status === 'PUBLISHED'
                              ? 'bg-amber-950/40 text-amber-300 border-amber-800/40 hover:bg-amber-900/60'
                              : 'bg-emerald-950/40 text-emerald-300 border-emerald-800/40 hover:bg-emerald-900/60'
                          }`}
                          title={video.status === 'PUBLISHED' ? 'Unpublish' : 'Publish'}
                        >
                          {video.status === 'PUBLISHED' ? <Clock className="w-3.5 h-3.5" /> : <CheckCircle className="w-3.5 h-3.5" />}
                        </button>
                        <button
                          onClick={() => handleOpenEdit(video)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeletingVideo(video)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/50 text-slate-400 hover:text-rose-300"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =================================================== */}
      {/* UPLOAD / EDIT VIDEO MODAL                           */}
      {/* =================================================== */}
      {isUploadModalOpen && (
        <div id="video-upload-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/50">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  {editingVideo ? <Edit2 className="w-5 h-5" /> : <Upload className="w-5 h-5" />}
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">
                    {editingVideo
                      ? t.videoEdit || 'Edit Educational Video'
                      : t.videoUploadNewTitle || 'Upload Agricultural Educational Video'}
                  </h2>
                  <p className="text-xs text-slate-400">
                    {editingVideo ? 'Update metadata or replace assets' : 'Configure video details for farmer training library'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  if (!isUploading) {
                    setIsUploadModalOpen(false);
                    setEditingVideo(null);
                  }
                }}
                disabled={isUploading}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
              {/* Upload Progress Bar if uploading */}
              {isUploading && (
                <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-800/60 space-y-3">
                  <div className="flex items-center justify-between text-xs font-semibold text-emerald-300">
                    <span className="flex items-center gap-2">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      {uploadStage}
                    </span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-emerald-500 to-emerald-400 h-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Section 1: Video File & Thumbnail Picker */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Video File Picker */}
                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    {t.videoUploadFileSelect || 'Video File (MP4, WebM, MOV)'} <span className="text-rose-400">*</span>
                  </label>

                  <input
                    ref={videoFileInputRef}
                    type="file"
                    accept="video/mp4,video/webm,video/ogg,video/quicktime"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        handleVideoFileChange(e.target.files[0]);
                      }
                    }}
                  />

                  <div
                    onClick={() => !isUploading && videoFileInputRef.current?.click()}
                    className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition flex flex-col items-center justify-center min-h-[140px] ${
                      formErrors.video
                        ? 'border-rose-500/60 bg-rose-950/20'
                        : uploadFile || uploadVideoPreviewUrl
                        ? 'border-emerald-500/50 bg-emerald-950/20'
                        : 'border-slate-700 bg-slate-950/40 hover:border-slate-600 hover:bg-slate-800/40'
                    }`}
                  >
                    {uploadFile || uploadVideoPreviewUrl ? (
                      <div className="space-y-2 text-center">
                        <FileVideo className="w-8 h-8 text-emerald-400 mx-auto" />
                        <p className="text-xs font-medium text-white truncate max-w-[200px]">
                          {uploadFile ? uploadFile.name : 'Existing Video Attached'}
                        </p>
                        <div className="flex items-center justify-center gap-2 text-[10px] text-slate-400">
                          <span>{formatDuration(videoDurationSeconds)}</span>
                          <span>•</span>
                          <span>{formatFileSize(videoFileSizeBytes)}</span>
                        </div>
                        <span className="text-[11px] text-emerald-400 hover:underline inline-block">
                          Click to replace video file
                        </span>
                      </div>
                    ) : (
                      <div className="space-y-1.5">
                        <Upload className="w-7 h-7 text-slate-400 mx-auto" />
                        <p className="text-xs font-medium text-slate-300">Click or Drag & Drop Video</p>
                        <p className="text-[10px] text-slate-500">MP4, WebM up to 100MB</p>
                      </div>
                    )}
                  </div>
                  {formErrors.video && <p className="text-xs text-rose-400 mt-1">{formErrors.video}</p>}
                </div>

                {/* Thumbnail File Picker */}
                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    {t.videoThumbnail || 'Video Thumbnail'} <span className="text-rose-400">*</span>
                  </label>

                  <input
                    ref={thumbnailFileInputRef}
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        handleThumbnailFileChange(e.target.files[0]);
                      }
                    }}
                  />

                  <div
                    onClick={() => !isUploading && thumbnailFileInputRef.current?.click()}
                    className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition flex flex-col items-center justify-center min-h-[140px] relative overflow-hidden ${
                      formErrors.thumbnail
                        ? 'border-rose-500/60 bg-rose-950/20'
                        : uploadThumbnailPreviewUrl
                        ? 'border-emerald-500/50 bg-emerald-950/20'
                        : 'border-slate-700 bg-slate-950/40 hover:border-slate-600 hover:bg-slate-800/40'
                    }`}
                  >
                    {uploadThumbnailPreviewUrl ? (
                      <div className="space-y-1.5 text-center">
                        <img
                          src={uploadThumbnailPreviewUrl}
                          alt="Thumbnail preview"
                          className="w-24 h-14 object-cover rounded-lg mx-auto border border-slate-700 shadow-md"
                        />
                        <p className="text-xs font-medium text-white truncate max-w-[200px]">
                          {uploadThumbnail ? uploadThumbnail.name : 'Custom Thumbnail'}
                        </p>
                        <span className="text-[11px] text-emerald-400 hover:underline inline-block">
                          Click to replace image
                        </span>
                      </div>
                    ) : (
                      <div className="space-y-1.5">
                        <ImageIcon className="w-7 h-7 text-slate-400 mx-auto" />
                        <p className="text-xs font-medium text-slate-300">Upload Custom Thumbnail</p>
                        <p className="text-[10px] text-slate-500">JPG, PNG, WEBP up to 5MB</p>
                      </div>
                    )}
                  </div>
                  {formErrors.thumbnail && <p className="text-xs text-rose-400 mt-1">{formErrors.thumbnail}</p>}
                </div>
              </div>

              {/* Section 2: Metadata Fields */}
              <div className="space-y-4">
                {/* Title */}
                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    {t.videoTitle || 'Video Title'} <span className="text-rose-400">*</span>
                  </label>
                  <input
                    id="video-form-title-input"
                    type="text"
                    value={formData.title}
                    onChange={(e) => {
                      setFormData((prev) => ({ ...prev, title: e.target.value }));
                      if (formErrors.title) {
                        setFormErrors((prev) => {
                          const copy = { ...prev };
                          delete copy.title;
                          return copy;
                        });
                      }
                    }}
                    placeholder="e.g. How to Control Fall Armyworm in Maize (Nkahe Kurwanya Nkongwa)"
                    className={`w-full px-3.5 py-2 bg-slate-950 border rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                      formErrors.title ? 'border-rose-500' : 'border-slate-700'
                    }`}
                  />
                  {formErrors.title && <p className="text-xs text-rose-400 mt-1">{formErrors.title}</p>}
                </div>

                {/* Description */}
                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    {t.videoDescription || 'Description'} <span className="text-rose-400">*</span>
                  </label>
                  <textarea
                    id="video-form-desc-input"
                    rows={3}
                    value={formData.description}
                    onChange={(e) => {
                      setFormData((prev) => ({ ...prev, description: e.target.value }));
                      if (formErrors.description) {
                        setFormErrors((prev) => {
                          const copy = { ...prev };
                          delete copy.description;
                          return copy;
                        });
                      }
                    }}
                    placeholder="Provide detailed instructions, seasonal timings, and RAB recommended practices covered in this video..."
                    className={`w-full px-3.5 py-2 bg-slate-950 border rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none ${
                      formErrors.description ? 'border-rose-500' : 'border-slate-700'
                    }`}
                  />
                  {formErrors.description && <p className="text-xs text-rose-400 mt-1">{formErrors.description}</p>}
                </div>

                {/* Category & Topic */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-200 mb-1">
                      {t.videoCategory || 'Category'} <span className="text-rose-400">*</span>
                    </label>
                    <select
                      id="video-form-category-select"
                      value={formData.category}
                      onChange={(e) => handleCategoryChange(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      {AGRICULTURAL_VIDEO_CATEGORIES.map((c) => (
                        <option key={c.id} value={c.name}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-200 mb-1">
                      {t.videoTopic || 'Topic / Subcategory'} <span className="text-rose-400">*</span>
                    </label>
                    <select
                      id="video-form-topic-select"
                      value={formData.topic}
                      onChange={(e) => setFormData((prev) => ({ ...prev, topic: e.target.value }))}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      {(
                        AGRICULTURAL_VIDEO_CATEGORIES.find((c) => c.name === formData.category)?.topics || [
                          formData.topic
                        ]
                      ).map((top) => (
                        <option key={top} value={top}>
                          {top}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Language, Target Audience, District */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-200 mb-1">
                      {t.videoLanguage || 'Content Language'} <span className="text-rose-400">*</span>
                    </label>
                    <select
                      id="video-form-language-select"
                      value={formData.language}
                      onChange={(e) => setFormData((prev) => ({ ...prev, language: e.target.value as any }))}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="rw">Kinyarwanda (rw)</option>
                      <option value="en">English (en)</option>
                      <option value="fr">Français (fr)</option>
                      <option value="all">Multilingual / All</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-200 mb-1">
                      {t.videoTargetAudience || 'Target Audience'} <span className="text-rose-400">*</span>
                    </label>
                    <select
                      id="video-form-audience-select"
                      value={formData.targetAudience}
                      onChange={(e) => setFormData((prev) => ({ ...prev, targetAudience: e.target.value }))}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      {TARGET_AUDIENCE_OPTIONS.map((aud) => (
                        <option key={aud} value={aud}>
                          {aud}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-200 mb-1">
                      {t.videoDistrict || 'Applicable District'}
                    </label>
                    <select
                      id="video-form-district-select"
                      value={formData.district}
                      onChange={(e) => setFormData((prev) => ({ ...prev, district: e.target.value }))}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      {RWANDAN_DISTRICTS_OPTIONS.map((dst) => (
                        <option key={dst} value={dst}>
                          {dst}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Optional Crop & Livestock Selectors */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-200 mb-1">
                      {t.videoCrop || 'Target Crop (Optional)'}
                    </label>
                    <select
                      id="video-form-crop-select"
                      value={formData.crop}
                      onChange={(e) => setFormData((prev) => ({ ...prev, crop: e.target.value }))}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="">-- None / General Crop --</option>
                      {RWANDAN_CROPS_OPTIONS.map((crp) => (
                        <option key={crp} value={crp}>
                          {crp}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-200 mb-1">
                      {t.videoLivestock || 'Target Livestock (Optional)'}
                    </label>
                    <select
                      id="video-form-livestock-select"
                      value={formData.livestock}
                      onChange={(e) => setFormData((prev) => ({ ...prev, livestock: e.target.value }))}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="">-- None / General Livestock --</option>
                      {RWANDAN_LIVESTOCK_OPTIONS.map((lv) => (
                        <option key={lv} value={lv}>
                          {lv}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Review & Certification Status Controls */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-xl bg-slate-950/80 border border-slate-800">
                  <div>
                    <label className="block text-xs font-semibold text-slate-200 mb-1">
                      {t.videoReviewStatus || 'Workflow Review Status'}
                    </label>
                    <select
                      id="video-form-status-select"
                      value={formData.status}
                      onChange={(e) => setFormData((prev) => ({ ...prev, status: e.target.value as EducationalVideoStatus }))}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="DRAFT">{t.videoDraft || 'Draft (Under Preparation)'}</option>
                      <option value="PENDING_REVIEW">{t.videoPendingReview || 'Pending Review (Awaiting Validation)'}</option>
                      <option value="APPROVED">{t.videoApproved || 'Approved (Ready to Publish)'}</option>
                      <option value="PUBLISHED">{t.videoPublished || 'Published (Visible to Farmers)'}</option>
                      <option value="REJECTED">{t.videoRejected || 'Rejected (Needs Revision)'}</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-200 mb-1">
                      {t.videoCertificationStatus || 'Official Certification State'}
                    </label>
                    <select
                      id="video-form-cert-select"
                      value={formData.certificationStatus || 'NONE'}
                      onChange={(e) => setFormData((prev) => ({ ...prev, certificationStatus: e.target.value as VideoCertificationStatus }))}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="NONE">{t.videoCertNone || 'Standard AGRIWISE Educational Content'}</option>
                      <option value="RAB_CERTIFIED">{t.videoCertRab || 'Official RAB Certified (Rwanda Agriculture Board)'}</option>
                      <option value="MINAGRI_CERTIFIED">{t.videoCertMinagri || 'Official MINAGRI Certified (Ministry of Agriculture)'}</option>
                    </select>
                    <p className="text-[10px] text-slate-400 mt-1">
                      {t.videoCertNotice || 'Only certified content will display official ministerial badges in the Farmer Learning Center.'}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer Actions */}
            <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 bg-slate-950/50">
              <button
                type="button"
                onClick={() => {
                  setIsUploadModalOpen(false);
                  setEditingVideo(null);
                }}
                disabled={isUploading}
                className="px-4 py-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 text-xs font-medium transition"
              >
                {t.photoCancel || 'Cancel'}
              </button>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  id="save-draft-btn"
                  onClick={() => handleSaveVideo('DRAFT')}
                  disabled={isUploading}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-600/40 text-xs font-semibold transition"
                >
                  {t.videoSaveAsDraft || 'Save as Draft'}
                </button>

                <button
                  type="button"
                  id="save-status-btn"
                  onClick={() => handleSaveVideo(formData.status)}
                  disabled={isUploading}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition"
                >
                  {editingVideo ? 'Update Video' : `Save as ${formData.status}`}
                </button>

                <button
                  type="button"
                  id="save-published-btn"
                  onClick={() => handleSaveVideo('PUBLISHED')}
                  disabled={isUploading}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-900/30 transition flex items-center gap-1.5"
                >
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>{t.videoSavePublished || 'Publish Video'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =================================================== */}
      {/* VIDEO PREVIEW MODAL                                 */}
      {/* =================================================== */}
      {previewingVideo && (
        <div id="video-preview-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-3.5 border-b border-slate-800 bg-slate-950">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                <h3 className="text-sm font-bold text-white truncate max-w-md">
                  {previewingVideo.title}
                </h3>
              </div>
              <button
                onClick={() => setPreviewingVideo(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Video Player */}
            <div className="aspect-video bg-black relative">
              <video
                src={previewingVideo.videoUrl}
                poster={previewingVideo.thumbnailUrl}
                controls
                autoPlay
                playsInline
                className="w-full h-full object-contain"
              >
                Your browser does not support the video tag.
              </video>
            </div>

            {/* Video Details Drawer */}
            <div className="p-6 space-y-4 max-h-60 overflow-y-auto bg-slate-900">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-950 text-emerald-300 border border-emerald-700/50">
                    {previewingVideo.category}
                  </span>
                  <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                    {previewingVideo.topic}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[11px] font-bold uppercase bg-slate-800 text-slate-300 border border-slate-700">
                    {previewingVideo.language}
                  </span>
                </div>

                <div className="flex items-center gap-3 text-xs text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{formatDuration(previewingVideo.duration)}</span>
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Eye className="w-3.5 h-3.5" />
                    <span>{previewingVideo.viewsCount || 0} views</span>
                  </span>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">{previewingVideo.description}</p>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-800 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Target Audience</span>
                  <span className="text-slate-200 font-medium">{previewingVideo.targetAudience}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Region / District</span>
                  <span className="text-slate-200 font-medium">{previewingVideo.district || 'All Rwanda'}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Crop / Livestock</span>
                  <span className="text-slate-200 font-medium">{previewingVideo.crop || previewingVideo.livestock || 'General'}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Uploaded By</span>
                  <span className="text-slate-200 font-medium">{previewingVideo.uploadedBy?.name || 'Administrator'}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =================================================== */}
      {/* DELETE CONFIRMATION MODAL                           */}
      {/* =================================================== */}
      {deletingVideo && (
        <div id="video-delete-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-rose-950/60 border border-rose-800/60 flex items-center justify-center text-rose-400 mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-base font-bold text-white">
                {t.videoDeleteConfirmTitle || 'Confirm Video Deletion'}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {t.videoDeleteConfirmMsg ||
                  'Are you sure you want to permanently delete this educational video? The Firestore metadata and Firebase Storage video/thumbnail assets will be removed.'}
              </p>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs font-semibold text-slate-200 truncate">
                "{deletingVideo.title}"
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeletingVideo(null)}
                disabled={isDeleting}
                className="px-4 py-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 text-xs font-medium transition"
              >
                {t.photoCancel || 'Cancel'}
              </button>

              <button
                type="button"
                id="confirm-delete-video-btn"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold shadow-lg shadow-rose-900/30 transition flex items-center gap-1.5"
              >
                {isDeleting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                <span>{isDeleting ? 'Deleting...' : t.videoDelete || 'Delete Permanently'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
