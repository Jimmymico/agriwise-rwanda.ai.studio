import React, { useState, useEffect, useRef } from 'react';
import { User, Language, RegisteredFarm, FarmActivity, SpecialistAgentType, VoiceMessage, FarmerMemoryBank } from '../../types';
import { translations } from '../../data/translations';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  Bot,
  RotateCcw,
  CheckCircle2,
  Loader2,
  Leaf,
  Bug,
  DollarSign,
  TrendingUp,
  CloudSun,
  ShieldAlert,
  Wifi,
  WifiOff,
  Image as ImageIcon,
  Upload,
  Plus,
  Trash2,
  PhoneCall,
  Send,
  Zap,
  Bookmark,
  ChevronRight,
  Layers,
  HelpCircle,
  Play,
  Square,
  Globe
} from 'lucide-react';

interface VoiceFarmAssistantProps {
  currentUser: User;
  language: Language;
  registeredFarms?: RegisteredFarm[];
  onAddFarmActivity?: (activity: Omit<FarmActivity, 'id'>) => void;
  onMakeMoMoPayment?: (amount: number, description: string) => void;
}

export const VoiceFarmAssistant: React.FC<VoiceFarmAssistantProps> = ({
  currentUser,
  language,
  registeredFarms = [],
  onAddFarmActivity,
  onMakeMoMoPayment,
}) => {
  const t = translations[language];

  // Language & Locale Selection
  const [activeLang, setActiveLang] = useState<Language>(language);
  const [voiceLocale, setVoiceLocale] = useState<string>(
    language === 'rw' ? 'rw-RW' : language === 'fr' ? 'fr-FR' : 'en-US'
  );

  // Specialist Agent Persona State
  const [selectedAgent, setSelectedAgent] = useState<SpecialistAgentType>('agronomist');
  const [autoRouteEnabled, setAutoRouteEnabled] = useState(true);

  // Voice Recording & Web Speech States
  const [isListening, setIsListening] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [isSpeakingMessageId, setIsSpeakingMessageId] = useState<string | null>(null);
  const [speechPitch, setSpeechPitch] = useState(1.0);
  const [speechRate, setSpeechRate] = useState(0.95);

  // Input States
  const [transcript, setTranscript] = useState('');
  const [typedMessage, setTypedMessage] = useState('');
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [lowBandwidthMode, setLowBandwidthMode] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  // Conversation & Memory Bank State
  const [messages, setMessages] = useState<VoiceMessage[]>([
    {
      id: 'welcome-msg',
      sender: 'assistant',
      text:
        activeLang === 'rw'
          ? "Muraho! Ndi inzozi yawe ya AI (" + selectedAgent.toUpperCase() + "). Kanda ku mbouto y'ijwi witegure kumbaza ikibazo icyo ari cyo cyose mu Kinyarwanda."
          : activeLang === 'fr'
          ? "Bonjour! Je suis votre assistant agricole IA. Appuyez sur le micro et posez votre question."
          : "Hello! I am your AGRIWISE Voice AI Assistant. Tap the microphone button to ask any farming question out loud.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      specialistAgent: 'agronomist',
      confidenceScore: 98,
      actionableRecommendation: activeLang === 'rw' ? "Kanda mbouto y'ijwi utangire kuvuga" : "Tap microphone to begin speaking",
    },
  ]);

  const [farmerMemory, setFarmerMemory] = useState<FarmerMemoryBank>({
    farmerName: currentUser.name || 'John Ndayisaba',
    location: currentUser.district || 'Musanze',
    farmSizeHa: 1.5,
    primaryCrops: currentUser.primaryCrops || ['Maize', 'Irish Potatoes'],
    livestockCount: 3,
    memories: [
      { id: 'mem-1', category: 'crop', content: 'Planted Kinigi Potato seed on Field A on March 12', dateAdded: '2026-03-12' },
      { id: 'mem-2', category: 'disease', content: 'Scanned Fall Armyworm infestation on Maize', dateAdded: '2026-07-28' },
    ],
  });

  const [newMemoryInput, setNewMemoryInput] = useState('');
  const [offlineQueue, setOfflineQueue] = useState<VoiceMessage[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const recordingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  // Sync Online status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Scroll chat thread to bottom
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isProcessing]);

  // Audio recording timer
  useEffect(() => {
    if (isListening) {
      setRecordingSeconds(0);
      recordingIntervalRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (recordingIntervalRef.current) clearInterval(recordingIntervalRef.current);
    }
    return () => {
      if (recordingIntervalRef.current) clearInterval(recordingIntervalRef.current);
    };
  }, [isListening]);

  // Handle Speech Recognition toggle
  const handleToggleListen = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }

    const windowObj = window as any;
    const SpeechRecognition = windowObj.SpeechRecognition || windowObj.webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.lang = voiceLocale;
      recognition.interimResults = true;
      recognition.continuous = false;

      recognition.onstart = () => {
        setIsListening(true);
        setTranscript('');
      };

      recognition.onresult = (e: any) => {
        const text = Array.from(e.results)
          .map((res: any) => res[0].transcript)
          .join('');
        setTranscript(text);
      };

      recognition.onerror = (err: any) => {
        console.warn('Speech recognition error:', err);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } else {
      // Browser fallback simulation for Web Speech
      setIsListening(true);
      setTimeout(() => {
        const simPrompts: Record<string, string> = {
          rw: 'Nshaka kumenya igiciro cy\'ibigori i Musanze no gushyira ifumbire ku binyabwoya.',
          fr: 'Je veux connaître le prix du maïs à Musanze et le dosage d\'engrais NPK.',
          en: 'What is the current market price of maize in Musanze and when should I spray fungicide?',
        };
        setTranscript(simPrompts[activeLang] || simPrompts.en);
        setIsListening(false);
      }, 3500);
    }
  };

  // Image Upload Handler
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setAttachedImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  // Agent Auto-Routing logic
  const detectSpecialistAgent = (text: string): SpecialistAgentType => {
    const lower = text.toLowerCase();
    if (lower.includes('inka') || lower.includes('cow') || lower.includes('vache') || lower.includes('amatungo') || lower.includes('mastitis') || lower.includes('amata')) {
      return 'veterinarian';
    }
    if (lower.includes('igiciro') || lower.includes('price') || lower.includes('prix') || lower.includes('kigali') || lower.includes('isoko') || lower.includes('market')) {
      return 'market';
    }
    if (lower.includes('imvura') || lower.includes('rain') || lower.includes('pluie') || lower.includes('ikirere') || lower.includes('weather')) {
      return 'weather';
    }
    if (lower.includes('inyungu') || lower.includes('profit') || lower.includes('inguzanyo') || lower.includes('loan') || lower.includes('faranga') || lower.includes('money')) {
      return 'business';
    }
    return 'agronomist';
  };

  // Submit Query to AI Engine
  const handleSendQuery = async (queryTextOverride?: string) => {
    const textToSend = queryTextOverride || transcript || typedMessage;
    if (!textToSend.trim() && !attachedImage) return;

    // Detect target agent if auto-routing enabled
    const agentToUse = autoRouteEnabled ? detectSpecialistAgent(textToSend) : selectedAgent;
    if (autoRouteEnabled) setSelectedAgent(agentToUse);

    const userMsgId = `usr-${Date.now()}`;
    const userMessage: VoiceMessage = {
      id: userMsgId,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      multimodalImage: attachedImage || undefined,
      status: isOnline ? 'delivered' : 'queued',
    };

    setMessages((prev) => [...prev, userMessage]);
    setTranscript('');
    setTypedMessage('');
    const currentImg = attachedImage;
    setAttachedImage(null);

    // If offline, queue message locally
    if (!isOnline) {
      setOfflineQueue((prev) => [...prev, userMessage]);
      const offlineReply: VoiceMessage = {
        id: `ast-${Date.now()}`,
        sender: 'assistant',
        text:
          activeLang === 'rw'
            ? 'Icyitonderwa: Nta internet ufite. Ubutumwa bwawe bwashyizwe muri queue. Bwiterwa niba interineti igarutse.'
            : 'Offline Notice: Your voice message has been queued locally. AI response will auto-sync when back online.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        specialistAgent: agentToUse,
        confidenceScore: 85,
        safetyDisclaimer: 'Offline response stored locally',
      };
      setMessages((prev) => [...prev, offlineReply]);
      return;
    }

    setIsProcessing(true);

    try {
      const res = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSend,
          language: activeLang,
          specialistAgent: agentToUse,
          imageBase64: currentImg,
          networkMode: lowBandwidthMode ? 'low_bandwidth' : 'normal',
          context: {
            name: farmerMemory.farmerName,
            district: farmerMemory.location,
            crops: farmerMemory.primaryCrops.join(', '),
            livestock: `Dairy Cows (${farmerMemory.livestockCount})`,
            farmSize: `${farmerMemory.farmSizeHa} Hectares`,
            memory: farmerMemory.memories.map((m) => m.content).join('; '),
          },
        }),
      });

      const data = await res.json();

      const aiMsgId = `ast-${Date.now()}`;
      const aiReply: VoiceMessage = {
        id: aiMsgId,
        sender: 'assistant',
        text: data.text || 'Icyifuzo cyakiriwe neza.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        specialistAgent: agentToUse,
        confidenceScore: data.confidenceScore || 92,
        safetyDisclaimer: data.safetyDisclaimer || undefined,
        actionableRecommendation: data.actionableRecommendation || undefined,
      };

      setMessages((prev) => [...prev, aiReply]);

      // Auto TTS read aloud audio summary
      handleSpeakMessage(aiReply.id, data.audioScript || data.text);
    } catch (err) {
      console.error('AI Voice call failed:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  // Text to Speech Synthesizer
  const handleSpeakMessage = (msgId: string, textToRead: string) => {
    if (!('speechSynthesis' in window)) {
      alert('Text-to-Speech audio is not supported in this browser.');
      return;
    }

    if (isSpeakingMessageId === msgId) {
      window.speechSynthesis.cancel();
      setIsSpeakingMessageId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(textToRead.slice(0, 300));
    utterance.lang = voiceLocale;
    utterance.pitch = speechPitch;
    utterance.rate = speechRate;

    utterance.onstart = () => setIsSpeakingMessageId(msgId);
    utterance.onend = () => setIsSpeakingMessageId(null);
    utterance.onerror = () => setIsSpeakingMessageId(null);

    window.speechSynthesis.speak(utterance);
  };

  // Add custom Farmer Memory note
  const handleAddMemory = () => {
    if (!newMemoryInput.trim()) return;
    const item = {
      id: `mem-${Date.now()}`,
      category: 'task' as const,
      content: newMemoryInput,
      dateAdded: new Date().toISOString().split('T')[0],
    };
    setFarmerMemory((prev) => ({
      ...prev,
      memories: [item, ...prev.memories],
    }));
    setNewMemoryInput('');
  };

  const handleRemoveMemory = (id: string) => {
    setFarmerMemory((prev) => ({
      ...prev,
      memories: prev.memories.filter((m) => m.id !== id),
    }));
  };

  // Preset Sample Voice Prompts
  const samplePrompts = [
    { text: 'Ibigori byanjye bifite amababi y\'umuhondo, nkorere iki?', agent: 'agronomist' as const },
    { text: 'Inka yanjye ifite amabehere abyimbye (Mastitis), mwampimbura?', agent: 'veterinarian' as const },
    { text: 'Ni ubuhe bwoko bw\'imbuto bwa RAB bwiza bwo guhinga mu Musanze?', agent: 'agronomist' as const },
    { text: 'Ni igiki igiciro cy\'ibirayi i Musanze no mu mugi wa Kigali?', agent: 'market' as const },
    { text: 'Ese imvura izagwa muri iki cyumweru mu Karere ka Musanze?', agent: 'weather' as const },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      
      {/* Top Banner Header */}
      <div className="relative overflow-hidden bg-gradient-to-r from-slate-950 via-teal-950 to-slate-900 border border-teal-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl text-white">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 bg-teal-500/20 text-teal-300 border border-teal-500/30 px-3.5 py-1 rounded-full text-xs font-bold tracking-wide">
              <Mic className="w-4 h-4 text-teal-400 animate-pulse" />
              <span>STEP 26 — Multilingual AI Voice Assistant</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">{t.navVoiceAssistant}</h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Speak naturally in Kinyarwanda, English, or French. Get specialized agricultural, veterinary, market, and climate guidance backed by RAB guidelines.
            </p>
          </div>

          {/* Network & Low Bandwidth Status Pill */}
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <div
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-xl border text-xs font-bold ${
                isOnline
                  ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300'
                  : 'bg-rose-950/80 border-rose-500/40 text-rose-300 animate-pulse'
              }`}
            >
              {isOnline ? <Wifi className="w-3.5 h-3.5 text-emerald-400" /> : <WifiOff className="w-3.5 h-3.5 text-rose-400" />}
              <span>{isOnline ? 'Online (Gemini Cloud)' : `Offline (${offlineQueue.length} Queued)`}</span>
            </div>

            <button
              onClick={() => setLowBandwidthMode(!lowBandwidthMode)}
              className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center space-x-1.5 transition-colors ${
                lowBandwidthMode
                  ? 'bg-amber-500 text-slate-950 border-amber-400 font-black'
                  : 'bg-slate-900 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>{lowBandwidthMode ? 'Low Bandwidth Active' : 'Low Data Mode'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Left Control & Agents / Right Conversational Thread */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (5 cols): Specialist Agents, Voice Mic Center, & Farmer Memory */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* 1. Voice Interactive Audio Center */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6 text-center">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-left">
              <div>
                <h2 className="text-sm font-bold text-white flex items-center space-x-2">
                  <Mic className="w-4 h-4 text-emerald-400" />
                  <span>Speech Input Studio</span>
                </h2>
                <p className="text-[11px] text-slate-400">Continuous Voice Recognition & Audio Synthesis</p>
              </div>

              {/* Language Selector */}
              <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-[11px] font-bold">
                <button
                  onClick={() => {
                    setActiveLang('rw');
                    setVoiceLocale('rw-RW');
                  }}
                  className={`px-2 py-0.5 rounded-lg transition-colors ${activeLang === 'rw' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'}`}
                >
                  RW
                </button>
                <button
                  onClick={() => {
                    setActiveLang('en');
                    setVoiceLocale('en-US');
                  }}
                  className={`px-2 py-0.5 rounded-lg transition-colors ${activeLang === 'en' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'}`}
                >
                  EN
                </button>
                <button
                  onClick={() => {
                    setActiveLang('fr');
                    setVoiceLocale('fr-FR');
                  }}
                  className={`px-2 py-0.5 rounded-lg transition-colors ${activeLang === 'fr' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'}`}
                >
                  FR
                </button>
              </div>
            </div>

            {/* Central Animated Mic Button */}
            <div className="relative inline-flex items-center justify-center py-4">
              {isListening && (
                <>
                  <div className="absolute w-44 h-44 bg-emerald-500/20 rounded-full animate-ping pointer-events-none" />
                  <div className="absolute w-52 h-52 bg-teal-500/10 rounded-full animate-pulse pointer-events-none" />
                </>
              )}

              <button
                onClick={handleToggleListen}
                disabled={isProcessing}
                className={`relative z-10 w-32 h-32 rounded-full flex flex-col items-center justify-center shadow-2xl transition-all transform hover:scale-105 active:scale-95 border-4 ${
                  isListening
                    ? 'bg-gradient-to-tr from-rose-600 via-amber-600 to-rose-500 border-rose-400 text-white shadow-rose-900/50'
                    : 'bg-gradient-to-tr from-emerald-600 via-teal-600 to-emerald-500 border-emerald-400/50 text-white shadow-emerald-950'
                }`}
              >
                {isListening ? (
                  <>
                    <MicOff className="w-12 h-12 animate-pulse" />
                    <span className="text-[10px] font-mono font-bold mt-1 text-amber-200">
                      00:0{recordingSeconds}s
                    </span>
                  </>
                ) : (
                  <>
                    <Mic className="w-12 h-12" />
                    <span className="text-[10px] font-bold mt-1 tracking-wider uppercase">Tap to Speak</span>
                  </>
                )}
              </button>
            </div>

            {/* Live Audio Equalizer Waveform Visualization */}
            {isListening && (
              <div className="flex items-center justify-center space-x-1.5 h-10">
                <span className="w-2 h-7 bg-emerald-400 rounded-full animate-bounce [animation-delay:0ms]" />
                <span className="w-2 h-10 bg-teal-400 rounded-full animate-bounce [animation-delay:150ms]" />
                <span className="w-2 h-5 bg-amber-400 rounded-full animate-bounce [animation-delay:300ms]" />
                <span className="w-2 h-9 bg-emerald-400 rounded-full animate-bounce [animation-delay:450ms]" />
                <span className="w-2 h-6 bg-teal-400 rounded-full animate-bounce [animation-delay:600ms]" />
              </div>
            )}

            {/* Speech Transcript Output Box */}
            {transcript && (
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl text-left space-y-3 animate-fadeIn">
                <div className="flex items-center justify-between text-[10px] font-bold text-slate-400">
                  <span className="uppercase tracking-wider">Captured Speech Transcript:</span>
                  <span className="text-emerald-400 font-mono">{voiceLocale}</span>
                </div>
                <p className="text-xs text-emerald-300 font-medium italic">"{transcript}"</p>

                <div className="flex items-center space-x-2 pt-1">
                  <button
                    onClick={() => handleSendQuery()}
                    disabled={isProcessing}
                    className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold py-2.5 rounded-xl flex items-center justify-center space-x-2 shadow-lg transition-colors"
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Sending to AI...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Send Voice Query</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => setTranscript('')}
                    className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs"
                  >
                    Clear
                  </button>
                </div>
              </div>
            )}

            {/* Multimodal Image Attachment Bar */}
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
              <label className="cursor-pointer text-slate-400 hover:text-emerald-400 flex items-center space-x-2 transition-colors">
                <ImageIcon className="w-4 h-4 text-emerald-400" />
                <span>{attachedImage ? 'Image Attached' : 'Attach Leaf / Animal Photo'}</span>
                <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
              </label>

              {attachedImage && (
                <div className="relative group">
                  <img src={attachedImage} alt="Attachment" className="w-9 h-9 rounded-lg object-cover border border-emerald-500" />
                  <button
                    onClick={() => setAttachedImage(null)}
                    className="absolute -top-1.5 -right-1.5 bg-rose-600 text-white rounded-full p-0.5"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>

          </div>

          {/* 2. Specialist AI Agent Routing Selector */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-xs font-bold text-slate-200 flex items-center space-x-1.5">
                <Bot className="w-4 h-4 text-emerald-400" />
                <span>AI Specialist Agent Routing</span>
              </h3>
              
              <label className="flex items-center space-x-1.5 text-[10px] text-slate-400 font-bold cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoRouteEnabled}
                  onChange={(e) => setAutoRouteEnabled(e.target.checked)}
                  className="rounded bg-slate-950 border-slate-800 text-emerald-500 focus:ring-0"
                />
                <span>Auto-Route</span>
              </label>
            </div>

            {/* Agent Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              
              {/* Agronomist */}
              <button
                onClick={() => {
                  setSelectedAgent('agronomist');
                  setAutoRouteEnabled(false);
                }}
                className={`p-3 rounded-2xl border text-left transition-all flex items-center space-x-3 ${
                  selectedAgent === 'agronomist'
                    ? 'bg-emerald-950/80 border-emerald-500 text-white shadow-lg'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 shrink-0">
                  <Leaf className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-white text-xs">Agronomist AI</p>
                  <p className="text-[10px] text-slate-400">Crops, Soil, Fertilizer</p>
                </div>
              </button>

              {/* Veterinarian */}
              <button
                onClick={() => {
                  setSelectedAgent('veterinarian');
                  setAutoRouteEnabled(false);
                }}
                className={`p-3 rounded-2xl border text-left transition-all flex items-center space-x-3 ${
                  selectedAgent === 'veterinarian'
                    ? 'bg-emerald-950/80 border-emerald-500 text-white shadow-lg'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 shrink-0">
                  <Bug className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-white text-xs">Veterinarian AI</p>
                  <p className="text-[10px] text-slate-400">Livestock, Milk, Vaccine</p>
                </div>
              </button>

              {/* Business ROI */}
              <button
                onClick={() => {
                  setSelectedAgent('business');
                  setAutoRouteEnabled(false);
                }}
                className={`p-3 rounded-2xl border text-left transition-all flex items-center space-x-3 ${
                  selectedAgent === 'business'
                    ? 'bg-emerald-950/80 border-emerald-500 text-white shadow-lg'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="p-2 rounded-xl bg-blue-500/20 text-blue-400 shrink-0">
                  <DollarSign className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-white text-xs">Farm Business AI</p>
                  <p className="text-[10px] text-slate-400">Profit, Expenses, Credit</p>
                </div>
              </button>

              {/* Market Prices */}
              <button
                onClick={() => {
                  setSelectedAgent('market');
                  setAutoRouteEnabled(false);
                }}
                className={`p-3 rounded-2xl border text-left transition-all flex items-center space-x-3 ${
                  selectedAgent === 'market'
                    ? 'bg-emerald-950/80 border-emerald-500 text-white shadow-lg'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 shrink-0">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-white text-xs">Market Price AI</p>
                  <p className="text-[10px] text-slate-400">Kigali / District Rates</p>
                </div>
              </button>

              {/* Weather Climate */}
              <button
                onClick={() => {
                  setSelectedAgent('weather');
                  setAutoRouteEnabled(false);
                }}
                className={`p-3 rounded-2xl border text-left transition-all flex items-center space-x-3 sm:col-span-2 ${
                  selectedAgent === 'weather'
                    ? 'bg-emerald-950/80 border-emerald-500 text-white shadow-lg'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="p-2 rounded-xl bg-teal-500/20 text-teal-400 shrink-0">
                  <CloudSun className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-white text-xs">Weather & Micro-Climate AI</p>
                  <p className="text-[10px] text-slate-400">District forecast & season planting windows</p>
                </div>
              </button>

            </div>
          </div>

          {/* 3. Farmer Memory System Panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-xs font-bold text-slate-200 flex items-center space-x-1.5">
                <Bookmark className="w-4 h-4 text-emerald-400" />
                <span>AI Farmer Memory Bank</span>
              </h3>
              <span className="text-[10px] text-emerald-400 font-mono">
                {farmerMemory.memories.length} Stored Notes
              </span>
            </div>

            {/* Profile summary badge */}
            <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-xs space-y-1">
              <p className="font-bold text-white">{farmerMemory.farmerName} • {farmerMemory.location}</p>
              <p className="text-[11px] text-slate-400">
                {farmerMemory.farmSizeHa} Ha • {farmerMemory.primaryCrops.join(', ')} • {farmerMemory.livestockCount} Cows
              </p>
            </div>

            {/* Memories list */}
            <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
              {farmerMemory.memories.map((mem) => (
                <div key={mem.id} className="p-2.5 bg-slate-950/70 border border-slate-800 rounded-xl text-xs flex items-center justify-between text-slate-300">
                  <div className="flex items-center space-x-2 min-w-0">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                    <span className="truncate">{mem.content}</span>
                  </div>
                  <button onClick={() => handleRemoveMemory(mem.id)} className="text-slate-500 hover:text-rose-400 p-1">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add Memory Input */}
            <div className="flex items-center space-x-2 pt-1">
              <input
                type="text"
                value={newMemoryInput}
                onChange={(e) => setNewMemoryInput(e.target.value)}
                placeholder="Add memory note (e.g. Planted beans today)..."
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:border-emerald-500 focus:outline-none"
              />
              <button
                onClick={handleAddMemory}
                className="p-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>

        {/* Right Column (7 cols): Conversational Thread & Action Panel */}
        <div className="lg:col-span-7 space-y-6">
          
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4 flex flex-col h-[740px]">
            
            {/* Conversation Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 shrink-0">
              <div className="flex items-center space-x-3">
                <div className="w-9 h-9 rounded-2xl bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-white flex items-center space-x-2">
                    <span>AGRIWISE Conversational Stream</span>
                  </h2>
                  <p className="text-[11px] text-slate-400 capitalize">Active Agent: {selectedAgent} AI</p>
                </div>
              </div>

              {/* Sample Voice Prompts Drawer Button */}
              <div className="flex items-center space-x-2">
                <span className="text-[10px] text-slate-500">Fast Questions:</span>
                <button
                  onClick={() => handleSendQuery(samplePrompts[0].text)}
                  className="px-2.5 py-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-lg text-[11px] text-emerald-300 truncate max-w-[140px]"
                >
                  Maize Yellow Leaves
                </button>
              </div>
            </div>

            {/* Chat Bubbles Scroll Area */}
            <div className="flex-1 overflow-y-auto space-y-4 pr-2">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'} space-y-1`}
                >
                  <div className="flex items-center space-x-2 text-[10px] text-slate-500 px-1">
                    <span>{msg.sender === 'user' ? farmerMemory.farmerName : `${msg.specialistAgent || 'agronomist'} AI`}</span>
                    <span>•</span>
                    <span>{msg.timestamp}</span>
                  </div>

                  <div
                    className={`max-w-xl p-4 rounded-3xl space-y-3 text-xs shadow-md transition-all ${
                      msg.sender === 'user'
                        ? 'bg-emerald-600 text-white rounded-tr-none'
                        : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-none'
                    }`}
                  >
                    {/* Image Attachment inside Bubble */}
                    {msg.multimodalImage && (
                      <img
                        src={msg.multimodalImage}
                        alt="User uploaded crop specimen"
                        className="w-48 h-32 rounded-xl object-cover border border-emerald-400/50"
                      />
                    )}

                    <p className="leading-relaxed whitespace-pre-line">{msg.text}</p>

                    {/* AI Assistant Controls: Audio Speak & Confidence Rating */}
                    {msg.sender === 'assistant' && (
                      <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
                        
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleSpeakMessage(msg.id, msg.text)}
                            className={`px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center space-x-1.5 transition-all ${
                              isSpeakingMessageId === msg.id
                                ? 'bg-amber-500 text-slate-950 shadow-md animate-pulse'
                                : 'bg-slate-900 hover:bg-slate-800 text-emerald-300 border border-emerald-500/30'
                            }`}
                          >
                            {isSpeakingMessageId === msg.id ? (
                              <>
                                <Square className="w-3.5 h-3.5 fill-current" />
                                <span>Stop Reading</span>
                              </>
                            ) : (
                              <>
                                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                                <span>Listen Audio</span>
                              </>
                            )}
                          </button>
                        </div>

                        {msg.confidenceScore && (
                          <div className="flex items-center space-x-2">
                            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-md border border-emerald-500/30">
                              Confidence: {msg.confidenceScore}%
                            </span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Safety Disclaimer Banner if needed */}
                    {msg.safetyDisclaimer && (
                      <div className="p-2.5 bg-amber-950/60 border border-amber-500/40 rounded-xl text-[11px] text-amber-200 flex items-start space-x-2">
                        <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <span>{msg.safetyDisclaimer}</span>
                      </div>
                    )}

                    {/* Recommended Action CTA */}
                    {msg.actionableRecommendation && (
                      <div className="p-2.5 bg-emerald-950/70 border border-emerald-500/40 rounded-xl text-[11px] text-emerald-300 flex items-center justify-between">
                        <span className="font-bold">Next Step: {msg.actionableRecommendation}</span>
                        <ChevronRight className="w-4 h-4 text-emerald-400 shrink-0" />
                      </div>
                    )}

                  </div>
                </div>
              ))}

              {isProcessing && (
                <div className="flex items-center space-x-3 text-xs text-emerald-400 p-3 bg-slate-950/80 rounded-2xl border border-slate-800 w-fit animate-pulse">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>AI Agent is analyzing context & generating response...</span>
                </div>
              )}

              <div ref={chatBottomRef} />
            </div>

            {/* Bottom Input Controls */}
            <div className="pt-3 border-t border-slate-800 space-y-2 shrink-0">
              
              {/* Sample Voice Prompts Selector */}
              <div className="flex items-center space-x-2 overflow-x-auto pb-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider shrink-0">Presets:</span>
                {samplePrompts.map((sp, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setSelectedAgent(sp.agent);
                      handleSendQuery(sp.text);
                    }}
                    className="px-2.5 py-1 bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded-lg text-[11px] whitespace-nowrap transition-colors"
                  >
                    {sp.text.slice(0, 32)}...
                  </button>
                ))}
              </div>

              {/* Text Field Input Form */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendQuery();
                }}
                className="flex items-center space-x-2"
              >
                <input
                  type="text"
                  value={typedMessage}
                  onChange={(e) => setTypedMessage(e.target.value)}
                  placeholder="Or type your question in Kinyarwanda / English / French..."
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-2xl px-4 py-3 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                />

                <button
                  type="submit"
                  disabled={isProcessing || (!typedMessage.trim() && !attachedImage)}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold p-3 rounded-2xl shadow-lg transition-colors disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>

              {/* RAB Expert Human Hotline Call Footer */}
              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                <span>RAB Human Specialist Advisory Hotline:</span>
                <a
                  href="tel:+250788123456"
                  className="text-emerald-400 hover:underline flex items-center space-x-1 font-bold"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Call +250 788 123 456 (Free)</span>
                </a>
              </div>

            </div>

          </div>

        </div>

      </div>

    </div>
  );
};
