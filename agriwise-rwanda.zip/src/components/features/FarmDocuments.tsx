import React, { useState } from 'react';
import { FarmDocumentRecord, RegisteredFarm, Language, User } from '../../types';
import { FileText, Download, Upload, ShieldCheck, FileCheck, CheckCircle2, Clock, Plus, ExternalLink, Printer, X } from 'lucide-react';

interface FarmDocumentsProps {
  documents: FarmDocumentRecord[];
  farms: RegisteredFarm[];
  currentUser: User;
  onUploadDocument: (doc: FarmDocumentRecord) => void;
  language: Language;
}

export const FarmDocuments: React.FC<FarmDocumentsProps> = ({
  documents,
  farms,
  currentUser,
  onUploadDocument,
  language,
}) => {
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showReportPreview, setShowReportPreview] = useState(false);

  // Form state
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<FarmDocumentRecord['category']>('Land Title');
  const [selectedFarmId, setSelectedFarmId] = useState(farms[0]?.id || 'farm_1');
  const [fileType, setFileType] = useState<'pdf' | 'jpg' | 'png'>('pdf');

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const newDoc: FarmDocumentRecord = {
      id: `doc_${Date.now()}`,
      farmId: selectedFarmId,
      title,
      category,
      uploadDate: new Date().toISOString().split('T')[0],
      fileUrl: '#',
      fileType,
      fileSizeMb: 1.8,
      verificationStatus: 'Pending Review',
    };

    onUploadDocument(newDoc);
    setShowUploadModal(false);
    setTitle('');
  };

  const getVerificationBadge = (status: FarmDocumentRecord['verificationStatus']) => {
    if (status === 'Verified by RAB') {
      return (
        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center space-x-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Verified by RAB</span>
        </span>
      );
    }
    if (status === 'Pending Review') {
      return (
        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center space-x-1">
          <Clock className="w-3.5 h-3.5" />
          <span>Pending RAB Verification</span>
        </span>
      );
    }
    return (
      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700 flex items-center space-x-1">
        <FileCheck className="w-3.5 h-3.5" />
        <span>Self Uploaded</span>
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-md">
        <div>
          <div className="flex items-center space-x-2">
            <FileText className="w-6 h-6 text-emerald-400" />
            <h1 className="text-xl font-bold text-slate-100">
              {language === 'rw' ? 'Ububiko bw\'Inyandiko z\'Isambu (Digital Vault)' : 'Farm Digital Vault & Document System'}
            </h1>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            {language === 'rw'
              ? 'Bika ibyemezo by\'ubutaka, ibya organic, inyanzuro z\'ifumbire, no gukora raporo y\'ubuhinzi.'
              : 'Store official land UPI deeds, RAB certificates, soil tests, and generate instant Agri-Passport reports.'}
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => setShowReportPreview(true)}
            className="flex items-center space-x-2 px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold shadow"
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>Generate Farm Passport</span>
          </button>

          <button
            onClick={() => setShowUploadModal(true)}
            className="flex items-center space-x-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-lg transition-all"
          >
            <Upload className="w-4 h-4" />
            <span>Upload Document</span>
          </button>
        </div>
      </div>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {documents.map((doc) => {
          const farmObj = farms.find((f) => f.id === doc.farmId);
          return (
            <div
              key={doc.id}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 space-y-4 shadow-md flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="p-3 bg-emerald-950/60 border border-emerald-800/60 text-emerald-400 rounded-xl">
                    <FileText className="w-6 h-6" />
                  </div>
                  {getVerificationBadge(doc.verificationStatus)}
                </div>

                <div>
                  <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">
                    {doc.category}
                  </span>
                  <h3 className="text-sm font-bold text-slate-100 mt-0.5">{doc.title}</h3>
                  <p className="text-[11px] text-slate-400 mt-1">
                    🏡 Plot: <span className="text-slate-200 font-medium">{farmObj?.farmName || 'Kinigi Volcanic Plot #1'}</span>
                  </p>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                <span>
                  {doc.uploadDate} • {doc.fileSizeMb} MB
                </span>
                <button
                  onClick={() => alert(`Downloading document: ${doc.title}`)}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 rounded-lg flex items-center space-x-1"
                  title="Download File"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Upload Document Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-2xl p-6 space-y-5 shadow-2xl relative">
            <button
              onClick={() => setShowUploadModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
                <Upload className="w-5 h-5 text-emerald-400" />
                <span>Upload Digital Farm Document</span>
              </h3>
            </div>

            <form onSubmit={handleUploadSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Document Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Official UPI Title Deed (Sector Kinigi)"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as FarmDocumentRecord['category'])}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                >
                  <option value="Land Title">Land Title (UPI Deed)</option>
                  <option value="Organic Certificate">Organic Certificate (RAB)</option>
                  <option value="Cooperative License">Cooperative License</option>
                  <option value="Input Purchase Receipt">Input Purchase Receipt</option>
                  <option value="Soil Test Report">Soil Test Report</option>
                  <option value="Bank Loan Agreement">Bank Loan Agreement</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Associated Farm Plot</label>
                <select
                  value={selectedFarmId}
                  onChange={(e) => setSelectedFarmId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                >
                  {farms.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.farmName} ({f.district})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Select File (PDF, PNG, JPG)</label>
                <div className="p-6 bg-slate-950 border-2 border-dashed border-slate-700 hover:border-emerald-500 rounded-xl text-center cursor-pointer transition-all">
                  <Upload className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                  <p className="text-slate-300 font-semibold">Click to select file or drag here</p>
                  <p className="text-slate-500 text-[10px] mt-1">Supports PDF, JPG, PNG up to 10MB</p>
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white font-semibold rounded-xl hover:bg-emerald-500 shadow-lg"
                >
                  Upload & Vault
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Farm Passport / Printable Report Modal */}
      {showReportPreview && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-3xl rounded-2xl p-6 space-y-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowReportPreview(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Printable Certificate Layout */}
            <div className="bg-slate-950 border-2 border-emerald-600/60 p-8 rounded-2xl space-y-6 text-slate-100 relative">
              <div className="flex items-center justify-between border-b-2 border-slate-800 pb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-emerald-600 text-white rounded-xl font-bold flex items-center justify-center text-xl shadow">
                    AG
                  </div>
                  <div>
                    <h2 className="text-lg font-extrabold text-white">REPUBLIC OF RWANDA — AGRIWISE PASSPORT</h2>
                    <p className="text-xs text-emerald-400 font-semibold">RAB & Ministry of Agriculture Digital Farm Report</p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-full text-xs font-bold">
                    Official Rab Verified
                  </span>
                  <p className="text-[10px] text-slate-400 mt-1">Date: {new Date().toISOString().split('T')[0]}</p>
                </div>
              </div>

              {/* Farmer & Farm Summary */}
              <div className="grid grid-cols-2 gap-4 text-xs border-b border-slate-800 pb-4">
                <div>
                  <span className="text-slate-400 font-bold block mb-1">FARMER OWNER DETAILS</span>
                  <p className="font-bold text-slate-100">{currentUser.name}</p>
                  <p className="text-slate-300">National ID: 1 1988 8 0034125 1 23</p>
                  <p className="text-slate-300">Phone: {currentUser.phone}</p>
                  <p className="text-slate-300">District: {currentUser.district}, Sector: {currentUser.sector}</p>
                </div>

                <div>
                  <span className="text-slate-400 font-bold block mb-1">AGRICULTURAL STATS</span>
                  <p className="text-slate-300">Total Registered Land: <strong className="text-white">2.5 Hectares</strong></p>
                  <p className="text-slate-300">AI Health Index: <strong className="text-emerald-400">86% Excellent</strong></p>
                  <p className="text-slate-300">AgriCredit Reliability: <strong className="text-emerald-400">780 / 900 (Grade A)</strong></p>
                  <p className="text-slate-300">Cooperative: Abahizi Kinigi Potato Farmers</p>
                </div>
              </div>

              {/* Verified Farms List */}
              <div className="space-y-2 text-xs">
                <span className="text-slate-400 font-bold block">REGISTERED FARM PLOTS & SOIL CLASSIFICATIONS</span>
                {farms.map((f, i) => (
                  <div key={f.id} className="p-3 bg-slate-900 border border-slate-800 rounded-xl flex justify-between items-center">
                    <div>
                      <p className="font-bold text-slate-100">Plot #{i + 1}: {f.farmName}</p>
                      <p className="text-[11px] text-slate-400">{f.soilType} • {f.waterSource} • {f.landOwnershipType}</p>
                    </div>
                    <span className="font-bold text-emerald-400">{f.sizeHectares} Ha</span>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-800 text-[10px] text-slate-500">
                <span>Digital verification ref: RW-RAB-2026-99381-AG</span>
                <span>Generated by AgriWise AI Rwanda Platform</span>
              </div>
            </div>

            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowReportPreview(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold"
              >
                Close
              </button>
              <button
                onClick={() => {
                  window.print();
                }}
                className="px-5 py-2 bg-emerald-600 text-white font-semibold rounded-xl text-xs hover:bg-emerald-500 shadow-lg flex items-center space-x-2"
              >
                <Printer className="w-4 h-4" />
                <span>Print / Download PDF</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
