import React, { useState } from 'react';
import { FarmActivity, RegisteredFarm, Language } from '../../types';
import { CalendarCheck, Plus, CheckCircle2, Clock, AlertCircle, Calendar, Filter, DollarSign, Sprout, ShieldAlert, X } from 'lucide-react';

interface FarmActivityTrackerProps {
  activities: FarmActivity[];
  farms: RegisteredFarm[];
  onAddActivity: (act: FarmActivity) => void;
  onToggleComplete: (actId: string) => void;
  language: Language;
}

export const FarmActivityTracker: React.FC<FarmActivityTrackerProps> = ({
  activities,
  farms,
  onAddActivity,
  onToggleComplete,
  language,
}) => {
  const [filterFarmId, setFilterFarmId] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'completed' | 'overdue'>('all');
  const [showAddModal, setShowAddModal] = useState(false);

  // Form State
  const [title, setTitle] = useState('');
  const [selectedFarmId, setSelectedFarmId] = useState(farms[0]?.id || 'farm_1');
  const [activityType, setActivityType] = useState<FarmActivity['activityType']>('Fertilizing');
  const [cropOrAnimalTarget, setCropOrAnimalTarget] = useState('Irish Potatoes (Kinigi)');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [inputUsed, setInputUsed] = useState('');
  const [inputQuantity, setInputQuantity] = useState('');
  const [assignedLaborers, setAssignedLaborers] = useState(2);
  const [costRwf, setCostRwf] = useState(25000);

  const filteredActivities = activities.filter((act) => {
    if (filterFarmId !== 'all' && act.farmId !== filterFarmId) return false;
    if (filterStatus !== 'all' && act.status !== filterStatus) return false;
    return true;
  });

  const handleCreateActivity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const farmObj = farms.find((f) => f.id === selectedFarmId);

    const newAct: FarmActivity = {
      id: `act_${Date.now()}`,
      farmId: selectedFarmId,
      farmName: farmObj?.farmName || 'Kinigi Volcanic Plot #1',
      activityType,
      title,
      description,
      date,
      status: 'pending',
      cropOrAnimalTarget,
      inputUsed,
      inputQuantity,
      assignedLaborers: Number(assignedLaborers),
      costRwf: Number(costRwf),
    };

    onAddActivity(newAct);
    setShowAddModal(false);
    setTitle('');
    setDescription('');
    setInputUsed('');
    setInputQuantity('');
  };

  const getStatusBadge = (status: FarmActivity['status']) => {
    if (status === 'completed') {
      return (
        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center space-x-1">
          <CheckCircle2 className="w-3 h-3" />
          <span>Completed</span>
        </span>
      );
    }
    if (status === 'overdue') {
      return (
        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center space-x-1">
          <AlertCircle className="w-3 h-3" />
          <span>Overdue</span>
        </span>
      );
    }
    return (
      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center space-x-1">
        <Clock className="w-3 h-3" />
        <span>Pending Schedule</span>
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-md">
        <div>
          <div className="flex items-center space-x-2">
            <CalendarCheck className="w-6 h-6 text-emerald-400" />
            <h1 className="text-xl font-bold text-slate-100">
              {language === 'rw' ? 'Gukurikirana Imirimo y\'Isambu' : 'Farm Activity & Operations Calendar'}
            </h1>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            {language === 'rw'
              ? 'Guhina, gufumbira, gufata imiti, gukingira amatungo, no gusarura ku gihe.'
              : 'Log, schedule, and track field spraying, fertilizing, harvesting, and veterinary vaccinations.'}
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center space-x-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-lg transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>{language === 'rw' ? 'Andika Umurimo Mu Bitaramo' : 'Record Farm Activity'}</span>
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 border border-slate-800 p-3 rounded-xl">
        <div className="flex items-center space-x-3 text-xs">
          <span className="text-slate-400 font-semibold flex items-center space-x-1">
            <Filter className="w-3.5 h-3.5 text-emerald-400" />
            <span>Filter Farm:</span>
          </span>
          <select
            value={filterFarmId}
            onChange={(e) => setFilterFarmId(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-slate-200 text-xs focus:outline-none focus:border-emerald-500"
          >
            <option value="all">All Registered Farms</option>
            {farms.map((f) => (
              <option key={f.id} value={f.id}>
                {f.farmName}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center space-x-2 text-xs">
          {(['all', 'pending', 'completed', 'overdue'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize transition-all ${
                filterStatus === st
                  ? 'bg-emerald-600 text-white shadow'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Activities Timeline List */}
      <div className="space-y-3">
        {filteredActivities.length === 0 ? (
          <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-2xl text-slate-400 text-xs">
            No farm activities matching the filter criteria.
          </div>
        ) : (
          filteredActivities.map((act) => (
            <div
              key={act.id}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 space-y-3 transition-all shadow-md"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                <div className="flex items-center space-x-3">
                  <span className="p-2 bg-emerald-950 border border-emerald-800/60 text-emerald-400 rounded-xl text-xs font-bold">
                    {act.activityType}
                  </span>
                  <div>
                    <h3 className="text-sm font-bold text-slate-100">{act.title}</h3>
                    <p className="text-[11px] text-slate-400">
                      🏡 {act.farmName} • Target: <span className="text-emerald-300 font-medium">{act.cropOrAnimalTarget}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <span className="text-xs text-slate-400 flex items-center space-x-1">
                    <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{act.date}</span>
                  </span>
                  {getStatusBadge(act.status)}
                  <button
                    onClick={() => onToggleComplete(act.id)}
                    className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
                      act.status === 'completed'
                        ? 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                        : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow'
                    }`}
                  >
                    {act.status === 'completed' ? 'Mark Pending' : '✓ Mark Complete'}
                  </button>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">{act.description}</p>

              {/* Detail Metrics Footer */}
              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-1">
                {act.inputUsed && (
                  <span>
                    🌱 Input: <strong className="text-slate-200">{act.inputUsed}</strong> ({act.inputQuantity})
                  </span>
                )}
                {act.assignedLaborers && (
                  <span>
                    👥 Laborers: <strong className="text-slate-200">{act.assignedLaborers} Workers</strong>
                  </span>
                )}
                {act.costRwf && (
                  <span>
                    💰 Expense: <strong className="text-emerald-400">{act.costRwf.toLocaleString()} RWF</strong>
                  </span>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add Activity Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-xl rounded-2xl p-6 space-y-5 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
                <CalendarCheck className="w-5 h-5 text-emerald-400" />
                <span>Schedule New Farm Activity</span>
              </h3>
            </div>

            <form onSubmit={handleCreateActivity} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Select Farm Plot</label>
                <select
                  value={selectedFarmId}
                  onChange={(e) => setSelectedFarmId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                >
                  {farms.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.farmName} ({f.district})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Activity Type</label>
                  <select
                    value={activityType}
                    onChange={(e) => setActivityType(e.target.value as FarmActivity['activityType'])}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  >
                    <option value="Planting">Planting</option>
                    <option value="Fertilizing">Fertilizing</option>
                    <option value="Spraying">Spraying</option>
                    <option value="Irrigation">Irrigation</option>
                    <option value="Harvesting">Harvesting</option>
                    <option value="Animal Vaccination">Animal Vaccination</option>
                    <option value="Feeding">Feeding</option>
                    <option value="Soil Testing">Soil Testing</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Crop or Livestock Target</label>
                  <input
                    type="text"
                    value={cropOrAnimalTarget}
                    onChange={(e) => setCropOrAnimalTarget(e.target.value)}
                    placeholder="e.g. Irish Potatoes (Kinigi)"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Activity Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Preventive Spraying for Potato Blight"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Activity Description / Instructions</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  placeholder="Detailed notes on dosage, timing, and field section..."
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Scheduled Date</label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Estimated Cost (RWF)</label>
                  <input
                    type="number"
                    value={costRwf}
                    onChange={(e) => setCostRwf(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Input Used (Optional)</label>
                  <input
                    type="text"
                    value={inputUsed}
                    onChange={(e) => setInputUsed(e.target.value)}
                    placeholder="e.g. NPK 17-17-17 / Mancozeb"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Quantity / Dose</label>
                  <input
                    type="text"
                    value={inputQuantity}
                    onChange={(e) => setInputQuantity(e.target.value)}
                    placeholder="e.g. 50 Kg / 2.5 L"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white font-semibold rounded-xl hover:bg-emerald-500 shadow-lg"
                >
                  Schedule Activity
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
