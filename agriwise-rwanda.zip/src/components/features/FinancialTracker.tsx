import React, { useState } from 'react';
import { FinancialTransaction, Language } from '../../types';
import { INITIAL_TRANSACTIONS } from '../../data/mockData';
import { translations } from '../../data/translations';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  Wallet,
  Download,
  Receipt
} from 'lucide-react';

interface FinancialTrackerProps {
  language: Language;
}

export const FinancialTracker: React.FC<FinancialTrackerProps> = ({ language }) => {
  const t = translations[language];
  const [transactions, setTransactions] = useState<FinancialTransaction[]>(INITIAL_TRANSACTIONS);
  const [showAddModal, setShowAddModal] = useState(false);

  const [desc, setDesc] = useState('Sale of 1.2 Tons Irish Potatoes');
  const [amount, setAmount] = useState(480000);
  const [type, setType] = useState<'income' | 'expense'>('income');
  const [category, setCategory] = useState<FinancialTransaction['category']>('Produce Sale');

  const totalIncome = transactions
    .filter((t) => t.type === 'income')
    .reduce((acc, curr) => acc + curr.amountRwf, 0);

  const totalExpense = transactions
    .filter((t) => t.type === 'expense')
    .reduce((acc, curr) => acc + curr.amountRwf, 0);

  const netProfit = totalIncome - totalExpense;

  const handleAddTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    const created: FinancialTransaction = {
      id: `tx_${Date.now()}`,
      farmerId: 'user_1',
      date: new Date().toISOString().split('T')[0],
      category,
      type,
      amountRwf: Number(amount),
      description: desc,
      paymentMethod: 'MTN Mobile Money',
      receiptRef: `MOMO-RW-${Math.floor(1000000 + Math.random() * 9000000)}`
    };
    setTransactions([created, ...transactions]);
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-white">
        <div>
          <div className="inline-flex items-center space-x-2 bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3 py-1 rounded-full text-xs font-bold mb-1">
            <DollarSign className="w-3.5 h-3.5 text-amber-400" />
            <span>Farm Accounting & Cash Flow Log</span>
          </div>
          <h2 className="text-xl font-black">{t.navFinancials}</h2>
          <p className="text-xs text-slate-400">Track input expenses, produce sales, and calculate net profits in RWF.</p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg flex items-center space-x-2 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Log Transaction</span>
          </button>
        </div>
      </div>

      {/* Summary Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-xl flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Income</p>
            <p className="text-xl font-black text-emerald-400 mt-1">
              {totalIncome.toLocaleString()} RWF
            </p>
          </div>
          <div className="w-10 h-10 rounded-2xl bg-emerald-950 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
            <ArrowUpRight className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-xl flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Expenses</p>
            <p className="text-xl font-black text-rose-400 mt-1">
              {totalExpense.toLocaleString()} RWF
            </p>
          </div>
          <div className="w-10 h-10 rounded-2xl bg-rose-950 text-rose-400 flex items-center justify-center border border-rose-500/30">
            <ArrowDownRight className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900 border border-emerald-500/30 p-5 rounded-3xl shadow-xl flex items-center justify-between bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950">
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Net Farm Profit</p>
            <p className="text-xl font-black text-amber-300 mt-1">
              {netProfit.toLocaleString()} RWF
            </p>
          </div>
          <div className="w-10 h-10 rounded-2xl bg-amber-950 text-amber-300 flex items-center justify-center border border-amber-500/30">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

      </div>

      {/* Transaction Records Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 text-white">
        <h3 className="text-sm font-bold text-white flex items-center space-x-2">
          <Receipt className="w-4 h-4 text-emerald-400" />
          <span>Recent Financial Transactions</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Description</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">MoMo Receipt Ref</th>
                <th className="py-2.5 px-3 text-right">Amount (RWF)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {transactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-slate-800/50">
                  <td className="py-3 px-3 text-slate-400">{tx.date}</td>
                  <td className="py-3 px-3 font-semibold text-white">{tx.description}</td>
                  <td className="py-3 px-3 text-slate-300">
                    <span className="px-2 py-0.5 rounded-full bg-slate-800 text-[10px] font-bold">
                      {tx.category}
                    </span>
                  </td>
                  <td className="py-3 px-3 font-mono text-[11px] text-amber-300">{tx.receiptRef || 'N/A'}</td>
                  <td className={`py-3 px-3 text-right font-black ${tx.type === 'income' ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {tx.type === 'income' ? '+' : '-'}{tx.amountRwf.toLocaleString()} RWF
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full text-white space-y-4 shadow-2xl">
            <h3 className="text-base font-black">Record Financial Log</h3>

            <form onSubmit={handleAddTransaction} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Type:</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as 'income' | 'expense')}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  <option value="income">Income (+) Produce / Livestock Sale</option>
                  <option value="expense">Expense (-) Fertilizer / Labor / Seeds</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Description:</label>
                <input
                  type="text"
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Amount (RWF):</label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div className="pt-3 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 rounded-xl shadow"
                >
                  Save Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
