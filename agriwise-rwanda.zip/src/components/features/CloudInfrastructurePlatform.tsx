import React, { useState } from 'react';
import { User, Language } from '../../types';
import { translations } from '../../data/translations';
import {
  INFRASTRUCTURE_SUMMARY,
  MICROSERVICES_HEALTH,
  DATABASE_PARTITIONS,
  CACHE_CLUSTERS,
  OFFLINE_SYNC_STATUS,
} from '../../data/infrastructureData';
import {
  Server,
  Cpu,
  Database,
  Zap,
  Activity,
  WifiOff,
  Cloud,
  ShieldCheck,
  Bot,
  Sparkles,
  RefreshCw,
  BarChart3,
  Layers,
  HardDrive,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowUpRight,
  Lock,
  DollarSign,
  Globe,
  Sliders,
  Terminal,
} from 'lucide-react';

interface CloudInfrastructurePlatformProps {
  currentUser: User;
  language: Language;
}

export const CloudInfrastructurePlatform: React.FC<CloudInfrastructurePlatformProps> = ({
  currentUser,
  language,
}) => {
  const [activeTab, setActiveTab] = useState<
    'overview' | 'microservices' | 'database_opt' | 'cache_cdn' | 'offline_sync' | 'ai_devops_copilot'
  >('overview');

  const [targetCluster, setTargetCluster] = useState<string>('GKE Autopilot Kigali Node');
  const [focusArea, setFocusArea] = useState<string>(
    'Database Query Latency, Redis Cache Eviction & Gemini API Token Optimization'
  );
  const [isAiDiagnosing, setIsAiDiagnosing] = useState<boolean>(false);
  const [aiDiagResult, setAiDiagResult] = useState<any>(null);

  const t = translations[language] || translations['rw'];

  const handleRunAiDiagnostics = async () => {
    setIsAiDiagnosing(true);
    try {
      const res = await fetch('/api/ai/infra-optimizer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetCluster,
          focusArea,
          language,
        }),
      });
      const data = await res.json();
      setAiDiagResult(data);
    } catch (err) {
      console.error('Failed to run infra AI diagnosis:', err);
    } finally {
      setIsAiDiagnosing(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-emerald-500/15 border border-emerald-400/30 px-3 py-1 rounded-full text-xs font-bold text-emerald-300">
              <Server className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span>STEP 46 • PERFORMANCE OPTIMIZATION & CLOUD INFRASTRUCTURE</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              AGRIWISE Cloud Infrastructure Engine
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 font-medium leading-relaxed">
              Global multi-tenant cloud telemetry, microservices mesh status, database partitioning, Redis L2 caching clusters, and offline low-bandwidth delta sync for rural smallholder accessibility.
            </p>
          </div>

          {/* Quick Uptime SLA Badge */}
          <div className="flex items-center gap-3 bg-slate-900/90 border border-emerald-500/40 p-3.5 rounded-2xl shadow-lg">
            <div className="w-10 h-10 rounded-xl bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-bold">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                Uptime SLA Target
              </span>
              <span className="text-sm font-black text-emerald-400 font-mono">99.99% Operational</span>
            </div>
          </div>
        </div>

        {/* Real-time Infrastructure Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-6 pt-6 border-t border-emerald-500/20 text-xs">
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Active Pod Containers</span>
            <span className="text-lg font-black text-emerald-400 font-mono">
              {INFRASTRUCTURE_SUMMARY.totalActiveContainers} Pods
            </span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Global Throughput</span>
            <span className="text-lg font-black text-teal-400 font-mono">
              {INFRASTRUCTURE_SUMMARY.globalRps.toLocaleString()} RPS
            </span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">P95 Latency SLA</span>
            <span className="text-lg font-black text-amber-400 font-mono">
              {INFRASTRUCTURE_SUMMARY.p95LatencyMs} ms
            </span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Spot Compute Savings</span>
            <span className="text-lg font-black text-blue-400 font-mono">
              {INFRASTRUCTURE_SUMMARY.spotSavingsPercentage}% Saved
            </span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Monthly Infrastructure</span>
            <span className="text-lg font-black text-emerald-300 font-mono">
              ${INFRASTRUCTURE_SUMMARY.monthlyCloudCostUsd.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex overflow-x-auto gap-2 bg-slate-900/90 p-2 rounded-2xl border border-slate-800 custom-scrollbar text-xs font-bold">
        {[
          { id: 'overview', label: 'Cloud Overview & SLAs', icon: Activity },
          { id: 'microservices', label: 'Microservices Mesh (7)', icon: Server },
          { id: 'database_opt', label: 'Database Partitions & Replicas', icon: Database },
          { id: 'cache_cdn', label: 'Redis Cache & Edge CDN', icon: Layers },
          { id: 'offline_sync', label: 'Rural Offline Delta Sync', icon: WifiOff },
          { id: 'ai_devops_copilot', label: 'Gemini AI DevOps Copilot', icon: Bot, badge: 'Gemini 3.6' },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.badge && (
                <span className="text-[9px] bg-emerald-500/30 text-emerald-300 border border-emerald-400/30 px-1.5 py-0.5 rounded-full uppercase">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: CLOUD OVERVIEW & SLAS */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-emerald-400" />
                Global Latency Percentiles & SLA Targets
              </h2>
              <p className="text-xs text-slate-400">
                Real-time round-trip latency monitored across African edge PoPs and GCP europe-west2 secondary nodes.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-400">P50 Median Latency</span>
                <span className="text-xs font-bold text-emerald-400 bg-emerald-950 border border-emerald-500/30 px-2 py-0.5 rounded-md">
                  Target &lt; 30ms
                </span>
              </div>
              <div className="text-3xl font-black text-white font-mono">
                {INFRASTRUCTURE_SUMMARY.p50LatencyMs} <span className="text-sm text-slate-400 font-sans">ms</span>
              </div>
              <p className="text-xs text-slate-400">
                Covers basic API calls, authentication tokens, and cached marketplace price lookups.
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-400">P95 Latency SLA</span>
                <span className="text-xs font-bold text-teal-400 bg-teal-950 border border-teal-500/30 px-2 py-0.5 rounded-md">
                  Target &lt; 100ms
                </span>
              </div>
              <div className="text-3xl font-black text-white font-mono">
                {INFRASTRUCTURE_SUMMARY.p95LatencyMs} <span className="text-sm text-slate-400 font-sans">ms</span>
              </div>
              <p className="text-xs text-slate-400">
                Covers complex GIS polygon boundary intersections and mobile payment gateway webhooks.
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-400">P99 Maximum Latency</span>
                <span className="text-xs font-bold text-amber-400 bg-amber-950 border border-amber-500/30 px-2 py-0.5 rounded-md">
                  Target &lt; 200ms
                </span>
              </div>
              <div className="text-3xl font-black text-white font-mono">
                {INFRASTRUCTURE_SUMMARY.p99LatencyMs} <span className="text-sm text-slate-400 font-sans">ms</span>
              </div>
              <p className="text-xs text-slate-400">
                Covers satellite multi-spectral raster rendering and AI disease vision model inference.
              </p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Globe className="w-5 h-5 text-emerald-400" />
              Multi-Region Cloud Data Residency Nodes
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              {INFRASTRUCTURE_SUMMARY.dataResidencyRegions.map((region, idx) => (
                <div key={idx} className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Region Node {idx + 1}</span>
                  </div>
                  <p className="text-slate-200 font-mono font-medium">{region}</p>
                  <span className="text-[10px] text-slate-400 block">Status: Active Sync</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MICROSERVICES MESH */}
      {activeTab === 'microservices' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Server className="w-5 h-5 text-emerald-400" />
                Containerized Microservices Cluster Health
              </h2>
              <p className="text-xs text-slate-400">
                GKE Autopilot horizontal pod autoscalers (HPA) operating with CPU/Memory bounds and zero-downtime rollouts.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {MICROSERVICES_HEALTH.map((svc) => (
              <div
                key={svc.id}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3"
              >
                <div className="flex justify-between items-start border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="font-bold text-white text-sm">{svc.name}</h3>
                    <span className="text-[11px] text-slate-400 font-mono">{svc.region}</span>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2.5 py-1 rounded-full border ${
                      svc.status === 'Healthy'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                        : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                    }`}
                  >
                    {svc.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">Active Replicas</span>
                    <span className="font-bold text-emerald-400 font-mono text-sm">{svc.replicas} Pods</span>
                  </div>

                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">Requests / Sec</span>
                    <span className="font-bold text-teal-400 font-mono text-sm">{svc.requestsPerSec} RPS</span>
                  </div>

                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">CPU Utilization</span>
                    <span className="font-bold text-amber-400 font-mono text-sm">{svc.cpuUsagePct}%</span>
                  </div>

                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">P95 Latency</span>
                    <span className="font-bold text-blue-400 font-mono text-sm">{svc.latencyP95Ms} ms</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: DATABASE PARTITIONS & REPLICAS */}
      {activeTab === 'database_opt' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Database className="w-5 h-5 text-emerald-400" />
                Database Sharding & Read Replica Topology
              </h2>
              <p className="text-xs text-slate-400">
                Separating real-time operational transactions from large-scale PostGIS spatial queries and immutable financial ledgers.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {DATABASE_PARTITIONS.map((part, idx) => (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4"
              >
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="font-bold text-white text-base">{part.partitionName}</h3>
                    <span className="text-xs text-slate-400 font-mono">
                      Storage: {part.storageGb} GB • Read Replicas: {part.readReplicaCount} Active Nodes
                    </span>
                  </div>

                  <span className="text-xs font-bold bg-emerald-950 border border-emerald-500/30 text-emerald-300 px-3 py-1 rounded-full font-mono">
                    Query SLA: {part.avgQueryTimeMs} ms
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
                    <span className="text-slate-400 block">Total Partition Records</span>
                    <span className="text-base font-black text-emerald-400 font-mono">
                      {(part.totalRecords / 1000000).toFixed(1)}M Rows
                    </span>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
                    <span className="text-slate-400 block">Read Query Cache Hit Ratio</span>
                    <span className="text-base font-black text-teal-400 font-mono">
                      {part.cacheHitRatioPct}%
                    </span>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
                    <span className="text-slate-400 block">Average Query Latency</span>
                    <span className="text-base font-black text-amber-400 font-mono">
                      {part.avgQueryTimeMs} ms
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: REDIS CACHE & CDN */}
      {activeTab === 'cache_cdn' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-emerald-400" />
                Redis L2 Caching Clusters & Edge CDN
              </h2>
              <p className="text-xs text-slate-400">
                Multi-layer caching reducing database load by over 96% and lowering AI response latency for repetitive farming queries.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {CACHE_CLUSTERS.map((cluster, i) => (
              <div
                key={i}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4"
              >
                <div className="border-b border-slate-800 pb-3">
                  <span className="text-[10px] bg-slate-800 text-emerald-300 border border-slate-700 px-2 py-0.5 rounded-md font-bold uppercase block w-fit mb-1">
                    {cluster.type}
                  </span>
                  <h3 className="font-bold text-white text-sm">{cluster.clusterName}</h3>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Total Keys:</span>
                    <span className="font-mono font-bold text-emerald-400">
                      {(cluster.totalKeys / 1000000).toFixed(2)}M
                    </span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">Memory Allocated:</span>
                    <span className="font-mono font-bold text-teal-400">
                      {(cluster.memoryUsedMb / 1024).toFixed(1)} GB
                    </span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">Cache Hit Ratio:</span>
                    <span className="font-mono font-bold text-amber-400">
                      {cluster.hitRatioPct}%
                    </span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">Evictions / Sec:</span>
                    <span className="font-mono font-bold text-slate-300">
                      {cluster.evictionCount}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: RURAL OFFLINE DELTA SYNC */}
      {activeTab === 'offline_sync' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <div className="p-3 bg-emerald-950 border border-emerald-500/30 rounded-2xl text-emerald-400">
              <WifiOff className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">
                Rural Low-Bandwidth & Offline Delta Sync Engine
              </h2>
              <p className="text-xs text-slate-400">
                Protobuf binary delta compression empowering rural farmers on 2G/EDGE networks to log farm activities offline and auto-sync without data loss.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-1">
              <span className="text-slate-400 block">Bandwidth Saved Ratio</span>
              <span className="text-2xl font-black text-emerald-400 font-mono">
                {OFFLINE_SYNC_STATUS.avgCompressionRatioPct}%
              </span>
              <span className="text-[10px] text-slate-400 block">Via Protobuf Delta Compression</span>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-1">
              <span className="text-slate-400 block">Sync Success Rate</span>
              <span className="text-2xl font-black text-teal-400 font-mono">
                {OFFLINE_SYNC_STATUS.syncSuccessRatePct}%
              </span>
              <span className="text-[10px] text-slate-400 block">CRDT Conflict Resolution</span>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-1">
              <span className="text-slate-400 block">Active Syncing Rural Nodes</span>
              <span className="text-2xl font-black text-amber-400 font-mono">
                {OFFLINE_SYNC_STATUS.activeRuralNodesSyncing}
              </span>
              <span className="text-[10px] text-slate-400 block">Sector Level Aggregators</span>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-1">
              <span className="text-slate-400 block">Pending Delta Queue</span>
              <span className="text-2xl font-black text-blue-400 font-mono">
                {OFFLINE_SYNC_STATUS.totalPendingDeltas}
              </span>
              <span className="text-[10px] text-slate-400 block">Awaiting Connectivity</span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: GEMINI AI DEVOPS COPILOT */}
      {activeTab === 'ai_devops_copilot' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950 border border-emerald-500/30 rounded-3xl p-6 shadow-2xl space-y-5">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-0.5 shadow-lg">
                <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                  <Bot className="w-6 h-6 text-emerald-400" />
                </div>
              </div>
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  Gemini 3.6 Flash DevOps Infrastructure Architect
                </h2>
                <p className="text-xs text-slate-300">
                  Analyze microservice bottlenecks, optimize database compound indexes, tuning Redis TTLs, and reduce AI API token consumption costs.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Target Cloud Cluster:
                </label>
                <input
                  type="text"
                  value={targetCluster}
                  onChange={(e) => setTargetCluster(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl p-3 text-slate-100 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Performance Diagnostic Focus:
                </label>
                <input
                  type="text"
                  value={focusArea}
                  onChange={(e) => setFocusArea(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl p-3 text-slate-100 font-medium"
                />
              </div>
            </div>

            <button
              onClick={handleRunAiDiagnostics}
              disabled={isAiDiagnosing}
              className="bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black px-6 py-3 rounded-2xl shadow-xl transition-all flex items-center gap-2 text-xs uppercase tracking-wide"
            >
              {isAiDiagnosing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Running Cluster Diagnostics...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-slate-950" />
                  <span>Run AI Infrastructure Optimization Diagnostic</span>
                </>
              )}
            </button>

            {aiDiagResult && (
              <div className="bg-slate-950 border border-emerald-500/40 rounded-2xl p-5 space-y-4 animate-in fade-in text-xs">
                <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                  <span className="font-bold text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    Diagnostic Complete for {aiDiagResult.targetCluster}
                  </span>
                  <span className="bg-emerald-950 border border-emerald-500/30 text-emerald-300 px-2.5 py-1 rounded-full font-mono font-bold">
                    Est. Savings: ${aiDiagResult.costSavingsEstimateUsd}/mo
                  </span>
                </div>

                <p className="text-slate-200 leading-relaxed font-medium">
                  {aiDiagResult.diagnosticSummary}
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                    <span className="font-bold text-teal-400 block">Database Query Indexing Tip:</span>
                    <p className="text-slate-300">{aiDiagResult.databaseOptimizationTip}</p>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                    <span className="font-bold text-amber-400 block">AI Token Caching Strategy:</span>
                    <p className="text-slate-300">{aiDiagResult.aiTokenSavingStrategy}</p>
                  </div>
                </div>

                <div className="pt-2">
                  <span className="font-bold text-slate-300 block mb-1">Recommended Action Plan:</span>
                  <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                    {aiDiagResult.recommendedActions?.map((act: string, idx: number) => (
                      <li key={idx}>{act}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
