import React, { useState } from 'react';
import {
  ExpertProfile,
  ConsultationBooking,
  PrescriptionSlip,
  KnowledgeArticle,
  ForumPost,
  ForumComment,
  User,
  Language,
  ExpertSpecialty
} from '../../types';
import {
  SAMPLE_EXPERTS,
  SAMPLE_BOOKINGS,
  SAMPLE_KNOWLEDGE_ARTICLES,
  SAMPLE_FORUM_POSTS
} from '../../data/mockExpertData';
import { translations } from '../../data/translations';
import {
  Stethoscope,
  Star,
  Calendar,
  Clock,
  Phone,
  Video,
  MessageSquare,
  CheckCircle2,
  BookOpen,
  Award,
  Users,
  Search,
  Plus,
  Filter,
  ShieldCheck,
  MapPin,
  Sparkles,
  FileText,
  ThumbsUp,
  Share2,
  DollarSign,
  AlertTriangle,
  UserCheck,
  Send,
  Building,
  GraduationCap
} from 'lucide-react';

interface ExpertConsultationProps {
  currentUser: User;
  language: Language;
  onInitiateMomoPayment: (amountRwf: number, title: string) => void;
}

export const ExpertConsultation: React.FC<ExpertConsultationProps> = ({
  currentUser,
  language,
  onInitiateMomoPayment,
}) => {
  const t = translations[language];

  // Active Tab
  const [activeTab, setActiveTab] = useState<'experts' | 'ai_triage' | 'my_consultations' | 'knowledge' | 'forum' | 'expert_portal'>('experts');

  // State
  const [experts, setExperts] = useState<ExpertProfile[]>(SAMPLE_EXPERTS);
  const [bookings, setBookings] = useState<ConsultationBooking[]>(SAMPLE_BOOKINGS);
  const [articles, setArticles] = useState<KnowledgeArticle[]>(SAMPLE_KNOWLEDGE_ARTICLES);
  const [posts, setPosts] = useState<ForumPost[]>(SAMPLE_FORUM_POSTS);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('All');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All');

  // Booking Modal
  const [selectedExpertForBooking, setSelectedExpertForBooking] = useState<ExpertProfile | null>(null);
  const [bookingType, setBookingType] = useState<'Chat Consultation' | 'Voice Call' | 'Video Call' | 'Farm Visit'>('Video Call');
  const [bookingProblem, setBookingProblem] = useState('');

  // AI Triage State
  const [triageProblemInput, setTriageProblemInput] = useState('Potato leaf yellowing and brown spots after rains');
  const [triageLoading, setTriageLoading] = useState(false);
  const [triageResult, setTriageResult] = useState<any>(null);

  // Knowledge Reader Modal
  const [activeArticle, setActiveArticle] = useState<KnowledgeArticle | null>(null);

  // Forum New Post Modal & Comment Input
  const [showNewPostModal, setShowNewPostModal] = useState(false);
  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostCategory, setNewPostCategory] = useState<'Crops' | 'Livestock' | 'Pest Outbreak' | 'Equipment' | 'Markets'>('Crops');
  const [commentInputs, setCommentInputs] = useState<{ [postId: string]: string }>({});

  // Expert Registration Modal
  const [showRegistrationModal, setShowRegistrationModal] = useState(false);
  const [regName, setRegName] = useState('');
  const [regTitle, setRegTitle] = useState('Senior Veterinary Officer');
  const [regSpecialty, setRegSpecialty] = useState<ExpertSpecialty>('Veterinary Officer (Livestock)');
  const [regOrg, setRegOrg] = useState('Rwanda Agriculture Board (RAB)');
  const [regYears, setRegYears] = useState(5);
  const [regLicense, setRegLicense] = useState('RAB-VET-2026-099');

  // Prescription Form Modal for Expert Portal
  const [prescribeBookingId, setPrescribeBookingId] = useState<string | null>(null);
  const [rxDiagnosis, setRxDiagnosis] = useState('');
  const [rxMedicine, setRxMedicine] = useState('');
  const [rxDosage, setRxDosage] = useState('');
  const [rxSchedule, setRxSchedule] = useState('');

  // Filter Experts
  const filteredExperts = experts.filter((exp) => {
    const matchSpec = selectedSpecialty === 'All' || exp.specialty === selectedSpecialty;
    const matchDist = selectedDistrict === 'All' || exp.district === selectedDistrict;
    const matchSearch = exp.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        exp.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        exp.bio.toLowerCase().includes(searchQuery.toLowerCase());
    return matchSpec && matchDist && matchSearch;
  });

  // Handle Book Expert
  const handleConfirmBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedExpertForBooking) return;

    const fee = bookingType === 'Chat Consultation'
      ? selectedExpertForBooking.chatFeeRwf
      : bookingType === 'Video Call' || bookingType === 'Voice Call'
      ? selectedExpertForBooking.videoFeeRwf
      : selectedExpertForBooking.farmVisitFeeRwf;

    const newBooking: ConsultationBooking = {
      id: `consult-${Date.now().toString().slice(-4)}`,
      farmerId: currentUser.id,
      farmerName: currentUser.name,
      farmerPhone: currentUser.phone || '+250 788 000 111',
      farmerDistrict: currentUser.district || 'Musanze',
      expertId: selectedExpertForBooking.id,
      expertName: selectedExpertForBooking.fullName,
      expertSpecialty: selectedExpertForBooking.specialty,
      type: bookingType,
      status: 'confirmed',
      feeRwf: fee,
      scheduledTime: 'Tomorrow at 10:00 AM',
      problemSummary: bookingProblem || 'General crop/livestock health advisory',
      momoPaymentStatus: 'paid_escrow',
      createdAt: new Date().toISOString().split('T')[0],
    };

    setBookings([newBooking, ...bookings]);
    setSelectedExpertForBooking(null);
    setActiveTab('my_consultations');
    onInitiateMomoPayment(fee, `Consultation with ${selectedExpertForBooking.fullName}`);
  };

  // Handle AI Expert Triage
  const handleRunAiTriage = async () => {
    setTriageLoading(true);
    try {
      const res = await fetch('/api/ai/expert-triage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          problemSummary: triageProblemInput,
          district: currentUser.district || 'Musanze',
          language
        }),
      });
      const data = await res.json();
      setTriageResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setTriageLoading(false);
    }
  };

  // Handle Register Expert Profile
  const handleRegisterExpert = (e: React.FormEvent) => {
    e.preventDefault();
    const newExp: ExpertProfile = {
      id: `exp-${Date.now()}`,
      fullName: regName || currentUser.name,
      title: regTitle,
      specialty: regSpecialty,
      organization: regOrg,
      experienceYears: Number(regYears),
      district: currentUser.district || 'Musanze',
      languages: ['Kinyarwanda', 'English'],
      rating: 5.0,
      reviewCount: 1,
      verifiedBadge: true,
      licenseNumber: regLicense,
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
      bio: `Certified ${regSpecialty} officer serving smallholders across ${currentUser.district || 'Rwanda'}.`,
      chatFeeRwf: 2000,
      videoFeeRwf: 5000,
      farmVisitFeeRwf: 25000,
      availability: 'Online Now',
      phone: currentUser.phone || '+250 788 123 456',
      email: currentUser.email || 'expert@agriwise.rw',
    };

    setExperts([newExp, ...experts]);
    setShowRegistrationModal(false);
  };

  // Handle Issue RAB Prescription Slip
  const handleIssuePrescription = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prescribeBookingId) return;

    const rx: PrescriptionSlip = {
      id: `rx-${Date.now()}`,
      consultationId: prescribeBookingId,
      expertName: currentUser.name || 'Dr. Jean-Claude Habimana',
      licenseNumber: 'RAB-AGR-2026-901',
      diagnosis: rxDiagnosis || 'Crop Blight & Nutrient Deficit',
      recommendedChemicalOrMedicine: rxMedicine || 'Mancozeb 80% WP + Urea 46%',
      dosageInstructions: rxDosage || '50g per 20L backpack sprayer',
      applicationSchedule: rxSchedule || 'Spray every 7 days in early morning',
      preventativeMeasures: 'Improve drainage and crop rotation',
      issuedDate: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setBookings(bookings.map(b => b.id === prescribeBookingId ? { ...b, prescriptionSlip: rx, status: 'completed' } : b));
    setPrescribeBookingId(null);
  };

  // Handle New Forum Post
  const handleCreateForumPost = (e: React.FormEvent) => {
    e.preventDefault();
    const newPost: ForumPost = {
      id: `post-${Date.now()}`,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorRole: currentUser.role || 'farmer',
      district: currentUser.district || 'Musanze',
      title: newPostTitle,
      content: newPostContent,
      category: newPostCategory,
      upvotes: 1,
      commentsCount: 0,
      hasExpertAnswer: false,
      createdAt: 'Just now',
      comments: [],
    };

    setPosts([newPost, ...posts]);
    setShowNewPostModal(false);
  };

  // Handle Add Comment to Forum Post
  const handleAddComment = (postId: string) => {
    const text = commentInputs[postId];
    if (!text) return;

    const comment: ForumComment = {
      id: `c-${Date.now()}`,
      postId,
      authorName: currentUser.name,
      authorRole: currentUser.role || 'farmer',
      isVerifiedExpert: currentUser.role === 'expert',
      content: text,
      createdAt: 'Just now',
    };

    setPosts(posts.map(p => {
      if (p.id === postId) {
        return {
          ...p,
          commentsCount: p.commentsCount + 1,
          hasExpertAnswer: p.hasExpertAnswer || currentUser.role === 'expert',
          comments: [...(p.comments || []), comment]
        };
      }
      return p;
    }));

    setCommentInputs({ ...commentInputs, [postId]: '' });
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* Top Banner & Network Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden text-white">
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center space-x-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold mb-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>RAB & NAEB Certified Extension Tele-Agronomy</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Agricultural Expert Network & Knowledge Library
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mt-1">
              Connect directly with verified RAB agronomists, veterinary doctors, soil scientists, and agribusiness extension specialists across Rwanda.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setShowRegistrationModal(true)}
              className="bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 font-bold text-xs px-4 py-3 rounded-2xl shadow flex items-center space-x-2 transition-all"
            >
              <UserCheck className="w-4 h-4" />
              <span>Register as Verified Expert</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary Module Navigation Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2 flex flex-wrap items-center gap-2 text-xs">
        <button
          onClick={() => setActiveTab('experts')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'experts'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Stethoscope className="w-4 h-4" />
          <span>Find Experts ({filteredExperts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('ai_triage')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'ai_triage'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>AI + Human Triage</span>
        </button>

        <button
          onClick={() => setActiveTab('my_consultations')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'my_consultations'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Bookings & Prescriptions ({bookings.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('knowledge')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'knowledge'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <BookOpen className="w-4 h-4 text-blue-400" />
          <span>Knowledge Library ({articles.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('forum')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'forum'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <MessageSquare className="w-4 h-4 text-teal-300" />
          <span>Farmer Community Q&A</span>
        </button>
      </div>

      {/* TAB 1: FIND EXPERTS DIRECTORY */}
      {activeTab === 'experts' && (
        <div className="space-y-6">
          
          {/* Search & Filters */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-4">
            <div className="flex flex-col md:flex-row items-center gap-3">
              <div className="relative flex-1 w-full">
                <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search agronomists, vets, soil scientists, doctor name..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2 text-xs w-full md:w-auto">
                <select
                  value={selectedSpecialty}
                  onChange={(e) => setSelectedSpecialty(e.target.value)}
                  className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs"
                >
                  <option value="All">All Specialties</option>
                  <option value="Agronomist (Crops & Pests)">Agronomist (Crops & Pests)</option>
                  <option value="Veterinary Officer (Livestock)">Veterinary Officer (Livestock)</option>
                  <option value="Soil & Fertilizer Specialist">Soil & Fertilizer Specialist</option>
                  <option value="Agribusiness & Market Finance">Agribusiness & Finance</option>
                </select>

                <select
                  value={selectedDistrict}
                  onChange={(e) => setSelectedDistrict(e.target.value)}
                  className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs"
                >
                  <option value="All">All Districts</option>
                  <option value="Musanze">Musanze</option>
                  <option value="Huye">Huye</option>
                  <option value="Kigali City">Kigali City</option>
                  <option value="Rubavu">Rubavu</option>
                </select>
              </div>
            </div>
          </div>

          {/* Expert Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredExperts.map((exp) => (
              <div
                key={exp.id}
                className="bg-slate-900 border border-slate-800 hover:border-emerald-500/40 rounded-3xl p-6 shadow-xl flex flex-col justify-between space-y-4 text-white transition-all group"
              >
                <div>
                  <div className="flex items-start space-x-4">
                    <div className="relative">
                      <img
                        src={exp.avatarUrl}
                        alt={exp.fullName}
                        className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-500 shadow-md"
                      />
                      {exp.verifiedBadge && (
                        <span className="absolute -bottom-1 -right-1 bg-emerald-500 text-slate-950 rounded-full p-0.5" title="RAB Verified">
                          <CheckCircle2 className="w-4 h-4 fill-emerald-400 text-slate-950" />
                        </span>
                      )}
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
                          {exp.specialty}
                        </span>
                        <span className="text-[10px] text-amber-300 font-bold flex items-center space-x-1">
                          <Star className="w-3 h-3 fill-amber-300" />
                          <span>{exp.rating} ({exp.reviewCount})</span>
                        </span>
                      </div>

                      <h3 className="text-base font-black text-white">{exp.fullName}</h3>
                      <p className="text-xs text-slate-400">{exp.title} • {exp.organization}</p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 mt-3 line-clamp-2 leading-relaxed bg-slate-950 p-3 rounded-2xl border border-slate-800">
                    "{exp.bio}"
                  </p>

                  <div className="mt-3 grid grid-cols-3 gap-2 text-[11px] text-slate-300">
                    <div className="bg-slate-800/60 p-2 rounded-xl border border-slate-700/50">
                      <span className="text-slate-400 block text-[9px]">License:</span>
                      <span className="font-bold text-emerald-300 truncate block">{exp.licenseNumber}</span>
                    </div>

                    <div className="bg-slate-800/60 p-2 rounded-xl border border-slate-700/50">
                      <span className="text-slate-400 block text-[9px]">Experience:</span>
                      <span className="font-bold text-white">{exp.experienceYears} Years</span>
                    </div>

                    <div className="bg-slate-800/60 p-2 rounded-xl border border-slate-700/50">
                      <span className="text-slate-400 block text-[9px]">Station:</span>
                      <span className="font-bold text-teal-300">{exp.district}</span>
                    </div>
                  </div>
                </div>

                {/* Consultation Pricing & Booking Button */}
                <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Consultation Fee:</span>
                    <span className="font-black text-amber-300 text-sm">{exp.videoFeeRwf.toLocaleString()} RWF</span>
                  </div>

                  <button
                    onClick={() => {
                      setSelectedExpertForBooking(exp);
                      setBookingProblem('');
                    }}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 px-4 rounded-xl shadow-lg flex items-center space-x-1.5 transition-all"
                  >
                    <Video className="w-3.5 h-3.5" />
                    <span>Book Consultation</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: AI + HUMAN EXPERT TRIAGE */}
      {activeTab === 'ai_triage' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex items-center space-x-2 text-amber-400 font-bold text-sm">
              <Sparkles className="w-5 h-5" />
              <span>AI Symptom Triage & Expert Escalation Engine</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Describe your farm crop symptoms or livestock condition below. If AGRIWISE AI confidence is below 75%, it will automatically prepare a consultation ticket and escalate directly to a verified RAB Agronomist or Veterinary Doctor.
            </p>

            <div className="space-y-3">
              <textarea
                rows={3}
                value={triageProblemInput}
                onChange={(e) => setTriageProblemInput(e.target.value)}
                placeholder="e.g. Kinigi potato leaves turning dark brown with white mold underneath after heavy rain..."
                className="w-full bg-slate-800 border border-slate-700 rounded-2xl p-4 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
              />

              <button
                onClick={handleRunAiTriage}
                disabled={triageLoading}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-6 py-3 rounded-xl shadow-lg flex items-center space-x-2 transition-all"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>{triageLoading ? 'Running AI Triage...' : 'Run Symptom Triage'}</span>
              </button>
            </div>
          </div>

          {/* Triage Output Card */}
          {triageResult && (
            <div className="bg-slate-900 border border-amber-500/40 rounded-3xl p-6 shadow-2xl text-white space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">Triage Diagnosis</span>
                  <h3 className="text-base font-black text-white">{triageResult.triageDiagnosis}</h3>
                </div>

                <div className="text-right">
                  <span className="text-xs text-slate-400 block">AI Confidence Score:</span>
                  <span className="text-lg font-black text-amber-300">{triageResult.aiConfidencePct}%</span>
                </div>
              </div>

              <div className="bg-amber-950/40 border border-amber-500/30 p-4 rounded-2xl text-xs space-y-2">
                <div className="flex items-center space-x-2 text-amber-300 font-bold">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Reason for Expert Escalation:</span>
                </div>
                <p className="text-slate-200">{triageResult.reasonForHumanEscalation}</p>
              </div>

              <div className="bg-slate-800 p-4 rounded-2xl space-y-2 text-xs">
                <span className="text-slate-400 font-bold block">Immediate First-Aid Action:</span>
                <p className="text-emerald-300 font-medium">{triageResult.immediateFirstAidAdvice}</p>
              </div>

              <div className="pt-2 flex items-center justify-between border-t border-slate-800">
                <div className="text-xs">
                  <span className="text-slate-400 block">Recommended Specialist:</span>
                  <span className="font-bold text-white">{triageResult.recommendedExpertName} ({triageResult.recommendedSpecialty})</span>
                </div>

                <button
                  onClick={() => {
                    const exp = experts.find(e => e.id === triageResult.recommendedExpertId) || experts[0];
                    setSelectedExpertForBooking(exp);
                    setBookingProblem(triageProblemInput);
                  }}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow flex items-center space-x-1.5"
                >
                  <Stethoscope className="w-4 h-4" />
                  <span>Escalate to Expert (2,000 RWF)</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: BOOKINGS & DIGITAL PRESCRIPTIONS */}
      {activeTab === 'my_consultations' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <h3 className="text-base font-black">My Consultation Bookings & RAB Prescriptions</h3>
            <p className="text-xs text-slate-400">
              View confirmed appointments, call records, and digital medical/chemical prescription slips issued by certified RAB agronomists.
            </p>

            <div className="space-y-4">
              {bookings.map((b) => (
                <div key={b.id} className="bg-slate-800 border border-slate-700 rounded-2xl p-5 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-700 pb-3">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-black text-amber-300">Booking #{b.id}</span>
                        <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
                          {b.type}
                        </span>
                      </div>
                      <h4 className="text-base font-black text-white mt-0.5">{b.expertName} ({b.expertSpecialty})</h4>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block">Consultation Fee:</span>
                      <span className="text-base font-black text-emerald-400">{b.feeRwf.toLocaleString()} RWF</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs text-slate-300">
                    <div>
                      <span className="text-slate-500 block text-[10px]">Scheduled Time:</span>
                      <span className="font-bold text-white">{b.scheduledTime}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 block text-[10px]">Status:</span>
                      <span className="font-bold text-emerald-400 capitalize">{b.status}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 block text-[10px]">Escrow Status:</span>
                      <span className="font-bold text-teal-300 uppercase">{b.momoPaymentStatus.replace(/_/g, ' ')}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 block text-[10px]">District:</span>
                      <span className="text-slate-300">{b.farmerDistrict}</span>
                    </div>
                  </div>

                  {b.problemSummary && (
                    <p className="text-xs text-slate-300 bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                      📋 Problem Note: "{b.problemSummary}"
                    </p>
                  )}

                  {/* Digital RAB Prescription Slip */}
                  {b.prescriptionSlip ? (
                    <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-2xl p-4 text-xs space-y-2">
                      <div className="flex items-center justify-between border-b border-emerald-500/30 pb-2">
                        <span className="font-bold text-emerald-300 flex items-center space-x-1.5">
                          <FileText className="w-4 h-4 text-emerald-400" />
                          <span>RAB Digital Agricultural Prescription Slip (#{b.prescriptionSlip.id})</span>
                        </span>
                        <span className="text-[10px] text-slate-400">{b.prescriptionSlip.issuedDate}</span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-1 text-slate-200">
                        <div>
                          <strong className="text-emerald-400">Diagnosis:</strong> {b.prescriptionSlip.diagnosis}
                        </div>
                        <div>
                          <strong className="text-emerald-400">Prescribed Fungicide/Medicine:</strong> {b.prescriptionSlip.recommendedChemicalOrMedicine}
                        </div>
                        <div>
                          <strong className="text-emerald-400">Dosage:</strong> {b.prescriptionSlip.dosageInstructions}
                        </div>
                        <div>
                          <strong className="text-emerald-400">Schedule:</strong> {b.prescriptionSlip.applicationSchedule}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2 pt-1">
                      <button
                        onClick={() => setPrescribeBookingId(b.id)}
                        className="bg-slate-700 hover:bg-slate-600 text-emerald-300 font-bold text-xs py-2 px-3 rounded-xl border border-slate-600"
                      >
                        + Issue RAB Prescription (Expert Portal)
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: KNOWLEDGE LIBRARY */}
      {activeTab === 'knowledge' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-black">RAB Verified Extension Knowledge Library</h3>
                <p className="text-xs text-slate-400">
                  Access official research documents, video guides, and best practice manuals published by MINAGRI & RAB.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {articles.map((art) => (
                <div
                  key={art.id}
                  onClick={() => setActiveArticle(art)}
                  className="bg-slate-800 border border-slate-700 hover:border-emerald-500/40 rounded-3xl overflow-hidden shadow-lg text-white flex flex-col justify-between cursor-pointer transition-all group"
                >
                  <div>
                    <div className="relative h-44 w-full bg-slate-950 overflow-hidden">
                      <img
                        src={art.imageUrl}
                        alt={art.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <span className="absolute top-3 left-3 bg-emerald-950/90 text-emerald-300 text-[10px] font-bold px-2.5 py-1 rounded-full border border-emerald-500/40 backdrop-blur">
                        {art.category}
                      </span>
                    </div>

                    <div className="p-4 space-y-2">
                      <div className="flex items-center justify-between text-[10px] text-slate-400">
                        <span>{art.authorName}</span>
                        <span>{art.readingTimeMinutes} min read</span>
                      </div>

                      <h4 className="text-sm font-black text-white leading-snug line-clamp-2">{art.title}</h4>
                      <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{art.summary}</p>
                    </div>
                  </div>

                  <div className="p-4 pt-0 flex items-center justify-between text-xs text-emerald-400 font-bold">
                    <span>Read RAB Guide ➔</span>
                    <span className="text-slate-400 text-[10px]">👍 {art.likesCount}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: FARMER COMMUNITY FORUM Q&A */}
      {activeTab === 'forum' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-black">Farmer Peer Community & Extension Q&A</h3>
                <p className="text-xs text-slate-400">
                  Ask questions, share real-time pest outbreaks, and receive verified answers from RAB agronomists and peer farmers.
                </p>
              </div>

              <button
                onClick={() => setShowNewPostModal(true)}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow flex items-center space-x-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Ask Community Question</span>
              </button>
            </div>

            <div className="space-y-6">
              {posts.map((post) => (
                <div key={post.id} className="bg-slate-800 border border-slate-700 rounded-3xl p-6 space-y-4 text-white shadow-md">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center space-x-2 text-xs">
                        <span className="font-bold text-emerald-300">{post.authorName}</span>
                        <span className="text-slate-400">• {post.district}</span>
                        <span className="bg-slate-700 text-slate-300 text-[10px] font-bold px-2 py-0.5 rounded-full">
                          {post.category}
                        </span>
                      </div>

                      <h4 className="text-base font-black text-white mt-1">{post.title}</h4>
                    </div>

                    <span className="text-[10px] text-slate-400">{post.createdAt}</span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">{post.content}</p>

                  {post.imageUrl && (
                    <img src={post.imageUrl} alt="Pest photo" className="w-full max-h-56 object-cover rounded-2xl border border-slate-700" />
                  )}

                  {/* Comments Thread */}
                  <div className="pt-3 border-t border-slate-700 space-y-3">
                    <h5 className="text-xs font-bold text-slate-400">Responses & Expert Answers ({post.commentsCount}):</h5>
                    
                    {(post.comments || []).map((c) => (
                      <div key={c.id} className={`p-3 rounded-2xl text-xs space-y-1 ${c.isVerifiedExpert ? 'bg-emerald-950/40 border border-emerald-500/30' : 'bg-slate-900 border border-slate-800'}`}>
                        <div className="flex items-center space-x-2">
                          <span className={`font-bold ${c.isVerifiedExpert ? 'text-emerald-300' : 'text-slate-300'}`}>{c.authorName}</span>
                          {c.isVerifiedExpert && (
                            <span className="bg-emerald-500 text-slate-950 text-[9px] font-black px-1.5 py-0.5 rounded-full flex items-center space-x-1">
                              <CheckCircle2 className="w-3 h-3 text-slate-950" />
                              <span>Verified RAB Expert</span>
                            </span>
                          )}
                        </div>
                        <p className="text-slate-200">{c.content}</p>
                      </div>
                    ))}

                    {/* Add Comment */}
                    <div className="flex items-center space-x-2 pt-2">
                      <input
                        type="text"
                        placeholder="Write a helpful reply or expert advice..."
                        value={commentInputs[post.id] || ''}
                        onChange={(e) => setCommentInputs({ ...commentInputs, [post.id]: e.target.value })}
                        className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                      />
                      <button
                        onClick={() => handleAddComment(post.id)}
                        className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2 rounded-xl"
                      >
                        Reply
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: BOOK CONSULTATION */}
      {selectedExpertForBooking && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white">Book Consultation with {selectedExpertForBooking.fullName}</h3>
              <button onClick={() => setSelectedExpertForBooking(null)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <form onSubmit={handleConfirmBooking} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Consultation Channel:</label>
                <select
                  value={bookingType}
                  onChange={(e) => setBookingType(e.target.value as any)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  <option value="Chat Consultation">Chat Consultation ({selectedExpertForBooking.chatFeeRwf.toLocaleString()} RWF)</option>
                  <option value="Voice Call">Voice Call ({selectedExpertForBooking.videoFeeRwf.toLocaleString()} RWF)</option>
                  <option value="Video Call">Video Tele-Consult ({selectedExpertForBooking.videoFeeRwf.toLocaleString()} RWF)</option>
                  <option value="Farm Visit">Direct Farm Visit ({selectedExpertForBooking.farmVisitFeeRwf.toLocaleString()} RWF)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Describe Farm Problem / Symptoms:</label>
                <textarea
                  rows={3}
                  value={bookingProblem}
                  onChange={(e) => setBookingProblem(e.target.value)}
                  placeholder="e.g., Potato leaf blight in Kinigi sector..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div className="pt-2 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setSelectedExpertForBooking(null)}
                  className="flex-1 bg-slate-800 text-slate-300 font-bold py-2.5 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl shadow"
                >
                  Pay MoMo Escrow
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: REGISTER AS EXPERT */}
      {showRegistrationModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white">Register as Verified RAB Extension Expert</h3>
              <button onClick={() => setShowRegistrationModal(false)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <form onSubmit={handleRegisterExpert} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Full Name:</label>
                <input
                  type="text"
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="Dr. Jean-Baptiste Habimana"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Specialty:</label>
                <select
                  value={regSpecialty}
                  onChange={(e) => setRegSpecialty(e.target.value as any)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  <option value="Agronomist (Crops & Pests)">Agronomist (Crops & Pests)</option>
                  <option value="Veterinary Officer (Livestock)">Veterinary Officer (Livestock)</option>
                  <option value="Soil & Fertilizer Specialist">Soil & Fertilizer Specialist</option>
                  <option value="Agribusiness & Market Finance">Agribusiness & Market Finance</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">RAB / NAEB License Number:</label>
                <input
                  type="text"
                  value={regLicense}
                  onChange={(e) => setRegLicense(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div className="pt-2 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowRegistrationModal(false)}
                  className="flex-1 bg-slate-800 text-slate-300 font-bold py-2.5 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl shadow"
                >
                  Submit for Verification
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ISSUE RAB PRESCRIPTION SLIP */}
      {prescribeBookingId && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-lg w-full text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white">Issue RAB Digital Agricultural Prescription</h3>
              <button onClick={() => setPrescribeBookingId(null)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <form onSubmit={handleIssuePrescription} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Diagnosis:</label>
                <input
                  type="text"
                  value={rxDiagnosis}
                  onChange={(e) => setRxDiagnosis(e.target.value)}
                  placeholder="e.g., Potato Late Blight (Phytophthora infestans)"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Recommended Fungicide / Medicine:</label>
                <input
                  type="text"
                  value={rxMedicine}
                  onChange={(e) => setRxMedicine(e.target.value)}
                  placeholder="e.g., Mancozeb 80% WP"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Dosage:</label>
                  <input
                    type="text"
                    value={rxDosage}
                    onChange={(e) => setRxDosage(e.target.value)}
                    placeholder="e.g. 50g per 20L backpack sprayer"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Application Schedule:</label>
                  <input
                    type="text"
                    value={rxSchedule}
                    onChange={(e) => setRxSchedule(e.target.value)}
                    placeholder="e.g. Spray early morning every 7 days"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>
              </div>

              <div className="pt-2 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setPrescribeBookingId(null)}
                  className="flex-1 bg-slate-800 text-slate-300 font-bold py-2.5 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl shadow"
                >
                  Issue Prescription Slip
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: KNOWLEDGE ARTICLE READER */}
      {activeArticle && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-2xl w-full text-white space-y-4 max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs font-bold text-emerald-400 uppercase">{activeArticle.category} • {activeArticle.organization}</span>
              <button onClick={() => setActiveArticle(null)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <h2 className="text-lg font-black text-white">{activeArticle.title}</h2>
            <p className="text-xs text-slate-400">By {activeArticle.authorName} ({activeArticle.authorRole}) • Published {activeArticle.publishedDate}</p>

            <img src={activeArticle.imageUrl} alt={activeArticle.title} className="w-full h-56 object-cover rounded-2xl border border-slate-800" />

            <div className="text-xs text-slate-300 whitespace-pre-line leading-relaxed bg-slate-950 p-4 rounded-2xl border border-slate-800">
              {activeArticle.contentMarkdown}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setActiveArticle(null)}
                className="bg-emerald-600 text-white font-bold text-xs py-2 px-5 rounded-xl shadow"
              >
                Close Article
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
