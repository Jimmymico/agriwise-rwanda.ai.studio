import React, { useState } from 'react';
import {
  MarketplaceProductFull,
  MarketplaceOffer,
  MarketplaceOrderFull,
  TransporterJob,
  MarketPriceRecord,
  User,
  Language,
  UserRole
} from '../../types';
import {
  SAMPLE_PRODUCTS,
  SAMPLE_OFFERS,
  SAMPLE_ORDERS,
  SAMPLE_TRANSPORTER_JOBS,
  SAMPLE_MARKET_PRICES
} from '../../data/mockMarketplaceData';
import { translations } from '../../data/translations';
import {
  Store,
  Plus,
  Phone,
  ShoppingCart,
  Filter,
  CheckCircle2,
  Tag,
  MapPin,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
  MessageSquare,
  Truck,
  Sparkles,
  Search,
  Award,
  DollarSign,
  UserCheck,
  Star,
  RefreshCw,
  Send,
  Package,
  Clock,
  Briefcase,
  Users
} from 'lucide-react';

interface MarketplaceProps {
  currentUser: User;
  language: Language;
  onInitiateMomoPayment: (amountRwf: number, title: string) => void;
}

export const Marketplace: React.FC<MarketplaceProps> = ({
  currentUser,
  language,
  onInitiateMomoPayment
}) => {
  const t = translations[language];

  // Primary Tab State
  const [activeTab, setActiveTab] = useState<'browse' | 'ai_advisor' | 'negotiations' | 'my_orders' | 'transporters'>('browse');

  // Active Role Portal View (Farmer, Buyer, Agro-dealer, Transporter, Cooperative)
  const [activePortalRole, setActivePortalRole] = useState<UserRole>(currentUser.role || 'farmer');

  // Products state
  const [products, setProducts] = useState<MarketplaceProductFull[]>(SAMPLE_PRODUCTS);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All');
  const [selectedGrade, setSelectedGrade] = useState<string>('All');

  // Offers state
  const [offers, setOffers] = useState<MarketplaceOffer[]>(SAMPLE_OFFERS);

  // Orders state
  const [orders, setOrders] = useState<MarketplaceOrderFull[]>(SAMPLE_ORDERS);

  // Transporter jobs state
  const [jobs, setJobs] = useState<TransporterJob[]>(SAMPLE_TRANSPORTER_JOBS);

  // Modals
  const [showPostModal, setShowPostModal] = useState(false);
  const [showOfferModal, setShowOfferModal] = useState<MarketplaceProductFull | null>(null);
  const [selectedProductDetails, setSelectedProductDetails] = useState<MarketplaceProductFull | null>(null);

  // New Listing Form
  const [postTitle, setPostTitle] = useState('Organic RAB Kinigi Potatoes');
  const [postCategory, setPostCategory] = useState<'Produce' | 'Inputs' | 'Livestock' | 'Machinery'>('Produce');
  const [postSubcategory, setPostSubcategory] = useState('Irish Potatoes');
  const [postQty, setPostQty] = useState<number>(10);
  const [postUnit, setPostUnit] = useState<'Kg' | 'Tons' | 'Liters' | 'Bags' | 'Heads' | 'Units'>('Tons');
  const [postPrice, setPostPrice] = useState<number>(420000);
  const [postGrade, setPostGrade] = useState<'Grade A1 Export' | 'Grade A2 Local' | 'Standard Bulk'>('Grade A1 Export');
  const [postDesc, setPostDesc] = useState('RAB inspected export grade produce harvested from volcanic Musanze soils.');

  // Negotiation Form
  const [offerPrice, setOfferPrice] = useState<number>(400000);
  const [offerQty, setOfferQty] = useState<number>(5);
  const [offerNote, setOfferNote] = useState('');

  // AI Marketplace Query state
  const [aiQuery, setAiQuery] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiAdviceResponse, setAiAdviceResponse] = useState<any>(null);

  // Filtered Products
  const filteredProducts = products.filter((prod) => {
    const matchCat = selectedCategory === 'All' || prod.category === selectedCategory;
    const matchDist = selectedDistrict === 'All' || prod.district === selectedDistrict;
    const matchGrade = selectedGrade === 'All' || prod.qualityGrade === selectedGrade;
    const matchSearch = prod.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        prod.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        prod.sellerName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchDist && matchGrade && matchSearch;
  });

  // Handle Create New Listing
  const handlePublishListing = (e: React.FormEvent) => {
    e.preventDefault();
    const newProduct: MarketplaceProductFull = {
      id: `prod-${Date.now()}`,
      sellerId: currentUser.id,
      sellerName: currentUser.name,
      sellerRole: activePortalRole,
      sellerPhone: currentUser.phone || '+250 788 123 456',
      sellerRating: 5.0,
      sellerVerified: true,
      district: currentUser.district || 'Musanze',
      sector: currentUser.sector || 'Kinigi',
      title: postTitle,
      category: postCategory,
      subcategory: postSubcategory,
      availableQuantity: Number(postQty),
      unit: postUnit,
      pricePerUnitRwf: Number(postPrice),
      minOrderQuantity: 1,
      qualityGrade: postGrade,
      imageUrl: postCategory === 'Produce'
        ? 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=800&auto=format&fit=crop&q=80'
        : postCategory === 'Inputs'
        ? 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800&auto=format&fit=crop&q=80'
        : postCategory === 'Livestock'
        ? 'https://images.unsplash.com/photo-1546445317-29f4545f9d52?w=800&auto=format&fit=crop&q=80'
        : 'https://images.unsplash.com/photo-1592417817098-8f3d6ef23a28?w=800&auto=format&fit=crop&q=80',
      description: postDesc,
      status: 'available',
      createdAt: new Date().toISOString().split('T')[0],
    };

    setProducts([newProduct, ...products]);
    setShowPostModal(false);
  };

  // Handle Submit Negotiation Offer
  const handleSubmitOffer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!showOfferModal) return;

    const newOffer: MarketplaceOffer = {
      id: `off-${Date.now()}`,
      productId: showOfferModal.id,
      productTitle: showOfferModal.title,
      buyerId: currentUser.id,
      buyerName: currentUser.name,
      buyerPhone: currentUser.phone || '+250 788 000 111',
      sellerId: showOfferModal.sellerId,
      sellerName: showOfferModal.sellerName,
      offeredPricePerUnitRwf: Number(offerPrice),
      offeredQuantity: Number(offerQty),
      totalOfferAmountRwf: Number(offerPrice) * Number(offerQty),
      status: 'pending',
      notes: offerNote || 'Negotiated bulk purchase request',
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setOffers([newOffer, ...offers]);
    setShowOfferModal(null);
    setActiveTab('negotiations');
  };

  // Handle Direct Buy Now via MoMo Escrow
  const handleBuyNow = (product: MarketplaceProductFull) => {
    const subtotal = product.pricePerUnitRwf * product.minOrderQuantity;
    const deliveryFee = 25000;
    const total = subtotal + deliveryFee;

    const newOrder: MarketplaceOrderFull = {
      id: `ord-${Date.now().toString().slice(-4)}`,
      productId: product.id,
      productTitle: product.title,
      category: product.category,
      sellerId: product.sellerId,
      sellerName: product.sellerName,
      sellerPhone: product.sellerPhone,
      buyerId: currentUser.id,
      buyerName: currentUser.name,
      buyerPhone: currentUser.phone || '+250 788 000 111',
      quantity: product.minOrderQuantity,
      unit: product.unit,
      pricePerUnitRwf: product.pricePerUnitRwf,
      subtotalAmountRwf: subtotal,
      deliveryFeeRwf: deliveryFee,
      totalAmountRwf: total,
      deliveryDistrict: currentUser.district || 'Musanze',
      deliveryAddress: 'Direct Farm Gate Delivery',
      escrowStatus: 'held_in_escrow',
      orderStatus: 'accepted',
      trackingCode: `TRK-RW-${Math.floor(10000 + Math.random() * 90000)}`,
      createdAt: new Date().toISOString().split('T')[0] + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setOrders([newOrder, ...orders]);
    onInitiateMomoPayment(total, `Escrow Buy: ${product.title}`);
  };

  // AI Market Intelligence Assistant query call
  const handleFetchAiMarketIntelligence = async () => {
    setAiLoading(true);
    try {
      const res = await fetch('/api/ai/marketplace', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'price_prediction',
          cropName: aiQuery || 'Irish Potatoes',
          district: currentUser.district || 'Musanze',
          language
        }),
      });
      const data = await res.json();
      setAiAdviceResponse(data);
    } catch (e) {
      console.error(e);
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* Top Banner & Multi-Role Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden text-white">
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center space-x-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold mb-2">
              <Store className="w-4 h-4 text-emerald-400" />
              <span>{t.marketplaceTitle} • Smart Agriculture Commerce</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              National Commodity & Input Marketplace
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mt-1">
              Connect smallholder farmers, bulk wholesale buyers, certified agro-dealers, and freight transporters with MoMo Escrow protection across Rwanda.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setShowPostModal(true)}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-3 rounded-2xl shadow-lg flex items-center space-x-2 transition-all hover:scale-105"
            >
              <Plus className="w-4 h-4" />
              <span>{t.postListing}</span>
            </button>
          </div>
        </div>

        {/* Portal User Role Switcher */}
        <div className="mt-6 pt-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-2">
            <Users className="w-4 h-4 text-emerald-400" />
            <span className="text-slate-400 font-bold">Active Portal Mode:</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {[
              { role: 'farmer', label: '🌾 Farmer Portal', icon: Store },
              { role: 'buyer', label: '🛒 Buyer / Consumer', icon: ShoppingCart },
              { role: 'agrodealer', label: '🏪 Agro-dealer', icon: ShieldCheck },
              { role: 'transporter', label: '🚛 Transporter', icon: Truck },
              { role: 'cooperative', label: '🏢 Cooperative Bulk', icon: Briefcase },
            ].map((p) => (
              <button
                key={p.role}
                onClick={() => setActivePortalRole(p.role as UserRole)}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all flex items-center space-x-1.5 ${
                  activePortalRole === p.role
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <span>{p.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Primary Marketplace Navigation Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2 flex flex-wrap items-center gap-2 text-xs">
        <button
          onClick={() => setActiveTab('browse')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'browse'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Store className="w-4 h-4" />
          <span>Browse Marketplace ({filteredProducts.length})</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('ai_advisor');
            if (!aiAdviceResponse) handleFetchAiMarketIntelligence();
          }}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'ai_advisor'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>AI Price & Market Intelligence</span>
        </button>

        <button
          onClick={() => setActiveTab('negotiations')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all relative ${
            activeTab === 'negotiations'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Offers & Chat</span>
          {offers.length > 0 && (
            <span className="bg-amber-500 text-slate-950 font-black px-1.5 py-0.5 rounded-full text-[10px]">
              {offers.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('my_orders')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'my_orders'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>Orders & Escrow ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('transporters')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'transporters'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Truck className="w-4 h-4" />
          <span>Transport Freight ({jobs.length})</span>
        </button>
      </div>

      {/* TAB 1: BROWSE MARKETPLACE */}
      {activeTab === 'browse' && (
        <div className="space-y-6">
          
          {/* Search and Filters */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-4">
            <div className="flex flex-col md:flex-row items-center gap-3">
              <div className="relative flex-1 w-full">
                <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search maize, beans, potatoes, NPK fertilizer, solar pump..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2 text-xs w-full md:w-auto">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs"
                >
                  <option value="All">All Categories</option>
                  <option value="Produce">Produce (Crops)</option>
                  <option value="Inputs">Agri-Inputs & Fertilizer</option>
                  <option value="Livestock">Livestock</option>
                  <option value="Machinery">Equipment & Solar</option>
                </select>

                <select
                  value={selectedDistrict}
                  onChange={(e) => setSelectedDistrict(e.target.value)}
                  className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs"
                >
                  <option value="All">All 30 Districts</option>
                  <option value="Musanze">Musanze</option>
                  <option value="Nyagatare">Nyagatare</option>
                  <option value="Huye">Huye</option>
                  <option value="Rubavu">Rubavu</option>
                  <option value="Bugesera">Bugesera</option>
                  <option value="Kigali City">Kigali City</option>
                </select>

                <select
                  value={selectedGrade}
                  onChange={(e) => setSelectedGrade(e.target.value)}
                  className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs"
                >
                  <option value="All">All Quality Grades</option>
                  <option value="Grade A1 Export">Grade A1 (RAB Certified)</option>
                  <option value="Grade A2 Local">Grade A2 (Standard Quality)</option>
                  <option value="Standard Bulk">Standard Bulk</option>
                </select>
              </div>
            </div>
          </div>

          {/* Product Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((prod) => (
              <div
                key={prod.id}
                className="bg-slate-900 border border-slate-800 hover:border-emerald-500/40 rounded-3xl overflow-hidden shadow-xl flex flex-col justify-between text-white transition-all group"
              >
                <div>
                  {/* Image & Badges */}
                  <div className="relative h-48 w-full bg-slate-950 overflow-hidden">
                    <img
                      src={prod.imageUrl}
                      alt={prod.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                    
                    <span className="absolute top-3 left-3 bg-emerald-950/90 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold px-2.5 py-1 rounded-full backdrop-blur flex items-center space-x-1">
                      <Award className="w-3 h-3 text-emerald-400" />
                      <span>{prod.qualityGrade}</span>
                    </span>

                    <span className="absolute top-3 right-3 bg-slate-900/90 text-amber-300 border border-slate-700 text-[10px] font-bold px-2 py-1 rounded-full backdrop-blur flex items-center space-x-1">
                      <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                      <span>{prod.sellerRating}</span>
                    </span>

                    <span className="absolute bottom-3 left-3 bg-slate-900/90 text-slate-200 text-[11px] font-semibold px-2.5 py-1 rounded-lg backdrop-blur flex items-center space-x-1">
                      <MapPin className="w-3 h-3 text-teal-400" />
                      <span>{prod.district}, {prod.sector}</span>
                    </span>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 space-y-3">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-emerald-400 font-bold uppercase tracking-wider">{prod.category} • {prod.subcategory}</span>
                      <span className="text-slate-400">{prod.sellerName}</span>
                    </div>

                    <h3 className="text-base font-black text-white leading-snug line-clamp-2">{prod.title}</h3>
                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{prod.description}</p>

                    {prod.cooperativeName && (
                      <div className="bg-slate-800/60 rounded-xl p-2 text-[11px] text-slate-300 flex items-center space-x-1.5 border border-slate-700/50">
                        <Briefcase className="w-3.5 h-3.5 text-blue-400" />
                        <span>Coop: <strong>{prod.cooperativeName}</strong></span>
                      </div>
                    )}

                    <div className="pt-2 flex items-center justify-between border-t border-slate-800 text-xs">
                      <div>
                        <span className="text-slate-400 block text-[10px]">Price per {prod.unit}:</span>
                        <span className="font-black text-amber-300 text-base">{prod.pricePerUnitRwf.toLocaleString()} RWF</span>
                      </div>

                      <div className="text-right">
                        <span className="text-slate-400 block text-[10px]">Available Stock:</span>
                        <span className="font-bold text-emerald-400 text-xs">{prod.availableQuantity} {prod.unit}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="p-5 pt-0 grid grid-cols-2 gap-2 text-xs">
                  <button
                    onClick={() => handleBuyNow(prod)}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 px-3 rounded-xl shadow-lg flex items-center justify-center space-x-1.5 transition-all"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                    <span>MoMo Buy</span>
                  </button>

                  <button
                    onClick={() => {
                      setShowOfferModal(prod);
                      setOfferPrice(Math.round(prod.pricePerUnitRwf * 0.95));
                      setOfferQty(prod.minOrderQuantity || 1);
                    }}
                    className="w-full bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-white font-bold py-2.5 px-3 rounded-xl flex items-center justify-center space-x-1.5 border border-slate-700 transition-all"
                  >
                    <DollarSign className="w-3.5 h-3.5 text-amber-400" />
                    <span>Negotiate</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: AI PRICE & MARKET INTELLIGENCE */}
      {activeTab === 'ai_advisor' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex items-center space-x-2 text-amber-400 font-bold text-sm">
              <Sparkles className="w-5 h-5" />
              <span>Real-Time AI Market Price Predictor & Strategic Advisory</span>
            </div>
            
            <p className="text-xs text-slate-300">
              AGRIWISE AI analyzes current demand signals, transport freight indices, and harvest yields across Rwanda's 30 districts to recommend optimal selling prices and high-demand markets.
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
              <input
                type="text"
                value={aiQuery}
                onChange={(e) => setAiQuery(e.target.value)}
                placeholder="Enter commodity (e.g., Kinigi Potatoes, Dry Maize H513, Red Beans)..."
                className="w-full sm:flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
              />
              <button
                onClick={handleFetchAiMarketIntelligence}
                disabled={aiLoading}
                className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-6 py-3 rounded-xl shadow-lg flex items-center justify-center space-x-2 transition-all"
              >
                {aiLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4 text-amber-300" />}
                <span>{aiLoading ? 'Analyzing Markets...' : 'Analyze Market Trends'}</span>
              </button>
            </div>
          </div>

          {/* AI Response Card */}
          {aiAdviceResponse && (
            <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl p-6 shadow-2xl text-white space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-base font-black text-white">{aiAdviceResponse.commodity} Market Intelligence Report</h3>
                  <p className="text-xs text-slate-400">Target District: {currentUser.district || 'Musanze'}</p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400 block">Suggested Benchmark:</span>
                  <span className="text-xl font-black text-amber-300">{aiAdviceResponse.suggestedPricePerKgRwf} RWF / Kg</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60 space-y-1">
                  <span className="text-slate-400 font-bold block">Market Trend Forecast</span>
                  <div className="flex items-center space-x-2 text-emerald-400 font-black text-sm">
                    <TrendingUp className="w-4 h-4" />
                    <span className="capitalize">{aiAdviceResponse.trendForecast} Demand Surge</span>
                  </div>
                </div>

                <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60 space-y-1">
                  <span className="text-slate-400 font-bold block">Recommended Sell Window</span>
                  <p className="text-amber-300 font-semibold">{aiAdviceResponse.recommendedSellWindow}</p>
                </div>

                <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60 space-y-1">
                  <span className="text-slate-400 font-bold block">High Demand Markets</span>
                  <p className="text-emerald-300 font-medium">{(aiAdviceResponse.highDemandDistricts || []).join(', ')}</p>
                </div>
              </div>

              <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-2xl p-4 text-xs space-y-2">
                <h4 className="font-bold text-emerald-300 flex items-center space-x-2">
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>AI Strategic Commerce Insight:</span>
                </h4>
                <p className="text-slate-200 leading-relaxed">{aiAdviceResponse.aiMarketInsight}</p>
                <div className="pt-2 border-t border-emerald-500/20 text-amber-300 font-medium">
                  💡 Negotiation Tip: {aiAdviceResponse.negotiationTip}
                </div>
              </div>
            </div>
          )}

          {/* Regional District Price Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <h3 className="text-sm font-black text-slate-200">National District Commodity Benchmark Prices</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                    <th className="py-3 px-3">Commodity</th>
                    <th className="py-3 px-3">District</th>
                    <th className="py-3 px-3">Current Price (RWF/Kg)</th>
                    <th className="py-3 px-3">Trend</th>
                    <th className="py-3 px-3">Primary Buyer Market</th>
                    <th className="py-3 px-3">AI Action Advice</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {SAMPLE_MARKET_PRICES.map((prc) => (
                    <tr key={prc.id} className="hover:bg-slate-800/40">
                      <td className="py-3.5 px-3 font-bold text-white">{prc.commodity}</td>
                      <td className="py-3.5 px-3 text-teal-300 font-medium">{prc.district}</td>
                      <td className="py-3.5 px-3 font-black text-amber-300">{prc.pricePerKgRwf} RWF</td>
                      <td className="py-3.5 px-3">
                        <span className={`inline-flex items-center space-x-1 font-bold ${prc.priceTrend === 'up' ? 'text-emerald-400' : 'text-slate-400'}`}>
                          {prc.priceTrend === 'up' ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                          <span>+{prc.weeklyChangePct}%</span>
                        </span>
                      </td>
                      <td className="py-3.5 px-3 text-slate-300">{prc.highDemandMarket}</td>
                      <td className="py-3.5 px-3 text-emerald-400 font-medium">{prc.recommendedSellTime}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: OFFERS & NEGOTIATION CHAT */}
      {activeTab === 'negotiations' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <h3 className="text-base font-black">Active Price Negotiations & Counter-Offers</h3>
            <p className="text-xs text-slate-400">
              Negotiate price and order quantity with buyers or sellers before placing escrow payment.
            </p>

            <div className="space-y-4">
              {offers.map((off) => (
                <div key={off.id} className="bg-slate-800 border border-slate-700 rounded-2xl p-4 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-700 pb-3">
                    <div>
                      <span className="text-[10px] text-emerald-400 font-bold uppercase">Product: {off.productTitle}</span>
                      <h4 className="text-sm font-black text-white">Buyer: {off.buyerName} ({off.buyerPhone})</h4>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block">Offered Total:</span>
                      <span className="text-sm font-black text-amber-300">{off.totalOfferAmountRwf.toLocaleString()} RWF</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs text-slate-300">
                    <div>
                      <span className="text-slate-500 block text-[10px]">Offered Unit Price:</span>
                      <span className="font-bold text-white">{off.offeredPricePerUnitRwf.toLocaleString()} RWF</span>
                    </div>

                    <div>
                      <span className="text-slate-500 block text-[10px]">Offered Qty:</span>
                      <span className="font-bold text-white">{off.offeredQuantity}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 block text-[10px]">Status:</span>
                      <span className="font-bold text-amber-400 capitalize">{off.status}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 block text-[10px]">Time:</span>
                      <span className="text-slate-400">{off.createdAt}</span>
                    </div>
                  </div>

                  {off.notes && (
                    <p className="text-xs text-slate-400 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                      💬 "{off.notes}"
                    </p>
                  )}

                  <div className="flex items-center space-x-2 pt-2 text-xs">
                    <button
                      onClick={() => {
                        onInitiateMomoPayment(off.totalOfferAmountRwf, `Accepted Offer: ${off.productTitle}`);
                        setOffers(offers.map(o => o.id === off.id ? { ...o, status: 'accepted' } : o));
                      }}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 px-4 rounded-xl shadow transition-all"
                    >
                      Accept & Pay MoMo
                    </button>
                    <button
                      onClick={() => {
                        setOffers(offers.map(o => o.id === off.id ? { ...o, status: 'rejected' } : o));
                      }}
                      className="bg-slate-700 hover:bg-slate-600 text-slate-300 font-bold py-2 px-4 rounded-xl transition-all"
                    >
                      Decline
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: ORDERS & ESCROW MANAGEMENT */}
      {activeTab === 'my_orders' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <h3 className="text-base font-black">Escrow Orders & Freight Tracking</h3>
            <p className="text-xs text-slate-400">
              Payments are held securely in MoMo Escrow until you confirm receipt of quality produce.
            </p>

            <div className="space-y-4">
              {orders.map((ord) => (
                <div key={ord.id} className="bg-slate-800 border border-slate-700 rounded-2xl p-5 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-700 pb-3">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-black text-amber-300">Order #{ord.id}</span>
                        <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
                          {ord.trackingCode}
                        </span>
                      </div>
                      <h4 className="text-base font-black text-white mt-0.5">{ord.productTitle}</h4>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block">Total Paid (MoMo Escrow):</span>
                      <span className="text-lg font-black text-emerald-400">{ord.totalAmountRwf.toLocaleString()} RWF</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[10px]">Seller:</span>
                      <span className="font-bold text-white">{ord.sellerName}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">Quantity:</span>
                      <span className="font-bold text-white">{ord.quantity} {ord.unit}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">Escrow Status:</span>
                      <span className="font-bold text-emerald-400 uppercase">{ord.escrowStatus.replace(/_/g, ' ')}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">Delivery Status:</span>
                      <span className="font-bold text-amber-300 uppercase">{ord.orderStatus}</span>
                    </div>
                  </div>

                  {ord.transporterName && (
                    <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-700/60 flex items-center justify-between text-xs">
                      <div className="flex items-center space-x-2">
                        <Truck className="w-4 h-4 text-emerald-400" />
                        <div>
                          <span className="text-white font-bold block">{ord.transporterName}</span>
                          <span className="text-slate-400 text-[11px]">{ord.transporterPhone}</span>
                        </div>
                      </div>
                      <a
                        href={`tel:${ord.transporterPhone}`}
                        className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg text-xs font-bold"
                      >
                        Call Driver
                      </a>
                    </div>
                  )}

                  {ord.escrowStatus === 'held_in_escrow' && (
                    <button
                      onClick={() => {
                        setOrders(orders.map(o => o.id === ord.id ? { ...o, escrowStatus: 'released_to_seller', orderStatus: 'completed' } : o));
                      }}
                      className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl shadow text-xs flex items-center justify-center space-x-2"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      <span>Confirm Delivery & Release MoMo Funds to Farmer</span>
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: TRANSPORTER FREIGHT BOARD */}
      {activeTab === 'transporters' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-black">National Logistics & Freight Jobs</h3>
                <p className="text-xs text-slate-400">
                  Transporters and pickup drivers can view available agricultural delivery contracts across Rwanda.
                </p>
              </div>
              <span className="bg-emerald-500/20 text-emerald-300 font-bold px-3 py-1 rounded-full text-xs border border-emerald-500/30">
                {jobs.length} Active Cargoes
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {jobs.map((j) => (
                <div key={j.id} className="bg-slate-800 border border-slate-700 rounded-2xl p-5 space-y-3 text-xs">
                  <div className="flex items-center justify-between border-b border-slate-700 pb-2">
                    <h4 className="font-black text-white text-sm">{j.cargoTitle}</h4>
                    <span className="font-black text-amber-300 text-sm">{j.transportFeeRwf.toLocaleString()} RWF</span>
                  </div>

                  <div className="space-y-1.5 text-slate-300">
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Pickup: <strong>{j.pickupDistrict}</strong> ➔ Delivery: <strong>{j.deliveryDistrict}</strong></span>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Truck className="w-3.5 h-3.5 text-blue-400" />
                      <span>Required Vehicle: <strong>{j.vehicleType}</strong> ({j.cargoWeightTons} Tons)</span>
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <span className={`font-bold px-2 py-0.5 rounded-full text-[10px] uppercase ${j.status === 'available' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-300'}`}>
                      {j.status}
                    </span>

                    {j.status === 'available' && (
                      <button
                        onClick={() => {
                          setJobs(jobs.map(job => job.id === j.id ? { ...job, status: 'in_transit', driverName: currentUser.name, driverPhone: currentUser.phone } : job));
                        }}
                        className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded-xl text-xs shadow"
                      >
                        Accept Cargo Job
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: POST NEW LISTING */}
      {showPostModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-lg w-full text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white">{t.postListing}</h3>
              <button onClick={() => setShowPostModal(false)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <form onSubmit={handlePublishListing} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Product Title:</label>
                <input
                  type="text"
                  value={postTitle}
                  onChange={(e) => setPostTitle(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Category:</label>
                  <select
                    value={postCategory}
                    onChange={(e) => setPostCategory(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="Produce">Produce (Crops)</option>
                    <option value="Inputs">Inputs & Fertilizer</option>
                    <option value="Livestock">Livestock</option>
                    <option value="Machinery">Equipment & Solar</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Quality Grade:</label>
                  <select
                    value={postGrade}
                    onChange={(e) => setPostGrade(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="Grade A1 Export">Grade A1 (RAB Export)</option>
                    <option value="Grade A2 Local">Grade A2 (Local Standard)</option>
                    <option value="Standard Bulk">Standard Bulk</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Quantity:</label>
                  <input
                    type="number"
                    value={postQty}
                    onChange={(e) => setPostQty(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Unit:</label>
                  <select
                    value={postUnit}
                    onChange={(e) => setPostUnit(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="Tons">Tons</option>
                    <option value="Kg">Kg</option>
                    <option value="Bags">Bags (50Kg)</option>
                    <option value="Heads">Heads</option>
                    <option value="Units">Units</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Price / Unit (RWF):</label>
                  <input
                    type="number"
                    value={postPrice}
                    onChange={(e) => setPostPrice(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Description:</label>
                <textarea
                  rows={3}
                  value={postDesc}
                  onChange={(e) => setPostDesc(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div className="pt-2 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowPostModal(false)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2.5 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl shadow"
                >
                  Publish Listing
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: SUBMIT NEGOTIATION OFFER */}
      {showOfferModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white">Negotiate Price & Bulk Order</h3>
              <button onClick={() => setShowOfferModal(null)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <p className="text-xs text-slate-300">
              Submit a counter-offer for <strong>{showOfferModal.title}</strong> to seller {showOfferModal.sellerName}.
            </p>

            <form onSubmit={handleSubmitOffer} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Offered Unit Price (RWF):</label>
                <input
                  type="number"
                  value={offerPrice}
                  onChange={(e) => setOfferPrice(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Offered Quantity ({showOfferModal.unit}):</label>
                <input
                  type="number"
                  value={offerQty}
                  onChange={(e) => setOfferQty(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Negotiation Message / Delivery Terms:</label>
                <textarea
                  rows={2}
                  placeholder="e.g., We are purchasing 5 tons for Nyabugogo depot..."
                  value={offerNote}
                  onChange={(e) => setOfferNote(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700 flex items-center justify-between">
                <span className="text-slate-400 font-bold">Calculated Offer Total:</span>
                <span className="text-base font-black text-amber-300">{(offerPrice * offerQty).toLocaleString()} RWF</span>
              </div>

              <div className="pt-2 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowOfferModal(null)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2.5 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl shadow"
                >
                  Send Counter-Offer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
