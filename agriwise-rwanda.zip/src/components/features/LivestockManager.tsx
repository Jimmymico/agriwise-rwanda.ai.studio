import React, { useState } from 'react';
import { LivestockRecord, Language } from '../../types';
import { INITIAL_LIVESTOCK } from '../../data/mockData';
import { translations } from '../../data/translations';
import {
  Beef,
  Plus,
  ShieldCheck,
  Milk,
  Syringe,
  Activity,
  Heart
} from 'lucide-react';

interface LivestockManagerProps {
  language: Language;
}

export const LivestockManager: React.FC<LivestockManagerProps> = ({ language }) => {
  const t = translations[language];
  const [livestock, setLivestock] = useState<LivestockRecord[]>(INITIAL_LIVESTOCK);
  const [showAddModal, setShowAddModal] = useState(false);

  const [tagNumber, setTagNumber] = useState('RWA-NYA-2026-301');
  const [animalType, setAnimalType] = useState<'Cattle' | 'Goat' | 'Poultry' | 'Pig' | 'Sheep'>('Cattle');
  const [breed, setBreed] = useState('Friesian Purebred');
  const [dailyYield, setDailyYield] = useState(24.5);

  const handleAddLivestock = (e: React.FormEvent) => {
    e.preventDefault();
    const item: LivestockRecord = {
      id: `live_${Date.now()}`,
      farmerId: 'user_2',
      tagNumber,
      animalType,
      breed,
      gender: 'Female',
      ageMonths: 24,
      healthStatus: 'Excellent',
      lastVaccinationDate: new Date().toISOString().split('T')[0],
      dailyYieldLitersOrEggs: Number(dailyYield)
    };
    setLivestock([item, ...livestock]);
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-white">
        <div>
          <div className="inline-flex items-center space-x-2 bg-blue-500/20 text-blue-300 border border-blue-500/30 px-3 py-1 rounded-full text-xs font-bold mb-1">
            <Beef className="w-3.5 h-3.5 text-blue-400" />
            <span>Digital Herd & Animal Health Registry</span>
          </div>
          <h2 className="text-xl font-black">{t.navLivestockManager}</h2>
          <p className="text-xs text-slate-400">Vaccination records, milk/egg yields, and disease tracking.</p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg flex items-center space-x-2 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Register Animal Profile</span>
        </button>
      </div>

      {/* Herd Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {livestock.map((item) => (
          <div
            key={item.id}
            className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 text-white"
          >
            <div className="flex items-start justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{item.tagNumber}</span>
                <h3 className="text-base font-black text-white">{item.breed}</h3>
              </div>
              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/30 flex items-center space-x-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>{item.healthStatus}</span>
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center space-x-2">
                <Milk className="w-5 h-5 text-amber-400" />
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold uppercase">Daily Yield</span>
                  <span className="text-sm font-black text-white">{item.dailyYieldLitersOrEggs} Liters/day</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center space-x-2">
                <Syringe className="w-5 h-5 text-blue-400" />
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold uppercase">Vaccinated</span>
                  <span className="text-xs font-bold text-emerald-400">{item.lastVaccinationDate}</span>
                </div>
              </div>
            </div>

            <div className="text-[11px] text-slate-300 bg-slate-950 p-3 rounded-2xl border border-slate-800 flex justify-between">
              <span><strong>Animal:</strong> {item.animalType} ({item.gender})</span>
              <span><strong>Age:</strong> {item.ageMonths} Months</span>
            </div>

          </div>
        ))}
      </div>

      {/* Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full text-white space-y-4 shadow-2xl">
            <h3 className="text-base font-black">Register Animal Tag</h3>

            <form onSubmit={handleAddLivestock} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Tag Number:</label>
                <input
                  type="text"
                  value={tagNumber}
                  onChange={(e) => setTagNumber(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Breed & Species:</label>
                <input
                  type="text"
                  value={breed}
                  onChange={(e) => setBreed(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Daily Yield (Liters/Eggs):</label>
                <input
                  type="number"
                  step="0.5"
                  value={dailyYield}
                  onChange={(e) => setDailyYield(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div className="pt-3 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 rounded-xl shadow"
                >
                  Save Animal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
