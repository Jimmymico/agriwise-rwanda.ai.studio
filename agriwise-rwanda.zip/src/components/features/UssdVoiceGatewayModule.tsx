import React, { useState, useEffect, useRef } from 'react';
import { Language, User, USSDRequestLog, VoiceCallLog, SMSMessageLog } from '../../types';
import { translations } from '../../data/translations';
import {
  Phone,
  PhoneCall,
  PhoneOff,
  PhoneForwarded,
  MessageSquare,
  Radio,
  Wifi,
  WifiOff,
  Zap,
  Globe2,
  CheckCircle2,
  AlertTriangle,
  UserCheck,
  Send,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  Activity,
  Award,
  Layers,
  ChevronRight,
  Info,
  Clock,
  MapPin,
  Sprout
} from 'lucide-react';

interface UssdVoiceGatewayModuleProps {
  currentUser?: User;
  language: Language;
}

export const UssdVoiceGatewayModule: React.FC<UssdVoiceGatewayModuleProps> = ({
  currentUser,
  language,
}) => {
  const t = translations[language] || translations['rw'];

  // Tab mode: 'ussd' | 'voice' | 'telecom_dashboard'
  const [activeTab, setActiveTab] = useState<'ussd' | 'voice' | 'telecom_dashboard'>('ussd');

  // ----------------------------------------------------------------------
  // 1. USSD Simulator State (*111#)
  // ----------------------------------------------------------------------
  const [ussdPhone, setUssdPhone] = useState<string>('+250 788 123 456');
  const [ussdSessionId, setUssdSessionId] = useState<string>(`SESS-${Date.now().toString().slice(-6)}`);
  const [ussdTextHistory, setUssdTextHistory] = useState<string>(''); // e.g., "1*2"
  const [ussdInputBuffer, setUssdInputBuffer] = useState<string>('');
  const [ussdScreenOutput, setUssdScreenOutput] = useState<string>(
    'Dial *111# to initiate AGRIWISE USSD Session\n\nPressez *111# pour commencer.'
  );
  const [ussdResponseType, setUssdResponseType] = useState<'IDLE' | 'CON' | 'END'>('IDLE');
  const [ussdRequestLogs, setUssdRequestLogs] = useState<USSDRequestLog[]>([]);
  const [ussdLoading, setUssdLoading] = useState<boolean>(false);

  // ----------------------------------------------------------------------
  // 2. 1111 Voice AI Call Simulator State
  // ----------------------------------------------------------------------
  const [voiceCallStatus, setVoiceCallStatus] = useState<'idle' | 'calling' | 'connected' | 'transferred' | 'ended'>('idle');
  const [callTimerSeconds, setCallTimerSeconds] = useState<number>(0);
  const [userSpeechInput, setUserSpeechInput] = useState<string>('Inyanya zange zifite ibibabi byumye, nkoreshe uwuhe muti?');
  const [voiceLanguage, setVoiceLanguage] = useState<'rw' | 'en' | 'fr'>(language);
  const [voiceLogs, setVoiceLogs] = useState<VoiceCallLog[]>([]);
  const [activeCallSummary, setActiveCallSummary] = useState<any>(null);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isAudioSpeaking, setIsAudioSpeaking] = useState<boolean>(false);
  const [voiceLoading, setVoiceLoading] = useState<boolean>(false);

  // ----------------------------------------------------------------------
  // 3. SMS Inbox State
  // ----------------------------------------------------------------------
  const [smsLogs, setSmsLogs] = useState<SMSMessageLog[]>([
    {
      id: 'SMS-101',
      phoneNumber: '+250 788 123 456',
      messageBody: '[AGRIWISE] Welcome! Your Musanze potato farm parcel (1.85 Ha) was certified by RAB.',
      status: 'delivered',
      gateway: 'MTN SMS API',
      type: 'USSD_RECEIPT',
      timestamp: new Date().toISOString(),
    },
  ]);

  // Timer Ref for Active Call
  const callIntervalRef = useRef<any>(null);

  useEffect(() => {
    if (voiceCallStatus === 'connected') {
      callIntervalRef.current = setInterval(() => {
        setCallTimerSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (callIntervalRef.current) clearInterval(callIntervalRef.current);
    }
    return () => {
      if (callIntervalRef.current) clearInterval(callIntervalRef.current);
    };
  }, [voiceCallStatus]);

  // ----------------------------------------------------------------------
  // USSD API Dispatcher
  // ----------------------------------------------------------------------
  const handleDialUssd = async (textPayload: string) => {
    setUssdLoading(true);
    try {
      const res = await fetch('/api/ussd', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: ussdSessionId,
          phoneNumber: ussdPhone,
          text: textPayload,
          serviceCode: '*111#',
        }),
      });

      const rawText = await res.text();
      const firstSpace = rawText.indexOf(' ');
      const type = rawText.substring(0, firstSpace) as 'CON' | 'END';
      const body = rawText.substring(firstSpace + 1);

      setUssdResponseType(type);
      setUssdScreenOutput(body);
      setUssdTextHistory(textPayload);
      setUssdInputBuffer('');

      // Add to Log
      const newLog: USSDRequestLog = {
        id: `LOG-${Date.now().toString().slice(-6)}`,
        sessionId: ussdSessionId,
        phoneNumber: ussdPhone,
        rawInput: textPayload || '*111#',
        responseText: body,
        responseType: type,
        timestamp: new Date().toLocaleTimeString(),
        operator: 'MTN',
      };
      setUssdRequestLogs((prev) => [newLog, ...prev]);

      if (type === 'END') {
        // Trigger automatic SMS summary
        triggerSmsDelivery(ussdPhone, `[AGRIWISE USSD] ${body.slice(0, 140)}`, 'USSD_RECEIPT');
      }
    } catch (e) {
      setUssdScreenOutput('END Network Connection Error. Please retry dialing *111#.');
      setUssdResponseType('END');
    } finally {
      setUssdLoading(false);
    }
  };

  const handleKeypadPress = (val: string) => {
    if (ussdResponseType === 'IDLE' || ussdResponseType === 'END') {
      if (val === '*') {
        setUssdInputBuffer('*111#');
      } else {
        setUssdInputBuffer((prev) => prev + val);
      }
    } else {
      setUssdInputBuffer((prev) => prev + val);
    }
  };

  const handleSendUssd = () => {
    if (ussdResponseType === 'IDLE' || ussdResponseType === 'END') {
      if (ussdInputBuffer === '*111#' || ussdInputBuffer === '111') {
        const newSess = `SESS-${Date.now().toString().slice(-6)}`;
        setUssdSessionId(newSess);
        handleDialUssd('');
      } else {
        alert('To start USSD session, please type *111# and press Call/Send.');
      }
    } else {
      const nextHistory = ussdTextHistory ? `${ussdTextHistory}*${ussdInputBuffer}` : ussdInputBuffer;
      handleDialUssd(nextHistory);
    }
  };

  const handleResetUssd = () => {
    setUssdSessionId(`SESS-${Date.now().toString().slice(-6)}`);
    setUssdTextHistory('');
    setUssdInputBuffer('');
    setUssdResponseType('IDLE');
    setUssdScreenOutput('Dial *111# to initiate AGRIWISE USSD Session\n\nPressez *111# pour commencer.');
  };

  // ----------------------------------------------------------------------
  // 1111 Voice AI Call Dispatcher
  // ----------------------------------------------------------------------
  const handleInitiate1111Call = async () => {
    setVoiceCallStatus('calling');
    setCallTimerSeconds(0);
    setVoiceLoading(true);

    setTimeout(async () => {
      setVoiceCallStatus('connected');
      await handleProcessVoiceQuery(userSpeechInput);
    }, 1500);
  };

  const handleProcessVoiceQuery = async (query: string) => {
    setVoiceLoading(true);
    try {
      const res = await fetch('/api/voice/interact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: ussdPhone,
          language: voiceLanguage,
          speechQuery: query,
          district: 'Musanze',
        }),
      });

      const data = await res.json();
      setActiveCallSummary(data);

      if (data.transferredToExpert) {
        setVoiceCallStatus('transferred');
      }

      // Add to Voice Logs
      const newVoiceLog: VoiceCallLog = {
        callId: data.callId,
        phoneNumber: ussdPhone,
        farmerName: currentUser?.name || 'Musanze Farmer',
        language: voiceLanguage,
        durationSeconds: callTimerSeconds + 15,
        status: data.transferredToExpert ? 'transferred' : 'completed',
        transcriptSummary: query,
        aiSentiment: data.aiSentiment,
        transferredToExpert: data.transferredToExpert,
        expertName: data.expertName,
        timestamp: new Date().toLocaleTimeString(),
        smsFollowupSent: true,
      };
      setVoiceLogs((prev) => [newVoiceLog, ...prev]);

      // Trigger Speech Synthesis (Web Speech API)
      if ('speechSynthesis' in window && !isMuted) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(data.responseText);
        utterance.lang = voiceLanguage === 'rw' ? 'sw-TZ' : voiceLanguage === 'fr' ? 'fr-FR' : 'en-US';
        utterance.onstart = () => setIsAudioSpeaking(true);
        utterance.onend = () => setIsAudioSpeaking(false);
        window.speechSynthesis.speak(utterance);
      }

      // Trigger SMS Delivery
      triggerSmsDelivery(ussdPhone, data.smsBody, 'VOICE_SUMMARY');
    } catch (e) {
      console.error('1111 Voice AI Error:', e);
    } finally {
      setVoiceLoading(false);
    }
  };

  const handleEnd1111Call = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setVoiceCallStatus('ended');
    setIsAudioSpeaking(false);
    setTimeout(() => setVoiceCallStatus('idle'), 2000);
  };

  const triggerSmsDelivery = (phoneNumber: string, body: string, type: 'USSD_RECEIPT' | 'VOICE_SUMMARY') => {
    const newSms: SMSMessageLog = {
      id: `SMS-${Date.now().toString().slice(-5)}`,
      phoneNumber,
      messageBody: body,
      status: 'delivered',
      gateway: 'MTN SMS API',
      type,
      timestamp: new Date().toLocaleTimeString(),
    };
    setSmsLogs((prev) => [newSms, ...prev]);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16 font-sans text-slate-100">
      
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold">
              <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span>OFFLINE TELECOM GATEWAY (*111# & 1111)</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              AGRIWISE USSD & 1111 Voice AI Service
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 font-medium max-w-2xl">
              Empowering 2G feature phone users across Rwanda with offline USSD menus, Kinyarwanda Gemini 3.6 Voice AI, automatic SMS receipts, and human extension officer transfers.
            </p>
          </div>

          {/* Telecom Gateway Indicators */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="bg-slate-900/90 border border-slate-800 px-3.5 py-2 rounded-2xl text-xs font-bold flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-emerald-400 font-mono">MTN / Airtel WASP Live</span>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 px-3.5 py-2 rounded-2xl text-xs font-bold flex items-center gap-2">
              <PhoneCall className="w-4 h-4 text-teal-400" />
              <span className="text-slate-200">
                Voice AI 1111: <strong className="text-emerald-400 font-mono">24/7 Ready</strong>
              </span>
            </div>
          </div>
        </div>

        {/* Navigation Mode Switcher */}
        <div className="flex items-center gap-2 mt-6 pt-6 border-t border-emerald-500/20 text-xs overflow-x-auto">
          {[
            { id: 'ussd', label: 'USSD (*111#) Feature Phone Simulator', icon: MessageSquare },
            { id: 'voice', label: '1111 Voice AI Call Assistant', icon: PhoneCall },
            { id: 'telecom_dashboard', label: 'Telecom Gateway Analytics & SMS Center', icon: Activity },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2.5 rounded-2xl font-bold flex items-center gap-2 transition-all shrink-0 ${
                  activeTab === tab.id
                    ? 'bg-emerald-600 text-white shadow-lg'
                    : 'bg-slate-950/60 hover:bg-slate-900 text-slate-300 border border-slate-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB 1: USSD INTERACTIVE FEATURE PHONE SIMULATOR (*111#) */}
      {activeTab === 'ussd' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Left Column: Realistic GSM Handset Shell */}
          <div className="bg-slate-950 border-4 border-slate-800 rounded-[40px] p-6 shadow-2xl flex flex-col items-center space-y-5 max-w-md mx-auto w-full">
            
            {/* Phone Speaker & Camera Notch */}
            <div className="w-full flex justify-between items-center px-4 pt-1">
              <span className="text-[10px] font-mono text-slate-500 font-bold">MTN RWANDA 4G/2G</span>
              <div className="w-12 h-1.5 bg-slate-800 rounded-full" />
              <span className="text-[10px] font-mono text-emerald-400 font-bold">100% 🔋</span>
            </div>

            {/* Matrix LCD Display Screen */}
            <div className="w-full h-72 bg-emerald-950/90 border-2 border-emerald-500/50 rounded-2xl p-4 shadow-inner text-emerald-300 font-mono text-xs flex flex-col justify-between overflow-hidden relative">
              <div className="flex justify-between items-center pb-2 border-b border-emerald-500/30 text-[10px]">
                <span>USSD SESSION: {ussdSessionId}</span>
                <span className="font-bold">{ussdResponseType}</span>
              </div>

              {/* Screen Body Text */}
              <div className="whitespace-pre-wrap leading-relaxed overflow-y-auto flex-1 my-2 pr-1 font-mono text-[11px] text-emerald-200">
                {ussdLoading ? (
                  <div className="flex items-center justify-center h-full gap-2 text-emerald-400 animate-pulse">
                    <Radio className="w-4 h-4 animate-spin" />
                    <span>Communicating with MTN Gateway...</span>
                  </div>
                ) : (
                  ussdScreenOutput
                )}
              </div>

              {/* Screen Input Box */}
              <div className="pt-2 border-t border-emerald-500/30 flex items-center justify-between gap-1 bg-emerald-950">
                <span className="text-emerald-400 font-bold">&gt;</span>
                <input
                  type="text"
                  value={ussdInputBuffer}
                  onChange={(e) => setUssdInputBuffer(e.target.value)}
                  placeholder={ussdResponseType === 'IDLE' ? 'Type *111#' : 'Enter option #'}
                  className="bg-transparent border-none outline-none text-emerald-100 font-bold font-mono text-xs w-full px-1"
                />
              </div>
            </div>

            {/* Handset Keypad Grid */}
            <div className="w-full space-y-3">
              <div className="grid grid-cols-3 gap-2">
                {[
                  { num: '1', sub: '' },
                  { num: '2', sub: 'ABC' },
                  { num: '3', sub: 'DEF' },
                  { num: '4', sub: 'GHI' },
                  { num: '5', sub: 'JKL' },
                  { num: '6', sub: 'MNO' },
                  { num: '7', sub: 'PQRS' },
                  { num: '8', sub: 'TUV' },
                  { num: '9', sub: 'WXYZ' },
                  { num: '*', sub: '' },
                  { num: '0', sub: '+' },
                  { num: '#', sub: '' },
                ].map((k) => (
                  <button
                    key={k.num}
                    onClick={() => handleKeypadPress(k.num)}
                    className="bg-slate-900 hover:bg-slate-800 border border-slate-700/80 active:bg-emerald-900/60 rounded-2xl py-3 text-center transition-all shadow active:scale-95 text-white"
                  >
                    <span className="text-base font-bold font-mono block leading-none">{k.num}</span>
                    {k.sub && <span className="text-[9px] text-slate-400 font-mono uppercase">{k.sub}</span>}
                  </button>
                ))}
              </div>

              {/* Action Buttons: Dial / Cancel */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={handleSendUssd}
                  className="bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-bold py-3 px-4 rounded-2xl shadow-lg flex items-center justify-center gap-2 text-xs transition-all"
                >
                  <Phone className="w-4 h-4 fill-white" />
                  <span>Send / Dial</span>
                </button>

                <button
                  onClick={handleResetUssd}
                  className="bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800/80 font-bold py-3 px-4 rounded-2xl shadow flex items-center justify-center gap-2 text-xs transition-all"
                >
                  <PhoneOff className="w-4 h-4" />
                  <span>End Session</span>
                </button>
              </div>
            </div>

          </div>

          {/* Right 2 Columns: Preset Test Scenarios & USSD Log */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Quick Test Presets */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <h3 className="font-bold text-white flex items-center gap-2 text-sm">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <span>Automated USSD Scenario Quick-Dial Presets</span>
                </h3>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono">
                  1-Click Automation
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {[
                  {
                    title: '1. Check Market Prices (Kinyarwanda)',
                    code: '1*2',
                    desc: 'Fetch Musanze & Kigali commodity prices for Potatoes, Maize & Milk',
                  },
                  {
                    title: '2. Musanze Weather Forecast',
                    code: '1*1',
                    desc: 'Fetch 3-day rain prediction and agronomic spray advisory',
                  },
                  {
                    title: '3. Ask AI Agriculture Question',
                    code: '1*3*Inyanya zange zifite ibibabi byumye',
                    desc: 'Send tomato blight question to Gemini AI via USSD',
                  },
                  {
                    title: '4. Register New Farm Boundary',
                    code: '1*4*Jean Musanze',
                    desc: 'Multi-step farmer profile & parcel registration form',
                  },
                ].map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setUssdInputBuffer('*111#');
                      const newSess = `SESS-${Date.now().toString().slice(-6)}`;
                      setUssdSessionId(newSess);
                      handleDialUssd(preset.code);
                    }}
                    className="p-3.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-emerald-500/50 rounded-2xl text-left transition-all space-y-1 shadow group"
                  >
                    <div className="flex justify-between items-center text-emerald-400 font-bold">
                      <span>{preset.title}</span>
                      <span className="font-mono text-[10px] bg-slate-900 group-hover:bg-emerald-950 px-2 py-0.5 rounded-md border border-slate-700">
                        {preset.code}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">{preset.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Live USSD Protocol Request Log */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3 text-xs">
                <h3 className="font-bold text-white flex items-center gap-2">
                  <Activity className="w-4 h-4 text-teal-400" />
                  <span>Telecom WASP Packet Logs (`/api/ussd`)</span>
                </h3>
                <span className="text-slate-400 font-mono">Total Packets: {ussdRequestLogs.length}</span>
              </div>

              {ussdRequestLogs.length === 0 ? (
                <div className="text-center py-6 text-slate-500 text-xs font-mono">
                  No USSD packets sent yet. Press "*111#" and Send on the phone dialer.
                </div>
              ) : (
                <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                  {ussdRequestLogs.map((log) => (
                    <div
                      key={log.id}
                      className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-xs font-mono space-y-1.5"
                    >
                      <div className="flex justify-between text-[11px]">
                        <span className="text-emerald-400 font-bold">
                          [{log.operator}] {log.phoneNumber}
                        </span>
                        <span className="text-slate-400">{log.timestamp}</span>
                      </div>
                      <div className="text-slate-300">
                        Input: <strong className="text-amber-300">"{log.rawInput}"</strong>
                      </div>
                      <div className="text-slate-400 text-[11px] whitespace-pre-wrap border-l-2 border-emerald-500 pl-2 py-0.5">
                        Response [{log.responseType}]: {log.responseText}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>

        </div>
      )}

      {/* TAB 2: 1111 VOICE AI CALL ASSISTANT */}
      {activeTab === 'voice' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Left Column: Voice AI Call Console */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-6 text-white flex flex-col justify-between">
            
            <div className="space-y-4">
              <div className="pb-4 border-b border-slate-800 flex justify-between items-center">
                <div>
                  <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase block">
                    TELECOM SHORTCODE
                  </span>
                  <h2 className="text-xl font-black text-white flex items-center gap-2">
                    <PhoneCall className="w-5 h-5 text-emerald-400" />
                    <span>AGRIWISE 1111</span>
                  </h2>
                </div>

                <select
                  value={voiceLanguage}
                  onChange={(e) => setVoiceLanguage(e.target.value as any)}
                  className="bg-slate-950 border border-slate-800 text-emerald-400 font-bold text-xs rounded-xl px-3 py-1.5 outline-none"
                >
                  <option value="rw">Kinyarwanda</option>
                  <option value="en">English</option>
                  <option value="fr">Français</option>
                </select>
              </div>

              {/* Active Call Status Card */}
              <div className="bg-slate-950 p-5 rounded-3xl border border-slate-800 text-center space-y-4 relative overflow-hidden">
                
                {voiceCallStatus === 'connected' && (
                  <div className="absolute top-2 right-3 flex items-center gap-1 text-[11px] text-emerald-400 font-mono font-bold animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span>REC ON</span>
                  </div>
                )}

                <div className="w-20 h-20 mx-auto rounded-full bg-emerald-950 border-2 border-emerald-500/50 flex items-center justify-center relative">
                  {voiceCallStatus === 'connected' ? (
                    <Mic className="w-8 h-8 text-emerald-400 animate-bounce" />
                  ) : (
                    <PhoneCall className="w-8 h-8 text-slate-400" />
                  )}
                  {isAudioSpeaking && (
                    <div className="absolute inset-0 rounded-full border-4 border-emerald-400 animate-ping opacity-50" />
                  )}
                </div>

                <div>
                  <h3 className="font-bold text-base text-white">
                    {voiceCallStatus === 'idle' && 'Ready to Dial 1111'}
                    {voiceCallStatus === 'calling' && 'Ringing 1111 AGRIWISE AI...'}
                    {voiceCallStatus === 'connected' && '1111 Voice AI Connected'}
                    {voiceCallStatus === 'transferred' && 'Transferred to Extension Officer'}
                    {voiceCallStatus === 'ended' && 'Call Ended'}
                  </h3>

                  <p className="text-xs text-slate-400 font-mono mt-0.5">
                    {voiceCallStatus === 'connected'
                      ? `Duration: 00:${callTimerSeconds.toString().padStart(2, '0')}`
                      : 'Free Toll-Free Agricultural Line'}
                  </p>
                </div>

                {/* Call Control Buttons */}
                <div className="flex justify-center items-center gap-4 pt-2">
                  {voiceCallStatus === 'idle' || voiceCallStatus === 'ended' ? (
                    <button
                      onClick={handleInitiate1111Call}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-6 py-3 rounded-2xl shadow-lg flex items-center gap-2 text-xs transition-all active:scale-95"
                    >
                      <PhoneCall className="w-4 h-4 fill-white" />
                      <span>Call 1111</span>
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={() => setIsMuted(!isMuted)}
                        className={`p-3 rounded-2xl border transition-all ${
                          isMuted
                            ? 'bg-rose-950 border-rose-800 text-rose-300'
                            : 'bg-slate-900 border-slate-700 text-slate-200'
                        }`}
                      >
                        {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                      </button>

                      <button
                        onClick={handleEnd1111Call}
                        className="bg-rose-600 hover:bg-rose-500 text-white font-bold p-3.5 rounded-full shadow-lg transition-all active:scale-95"
                      >
                        <PhoneOff className="w-6 h-6 fill-white" />
                      </button>
                    </>
                  )}
                </div>

              </div>

              {/* Speech Query Input Box */}
              <div className="space-y-2 text-xs">
                <label className="block text-slate-300 font-medium">
                  Spoken Query Prompt (Simulated Kinyarwanda STT):
                </label>
                <textarea
                  value={userSpeechInput}
                  onChange={(e) => setUserSpeechInput(e.target.value)}
                  rows={3}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-2xl p-3 text-white outline-none font-medium resize-none"
                  placeholder="Type or speak what the farmer says on call..."
                />
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {[
                    'Ibirayi birwara iki?',
                    'Ni ryari natangiye guhinga amasaka?',
                    'Nfite ikibazo gikomeye muri Musanze',
                    'Nfite inka irwaye amatsiko',
                  ].map((preset, idx) => (
                    <button
                      key={idx}
                      onClick={() => setUserSpeechInput(preset)}
                      className="text-[10px] bg-slate-950 hover:bg-slate-800 border border-slate-800 text-emerald-400 px-2.5 py-1 rounded-xl transition-colors"
                    >
                      "{preset}"
                    </button>
                  ))}
                </div>
              </div>

            </div>

            <button
              onClick={() => handleProcessVoiceQuery(userSpeechInput)}
              disabled={voiceLoading || voiceCallStatus !== 'connected'}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-4 rounded-2xl shadow-lg flex items-center justify-center gap-2 text-xs transition-all disabled:opacity-40"
            >
              <Send className="w-4 h-4" />
              <span>Send Spoken Prompt to Gemini 3.6 AI</span>
            </button>

          </div>

          {/* Right 2 Columns: Live Call Transcript & Audio Response Output */}
          <div className="lg:col-span-2 space-y-6">
            
            {activeCallSummary ? (
              <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 shadow-xl space-y-5 text-white animate-in fade-in">
                
                <div className="flex justify-between items-center border-b border-slate-800 pb-3 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 bg-emerald-950 rounded-xl text-emerald-400">
                      <Volume2 className="w-4 h-4" />
                    </span>
                    <h3 className="font-bold text-white text-sm">
                      1111 Live Audio Transcript & AI Reasoning
                    </h3>
                  </div>

                  {activeCallSummary.transferredToExpert && (
                    <span className="bg-rose-950 text-rose-300 border border-rose-800 px-3 py-1 rounded-full font-bold flex items-center gap-1.5 text-[11px]">
                      <PhoneForwarded className="w-3.5 h-3.5" />
                      Transferred to Human Expert
                    </span>
                  )}
                </div>

                {/* Spoken Dialogue Exchange */}
                <div className="space-y-3 text-xs">
                  <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-1">
                    <span className="text-[10px] font-bold text-emerald-400 uppercase">
                      Farmer Spoken Input (STT):
                    </span>
                    <p className="text-white font-medium text-sm">
                      "{activeCallSummary.speechQuery}"
                    </p>
                  </div>

                  <div className="bg-slate-950 p-4 rounded-2xl border border-emerald-500/40 space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-bold text-teal-300 uppercase">
                        AGRIWISE Gemini 3.6 Vocal Answer (TTS):
                      </span>
                      {isAudioSpeaking && (
                        <span className="text-[10px] text-emerald-400 font-bold animate-pulse flex items-center gap-1">
                          <Volume2 className="w-3 h-3" />
                          Synthesizing Audio Output...
                        </span>
                      )}
                    </div>
                    <p className="text-slate-200 leading-relaxed font-medium">
                      {activeCallSummary.responseText}
                    </p>
                  </div>

                  {activeCallSummary.transferredToExpert && (
                    <div className="bg-amber-950/80 p-4 rounded-2xl border border-amber-500/40 space-y-1 text-amber-200">
                      <span className="text-[10px] font-bold uppercase text-amber-400">
                        Human Extension Officer Assigned:
                      </span>
                      <p className="font-bold text-sm">{activeCallSummary.expertName}</p>
                    </div>
                  )}
                </div>

                {/* Automatic SMS Summary Notification Box */}
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                    Automatic Post-Call SMS Follow-Up Dispatched
                  </span>
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-xs font-mono text-slate-300">
                    {activeCallSummary.smsBody}
                  </div>
                </div>

              </div>
            ) : (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-xl text-center space-y-3">
                <Radio className="w-10 h-10 text-emerald-400 mx-auto animate-pulse" />
                <h3 className="font-bold text-white text-base">
                  1111 Voice AI Call Session
                </h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  Press "Call 1111" on the dialer console to start an interactive Kinyarwanda voice AI conversation.
                </p>
              </div>
            )}

            {/* Historic Voice Call Logs */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
              <h3 className="font-bold text-white text-xs flex items-center gap-2 border-b border-slate-800 pb-3">
                <Clock className="w-4 h-4 text-emerald-400" />
                <span>Call Center History & Transcripts</span>
              </h3>

              {voiceLogs.length === 0 ? (
                <div className="text-center py-6 text-slate-500 text-xs font-mono">
                  No call logs recorded yet.
                </div>
              ) : (
                <div className="space-y-2.5 max-h-56 overflow-y-auto">
                  {voiceLogs.map((log) => (
                    <div
                      key={log.callId}
                      className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-xs space-y-1"
                    >
                      <div className="flex justify-between items-center text-[11px]">
                        <span className="font-mono text-emerald-400 font-bold">
                          {log.callId} • {log.phoneNumber}
                        </span>
                        <span className="text-slate-400">{log.timestamp}</span>
                      </div>
                      <p className="text-slate-300">"{log.transcriptSummary}"</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>

        </div>
      )}

      {/* TAB 3: TELECOM GATEWAY ANALYTICS & SMS INBOX */}
      {activeTab === 'telecom_dashboard' && (
        <div className="space-y-6">
          
          {/* Operations Metrics Row */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl space-y-1">
              <span className="text-xs text-slate-400 font-medium block">Active USSD Sessions</span>
              <span className="text-2xl font-black text-emerald-400 font-mono">1,482</span>
              <span className="text-[10px] text-emerald-500 block">MTN & Airtel WASP Connected</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl space-y-1">
              <span className="text-xs text-slate-400 font-medium block">1111 Voice AI Concurrent Calls</span>
              <span className="text-2xl font-black text-teal-300 font-mono">312</span>
              <span className="text-[10px] text-teal-400 block">Kinyarwanda STT Active</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl space-y-1">
              <span className="text-xs text-slate-400 font-medium block">SMS Deliveries Today</span>
              <span className="text-2xl font-black text-amber-300 font-mono">24,850</span>
              <span className="text-[10px] text-amber-400 block">100% Delivery Success</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl space-y-1">
              <span className="text-xs text-slate-400 font-medium block">Human Expert Transfers</span>
              <span className="text-2xl font-black text-blue-300 font-mono">48</span>
              <span className="text-[10px] text-blue-400 block">RAB Officers Assigned</span>
            </div>
          </div>

          {/* SMS Dispatch Log Center */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <Send className="w-4 h-4 text-emerald-400" />
                <span>Automatic SMS Dispatch Stream (`/api/sms/send`)</span>
              </h3>
              <span className="text-xs font-mono text-emerald-400">Gateway: MTN SMS API</span>
            </div>

            <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
              {smsLogs.map((sms) => (
                <div
                  key={sms.id}
                  className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-xs font-mono space-y-1.5"
                >
                  <div className="flex justify-between items-center text-[11px]">
                    <span className="text-emerald-400 font-bold">
                      {sms.id} ➔ {sms.phoneNumber}
                    </span>
                    <span className="bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded-full text-[10px]">
                      {sms.status.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-slate-200">{sms.messageBody}</p>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
