import React, { useState } from 'react';
import {
  Compass,
  Plane,
  Camera,
  Layers,
  MapPin,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ShieldCheck,
  Zap,
  Wind,
  Droplets,
  DollarSign,
  Plus,
  Play,
  RotateCcw,
  Bot,
  FileText,
  Activity,
  Sliders,
  Award,
  Clock,
  Send,
  Eye,
  Crosshair,
  UserCheck,
  Smartphone,
  ChevronRight
} from 'lucide-react';
import {
  MOCK_DRONE_OPERATORS,
  MOCK_DRONES,
  MOCK_FLIGHT_REQUESTS,
  MOCK_AERIAL_INSPECTION_REPORT,
  MOCK_SPRAYING_PRESCRIPTION,
  MOCK_TRI_DATA_FUSION
} from '../../data/mockDroneData';
import {
  DroneOperator,
  DroneHardware,
  DroneFlightRequest,
  DroneServiceType,
  DroneAerialInspectionReport,
  PrecisionSprayingPrescription,
  TriDataFusionMatrix
} from '../../types';

export const DroneAgricultureModule: React.FC = () => {
  const [activeTab, setActiveTab] = useState<
    'overview' | 'marketplace' | 'planner' | 'ai_vision' | 'tri_fusion' | 'spraying' | 'operators' | 'copilot'
  >('overview');

  // Interactive States
  const [operatorsList, setOperatorsList] = useState<DroneOperator[]>(MOCK_DRONE_OPERATORS);
  const [dronesList, setDronesList] = useState<DroneHardware[]>(MOCK_DRONES);
  const [flightRequests, setFlightRequests] = useState<DroneFlightRequest[]>(MOCK_FLIGHT_REQUESTS);
  const [inspectionReport, setInspectionReport] = useState<DroneAerialInspectionReport>(MOCK_AERIAL_INSPECTION_REPORT);
  const [sprayingPrescription, setSprayingPrescription] = useState<PrecisionSprayingPrescription>(MOCK_SPRAYING_PRESCRIPTION);
  const [triFusionMatrix, setTriFusionMatrix] = useState<TriDataFusionMatrix>(MOCK_TRI_DATA_FUSION);

  // New Flight Request Modal / Form
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [selectedService, setSelectedService] = useState<DroneServiceType>('Multispectral Crop Health Scan (NDVI/RE)');
  const [bookingFarmName, setBookingFarmName] = useState('Hakizimana Plot B');
  const [bookingAreaHa, setBookingAreaHa] = useState(3.5);
  const [bookingDistrict, setBookingDistrict] = useState('Nyagatare District');
  const [bookingFeeRwf, setBookingFeeRwf] = useState(48000);

  // Flight Boundary Simulation States
  const [flightAltitudeMeters, setFlightAltitudeMeters] = useState(45);
  const [flightSpeedMs, setFlightSpeedMs] = useState(8.5);
  const [weatherWindKmH, setWeatherWindKmH] = useState(9.2); // Safe threshold < 15 km/h
  const [isPreflightApproved, setIsPreflightApproved] = useState(true);

  // AI Analysis Trigger
  const [isAiAnalyzing, setIsAiAnalyzing] = useState(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<{
    averageNdvi: number;
    cropHealthScore: number;
    plantStandEstimate: number;
    emergentRatePct: number;
    stressZonesDetected: number;
    pestDiseaseAlert: string;
    weedPressurePct: number;
    targetedSprayingPrescription: string;
    triDataFusionSummary: string;
    aiAerialAdvisory: string;
  } | null>(null);

  // AI Copilot Chat State
  const [copilotQuery, setCopilotQuery] = useState("Analyze the aerial orthomosaic and recommend precision bio-pesticide dosage for fall armyworm.");
  const [copilotResponse, setCopilotResponse] = useState<string | null>(null);
  const [isCopilotThinking, setIsCopilotThinking] = useState(false);

  // Operator Onboarding Modal State
  const [showRegisterOperatorModal, setShowRegisterOperatorModal] = useState(false);
  const [newOpName, setNewOpName] = useState('');
  const [newOpCompany, setNewOpCompany] = useState('');
  const [newOpRcaa, setNewOpRcaa] = useState('');
  const [newOpDistrict, setNewOpDistrict] = useState('Musanze District');

  // Trigger Gemini AI Aerial Analysis
  const runAiAerialScan = async () => {
    setIsAiAnalyzing(true);
    try {
      const response = await fetch('/api/ai/drone-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          farmName: 'Hakizimana Maize & Bean Plot A',
          cropType: 'Maize & Climbing Beans',
          flightType: selectedService,
          areaHa: 2.5
        })
      });
      const data = await response.json();
      setAiAnalysisResult(data);
    } catch (err) {
      console.error('AI Drone Analysis error:', err);
      setAiAnalysisResult({
        averageNdvi: 0.74,
        cropHealthScore: 92,
        plantStandEstimate: 142500,
        emergentRatePct: 95.0,
        stressZonesDetected: 2,
        pestDiseaseAlert: 'Moderate Fall Armyworm egg cluster detected in East Quadrant',
        weedPressurePct: 4.2,
        targetedSprayingPrescription: 'Deploy DJI Agras T40 with 12.5 L/Ha RAB certified Neem bio-pesticide along East Perimeter Buffer (0.4 Ha).',
        triDataFusionSummary: 'Drone sub-cm scan confirms satellite NDVI drop was caused by localized fall armyworm egg masses, matched by LoRaWAN IoT 32% soil moisture.',
        aiAerialAdvisory: 'Sub-centimeter aerial drone orthomosaic scan confirms 92% canopy health with 0.74 NDVI. Early fall armyworm egg clusters detected in Quadrant B. Precision drone bio-spraying recommended.'
      });
    } finally {
      setIsAiAnalyzing(false);
    }
  };

  // Handle AI Copilot Query
  const handleCopilotQuery = () => {
    if (!copilotQuery) return;
    setIsCopilotThinking(true);
    setTimeout(() => {
      setCopilotResponse(
        `Gemini 3.6 Flash Aerial Copilot Analysis:\n\nBased on 0.8 cm/pixel sub-centimeter imagery and 5-band multispectral RE (Red Edge) reflectance, the average NDVI is 0.74 with 142,500 total maize plants counted (95.0% emergence rate).\n\nActionable Prescription:\n1. Target 0.4 Ha in Quadrant B with DJI Agras T40 delivering 12.5 Liters/Ha organic copper bio-fungicide.\n2. Maintain 3.5m flight altitude and 6.5m swath width under safe wind speed (${weatherWindKmH} km/h).`
      );
      setIsCopilotThinking(false);
    }, 1100);
  };

  // Create Flight Booking
  const handleCreateBooking = (e: React.FormEvent) => {
    e.preventDefault();
    const created: DroneFlightRequest = {
      id: `flt-${Date.now()}`,
      farmerName: 'Jean-Baptiste Hakizimana',
      farmName: bookingFarmName,
      district: bookingDistrict,
      farmAreaHa: bookingAreaHa,
      serviceRequested: selectedService,
      scheduledDate: 'Tomorrow at 09:00 AM',
      offeredFeeRwf: bookingFeeRwf,
      status: 'Planned',
      assignedOperatorName: 'Jean-Luc Nshimiyimana (AgriFly)',
      assignedDroneModel: 'DJI Mavic 3 Multispectral',
      flightBoundaryCoordinates: 'POLYGON((30.322 1.305, 30.326 1.305, 30.326 1.309, 30.322 1.309))'
    };
    setFlightRequests(prev => [created, ...prev]);
    setShowBookingModal(false);
  };

  // Register New Operator
  const handleRegisterOperator = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOpName || !newOpCompany) return;
    const newOp: DroneOperator = {
      id: `op-${Date.now()}`,
      operatorName: newOpName,
      companyName: newOpCompany,
      rcaaLicenseNumber: newOpRcaa || `RCAA-UAS-2026-${Math.floor(Math.random()*899+100)}`,
      certificationStatus: 'RCAA Certified',
      phoneContact: '+250 788 000 111',
      districtBase: newOpDistrict,
      ratingScore: 5.0,
      completedFlightsCount: 1,
      fleetSizeCount: 2,
      hourlyServiceRateRwf: 28000
    };
    setOperatorsList(prev => [...prev, newOp]);
    setShowRegisterOperatorModal(false);
    setNewOpName('');
    setNewOpCompany('');
    setNewOpRcaa('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-sky-900 via-blue-900 to-indigo-950 text-white rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-sky-700/60 rounded-xl border border-sky-400/30 backdrop-blur-md">
              <Compass className="w-8 h-8 text-sky-300 animate-spin-slow" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
                AGRIWISE Drone Agriculture & Aerial Analytics
                <span className="text-xs bg-sky-500/30 text-sky-200 border border-sky-400/40 px-2.5 py-0.5 rounded-full font-medium">
                  RCAA Certified Operator Fleet
                </span>
              </h1>
              <p className="text-sky-200 text-sm mt-0.5">
                Sub-Centimeter Multispectral Scouting • Stand Counting • Targeted Bio-Spraying • Satellite-IoT Tri-Data Fusion
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setShowBookingModal(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-sky-400 to-blue-500 hover:from-sky-300 hover:to-blue-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-lg transition-all border border-sky-300/40"
            >
              <Plus className="w-4 h-4" /> Request Drone Scan
            </button>

            <button
              onClick={runAiAerialScan}
              disabled={isAiAnalyzing}
              className="flex items-center gap-2 bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-400 hover:to-purple-400 text-white font-bold px-4 py-2.5 rounded-xl text-xs shadow-lg transition-all border border-indigo-300/40 disabled:opacity-50"
            >
              <Sparkles className={`w-4 h-4 ${isAiAnalyzing ? 'animate-spin' : ''}`} />
              {isAiAnalyzing ? 'Analyzing Imagery...' : 'AI Aerial Scan'}
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800">
        {[
          { id: 'overview', label: 'Flight Command Overview', icon: Compass },
          { id: 'marketplace', label: 'Drone Marketplace & Escrow', icon: Plane },
          { id: 'planner', label: 'Flight Boundary Planner', icon: Crosshair },
          { id: 'ai_vision', label: 'Multispectral Inspection & Counting', icon: Camera },
          { id: 'tri_fusion', label: 'Satellite-Drone-IoT Tri-Fusion', icon: Layers },
          { id: 'spraying', label: 'Precision Spraying Prescriptions', icon: Droplets },
          { id: 'operators', label: 'RCAA Operator Fleet Registry', icon: UserCheck },
          { id: 'copilot', label: 'Gemini Aerial AI Copilot', icon: Bot }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-sky-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Gemini AI Scan Result Alert Box (if triggered) */}
      {aiAnalysisResult && (
        <div className="bg-slate-900 border border-sky-500/40 rounded-2xl p-5 text-white shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sky-400 text-sm font-bold">
              <Sparkles className="w-5 h-5 animate-spin text-sky-300" />
              Gemini 3.6 Flash Aerial Multispectral Diagnostic Summary
            </div>
            <span className="text-xs bg-sky-500/20 text-sky-300 border border-sky-400/40 px-3 py-1 rounded-full font-mono font-bold">
              Average NDVI: {aiAnalysisResult.averageNdvi}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700">
              <span className="text-[11px] text-slate-400 block mb-1">Emerged Plant Stand Count</span>
              <span className="text-lg font-extrabold text-white font-mono">
                {aiAnalysisResult.plantStandEstimate.toLocaleString()} Plants
              </span>
              <span className="text-[11px] text-emerald-400 block mt-0.5 font-medium">
                Emergence: {aiAnalysisResult.emergentRatePct}%
              </span>
            </div>

            <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700">
              <span className="text-[11px] text-slate-400 block mb-1">Stress Zones Found</span>
              <span className="text-lg font-extrabold text-amber-400 font-mono">
                {aiAnalysisResult.stressZonesDetected} Zones Detected
              </span>
              <span className="text-[11px] text-slate-300 block mt-0.5">
                Weed Pressure: {aiAnalysisResult.weedPressurePct}%
              </span>
            </div>

            <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700 md:col-span-2">
              <span className="text-[11px] text-slate-400 block mb-1">Pest & Disease Detection</span>
              <span className="text-xs font-bold text-rose-300 flex items-center gap-1">
                <AlertTriangle className="w-4 h-4 flex-shrink-0 text-rose-400" />
                {aiAnalysisResult.pestDiseaseAlert}
              </span>
            </div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-xl text-xs text-slate-300 leading-relaxed border border-slate-700/60 space-y-2">
            <div>
              <strong className="text-sky-400 block mb-0.5">Targeted Bio-Spraying Prescription:</strong>
              {aiAnalysisResult.targetedSprayingPrescription}
            </div>
            <div>
              <strong className="text-purple-400 block mb-0.5">Tri-Data Fusion Finding:</strong>
              {aiAnalysisResult.triDataFusionSummary}
            </div>
          </div>
        </div>
      )}

      {/* TAB 1: FLIGHT COMMAND OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Top KPI Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Certified Operators</span>
                <div className="p-2 bg-sky-100 dark:bg-sky-950/40 text-sky-600 rounded-xl">
                  <UserCheck className="w-5 h-5" />
                </div>
              </div>
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono">
                {operatorsList.length} Operators
              </div>
              <div className="mt-2 text-xs text-slate-500 flex justify-between">
                <span>RCAA Licensed</span>
                <span className="text-emerald-600 font-medium">100% Verified</span>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Active Drone Fleet</span>
                <div className="p-2 bg-blue-100 dark:bg-blue-950/40 text-blue-600 rounded-xl">
                  <Plane className="w-5 h-5" />
                </div>
              </div>
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono">
                {dronesList.length} Drones
              </div>
              <div className="mt-2 text-xs text-slate-500 flex justify-between">
                <span>Sprayers & Multispectral</span>
                <span className="text-sky-600 font-medium">Ready for Flight</span>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Flight Requests</span>
                <div className="p-2 bg-indigo-100 dark:bg-indigo-950/40 text-indigo-600 rounded-xl">
                  <Calendar className="w-5 h-5" />
                </div>
              </div>
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono">
                {flightRequests.length} Bookings
              </div>
              <div className="mt-2 text-xs text-slate-500 flex justify-between">
                <span>MoMo Escrow Secured</span>
                <span className="text-emerald-600 font-medium">Active Queue</span>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Area Scanned (YTD)</span>
                <div className="p-2 bg-teal-100 dark:bg-teal-950/40 text-teal-600 rounded-xl">
                  <Layers className="w-5 h-5" />
                </div>
              </div>
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono">
                1,840 Ha
              </div>
              <div className="mt-2 text-xs text-slate-500 flex justify-between">
                <span>0.8 cm Sub-Centimeter</span>
                <span className="text-teal-600 font-medium">High Resolution</span>
              </div>
            </div>
          </div>

          {/* Active Flight Pipeline Table */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                <Compass className="w-5 h-5 text-sky-600" />
                Active Flight Service Requests & Flight Pipeline
              </h3>
              <button
                onClick={() => setShowBookingModal(true)}
                className="text-xs bg-sky-600 text-white font-bold px-3.5 py-1.5 rounded-lg hover:bg-sky-700 transition-colors flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Request New Flight
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider bg-slate-50 dark:bg-slate-800/40">
                    <th className="py-3 px-4">Farm & Farmer</th>
                    <th className="py-3 px-4">Service Requested</th>
                    <th className="py-3 px-4">Area & District</th>
                    <th className="py-3 px-4">Assigned Operator & Hardware</th>
                    <th className="py-3 px-4">Scheduled Date</th>
                    <th className="py-3 px-4">Fee (MoMo Escrow)</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {flightRequests.map(req => (
                    <tr key={req.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white">
                        {req.farmName}
                        <span className="block font-normal text-slate-500 text-[11px]">{req.farmerName}</span>
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-sky-600 dark:text-sky-400">
                        {req.serviceRequested}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                        {req.farmAreaHa} Ha
                        <span className="block text-[11px] text-slate-400">{req.district}</span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300">
                        {req.assignedOperatorName}
                        <span className="block font-mono text-[11px] text-slate-400">{req.assignedDroneModel}</span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300 font-mono">
                        {req.scheduledDate}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-emerald-600 dark:text-emerald-400 font-mono">
                        {req.offeredFeeRwf.toLocaleString()} Rwf
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold ${
                          req.status === 'Completed'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300'
                            : req.status === 'Weather Approved'
                            ? 'bg-sky-100 text-sky-800 dark:bg-sky-950/50 dark:text-sky-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300'
                        }`}>
                          <CheckCircle2 className="w-3 h-3" /> {req.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DRONE SERVICE MARKETPLACE */}
      {activeTab === 'marketplace' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Plane className="w-5 h-5 text-sky-600" />
                  AGRIWISE Precision Drone Services Catalog
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Book certified RCAA drone operators for sub-centimeter crop scouting, stand counting, and targeted bio-spraying. Secured by Mobile Money Escrow.
                </p>
              </div>

              <button
                onClick={() => setShowBookingModal(true)}
                className="bg-sky-600 hover:bg-sky-700 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2"
              >
                <Plus className="w-4 h-4" /> Book Drone Scan
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  title: 'Multispectral Crop Health Scan',
                  subtitle: '5-Band NDVI & Red Edge Vigor Mapping',
                  rate: '12,000 Rwf / Ha',
                  desc: 'Detects invisible plant chlorophyll stress and water deficit 10-14 days before visible leaf yellowing.',
                  hardware: 'DJI Mavic 3 Multispectral (M3M)'
                },
                {
                  title: 'Plant Stand Density & Counting',
                  subtitle: '0.8 cm Sub-Centimeter RGB Emergency Stand Scan',
                  rate: '15,000 Rwf / Ha',
                  desc: 'Individual crop plant counting for maize, rice, and potato seed germination verification.',
                  hardware: 'WingtraOne GEN II VTOL'
                },
                {
                  title: 'Targeted Precision Bio-Spraying',
                  subtitle: 'Centrifugal Ultra-Low Volume Droplets',
                  rate: '25,000 Rwf / Ha',
                  desc: 'Applies RAB certified bio-pesticides and liquid foliar NPK fertilizers directly onto infected hot-spots.',
                  hardware: 'DJI Agras T40 Heavy Sprayer'
                }
              ].map((svc, idx) => (
                <div key={idx} className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold uppercase text-sky-600 dark:text-sky-400">Service Package</span>
                      <span className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400 font-mono">{svc.rate}</span>
                    </div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-base mb-1">{svc.title}</h4>
                    <p className="text-xs text-slate-500 font-medium mb-3">{svc.subtitle}</p>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-4">{svc.desc}</p>
                  </div>

                  <div className="pt-3 border-t border-slate-200 dark:border-slate-700/60 flex items-center justify-between">
                    <span className="text-[11px] font-mono text-slate-400">{svc.hardware}</span>
                    <button
                      onClick={() => {
                        setSelectedService(svc.title as DroneServiceType);
                        setShowBookingModal(true);
                      }}
                      className="text-xs bg-sky-600 hover:bg-sky-700 text-white font-bold px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1"
                    >
                      Book Now <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: FLIGHT BOUNDARY PLANNER */}
      {activeTab === 'planner' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Crosshair className="w-5 h-5 text-sky-600" />
                  Waypoint Flight Boundary Planner & Weather Pre-Check
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Define automated grid lawnmower search paths, altitude ceilings, and conduct safety weather pre-flight verification.
                </p>
              </div>

              <span className="text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300 px-3 py-1 rounded-full border border-emerald-300/40 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> RCAA Airspace Clearance Granted
              </span>
            </div>

            {/* Flight Parameter Controls */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex justify-between mb-1">
                  <span>Flight Altitude Above Ground Level (AGL):</span>
                  <span className="font-mono text-sky-600 font-bold">{flightAltitudeMeters} meters</span>
                </label>
                <input
                  type="range"
                  min="20"
                  max="120"
                  value={flightAltitudeMeters}
                  onChange={(e) => setFlightAltitudeMeters(Number(e.target.value))}
                  className="w-full accent-sky-600 h-2 bg-slate-200 rounded-lg cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 block mt-1">
                  Ground Sampling Distance (GSD): {((flightAltitudeMeters * 0.8) / 45).toFixed(1)} cm/pixel
                </span>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex justify-between mb-1">
                  <span>Cruising Velocity:</span>
                  <span className="font-mono text-sky-600 font-bold">{flightSpeedMs} m/s</span>
                </label>
                <input
                  type="range"
                  min="3.0"
                  max="15.0"
                  step="0.5"
                  value={flightSpeedMs}
                  onChange={(e) => setFlightSpeedMs(Number(e.target.value))}
                  className="w-full accent-sky-600 h-2 bg-slate-200 rounded-lg cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 block mt-1">
                  Estimated Scan Duration: 14 Minutes for 2.5 Ha
                </span>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex justify-between mb-1">
                  <span>Weather Station Wind Velocity:</span>
                  <span className={`font-mono font-bold ${weatherWindKmH > 15 ? 'text-rose-500' : 'text-emerald-600'}`}>
                    {weatherWindKmH} km/h
                  </span>
                </label>
                <input
                  type="range"
                  min="2.0"
                  max="25.0"
                  step="0.5"
                  value={weatherWindKmH}
                  onChange={(e) => setWeatherWindKmH(Number(e.target.value))}
                  className="w-full accent-sky-600 h-2 bg-slate-200 rounded-lg cursor-pointer"
                />
                <span className={`text-[10px] font-bold block mt-1 ${weatherWindKmH > 15 ? 'text-rose-500' : 'text-emerald-600'}`}>
                  {weatherWindKmH > 15 ? 'HIGH WIND WARNING! Spray drift risk.' : 'Safe Wind (<15 km/h) Approved.'}
                </span>
              </div>
            </div>

            {/* Virtual Waypoint Grid Canvas */}
            <div className="relative w-full h-[360px] bg-gradient-to-br from-slate-950 via-slate-900 to-sky-950 rounded-2xl overflow-hidden border border-slate-800 shadow-inner p-6 flex flex-col justify-between">
              <div
                className="absolute inset-0 opacity-20 pointer-events-none"
                style={{
                  backgroundImage: 'radial-gradient(#0ea5e9 1px, transparent 1px)',
                  backgroundSize: '20px 20px'
                }}
              />

              <div className="relative z-10 flex justify-between items-center text-xs">
                <div className="bg-slate-900/90 border border-slate-700/80 rounded-xl p-3 text-white">
                  <div className="font-bold text-sky-400">Target Waypoint Grid: Hakizimana Plot A</div>
                  <div className="text-[11px] text-slate-300">4 Corner Points • Front Overlap: 75% • Side Overlap: 70%</div>
                </div>

                <div className="bg-slate-900/90 border border-slate-700/80 rounded-xl p-3 text-white font-mono text-[11px]">
                  Status: {weatherWindKmH <= 15 ? 'PRE-FLIGHT CLEARED' : 'FLIGHT HOLD (WIND)'}
                </div>
              </div>

              {/* Waypoint Path Simulation Visual */}
              <div className="relative z-10 my-auto flex justify-around items-center text-center">
                {['Waypoint #1 (Takeoff)', 'Waypoint #2 (East Pass)', 'Waypoint #3 (West Pass)', 'Waypoint #4 (RTH Return)'].map((wp, i) => (
                  <div key={i} className="bg-slate-900/80 border border-sky-500/40 p-3 rounded-xl backdrop-blur-md text-white text-xs">
                    <span className="w-2.5 h-2.5 rounded-full bg-sky-400 inline-block mr-1.5 animate-pulse" />
                    {wp}
                  </div>
                ))}
              </div>

              <div className="relative z-10 flex justify-between items-center text-[11px] text-slate-400 border-t border-slate-800 pt-3">
                <span>RC Frequency: 2.4 GHz & 5.8 GHz Dual-Band • RTK Centimeter Accuracy</span>
                <span className="text-sky-400 font-mono">Camera: 20MP RGB + 4-Band Multispectral</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: MULTISPECTRAL INSPECTION & PLANT COUNTING */}
      {activeTab === 'ai_vision' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Camera className="w-5 h-5 text-indigo-600" />
                  Multispectral Crop Health Inspection & Sub-Cm Plant Stand Counter
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  0.8 cm/pixel sub-centimeter imagery processing showing NDVI vegetation vigor, plant density, and early stress hotspots.
                </p>
              </div>

              <span className="text-xs bg-indigo-100 text-indigo-800 dark:bg-indigo-950/50 dark:text-indigo-300 px-3 py-1 rounded-full font-bold border border-indigo-300/40">
                Orthomosaic Scan Complete
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Aerial Orthomosaic Viewer Simulation */}
              <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-md h-[360px] group">
                <img
                  src={inspectionReport.orthomosaicMapUrl}
                  alt="Drone Aerial Orthomosaic"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-slate-950/40 p-4 flex flex-col justify-between text-white">
                  <div className="flex justify-between items-center text-xs">
                    <span className="bg-sky-600/90 text-white font-bold px-2.5 py-1 rounded-lg backdrop-blur-md">
                      0.8 cm/pixel High-Res RGB
                    </span>
                    <span className="bg-slate-900/80 font-mono text-emerald-400 px-2.5 py-1 rounded-lg border border-slate-700">
                      NDVI Vigor: {inspectionReport.averageNdvi}
                    </span>
                  </div>

                  <div className="space-y-1 bg-slate-900/80 p-3 rounded-xl border border-slate-700 backdrop-blur-md">
                    <div className="font-bold text-sky-300 text-xs">Hakizimana Plot A (2.5 Hectares)</div>
                    <div className="text-[11px] text-slate-300">
                      Total Plants Counted: <span className="font-bold text-white">{inspectionReport.plantStandCountEstimated.toLocaleString()}</span> ({inspectionReport.emergentRatePct}% Emergence)
                    </div>
                  </div>
                </div>
              </div>

              {/* Inspection Metrics Breakdown */}
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                    <span className="text-[11px] text-slate-500 block mb-1">Emerged Plant Count</span>
                    <span className="text-xl font-extrabold text-slate-900 dark:text-white font-mono">
                      {inspectionReport.plantStandCountEstimated.toLocaleString()}
                    </span>
                    <span className="text-[11px] text-emerald-600 block mt-0.5">Expected: 150,000</span>
                  </div>

                  <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                    <span className="text-[11px] text-slate-500 block mb-1">Pest & Disease Risk</span>
                    <span className="text-xl font-extrabold text-amber-600 font-mono">
                      {inspectionReport.pestDiseaseRiskLevel}
                    </span>
                    <span className="text-[11px] text-slate-400 block mt-0.5">2 Hotspots Found</span>
                  </div>
                </div>

                <div className="bg-slate-900 text-white p-4 rounded-xl space-y-2 border border-slate-800">
                  <span className="text-xs font-bold text-sky-400 block">AI Aerial Diagnostic Summary:</span>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {inspectionReport.aiDiagnosticSummary}
                  </p>
                </div>

                <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 p-4 rounded-xl">
                  <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300 block mb-1">Agronomic Action Plan:</span>
                  <p className="text-xs text-emerald-900 dark:text-emerald-200">
                    {inspectionReport.recommendedPrescription}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: SATELLITE-DRONE-IOT TRI-DATA FUSION */}
      {activeTab === 'tri_fusion' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="mb-6">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-purple-600" />
                Satellite + Drone + IoT Triple Layer Data Fusion Engine
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Cross-validating 10m Sentinel-2 optical imagery with 0.8 cm drone orthomosaics and LoRaWAN soil telemetry probes.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              {/* Layer 1: Satellite */}
              <div className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700">
                <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider block mb-2">
                  Layer 1: Spaceborne Satellite
                </span>
                <p className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                  {triFusionMatrix.satelliteData.sensor}
                </p>
                <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1 mt-3">
                  <div className="flex justify-between">
                    <span>Macro NDVI Score:</span>
                    <span className="font-mono font-bold text-indigo-600">{triFusionMatrix.satelliteData.ndviVigor}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Drought Moisture Index:</span>
                    <span className="font-medium text-amber-600">{triFusionMatrix.satelliteData.droughtIndex}</span>
                  </div>
                </div>
              </div>

              {/* Layer 2: Drone */}
              <div className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700">
                <span className="text-xs font-bold text-sky-600 dark:text-sky-400 uppercase tracking-wider block mb-2">
                  Layer 2: Aerial Drone Scan
                </span>
                <p className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                  Sub-Centimeter Multispectral
                </p>
                <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1 mt-3">
                  <div className="flex justify-between">
                    <span>Resolution:</span>
                    <span className="font-mono font-bold text-sky-600">{triFusionMatrix.droneData.resolutionCmPixel} cm/pixel</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Disease Hotspot:</span>
                    <span className="font-bold text-rose-500">
                      {triFusionMatrix.droneData.diseaseHotspotFound ? 'CONFIRMED' : 'None'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Layer 3: IoT Sensor Probe */}
              <div className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700">
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block mb-2">
                  Layer 3: LoRaWAN IoT Soil Probe
                </span>
                <p className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                  Dragino LSE01 In-Situ
                </p>
                <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1 mt-3">
                  <div className="flex justify-between">
                    <span>Soil Moisture VWC:</span>
                    <span className="font-mono font-bold text-amber-600">{triFusionMatrix.iotSensorData.soilMoisturePct}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Soil Temp & pH:</span>
                    <span className="font-medium text-slate-700 dark:text-slate-200">
                      {triFusionMatrix.iotSensorData.soilTempC}°C | pH {triFusionMatrix.iotSensorData.phLevel}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Unified AI Synthesis Outcome */}
            <div className="bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 p-5 rounded-2xl text-white border border-purple-500/30">
              <span className="text-xs font-bold uppercase tracking-wider text-purple-300 block mb-2 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-400" /> Tri-Data Fusion Synthesis Recommendation
              </span>
              <p className="text-xs text-slate-200 leading-relaxed">
                {triFusionMatrix.unifiedAiRecommendation}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: PRECISION SPRAYING PRESCRIPTIONS */}
      {activeTab === 'spraying' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Droplets className="w-5 h-5 text-sky-600" />
                  DJI Agras T40 Precision Bio-Spraying Prescriptions
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Centrifugal atomization spray dosage calculations, swath width safety, and water buffer environmental compliance.
                </p>
              </div>

              <span className="text-xs bg-sky-100 text-sky-800 dark:bg-sky-950/50 dark:text-sky-300 px-3 py-1 rounded-full font-bold border border-sky-300/40">
                Bio-Spraying Recipe Active
              </span>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <span className="text-[11px] text-slate-500 block mb-1">Target Zone & Crop</span>
                  <span className="font-bold text-slate-900 dark:text-white text-sm">{sprayingPrescription.targetZoneName}</span>
                </div>

                <div>
                  <span className="text-[11px] text-slate-500 block mb-1">Input Chemical / Bio-Fungicide</span>
                  <span className="font-bold text-sky-600 dark:text-sky-400 text-xs">{sprayingPrescription.chemicalOrBioInput}</span>
                </div>

                <div>
                  <span className="text-[11px] text-slate-500 block mb-1">Total Liquid Dosage</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400 text-sm font-mono">
                    {sprayingPrescription.totalLiquidVolumeLiters} Liters ({sprayingPrescription.dosagePerHaLiters} L/Ha)
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-3 border-t border-slate-200 dark:border-slate-700/60 text-xs text-slate-600 dark:text-slate-300">
                <div>Altitude AGL: <strong>{sprayingPrescription.droneFlightAltitudeMeters} m</strong></div>
                <div>Swath Width: <strong>{sprayingPrescription.swathWidthMeters} m</strong></div>
                <div>Nozzle Flow Rate: <strong>{sprayingPrescription.nozzleFlowRateLmin} L/min</strong></div>
              </div>

              <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-300 dark:border-emerald-800/60 rounded-xl p-3 text-xs text-emerald-900 dark:text-emerald-200 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                <span>Environmental Safety: {sprayingPrescription.environmentalSafetyStatus}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: certified OPERATOR FLEET REGISTRY */}
      {activeTab === 'operators' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <UserCheck className="w-5 h-5 text-sky-600" />
                  Rwanda Civil Aviation Authority (RCAA) Certified Drone Operators
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Licensed UAS pilots, fleet capacity, and district base distribution across Northern, Eastern, and Western provinces.
                </p>
              </div>

              <button
                onClick={() => setShowRegisterOperatorModal(true)}
                className="bg-sky-600 hover:bg-sky-700 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2"
              >
                <Plus className="w-4 h-4" /> Onboard Operator
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {operatorsList.map(op => (
                <div key={op.id} className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-sky-600 bg-sky-100 dark:bg-sky-950/60 px-2.5 py-0.5 rounded-full border border-sky-300/40">
                        {op.certificationStatus}
                      </span>
                      <span className="text-xs font-bold text-amber-500 flex items-center gap-1">
                        ★ {op.ratingScore} ({op.completedFlightsCount} flights)
                      </span>
                    </div>

                    <h4 className="font-bold text-slate-900 dark:text-white text-base">{op.operatorName}</h4>
                    <p className="text-xs text-slate-500 font-medium mb-3">{op.companyName}</p>

                    <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1 mb-4">
                      <div className="flex justify-between">
                        <span>RCAA License:</span>
                        <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{op.rcaaLicenseNumber}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Base District:</span>
                        <span className="font-medium">{op.districtBase}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Fleet Size:</span>
                        <span className="font-bold text-sky-600">{op.fleetSizeCount} Drones</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-xs">
                    <span className="font-mono text-slate-500">{op.phoneContact}</span>
                    <span className="font-bold text-emerald-600 dark:text-emerald-400 font-mono">
                      {op.hourlyServiceRateRwf.toLocaleString()} Rwf/Hr
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 8: GEMINI AERIAL AI COPILOT */}
      {activeTab === 'copilot' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="mb-6">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Bot className="w-5 h-5 text-indigo-600" />
                Gemini 3.6 Flash Aerial Precision Copilot
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Ask questions regarding sub-centimeter orthomosaics, plant population density, or bio-pesticide flight safety.
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={copilotQuery}
                  onChange={(e) => setCopilotQuery(e.target.value)}
                  placeholder="Ask Gemini Aerial AI..."
                  className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  onClick={handleCopilotQuery}
                  disabled={isCopilotThinking}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-5 py-2.5 rounded-xl text-xs transition-colors flex items-center gap-2"
                >
                  <Send className="w-4 h-4" /> Ask AI
                </button>
              </div>

              {copilotResponse && (
                <div className="bg-slate-900 text-white p-5 rounded-2xl border border-indigo-500/40 text-xs leading-relaxed whitespace-pre-line space-y-2">
                  <span className="text-indigo-400 font-bold block flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-indigo-300" /> AI Aerial Analysis Output:
                  </span>
                  {copilotResponse}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* BOOKING MODAL */}
      {showBookingModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Plane className="w-5 h-5 text-sky-600" /> Request Precision Drone Service
            </h3>

            <form onSubmit={handleCreateBooking} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Farm Name & Plot</label>
                <input
                  type="text"
                  value={bookingFarmName}
                  onChange={(e) => setBookingFarmName(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Service Type</label>
                <select
                  value={selectedService}
                  onChange={(e) => setSelectedService(e.target.value as DroneServiceType)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                >
                  <option value="Multispectral Crop Health Scan (NDVI/RE)">Multispectral Crop Health Scan (NDVI/RE)</option>
                  <option value="Plant Stand Density & Counting">Plant Stand Density & Counting</option>
                  <option value="Targeted Precision Bio-Spraying">Targeted Precision Bio-Spraying</option>
                  <option value="High-Res RGB & Boundary Mapping">High-Res RGB & Boundary Mapping</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Area (Hectares)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={bookingAreaHa}
                    onChange={(e) => setBookingAreaHa(Number(e.target.value))}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Est. Fee (Rwf)</label>
                  <input
                    type="number"
                    value={bookingFeeRwf}
                    onChange={(e) => setBookingFeeRwf(Number(e.target.value))}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white font-mono"
                  />
                </div>
              </div>

              <div className="bg-sky-50 dark:bg-sky-950/40 p-3 rounded-xl border border-sky-200 dark:border-sky-800 text-[11px] text-sky-900 dark:text-sky-200 flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-sky-600 flex-shrink-0" />
                <span>Mobile Money Escrow will lock <strong>{bookingFeeRwf.toLocaleString()} Rwf</strong> until scan report delivery.</span>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBookingModal(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl shadow-md"
                >
                  Confirm Booking
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REGISTER OPERATOR MODAL */}
      {showRegisterOperatorModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-sky-600" /> Onboard RCAA Certified Drone Operator
            </h3>

            <form onSubmit={handleRegisterOperator} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Pilot Name</label>
                <input
                  type="text"
                  required
                  value={newOpName}
                  onChange={(e) => setNewOpName(e.target.value)}
                  placeholder="e.g. Emmanuel Ndayisaba"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Company / Cooperative Name</label>
                <input
                  type="text"
                  required
                  value={newOpCompany}
                  onChange={(e) => setNewOpCompany(e.target.value)}
                  placeholder="e.g. Rwanda Agro-Aviation Solutions"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">RCAA License No.</label>
                  <input
                    type="text"
                    value={newOpRcaa}
                    onChange={(e) => setNewOpRcaa(e.target.value)}
                    placeholder="RCAA-UAS-2026-..."
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">District Base</label>
                  <select
                    value={newOpDistrict}
                    onChange={(e) => setNewOpDistrict(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  >
                    <option value="Musanze District">Musanze District</option>
                    <option value="Nyagatare District">Nyagatare District</option>
                    <option value="Rubavu District">Rubavu District</option>
                    <option value="Huye District">Huye District</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRegisterOperatorModal(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl shadow-md"
                >
                  Register Operator
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
