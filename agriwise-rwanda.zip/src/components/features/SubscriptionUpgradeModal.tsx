import React, { useState } from 'react';
import { Language, UserSubscription } from '../../types';
import { translations } from '../../data/translations';
import {
  Sparkles,
  Zap,
  CheckCircle2,
  X,
  ShieldCheck,
  Award,
  Smartphone,
  ArrowRight,
  Bot,
  HelpCircle,
  Crown,
  Lock,
  RotateCcw
} from 'lucide-react';

interface SubscriptionUpgradeModalProps {
  subscription: UserSubscription;
  language: Language;
  onClose: () => void;
  onSelectPlanPayment: (planId: 'farmer_premium' | 'professional' | 'enterprise', amountRwf: number, title: string) => void;
}

export const SubscriptionUpgradeModal: React.FC<SubscriptionUpgradeModalProps> = ({
  subscription,
  language,
  onClose,
  onSelectPlanPayment,
}) => {
  const t = translations[language];

  const plans = [
    {
      id: 'free',
      name: language === 'rw' ? 'Gahunda y\'Buntu (Free)' : 'Free Trial',
      priceRwf: 0,
      period: language === 'rw' ? 'Burembwe' : 'Forever',
      description: language === 'rw' ? 'Ibaza bitabangamiwe kuri AI y\'ubuhinzi' : 'Basic farm records & 2 free AI consultations/month',
      features: [
        language === 'rw' ? 'Ibazo 2 bya AI buri kwezi' : '2 Free AI consultations/month',
        language === 'rw' ? 'Ikirere n\'ibihe by\'ibanze' : 'Basic Weather Forecast',
        language === 'rw' ? 'Iyandikisha ry\'umurima 1' : '1 Mapped Farm Parcel',
      ],
      badge: language === 'rw' ? 'IYI IRIRINGANIYE' : 'CURRENT PLAN',
      isPopular: false,
    },
    {
      id: 'farmer_premium',
      name: language === 'rw' ? 'Umuhinzi Premium' : 'Farmer Premium',
      priceRwf: 3000,
      period: language === 'rw' ? 'kwezi' : 'month',
      description: language === 'rw' ? 'AI idashira, paji y\'indwara n\'isoko' : 'Unlimited AI assistant, AI disease diagnosis & market intelligence',
      features: [
        language === 'rw' ? 'AI Assistant idafite imipaka' : 'Unlimited AI Assistant Queries',
        language === 'rw' ? 'Gusuzuma indwara z\'ibihingwa n\'ifoto' : 'Camera Plant Disease Diagnosis',
        language === 'rw' ? 'Isoko n\'amatsinda y\'ibiciro MTN MoMo' : 'Direct Marketplace Access & Escrow',
        language === 'rw' ? 'Inama z\'ibihe z\'umwihariko' : 'Hyper-local Agronomy Recommendations',
      ],
      badge: language === 'rw' ? 'IYAGUKONGA (POPULAR)' : 'MOST POPULAR',
      isPopular: true,
    },
    {
      id: 'professional',
      name: language === 'rw' ? 'Abahanga n\'Ingabo (Pro)' : 'Professional Plan',
      priceRwf: 15000,
      period: language === 'rw' ? 'kwezi' : 'month',
      description: language === 'rw' ? 'Aba-Expert ba RAB, Analytics n\'amatungo' : 'RAB Expert consultations, advanced satellite analytics & reports',
      features: [
        language === 'rw' ? 'Ibintu byose muri Farmer Premium' : 'Everything in Farmer Premium',
        language === 'rw' ? 'Guhamagara Abahanga ba RAB (Hotline 1111)' : 'Direct RAB Agro-Expert Phone Access',
        language === 'rw' ? 'Satellite NDVI Farm Health Monitoring' : 'Satellite NDVI Health Analytics',
        language === 'rw' ? 'Raporo y\'Inguzanyo mu Maduka' : 'Exportable Credit Scoring Reports',
      ],
      badge: 'RECOMMENDED',
      isPopular: false,
    },
    {
      id: 'enterprise',
      name: language === 'rw' ? 'Koperative n\'Inzego (Enterprise)' : 'Enterprise Plan',
      priceRwf: 75000,
      period: language === 'rw' ? 'kwezi' : 'month',
      description: language === 'rw' ? 'Koperative n\'Aba-Dealer' : 'Cooperatives, Agro-dealers, Financial Institutions & NGO dashboards',
      features: [
        language === 'rw' ? 'Umutungo wa Koperative n\'abahinzi 500+' : 'Multi-farmer Cooperative Dashboard (500+)',
        language === 'rw' ? 'Bulk SMS & USSD Broadcast Gateway' : 'Bulk SMS & USSD Broadcast Messaging',
        language === 'rw' ? 'API Integration n\'amazi y\'inguzanyo' : 'Custom Financial API & Dedicated Support',
      ],
      badge: 'ENTERPRISE',
      isPopular: false,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 max-w-4xl w-full text-white space-y-6 shadow-2xl relative my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="space-y-2 border-b border-slate-800 pb-4">
          <div className="inline-flex items-center gap-2 bg-emerald-500/15 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold text-emerald-300">
            <Crown className="w-3.5 h-3.5 text-emerald-400" />
            <span>AGRIWISE PREMIUM SUBSCRIPTION MONETIZATION</span>
          </div>

          <h2 className="text-2xl font-black text-white tracking-tight">
            {language === 'rw' ? 'Vugurura Akaunti Yanjye ku Kiciro cya Premium' : 'Upgrade to AGRIWISE Premium'}
          </h2>
          <p className="text-xs text-slate-300">
            {subscription.planId === 'free' ? (
              subscription.freeRequestsRemaining > 0 ? (
                <span>
                  Ufite <strong className="text-emerald-400">{subscription.freeRequestsRemaining} free AI consultation(s)</strong> remaining on your trial.
                </span>
              ) : (
                <span className="text-rose-400 font-bold">
                  ⚠️ Free trial limit reached (0 remaining). Upgrade now for unlimited AI assistance!
                </span>
              )
            ) : (
              <span>Your active plan: <strong className="text-emerald-400">{subscription.planName}</strong></span>
            )}
          </p>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {plans.map((plan) => {
            const isCurrent = subscription.planId === plan.id;
            return (
              <div
                key={plan.id}
                className={`rounded-2xl p-4 flex flex-col justify-between space-y-4 border transition-all ${
                  plan.isPopular
                    ? 'bg-slate-950 border-emerald-500/60 shadow-xl shadow-emerald-950/30 relative'
                    : isCurrent
                    ? 'bg-slate-950 border-slate-700'
                    : 'bg-slate-950/60 border-slate-800'
                }`}
              >
                <div>
                  {plan.isPopular && (
                    <span className="bg-emerald-500 text-slate-950 font-black text-[9px] uppercase tracking-wider px-2.5 py-0.5 rounded-full mb-2 inline-block shadow">
                      {plan.badge}
                    </span>
                  )}

                  <h3 className="font-bold text-white text-base">{plan.name}</h3>
                  <p className="text-[11px] text-slate-400 mt-1 min-h-[32px]">{plan.description}</p>

                  <div className="mt-3 text-emerald-400 font-black text-xl font-mono">
                    {plan.priceRwf === 0 ? '0 RWF' : `${plan.priceRwf.toLocaleString()} RWF`}
                    <span className="text-xs text-slate-400 font-normal"> /{plan.period}</span>
                  </div>

                  <ul className="mt-4 space-y-2 text-[11px] text-slate-300 border-t border-slate-800/80 pt-3">
                    {plan.features.map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  {isCurrent ? (
                    <button
                      disabled
                      className="w-full bg-slate-800 text-slate-400 font-bold py-2.5 rounded-xl text-xs cursor-default border border-slate-700"
                    >
                      Current Plan
                    </button>
                  ) : (
                    <button
                      onClick={() =>
                        onSelectPlanPayment(
                          plan.id as any,
                          plan.priceRwf,
                          `AGRIWISE ${plan.name} Subscription`
                        )
                      }
                      className={`w-full font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all shadow ${
                        plan.isPopular
                          ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black'
                          : 'bg-slate-800 hover:bg-slate-700 text-white'
                      }`}
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      <span>{language === 'rw' ? 'Kura ku MoMo' : 'Pay via MoMo'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Security Guarantee Footer */}
        <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>MTN MoMo (*182#) & Airtel Money instant activation with SMS receipt</span>
          </div>
          <span className="text-[10px] text-slate-500">Cancel or upgrade anytime with zero penalties</span>
        </div>
      </div>
    </div>
  );
};
