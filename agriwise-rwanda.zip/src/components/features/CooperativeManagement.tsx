import React, { useState, useEffect } from 'react';
import {
  CooperativeProfile,
  CooperativeMemberRecord,
  CollectionCenterDelivery,
  CooperativeBulkContract,
  CooperativeTransaction,
  User,
  Language
} from '../../types';
import {
  SAMPLE_COOPERATIVES,
  SAMPLE_MEMBERS,
  SAMPLE_DELIVERIES,
  SAMPLE_BULK_CONTRACTS,
  SAMPLE_TRANSACTIONS
} from '../../data/mockCooperativeData';
import { translations } from '../../data/translations';
import {
  Users,
  Building2,
  TrendingUp,
  Scale,
  FileCheck2,
  DollarSign,
  Sparkles,
  Plus,
  Search,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowUpRight,
  ShieldCheck,
  Send,
  PieChart,
  Layers,
  MapPin,
  Phone,
  BarChart3,
  Calendar,
  FileText
} from 'lucide-react';

interface CooperativeManagementProps {
  currentUser: User;
  language: Language;
  onInitiateMomoPayment: (amountRwf: number, title: string) => void;
}

export const CooperativeManagement: React.FC<CooperativeManagementProps> = ({
  currentUser,
  language,
  onInitiateMomoPayment,
}) => {
  const t = translations[language];

  // Active Cooperative State
  const [cooperative, setCooperative] = useState<CooperativeProfile>(SAMPLE_COOPERATIVES[0]);
  const [activeTab, setActiveTab] = useState<'overview' | 'members' | 'collection' | 'contracts' | 'finance' | 'ai_advisor'>('overview');

  // Data Collections
  const [members, setMembers] = useState<CooperativeMemberRecord[]>(SAMPLE_MEMBERS);
  const [deliveries, setDeliveries] = useState<CollectionCenterDelivery[]>(SAMPLE_DELIVERIES);
  const [contracts, setContracts] = useState<CooperativeBulkContract[]>(SAMPLE_BULK_CONTRACTS);
  const [transactions, setTransactions] = useState<CooperativeTransaction[]>(SAMPLE_TRANSACTIONS);

  // Search & Filters
  const [memberSearchQuery, setMemberSearchQuery] = useState('');

  // Modals State
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberPhone, setNewMemberPhone] = useState('+250 788 ');
  const [newMemberDistrict, setNewMemberDistrict] = useState('Nyagatare');
  const [newMemberFarmSize, setNewMemberFarmSize] = useState(2.0);
  const [newMemberCrop, setNewMemberCrop] = useState('Hybrid White Maize');

  // Collection Intake Modal
  const [showDeliveryModal, setShowDeliveryModal] = useState(false);
  const [delFarmerName, setDelFarmerName] = useState('John Ndayisaba');
  const [delCommodity, setDelCommodity] = useState('Hybrid White Maize');
  const [delWeightKg, setDelWeightKg] = useState(1500);
  const [delMoisture, setDelMoisture] = useState(13.0);
  const [delGrade, setDelGrade] = useState<'Grade A1 (Export Spec)' | 'Grade A2 (Standard)' | 'Grade B (Processing)'>('Grade A1 (Export Spec)');
  const [delPricePerKg, setDelPricePerKg] = useState(370);

  // AI Advisor State
  const [aiLoading, setAiLoading] = useState(false);
  const [aiAdvice, setAiAdvice] = useState<any>(null);

  // Run AI Cooperative Advisory on mount or coop change
  const fetchCoopAiAdvisory = async () => {
    setAiLoading(true);
    try {
      const res = await fetch('/api/ai/cooperative-intelligence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          coopName: cooperative.name,
          commodity: cooperative.mainCommodity,
          members: cooperative.totalMembers,
          totalHectares: cooperative.totalLandHectares,
          currentTons: cooperative.currentHarvestCollectedTons,
          language
        }),
      });
      const data = await res.json();
      setAiAdvice(data);
    } catch (e) {
      console.error(e);
    } finally {
      setAiLoading(false);
    }
  };

  useEffect(() => {
    fetchCoopAiAdvisory();
  }, [cooperative, language]);

  // Handlers
  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    const newMem: CooperativeMemberRecord = {
      id: `mem-${Date.now().toString().slice(-4)}`,
      farmerId: `usr-${Date.now()}`,
      farmerName: newMemberName,
      farmerPhone: newMemberPhone,
      district: newMemberDistrict,
      farmSizeHectares: Number(newMemberFarmSize),
      primaryCrop: newMemberCrop,
      seasonDeliveredTons: 0,
      payoutEarnedRwf: 0,
      payoutStatus: 'Pending Collection Settlement',
      joinedDate: new Date().toISOString().split('T')[0],
    };

    setMembers([newMem, ...members]);
    setCooperative({
      ...cooperative,
      totalMembers: cooperative.totalMembers + 1,
      totalLandHectares: cooperative.totalLandHectares + Number(newMemberFarmSize)
    });
    setShowAddMemberModal(false);
    setNewMemberName('');
  };

  const handleRecordDelivery = (e: React.FormEvent) => {
    e.preventDefault();
    const payout = delWeightKg * delPricePerKg;
    const newDel: CollectionCenterDelivery = {
      id: `del-${Date.now().toString().slice(-4)}`,
      farmerId: 'usr-88',
      farmerName: delFarmerName,
      commodity: delCommodity,
      quantityKg: Number(delWeightKg),
      qualityGrade: delGrade,
      moistureContentPct: Number(delMoisture),
      pricePerKgRwf: Number(delPricePerKg),
      totalPayoutRwf: payout,
      collectionCenterName: `${cooperative.district} Central Silo`,
      receivedByOfficer: currentUser.name || 'Field Officer',
      timestamp: 'Just now',
    };

    setDeliveries([newDel, ...deliveries]);
    const addedTons = Number(delWeightKg) / 1000;
    setCooperative({
      ...cooperative,
      currentHarvestCollectedTons: Number((cooperative.currentHarvestCollectedTons + addedTons).toFixed(1))
    });
    setShowDeliveryModal(false);
  };

  const filteredMembers = members.filter(m =>
    m.farmerName.toLowerCase().includes(memberSearchQuery.toLowerCase()) ||
    m.primaryCrop.toLowerCase().includes(memberSearchQuery.toLowerCase()) ||
    m.district.toLowerCase().includes(memberSearchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* Enterprise Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden text-white">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center space-x-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold mb-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>RCA Registered Agricultural Cooperative Platform</span>
            </div>

            <div className="flex items-center space-x-3">
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                {cooperative.name}
              </h1>
              <span className="bg-slate-800 text-slate-300 border border-slate-700 text-xs px-2.5 py-1 rounded-lg font-mono">
                {cooperative.registrationNumber}
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-400 max-w-3xl mt-1">
              District: <strong className="text-white">{cooperative.district}</strong> ({cooperative.sector} Sector) • Chair: <strong className="text-emerald-300">{cooperative.chairmanName}</strong> • Manager: <strong className="text-teal-300">{cooperative.managerName}</strong>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={cooperative.id}
              onChange={(e) => {
                const coop = SAMPLE_COOPERATIVES.find(c => c.id === e.target.value);
                if (coop) setCooperative(coop);
              }}
              className="bg-slate-800 text-emerald-300 border border-slate-700 font-bold text-xs px-3 py-2.5 rounded-xl"
            >
              {SAMPLE_COOPERATIVES.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>

            <button
              onClick={() => setShowDeliveryModal(true)}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow flex items-center space-x-1.5 transition-all"
            >
              <Scale className="w-4 h-4" />
              <span>Record Delivery</span>
            </button>
          </div>
        </div>
      </div>

      {/* Module Navigation Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2 flex flex-wrap items-center gap-2 text-xs">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'overview'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Executive Overview</span>
        </button>

        <button
          onClick={() => setActiveTab('members')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'members'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Members Roster ({members.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('collection')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'collection'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Scale className="w-4 h-4" />
          <span>Collection Center ({deliveries.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('contracts')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'contracts'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <FileCheck2 className="w-4 h-4 text-blue-400" />
          <span>Bulk Contracts ({contracts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('finance')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'finance'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <DollarSign className="w-4 h-4 text-amber-300" />
          <span>Finance & Dividends</span>
        </button>

        <button
          onClick={() => setActiveTab('ai_advisor')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'ai_advisor'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>AI Yield Forecast</span>
        </button>
      </div>

      {/* TAB 1: EXECUTIVE OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          
          {/* Key Metric Tiles Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Active Members</span>
                <Users className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-white">{cooperative.totalMembers} Farmers</div>
              <p className="text-[11px] text-emerald-400 font-medium"> Across {cooperative.totalLandHectares} Hectares Land Bank</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Season Harvest Progress</span>
                <Scale className="w-4 h-4 text-teal-400" />
              </div>
              <div className="text-2xl font-black text-white">{cooperative.currentHarvestCollectedTons} / {cooperative.expectedSeasonalHarvestTons} Tons</div>
              <p className="text-[11px] text-teal-300 font-medium">
                {Math.round((cooperative.currentHarvestCollectedTons / cooperative.expectedSeasonalHarvestTons) * 100)}% Target Collected
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Gross Commodity Revenue</span>
                <TrendingUp className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl font-black text-amber-300">{(cooperative.revenueRwf / 1000000).toFixed(1)}M RWF</div>
              <p className="text-[11px] text-amber-400 font-medium">Bulk Sales to Millers & Exporters</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Net Member Dividend Reserve</span>
                <DollarSign className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-emerald-400">
                {((cooperative.revenueRwf - cooperative.expensesRwf) / 1000000).toFixed(1)}M RWF
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Ready for MoMo Bulk Payouts</p>
            </div>
          </div>

          {/* AI Yield & Market Optimization Summary */}
          {aiAdvice && (
            <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 shadow-xl text-white space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2 text-emerald-300 font-bold text-sm">
                  <Sparkles className="w-5 h-5 text-amber-300" />
                  <span>AI Cooperative Enterprise Telemetry & Market Intelligence</span>
                </div>
                <span className="text-xs text-amber-300 font-bold">AI Confidence: {aiAdvice.aiConfidencePct}%</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="bg-slate-800 p-4 rounded-2xl space-y-1">
                  <span className="text-slate-400 block font-bold">Projected Final Yield:</span>
                  <span className="text-base font-black text-white">{aiAdvice.projectedFinalHarvestTons} Tons ({aiAdvice.yieldPerHectareTons} T/Ha)</span>
                </div>

                <div className="bg-slate-800 p-4 rounded-2xl space-y-1">
                  <span className="text-slate-400 block font-bold">Market Demand Forecast:</span>
                  <span className="text-emerald-300 font-medium leading-relaxed block">{aiAdvice.marketDemandForecast}</span>
                </div>

                <div className="bg-slate-800 p-4 rounded-2xl space-y-1">
                  <span className="text-slate-400 block font-bold">Est. Average Member Dividend:</span>
                  <span className="text-base font-black text-amber-300">{(aiAdvice.estimatedMemberDividendRwf || 540000).toLocaleString()} RWF</span>
                </div>
              </div>

              <div className="bg-emerald-950/40 border border-emerald-500/30 p-4 rounded-2xl text-xs space-y-1">
                <span className="text-emerald-300 font-bold block">💡 Strategic Recommendation for Leadership:</span>
                <p className="text-slate-200 leading-relaxed">{aiAdvice.recommendedAction}</p>
              </div>
            </div>
          )}

          {/* Recent Deliveries & Contracts Preview */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Recent Deliveries */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black">Recent Collection Intake Receipts</h3>
                <button onClick={() => setActiveTab('collection')} className="text-xs text-emerald-400 font-bold hover:underline">View All ➔</button>
              </div>

              <div className="space-y-3">
                {deliveries.slice(0, 3).map((d) => (
                  <div key={d.id} className="bg-slate-800 border border-slate-700 p-4 rounded-2xl flex items-center justify-between text-xs">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-white">{d.farmerName}</span>
                        <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full">
                          {d.qualityGrade}
                        </span>
                      </div>
                      <span className="text-slate-400 block mt-0.5">{d.quantityKg} Kg • Moisture: {d.moistureContentPct}%</span>
                    </div>

                    <div className="text-right">
                      <span className="font-black text-amber-300 text-sm">{d.totalPayoutRwf.toLocaleString()} RWF</span>
                      <span className="text-[10px] text-slate-400 block">{d.timestamp}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Active Bulk Buyer Contracts */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black">Active Buyer Tenders & Bulk Contracts</h3>
                <button onClick={() => setActiveTab('contracts')} className="text-xs text-emerald-400 font-bold hover:underline">View Contracts ➔</button>
              </div>

              <div className="space-y-3">
                {contracts.map((c) => (
                  <div key={c.id} className="bg-slate-800 border border-slate-700 p-4 rounded-2xl space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-sm">{c.buyerName}</span>
                      <span className="bg-blue-500/20 text-blue-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-blue-500/30">
                        {c.status}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-slate-300">
                      <span>Commodity: <strong>{c.commodity}</strong></span>
                      <span className="font-black text-emerald-400">{(c.totalContractValueRwf / 1000000).toFixed(1)}M RWF</span>
                    </div>

                    {/* Progress Bar */}
                    <div className="space-y-1 pt-1">
                      <div className="flex justify-between text-[10px] text-slate-400">
                        <span>Fulfillment: {c.fulfilledQuantityTons} / {c.contractQuantityTons} Tons</span>
                        <span>{Math.round((c.fulfilledQuantityTons / c.contractQuantityTons) * 100)}%</span>
                      </div>
                      <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-700">
                        <div
                          className="bg-emerald-500 h-full rounded-full"
                          style={{ width: `${(c.fulfilledQuantityTons / c.contractQuantityTons) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* TAB 2: MEMBERS ROSTER */}
      {activeTab === 'members' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-black">Cooperative Member Farmers Directory</h3>
                <p className="text-xs text-slate-400">
                  Manage registered smallholder members, farm land sizes, season harvest contributions, and payout histories.
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setShowAddMemberModal(true)}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow flex items-center space-x-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Member</span>
                </button>
              </div>
            </div>

            {/* Search input */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search member by name, crop, or district..."
                value={memberSearchQuery}
                onChange={(e) => setMemberSearchQuery(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Members Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="p-3">Farmer Name</th>
                    <th className="p-3">District</th>
                    <th className="p-3">Farm Size</th>
                    <th className="p-3">Crop Plot</th>
                    <th className="p-3">Delivered Yield</th>
                    <th className="p-3">Season Payout</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {filteredMembers.map((m) => (
                    <tr key={m.id} className="hover:bg-slate-800/40">
                      <td className="p-3 font-bold text-white">{m.farmerName}</td>
                      <td className="p-3 text-slate-400">{m.district}</td>
                      <td className="p-3 font-medium text-emerald-300">{m.farmSizeHectares} Ha</td>
                      <td className="p-3 text-slate-300">{m.primaryCrop}</td>
                      <td className="p-3 font-bold text-white">{m.seasonDeliveredTons} Tons</td>
                      <td className="p-3 font-black text-amber-300">{m.payoutEarnedRwf.toLocaleString()} RWF</td>
                      <td className="p-3">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          m.payoutStatus === 'Paid via MoMo' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        }`}>
                          {m.payoutStatus}
                        </span>
                      </td>
                      <td className="p-3">
                        <button
                          onClick={() => onInitiateMomoPayment(m.payoutEarnedRwf, `Dividend Payout to ${m.farmerName}`)}
                          className="bg-slate-800 hover:bg-slate-700 text-emerald-300 font-bold px-3 py-1 rounded-lg border border-slate-700 text-[10px]"
                        >
                          Disburse MoMo
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: COLLECTION CENTER INTAKE SCALE */}
      {activeTab === 'collection' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-black">Collection Center Weighing Scale & Quality Grading</h3>
                <p className="text-xs text-slate-400">
                  Record produce deliveries from individual smallholders with digital scale readings, RAB moisture tests, and auto-generated payment receipts.
                </p>
              </div>

              <button
                onClick={() => setShowDeliveryModal(true)}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow flex items-center space-x-1.5"
              >
                <Scale className="w-4 h-4" />
                <span>+ New Delivery Intake</span>
              </button>
            </div>

            <div className="space-y-3">
              {deliveries.map((del) => (
                <div key={del.id} className="bg-slate-800 border border-slate-700 rounded-2xl p-4 space-y-3 text-xs text-white">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-700 pb-2">
                    <div>
                      <span className="text-amber-400 font-bold font-mono text-[10px]">Intake Receipt #{del.id}</span>
                      <h4 className="text-sm font-black text-white">{del.farmerName} — {del.commodity}</h4>
                    </div>

                    <div className="text-right">
                      <span className="text-base font-black text-emerald-400">{del.totalPayoutRwf.toLocaleString()} RWF</span>
                      <span className="text-[10px] text-slate-400 block">({del.pricePerKgRwf} RWF / Kg)</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-slate-300">
                    <div>
                      <span className="text-slate-500 block text-[10px]">Net Weight:</span>
                      <span className="font-bold text-white">{del.quantityKg} Kg ({(del.quantityKg / 1000).toFixed(2)} Tons)</span>
                    </div>

                    <div>
                      <span className="text-slate-500 block text-[10px]">Quality Grade:</span>
                      <span className="font-bold text-teal-300">{del.qualityGrade}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 block text-[10px]">Moisture Content:</span>
                      <span className="font-bold text-amber-300">{del.moistureContentPct}%</span>
                    </div>

                    <div>
                      <span className="text-slate-500 block text-[10px]">Officer:</span>
                      <span className="text-slate-300">{del.receivedByOfficer}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: BULK CONTRACTS & BUYER TENDERS */}
      {activeTab === 'contracts' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <h3 className="text-base font-black">Bulk Commodity Contracts & Institutional Buyer Tenders</h3>
            <p className="text-xs text-slate-400">
              Manage long-term supply agreements with grain millers, food processors, MINAGRI grain reserves, and international exporters.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {contracts.map((c) => (
                <div key={c.id} className="bg-slate-800 border border-slate-700 rounded-3xl p-6 space-y-4 text-white shadow-md flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="bg-blue-500/20 text-blue-300 text-[10px] font-bold px-2.5 py-1 rounded-full border border-blue-500/30">
                        {c.buyerType}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">ID: {c.id}</span>
                    </div>

                    <h4 className="text-lg font-black text-white">{c.buyerName}</h4>
                    <p className="text-xs text-slate-300 font-medium">Commodity: <strong className="text-emerald-300">{c.commodity}</strong></p>

                    <div className="grid grid-cols-2 gap-2 pt-2 text-xs">
                      <div className="bg-slate-900 p-3 rounded-2xl">
                        <span className="text-slate-400 block text-[10px]">Contract Quantity:</span>
                        <span className="font-bold text-white">{c.contractQuantityTons} Tons</span>
                      </div>

                      <div className="bg-slate-900 p-3 rounded-2xl">
                        <span className="text-slate-400 block text-[10px]">Price per Ton:</span>
                        <span className="font-bold text-amber-300">{c.pricePerTonRwf.toLocaleString()} RWF</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-700 flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 block text-[10px]">Total Contract Value:</span>
                      <span className="text-base font-black text-emerald-400">{(c.totalContractValueRwf / 1000000).toFixed(1)}M RWF</span>
                    </div>

                    {c.momoEscrowSecured && (
                      <span className="bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold px-3 py-1.5 rounded-xl flex items-center space-x-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                        <span>MoMo Escrow Secured</span>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: FINANCIAL LEDGER */}
      {activeTab === 'finance' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-black">Cooperative Treasury & Member Dividend Allocation</h3>
                <p className="text-xs text-slate-400">
                  Track bulk sales revenue, operational expenses, fertilizer loans, and automated Mobile Money dividend disburser.
                </p>
              </div>

              <button
                onClick={() => onInitiateMomoPayment(125000000, `Mass Dividend Disbursal for ${cooperative.totalMembers} Members`)}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow flex items-center space-x-1.5"
              >
                <DollarSign className="w-4 h-4" />
                <span>Bulk Disburse Member Dividends</span>
              </button>
            </div>

            <div className="space-y-3">
              {transactions.map((tx) => (
                <div key={tx.id} className="bg-slate-800 border border-slate-700 rounded-2xl p-4 flex items-center justify-between text-xs text-white">
                  <div>
                    <span className="font-bold text-emerald-300">{tx.type}</span>
                    <p className="text-slate-300 mt-0.5">{tx.description}</p>
                    <span className="text-[10px] text-slate-400 block">Ref: {tx.referenceNumber} • Date: {tx.date}</span>
                  </div>

                  <span className={`text-base font-black ${
                    tx.type === 'Bulk Sale Revenue' ? 'text-emerald-400' : 'text-amber-400'
                  }`}>
                    {tx.type === 'Bulk Sale Revenue' ? '+' : '-'}{(tx.amountRwf / 1000000).toFixed(1)}M RWF
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: AI YIELD FORECAST */}
      {activeTab === 'ai_advisor' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex items-center space-x-2 text-amber-400 font-bold text-sm">
              <Sparkles className="w-5 h-5" />
              <span>AI Cooperative Yield Forecasting & Market Timing Engine</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              AGRIWISE AI evaluates climate feeds, historical district yields, and Kigali/export bulk market prices to optimize cooperative holding and selling strategies.
            </p>

            {aiLoading ? (
              <div className="p-8 text-center text-slate-400 text-xs font-bold">Generating AI Cooperative Strategy...</div>
            ) : aiAdvice ? (
              <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="bg-slate-900 p-4 rounded-2xl space-y-1">
                    <span className="text-slate-400 block font-bold">Projected Final Seasonal Harvest:</span>
                    <span className="text-xl font-black text-white">{aiAdvice.projectedFinalHarvestTons} Tons</span>
                  </div>

                  <div className="bg-slate-900 p-4 rounded-2xl space-y-1">
                    <span className="text-slate-400 block font-bold">Estimated Member Dividend:</span>
                    <span className="text-xl font-black text-amber-300">{(aiAdvice.estimatedMemberDividendRwf || 540000).toLocaleString()} RWF / Farmer</span>
                  </div>
                </div>

                <div className="bg-emerald-950/40 border border-emerald-500/30 p-4 rounded-2xl text-xs space-y-1">
                  <span className="text-emerald-300 font-bold block">📈 Market Demand & Price Trend:</span>
                  <p className="text-slate-200">{aiAdvice.marketDemandForecast}</p>
                </div>

                <div className="bg-slate-900 p-4 rounded-2xl text-xs space-y-1">
                  <span className="text-amber-300 font-bold block">⚠️ Risk Mitigation Alert:</span>
                  <p className="text-slate-300">{aiAdvice.riskMitigationAlert}</p>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* MODAL: ADD MEMBER */}
      {showAddMemberModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white">Register New Cooperative Member</h3>
              <button onClick={() => setShowAddMemberModal(false)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <form onSubmit={handleAddMember} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Farmer Full Name:</label>
                <input
                  type="text"
                  value={newMemberName}
                  onChange={(e) => setNewMemberName(e.target.value)}
                  placeholder="e.g. Beata Mukamana"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Phone Number (MoMo Wallet):</label>
                <input
                  type="text"
                  value={newMemberPhone}
                  onChange={(e) => setNewMemberPhone(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Farm Land Size (Ha):</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newMemberFarmSize}
                    onChange={(e) => setNewMemberFarmSize(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Primary Commodity:</label>
                  <input
                    type="text"
                    value={newMemberCrop}
                    onChange={(e) => setNewMemberCrop(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>
              </div>

              <div className="pt-2 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddMemberModal(false)}
                  className="flex-1 bg-slate-800 text-slate-300 font-bold py-2.5 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl shadow"
                >
                  Save Member Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: RECORD DELIVERY */}
      {showDeliveryModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white">Collection Center Intake Receipt</h3>
              <button onClick={() => setShowDeliveryModal(false)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <form onSubmit={handleRecordDelivery} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Farmer Name:</label>
                <input
                  type="text"
                  value={delFarmerName}
                  onChange={(e) => setDelFarmerName(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Quantity (Kg):</label>
                  <input
                    type="number"
                    value={delWeightKg}
                    onChange={(e) => setDelWeightKg(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Moisture %:</label>
                  <input
                    type="number"
                    step="0.1"
                    value={delMoisture}
                    onChange={(e) => setDelMoisture(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">RAB Quality Grade:</label>
                <select
                  value={delGrade}
                  onChange={(e) => setDelGrade(e.target.value as any)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  <option value="Grade A1 (Export Spec)">Grade A1 (Export Spec)</option>
                  <option value="Grade A2 (Standard)">Grade A2 (Standard)</option>
                  <option value="Grade B (Processing)">Grade B (Processing)</option>
                </select>
              </div>

              <div className="pt-2 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowDeliveryModal(false)}
                  className="flex-1 bg-slate-800 text-slate-300 font-bold py-2.5 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl shadow"
                >
                  Issue Receipt & Log Intake
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
