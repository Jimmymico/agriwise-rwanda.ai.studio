import React, { useState } from 'react';
import { User, Language } from '../../types';
import { translations } from '../../data/translations';
import {
  TEST_CASES,
  AI_MODEL_METRICS,
  SECURITY_SCANS,
  LOAD_TEST_BENCHMARKS,
  RELEASE_READINESS_LIST,
} from '../../data/qaData';
import {
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  Cpu,
  Zap,
  Activity,
  Bot,
  Sparkles,
  RefreshCw,
  BarChart3,
  Search,
  Filter,
  FileCheck,
  Lock,
  Smartphone,
  Gauge,
  Award,
  Users,
  CheckSquare,
  XCircle,
  HelpCircle,
  Layers,
  Terminal,
} from 'lucide-react';

interface QualityAssurancePlatformProps {
  currentUser: User;
  language: Language;
}

export const QualityAssurancePlatform: React.FC<QualityAssurancePlatformProps> = ({
  currentUser,
  language,
}) => {
  const [activeTab, setActiveTab] = useState<
    'overview' | 'test_cases' | 'ai_validation' | 'security_audit' | 'load_testing' | 'ai_qa_copilot' | 'release_board'
  >('overview');

  const [filterModule, setFilterModule] = useState<string>('ALL');
  const [targetModuleAi, setTargetModuleAi] = useState<string>('All AGRIWISE Core Modules');
  const [testScopeAi, setTestScopeAi] = useState<string>('Full End-to-End Regression, OWASP Security & AI Precision Audit');
  const [isAiValidating, setIsAiValidating] = useState<boolean>(false);
  const [aiQaResult, setAiQaResult] = useState<any>(null);

  const t = translations[language] || translations['rw'];

  const filteredTestCases = filterModule === 'ALL'
    ? TEST_CASES
    : TEST_CASES.filter((tc) => tc.module === filterModule);

  const handleRunAiQaAudit = async () => {
    setIsAiValidating(true);
    try {
      const res = await fetch('/api/ai/qa-validator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetModule: targetModuleAi,
          testScope: testScopeAi,
          language,
        }),
      });
      const data = await res.json();
      setAiQaResult(data);
    } catch (err) {
      console.error('Failed to run QA AI audit:', err);
    } finally {
      setIsAiValidating(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-teal-950 border border-teal-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-teal-500/15 border border-teal-400/30 px-3 py-1 rounded-full text-xs font-bold text-teal-300">
              <ShieldCheck className="w-3.5 h-3.5 text-teal-400 animate-pulse" />
              <span>STEP 47 • QUALITY ASSURANCE & PRODUCT VALIDATION</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              AGRIWISE Enterprise QA & Release Certification
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 font-medium leading-relaxed">
              Automated unit and E2E regression suites, AI model precision benchmarks, OWASP security audits, high-concurrency load stress tests, and final Go/No-Go production release readiness.
            </p>
          </div>

          {/* Go for Production Status Badge */}
          <div className="flex items-center gap-3 bg-slate-900/90 border border-emerald-500/50 p-3.5 rounded-2xl shadow-xl">
            <div className="w-10 h-10 rounded-xl bg-emerald-950 border border-emerald-500/50 flex items-center justify-center text-emerald-400 font-bold">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                Release Readiness Status
              </span>
              <span className="text-sm font-black text-emerald-400 font-mono">GO FOR PRODUCTION</span>
            </div>
          </div>
        </div>

        {/* Global Test Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-6 pt-6 border-t border-teal-500/20 text-xs">
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Test Suite Pass Rate</span>
            <span className="text-lg font-black text-emerald-400 font-mono">99.8% Passed</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">AI Model Precision</span>
            <span className="text-lg font-black text-teal-400 font-mono">98.4% Precision</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Security Vulnerabilities</span>
            <span className="text-lg font-black text-emerald-300 font-mono">0 Critical / 0 High</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Load Stress Benchmark</span>
            <span className="text-lg font-black text-blue-400 font-mono">1M Users Passed</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">UAT Sign-off Count</span>
            <span className="text-lg font-black text-amber-400 font-mono">349 Sign-offs</span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex overflow-x-auto gap-2 bg-slate-900/90 p-2 rounded-2xl border border-slate-800 custom-scrollbar text-xs font-bold">
        {[
          { id: 'overview', label: 'QA Strategy & Scope', icon: Activity },
          { id: 'test_cases', label: 'Functional Test Cases (6)', icon: FileCheck },
          { id: 'ai_validation', label: 'AI Model Precision Metrics', icon: Cpu },
          { id: 'security_audit', label: 'OWASP Security Audit', icon: Lock },
          { id: 'load_testing', label: '1M User Load Stress Test', icon: Gauge },
          { id: 'ai_qa_copilot', label: 'Gemini QA Release Copilot', icon: Bot, badge: 'Gemini 3.6' },
          { id: 'release_board', label: 'Go/No-Go Release Board', icon: Award },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-lg'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.badge && (
                <span className="text-[9px] bg-emerald-500/30 text-emerald-300 border border-emerald-400/30 px-1.5 py-0.5 rounded-full uppercase">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: QA STRATEGY & SCOPE */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-3">
              <div className="p-3 bg-teal-950 border border-teal-500/30 rounded-2xl text-teal-400 w-fit">
                <FileCheck className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-white text-base">Full Stack Automated Regression</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Continuous integration running Playwright E2E UI tests, Jest unit suites, and Supertest API regression on every pull request.
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-3">
              <div className="p-3 bg-emerald-950 border border-emerald-500/30 rounded-2xl text-emerald-400 w-fit">
                <Cpu className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-white text-base">AI Model Accuracy Ground-Truth</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Validating Gemini 3.6 Flash vision models against 250,000 ground-truth leaf disease images verified by RAB agronomists.
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-3">
              <div className="p-3 bg-amber-950 border border-amber-500/30 rounded-2xl text-amber-400 w-fit">
                <Smartphone className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-white text-base">Rural Mobile Offline Sync</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Simulating 2G/EDGE connectivity loss and CRDT delta synchronization across Android and iOS mobile smallholder devices.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: FUNCTIONAL TEST CASES */}
      {activeTab === 'test_cases' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-teal-400" />
                Functional & Integration Test Case Suite
              </h2>
              <p className="text-xs text-slate-400">
                Automated test execution logs across core AGRIWISE business modules.
              </p>
            </div>

            <div className="flex items-center gap-2 bg-slate-900 p-2 rounded-2xl border border-slate-800 text-xs">
              <Filter className="w-4 h-4 text-slate-400" />
              <select
                value={filterModule}
                onChange={(e) => setFilterModule(e.target.value)}
                className="bg-transparent text-slate-200 font-bold focus:outline-none"
              >
                <option value="ALL">All Business Modules</option>
                <option value="Auth">Auth & Identity</option>
                <option value="Farmer">Farmer Polygon</option>
                <option value="AI System">AI System</option>
                <option value="Marketplace">Marketplace & Payments</option>
                <option value="GIS Satellite">GIS Satellite</option>
                <option value="Security">Security</option>
              </select>
            </div>
          </div>

          <div className="space-y-3">
            {filteredTestCases.map((tc) => (
              <div
                key={tc.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-teal-400">{tc.id}</span>
                    <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-bold uppercase text-[10px]">
                      {tc.type}
                    </span>
                    <span className="bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded font-bold text-[10px]">
                      {tc.module}
                    </span>
                  </div>
                  <h3 className="font-bold text-white text-sm">{tc.title}</h3>
                  <p className="text-slate-400">{tc.description}</p>
                </div>

                <div className="flex items-center gap-4 text-right">
                  <div>
                    <span className="text-[10px] text-slate-400 block font-mono">{tc.executionTimeMs} ms</span>
                    <span className="text-[10px] text-slate-400 block">{tc.lastRunTimestamp}</span>
                  </div>

                  <span className="flex items-center gap-1.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold px-3 py-1 rounded-full">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    {tc.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: AI MODEL VALIDATION */}
      {activeTab === 'ai_validation' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Cpu className="w-5 h-5 text-teal-400" />
                AI Ground-Truth Precision & Recall Benchmark
              </h2>
              <p className="text-xs text-slate-400">
                Evaluation metrics for Gemini 3.6 Flash crop disease vision, yield predictor, and speech copilots.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {AI_MODEL_METRICS.map((metric, idx) => (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4"
              >
                <div className="border-b border-slate-800 pb-3">
                  <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded-full font-bold uppercase block w-fit mb-2">
                    {metric.status}
                  </span>
                  <h3 className="font-bold text-white text-base">{metric.modelName}</h3>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Accuracy Score:</span>
                    <span className="font-mono font-bold text-emerald-400">{metric.accuracyPct}%</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">Precision:</span>
                    <span className="font-mono font-bold text-teal-400">{metric.precisionPct}%</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">Recall Score:</span>
                    <span className="font-mono font-bold text-amber-400">{metric.recallPct}%</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">F1 Score:</span>
                    <span className="font-mono font-bold text-blue-400">{metric.f1ScorePct}%</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">Inference Latency:</span>
                    <span className="font-mono font-bold text-slate-200">{metric.avgInferenceLatencyMs} ms</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: SECURITY AUDIT */}
      {activeTab === 'security_audit' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Lock className="w-5 h-5 text-teal-400" />
                OWASP Security Audit & Vulnerability Penetration
              </h2>
              <p className="text-xs text-slate-400">
                Automated cryptographic token checks, PostGIS query injection prevention, and GDPR data residency compliance.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {SECURITY_SCANS.map((scan, idx) => (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3"
              >
                <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                  <h3 className="font-bold text-white text-sm">{scan.scanCategory}</h3>
                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold px-2.5 py-1 rounded-full">
                    {scan.status}
                  </span>
                </div>

                <p className="text-xs text-slate-300">{scan.vulnerabilityDetails}</p>

                <div className="flex justify-between items-center text-xs pt-2 border-t border-slate-800/80">
                  <span className="text-slate-400">Passed Checks:</span>
                  <span className="font-mono font-bold text-emerald-400">
                    {scan.passedChecks} / {scan.totalChecks}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: LOAD TESTING */}
      {activeTab === 'load_testing' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Gauge className="w-5 h-5 text-teal-400" />
                1M Concurrent User Load Stress Benchmark
              </h2>
              <p className="text-xs text-slate-400">
                Evaluating system throughput, error rate, and CPU utilization under simulated harvest spike traffic.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {LOAD_TEST_BENCHMARKS.map((bench, idx) => (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3"
              >
                <div className="border-b border-slate-800 pb-2">
                  <span className="text-[10px] text-teal-400 font-bold block">{bench.targetCategory}</span>
                  <h3 className="font-black text-white text-lg font-mono">
                    {bench.simulatedConcurrentUsers.toLocaleString()} Users
                  </h3>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">P95 Latency:</span>
                    <span className="font-mono font-bold text-emerald-400">{bench.p95LatencyMs} ms</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">Error Rate:</span>
                    <span className="font-mono font-bold text-teal-400">{bench.errorRatePct}%</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">Throughput:</span>
                    <span className="font-mono font-bold text-amber-400">{bench.throughputRps.toLocaleString()} RPS</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">CPU Load:</span>
                    <span className="font-mono font-bold text-blue-400">{bench.cpuUtilizationPct}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 6: GEMINI QA RELEASE COPILOT */}
      {activeTab === 'ai_qa_copilot' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-teal-950 border border-teal-500/30 rounded-3xl p-6 shadow-2xl space-y-5">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-teal-500 to-emerald-400 p-0.5 shadow-lg">
                <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                  <Bot className="w-6 h-6 text-teal-400" />
                </div>
              </div>
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  Gemini 3.6 Flash QA & Release Validation Architect
                </h2>
                <p className="text-xs text-slate-300">
                  Instant AI release risk assessment, security audit validation, and Go/No-Go decision synthesis.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Target Business Module:
                </label>
                <input
                  type="text"
                  value={targetModuleAi}
                  onChange={(e) => setTargetModuleAi(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-teal-500 rounded-xl p-3 text-slate-100 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Test & Audit Scope:
                </label>
                <input
                  type="text"
                  value={testScopeAi}
                  onChange={(e) => setTestScopeAi(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-teal-500 rounded-xl p-3 text-slate-100 font-medium"
                />
              </div>
            </div>

            <button
              onClick={handleRunAiQaAudit}
              disabled={isAiValidating}
              className="bg-gradient-to-r from-teal-500 via-emerald-500 to-teal-600 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-black px-6 py-3 rounded-2xl shadow-xl transition-all flex items-center gap-2 text-xs uppercase tracking-wide"
            >
              {isAiValidating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Evaluating QA Test Suites...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-slate-950" />
                  <span>Run Gemini QA Release Audit</span>
                </>
              )}
            </button>

            {aiQaResult && (
              <div className="bg-slate-950 border border-teal-500/40 rounded-2xl p-5 space-y-4 animate-in fade-in text-xs">
                <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                  <span className="font-bold text-teal-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-teal-400" />
                    QA Audit Complete for {aiQaResult.targetModule}
                  </span>
                  <span className="bg-emerald-950 border border-emerald-500/30 text-emerald-300 px-2.5 py-1 rounded-full font-mono font-bold">
                    Decision: {aiQaResult.releaseDecision}
                  </span>
                </div>

                <p className="text-slate-200 leading-relaxed font-medium">
                  {aiQaResult.releaseSummary}
                </p>

                <div className="pt-2">
                  <span className="font-bold text-slate-300 block mb-1">Critical Validation Findings:</span>
                  <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                    {aiQaResult.criticalFindings?.map((item: string, idx: number) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 7: RELEASE READINESS BOARD */}
      {activeTab === 'release_board' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <div className="p-3 bg-emerald-950 border border-emerald-500/30 rounded-2xl text-emerald-400">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">
                Production Go / No-Go Sign-off Board
              </h2>
              <p className="text-xs text-slate-400">
                Final approval sign-offs from domain leads certifying AGRIWISE for pan-African launch.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {RELEASE_READINESS_LIST.map((item, idx) => (
              <div
                key={idx}
                className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 text-xs"
              >
                <div>
                  <h3 className="font-bold text-white text-sm">{item.moduleName}</h3>
                  <span className="text-slate-400 text-[11px]">Sign-off Owner: {item.ownerSignoff}</span>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <span className="text-slate-400 block text-[10px]">Pass Rate</span>
                    <span className="font-mono font-bold text-emerald-400">{item.unitTestPassRatePct}%</span>
                  </div>

                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full font-bold">
                    {item.goNoGoStatus}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
