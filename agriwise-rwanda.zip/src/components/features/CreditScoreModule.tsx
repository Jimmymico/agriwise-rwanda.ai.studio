import React from 'react';
import { User, Language } from '../../types';
import { translations } from '../../data/translations';
import {
  Award,
  ShieldCheck,
  TrendingUp,
  Landmark,
  FileCheck,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

interface CreditScoreModuleProps {
  currentUser: User;
  language: Language;
}

export const CreditScoreModule: React.FC<CreditScoreModuleProps> = ({ currentUser, language }) => {
  const t = translations[language];

  const score = currentUser.creditScore || 780;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-white">
        <div>
          <div className="inline-flex items-center space-x-2 bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3 py-1 rounded-full text-xs font-bold mb-1">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span>AgriCredit Rwanda Evaluation Engine</span>
          </div>
          <h2 className="text-xl font-black">{t.creditScoreTitle}</h2>
          <p className="text-xs text-slate-400">{t.creditScoreSubtitle}</p>
        </div>
      </div>

      {/* Main Score Visualizer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Score Gauge Box */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-center space-y-4 text-white flex flex-col justify-center items-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">AgriCredit Score</p>
          
          <div className="relative w-40 h-40 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full border-8 border-slate-800"></div>
            <div className="absolute inset-0 rounded-full border-8 border-emerald-500 border-t-transparent animate-spin-slow"></div>
            <div className="text-center">
              <span className="text-4xl font-black text-amber-300">{score}</span>
              <span className="block text-[10px] text-slate-400">/ 850 Max</span>
            </div>
          </div>

          <div className="inline-flex items-center space-x-1.5 bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Grade A - High Reliability</span>
          </div>

          <p className="text-xs text-slate-300 max-w-xs">
            Qualified for low-interest agricultural loans & subsidized yield insurance up to <strong>15,000,000 RWF</strong>.
          </p>
        </div>

        {/* Evaluation Factors Breakdown */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 text-white">
          <h3 className="text-sm font-bold text-white flex items-center space-x-2 border-b border-slate-800 pb-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span>Credit Rating Factors</span>
          </h3>

          <div className="space-y-3 text-xs">
            
            <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
              <div>
                <p className="font-bold text-white">GPS Farm Boundary Verification</p>
                <p className="text-[11px] text-slate-400">2.5 Hectares mapped and verified in Kinigi, Musanze</p>
              </div>
              <span className="font-black text-emerald-400 text-sm">+210 Pts</span>
            </div>

            <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
              <div>
                <p className="font-bold text-white">Historical Yield Consistency</p>
                <p className="text-[11px] text-slate-400">3 consecutive seasons of verified harvests (12+ Tons/Ha)</p>
              </div>
              <span className="font-black text-emerald-400 text-sm">+260 Pts</span>
            </div>

            <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
              <div>
                <p className="font-bold text-white">Cooperative Membership & Standing</p>
                <p className="text-[11px] text-slate-400">Abahizi Kinigi Cooperative endorsement</p>
              </div>
              <span className="font-black text-emerald-400 text-sm">+180 Pts</span>
            </div>

            <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
              <div>
                <p className="font-bold text-white">Mobile Money Cash Flow Log</p>
                <p className="text-[11px] text-slate-400">Verified MoMo agricultural sales receipts</p>
              </div>
              <span className="font-black text-emerald-400 text-sm">+130 Pts</span>
            </div>

          </div>

          {/* Partner Institutions */}
          <div className="pt-3 border-t border-slate-800">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Pre-Approved Partners:</p>
            <div className="flex flex-wrap gap-2 text-xs font-bold text-slate-200">
              <span className="px-3 py-1 bg-slate-800 rounded-xl border border-slate-700">Bank of Kigali (BK Agribiz)</span>
              <span className="px-3 py-1 bg-slate-800 rounded-xl border border-slate-700">Equity Bank Rwanda</span>
              <span className="px-3 py-1 bg-slate-800 rounded-xl border border-slate-700">SACCO Rwanda</span>
              <span className="px-3 py-1 bg-slate-800 rounded-xl border border-slate-700">PRIME Insurance</span>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
