import React, { useState, useEffect } from 'react';
import { Language, User } from '../../types';
import { translations } from '../../data/translations';
import { defaultWeatherProvider, DistrictWeatherTelemetry } from '../../services/weatherProvider';
import {
  CloudSun,
  Droplets,
  Wind,
  Thermometer,
  AlertTriangle,
  MapPin,
  Sun,
  CloudRain,
  CheckCircle2,
  Clock,
  Sparkles,
  PhoneCall,
  X,
  Navigation,
  Check,
  Sprout,
  ShowerHead,
  ShieldCheck,
  Info
} from 'lucide-react';

interface WeatherWidgetProps {
  language: Language;
  currentUser?: User;
}

export const WeatherWidget: React.FC<WeatherWidgetProps> = ({ language, currentUser }) => {
  const t = translations[language];
  const [selectedDistrict, setSelectedDistrict] = useState<string>(currentUser?.district || 'Musanze');
  const [telemetry, setTelemetry] = useState<DistrictWeatherTelemetry | null>(null);
  const [isRadarActive, setIsRadarActive] = useState(false);
  const [showSmsModal, setShowSmsModal] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState(currentUser?.phone || '+250 788 345 678');
  const [smsSubscribed, setSmsSubscribed] = useState(false);
  const [activeTab, setActiveTab] = useState<'today' | 'agronomy' | '7days' | 'mitigation'>('today');

  // Load telemetry from provider
  useEffect(() => {
    let isMounted = true;
    defaultWeatherProvider.getWeatherForDistrict(selectedDistrict).then(data => {
      if (isMounted) {
        setTelemetry(data);
      }
    });
    return () => {
      isMounted = false;
    };
  }, [selectedDistrict]);

  const [completedItems, setCompletedItems] = useState<Record<string, boolean>>({});

  const toggleChecklistItem = (id: string) => {
    setCompletedItems(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const handleSmsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSmsSubscribed(true);
    setTimeout(() => {
      setShowSmsModal(false);
      setSmsSubscribed(false);
    }, 2000);
  };

  if (!telemetry) {
    return (
      <div className="p-8 text-center text-slate-400 bg-slate-900 border border-slate-800 rounded-3xl animate-pulse">
        {t.loading || 'Loading Meteo Rwanda Telemetry...'}
      </div>
    );
  }

  const getStatusBadge = (status: 'optimal' | 'caution' | 'hazardous') => {
    if (status === 'optimal') {
      return (
        <span className="inline-flex items-center space-x-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-0.5 rounded-full text-[11px] font-bold">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>{language === 'rw' ? 'Igihe Cyiza' : language === 'fr' ? 'Créneau Optimal' : 'Optimal Window'}</span>
        </span>
      );
    }
    if (status === 'caution') {
      return (
        <span className="inline-flex items-center space-x-1 bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2.5 py-0.5 rounded-full text-[11px] font-bold">
          <Clock className="w-3.5 h-3.5 text-amber-400" />
          <span>{language === 'rw' ? 'Witondere' : language === 'fr' ? 'Prudence' : 'Proceed with Caution'}</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center space-x-1 bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2.5 py-0.5 rounded-full text-[11px] font-bold">
        <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
        <span>{language === 'rw' ? 'Hagarika / Subika' : language === 'fr' ? 'Risqué / Reporter' : 'Hazardous / Delay'}</span>
      </span>
    );
  };

  const currentLang = language as 'rw' | 'en' | 'fr';

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Module Header Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4 text-white">
        <div>
          <div className="inline-flex items-center space-x-2 bg-blue-500/20 text-blue-300 border border-blue-500/30 px-3 py-1 rounded-full text-xs font-bold mb-2">
            <CloudSun className="w-4 h-4 text-blue-400" />
            <span>Meteo Rwanda Micro-climate & Agronomy Intelligence</span>
          </div>
          <h2 className="text-2xl font-black tracking-tight">{t.navWeather}</h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            {language === 'rw'
              ? 'Iteganyagihe ry\'imfashanyigisho ku bahinzi n\'aborozi muri Turere 30 tw\'u Rwanda, rigenga igihe cyo gutera, kuvomerera n\'isaruza.'
              : language === 'fr'
              ? 'Météo en temps réel et conseils agronomiques pour les 30 districts du Rwanda, guidant le semis, l\'irrigation et la récolte.'
              : 'Real-time hyper-local weather telemetry, agronomic spraying & harvesting advisories, and disaster mitigation for Rwanda\'s 30 districts.'}
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* SMS Subscription Button */}
          <button
            onClick={() => setShowSmsModal(true)}
            className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow transition-colors"
          >
            <PhoneCall className="w-4 h-4" />
            <span>{language === 'rw' ? 'SMS y\'Ikirere (Buntu)' : language === 'fr' ? 'Alertes SMS Gratuites' : 'Free SMS Alerts'}</span>
          </button>

          {/* District Selector */}
          <div className="flex items-center space-x-2 bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-xl">
            <MapPin className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              className="bg-transparent text-xs font-bold text-white focus:outline-none cursor-pointer"
            >
              <option value="Musanze" className="bg-slate-900 text-white">Musanze (Northern Volcanic)</option>
              <option value="Nyagatare" className="bg-slate-900 text-white">Nyagatare (Eastern Savanna)</option>
              <option value="Huye" className="bg-slate-900 text-white">Huye (Southern Plateau)</option>
              <option value="Rubavu" className="bg-slate-900 text-white">Rubavu (Lake Kivu Belt)</option>
              <option value="Bugesera" className="bg-slate-900 text-white">Bugesera (Eastern Drylands)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Meteo Rwanda Warning Banner (If present) */}
      {telemetry.alert && (
        <div className={`p-4 rounded-3xl border flex items-start space-x-3 text-xs shadow-lg ${
          telemetry.alert.type === 'warning'
            ? 'bg-amber-950/70 border-amber-500/50 text-amber-100'
            : telemetry.alert.type === 'critical'
            ? 'bg-rose-950/70 border-rose-500/50 text-rose-100'
            : 'bg-blue-950/70 border-blue-500/50 text-blue-100'
        }`}>
          <AlertTriangle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
            telemetry.alert.type === 'warning' ? 'text-amber-400' : 'text-rose-400'
          }`} />
          <div className="flex-1">
            <div className="flex items-center space-x-2">
              <span className="font-bold text-sm tracking-wide">
                {telemetry.alert.title[currentLang] || telemetry.alert.title['en']}
              </span>
              <span className="bg-slate-950/60 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider">
                Meteo Rwanda Official Alert
              </span>
            </div>
            <p className="mt-1 leading-relaxed opacity-90">
              {telemetry.alert.description[currentLang] || telemetry.alert.description['en']}
            </p>
          </div>
        </div>
      )}

      {/* Main Grid: Weather Telemetry Card + Agronomy Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Main Current Weather Telemetry Card */}
        <div className="bg-gradient-to-br from-blue-950 via-slate-900 to-slate-900 border border-blue-500/30 rounded-3xl p-6 shadow-xl space-y-6 text-white relative overflow-hidden">
          <div className="absolute -top-12 -right-12 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center space-x-2">
                <Navigation className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  {telemetry.district} District • {telemetry.altitudeMeters}m Alt
                </span>
              </div>
              <h3 className="text-4xl font-black text-white mt-2 tracking-tight">{telemetry.tempC}°C</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {language === 'rw' ? 'Ukoresheje ibipimo:' : 'Feels like'} {telemetry.feelsLikeC}°C
              </p>
              <div className="inline-flex items-center space-x-1.5 bg-blue-500/20 text-blue-300 border border-blue-500/30 px-3 py-1 rounded-xl text-xs font-semibold mt-2">
                <span>{telemetry.condition.text}</span>
              </div>
            </div>

            <div className="p-3 bg-blue-950/80 border border-blue-500/30 rounded-2xl shadow-inner text-amber-400">
              <CloudSun className="w-12 h-12 animate-pulse" />
            </div>
          </div>

          {/* Micro-Climate Sensor Metrics */}
          <div className="grid grid-cols-2 gap-2 text-xs pt-4 border-t border-slate-800/80">
            <div className="p-3 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-1">
              <div className="flex items-center space-x-1.5 text-blue-400">
                <Droplets className="w-4 h-4" />
                <span className="text-[10px] text-slate-400 font-bold uppercase">Humidity</span>
              </div>
              <p className="text-base font-black text-white">{telemetry.humidityPct}%</p>
              <p className="text-[10px] text-slate-400">Rain Prob: {telemetry.rainProbabilityPct}%</p>
            </div>

            <div className="p-3 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-1">
              <div className="flex items-center space-x-1.5 text-teal-400">
                <Wind className="w-4 h-4" />
                <span className="text-[10px] text-slate-400 font-bold uppercase">Wind Speed</span>
              </div>
              <p className="text-base font-black text-white">{telemetry.windSpeedKmh} <span className="text-xs font-normal">km/h</span></p>
              <p className="text-[10px] text-slate-400">Dir: {telemetry.windDirection}</p>
            </div>

            <div className="p-3 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-1">
              <div className="flex items-center space-x-1.5 text-amber-400">
                <Sun className="w-4 h-4" />
                <span className="text-[10px] text-slate-400 font-bold uppercase">UV Index</span>
              </div>
              <p className="text-base font-black text-white">{telemetry.uvIndex} <span className="text-xs text-amber-400 font-normal">/ 12</span></p>
              <p className="text-[10px] text-slate-400">Evap: {telemetry.evapotranspirationMmDay} mm/d</p>
            </div>

            <div className="p-3 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-1">
              <div className="flex items-center space-x-1.5 text-emerald-400">
                <Thermometer className="w-4 h-4" />
                <span className="text-[10px] text-slate-400 font-bold uppercase">Soil Moisture</span>
              </div>
              <p className="text-base font-black text-white">{telemetry.soilMoisturePct}%</p>
              <p className="text-[10px] text-emerald-400 font-medium">Root zone sensor</p>
            </div>
          </div>

          {/* Radar Simulation Toggle */}
          <div className="pt-2">
            <button
              onClick={() => setIsRadarActive(!isRadarActive)}
              className="w-full bg-slate-800/90 hover:bg-slate-800 border border-slate-700 py-2.5 rounded-2xl text-xs font-bold flex items-center justify-center space-x-2 transition-colors"
            >
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>
                {isRadarActive
                  ? (language === 'rw' ? 'Funga Radar y\'Imvura' : 'Close Rain Radar Stream')
                  : (language === 'rw' ? 'Reba Radar y\'Imvura Imbona-nkubone' : 'View Live Doppler Rain Radar')}
              </span>
            </button>
          </div>
        </div>

        {/* Right 2 Columns: Tabs for Hourly, 7-Day, Agronomy Windows & Mitigation */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6 text-white flex flex-col justify-between">
          
          {/* Tabs Navigation */}
          <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-4">
            <button
              onClick={() => setActiveTab('today')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'today'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {language === 'rw' ? 'Amasaha 24 y\'Uyu Munsi' : language === 'fr' ? 'Relevé 24h' : 'Today\'s 24h Timeline'}
            </button>
            <button
              onClick={() => setActiveTab('agronomy')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'agronomy'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {language === 'rw' ? 'Ibyemezo by\'Ubuhinzi (AI Matrix)' : language === 'fr' ? 'Matrice Agronomique IA' : 'AI Farm Advisory Windows'}
            </button>
            <button
              onClick={() => setActiveTab('7days')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === '7days'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {language === 'rw' ? 'Iteganyagihe ry\'Iminsi 7' : language === 'fr' ? 'Prévisions 7 Jours' : '7-Day Extended Forecast'}
            </button>
            <button
              onClick={() => setActiveTab('mitigation')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'mitigation'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {language === 'rw' ? 'Kwirinda Isuri & Ibiza' : language === 'fr' ? 'Prévention des Risques' : 'Disaster Mitigation Checklist'}
            </button>
          </div>

          {/* TAB 1: Hourly Forecast */}
          {activeTab === 'today' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="text-sm font-bold text-slate-200">
                  {language === 'rw' ? 'Ibipimo by\'Ikirere mu Masaha 24' : '24-Hour Micro-climate Telemetry'}
                </h4>
                <span className="text-[11px] text-slate-400">Live Meteo Stream</span>
              </div>

              {/* Radar view if toggled */}
              {isRadarActive && (
                <div className="p-4 bg-slate-950 border border-blue-500/30 rounded-2xl relative overflow-hidden space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-blue-400 flex items-center space-x-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block mr-1" />
                      Meteo Rwanda Live Doppler Radar ({telemetry.district})
                    </span>
                    <span className="text-[10px] text-slate-400">Radar Resolution: High</span>
                  </div>

                  <div className="h-36 bg-slate-900 rounded-xl relative flex items-center justify-center border border-slate-800 overflow-hidden">
                    <div className="absolute inset-0 bg-[radial-gradient(circle,_var(--tw-gradient-stops))] from-blue-900/40 via-slate-900 to-slate-950" />
                    <div className="w-24 h-24 rounded-full border border-emerald-500/30 animate-spin absolute" />
                    <div className="w-48 h-48 rounded-full border border-emerald-500/20 absolute" />
                    <div className="w-64 h-64 rounded-full border border-emerald-500/10 absolute" />

                    <div className="w-16 h-12 bg-blue-500/40 blur-md rounded-full absolute top-6 left-1/3 animate-pulse" />
                    <div className="w-20 h-16 bg-emerald-500/30 blur-lg rounded-full absolute bottom-4 right-1/4" />

                    <div className="relative z-10 text-center space-y-1">
                      <p className="text-xs font-bold text-white">Rain Cloud Sweep over {telemetry.district}</p>
                      <p className="text-[10px] text-emerald-300">Moisture Cloud Motion: NW Ridge • Rain Rate: {telemetry.rainfallMm}mm/h</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Hourly Cards Grid */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {telemetry.hourly.map((h, idx) => (
                  <div key={idx} className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-center space-y-1.5">
                    <span className="text-[11px] font-bold text-slate-400 block">{h.time}</span>
                    <CloudRain className="w-6 h-6 mx-auto text-blue-400" />
                    <span className="text-base font-black text-white block">{h.tempC}°C</span>
                    <span className="text-[10px] font-bold text-blue-400 bg-blue-950/60 px-1.5 py-0.5 rounded-full block">
                      {h.rainPct}% Rain
                    </span>
                    <span className="text-[9px] text-slate-400 block truncate">{h.condition}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: Agronomy Advisory Windows */}
          {activeTab === 'agronomy' && (
            <div className="space-y-4">
              <h4 className="text-sm font-bold text-slate-200">
                {language === 'rw' ? 'Ibyemezo n\'Ibihe by\'Ubuhinzi muri' : 'AI Agronomic Action Windows for'} {telemetry.district}
              </h4>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Planting Window */}
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <Sprout className="w-4 h-4 text-emerald-400" />
                      <span className="font-bold text-xs text-white">
                        {language === 'rw' ? 'Gutera Imbuto' : language === 'fr' ? 'Semis & Plantation' : 'Crop Planting'}
                      </span>
                    </div>
                    {getStatusBadge(telemetry.windows.planting.status)}
                  </div>
                  <p className="text-xs font-semibold text-emerald-400">
                    {telemetry.windows.planting.label[currentLang] || telemetry.windows.planting.label['en']}
                  </p>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {telemetry.windows.planting.advice[currentLang] || telemetry.windows.planting.advice['en']}
                  </p>
                </div>

                {/* Irrigation Window */}
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <ShowerHead className="w-4 h-4 text-blue-400" />
                      <span className="font-bold text-xs text-white">
                        {language === 'rw' ? 'Kuvomerera Imirima' : language === 'fr' ? 'Irrigation' : 'Field Irrigation'}
                      </span>
                    </div>
                    {getStatusBadge(telemetry.windows.irrigation.status)}
                  </div>
                  <p className="text-xs font-semibold text-blue-400">
                    {telemetry.windows.irrigation.label[currentLang] || telemetry.windows.irrigation.label['en']}
                  </p>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {telemetry.windows.irrigation.advice[currentLang] || telemetry.windows.irrigation.advice['en']}
                  </p>
                </div>

                {/* Spraying Window Card */}
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <span className="text-base">🧪</span>
                      <span className="font-bold text-xs text-white">
                        {language === 'rw' ? 'Gutera Umuti (Pesticide/Fungicide)' : language === 'fr' ? 'Pulvérisation Traitement' : 'Pesticide & Fungicide Spraying'}
                      </span>
                    </div>
                    {getStatusBadge(telemetry.windows.spraying.status)}
                  </div>
                  <p className="text-xs font-semibold text-amber-400">
                    {telemetry.windows.spraying.label[currentLang] || telemetry.windows.spraying.label['en']}
                  </p>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {telemetry.windows.spraying.advice[currentLang] || telemetry.windows.spraying.advice['en']}
                  </p>
                </div>

                {/* Fertilizer Window Card */}
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <span className="text-base">🌱</span>
                      <span className="font-bold text-xs text-white">
                        {language === 'rw' ? 'Gushyiramo Ifumbire (NPK/Urea)' : language === 'fr' ? 'Fertilisation NPK/Urea' : 'Fertilizer Application (NPK/Urea)'}
                      </span>
                    </div>
                    {getStatusBadge(telemetry.windows.fertilizer.status)}
                  </div>
                  <p className="text-xs font-semibold text-emerald-400">
                    {telemetry.windows.fertilizer.label[currentLang] || telemetry.windows.fertilizer.label['en']}
                  </p>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {telemetry.windows.fertilizer.advice[currentLang] || telemetry.windows.fertilizer.advice['en']}
                  </p>
                </div>
              </div>

              {/* Harvesting Window Card Full Width */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <span className="text-base">🌽</span>
                    <span className="font-bold text-xs text-white">
                      {language === 'rw' ? 'Gusarura & Kwanika Umusaruro' : language === 'fr' ? 'Récolte et Séchage' : 'Harvesting & Sun-Drying Operations'}
                    </span>
                  </div>
                  {getStatusBadge(telemetry.windows.harvesting.status)}
                </div>
                <p className="text-xs font-semibold text-teal-400">
                  {telemetry.windows.harvesting.label[currentLang] || telemetry.windows.harvesting.label['en']}
                </p>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {telemetry.windows.harvesting.advice[currentLang] || telemetry.windows.harvesting.advice['en']}
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: 7-Day Forecast */}
          {activeTab === '7days' && (
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-slate-200">
                {language === 'rw' ? 'Iteganyagihe Ryitondewe ry\'Iminsi 7' : '7-Day Extended Micro-climate Outlook'}
              </h4>
              <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                {telemetry.forecast7Days.map((f, idx) => (
                  <div key={idx} className="p-3 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="flex items-center space-x-3 w-40">
                      <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center font-bold text-white">
                        {f.day.substring(0, 3)}
                      </div>
                      <div>
                        <p className="font-bold text-white">{f.day} <span className="text-[10px] text-slate-400">({f.date})</span></p>
                        <p className="text-[11px] text-blue-400">{f.condition}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      <div className="text-center">
                        <span className="text-[10px] text-slate-400 block">High / Low</span>
                        <span className="font-black text-white">{f.tempHighC}° / {f.tempLowC}°C</span>
                      </div>

                      <div className="text-center">
                        <span className="text-[10px] text-slate-400 block">Rain Vol</span>
                        <span className="font-bold text-blue-400">{f.rainfallMm} mm ({f.rainPct}%)</span>
                      </div>
                    </div>

                    <div className="flex-1 bg-slate-900 p-2 rounded-xl border border-slate-800 text-[11px] text-slate-300">
                      <span className="text-emerald-400 font-bold mr-1">RAB Note:</span>
                      {f.agronomyNote[currentLang] || f.agronomyNote['en']}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: Terracing & Disaster Actions */}
          {activeTab === 'mitigation' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="text-sm font-bold text-slate-200">
                    {language === 'rw' ? 'Gukoresha Imiferege & Kurwanya Isuri' : 'Disaster Preparedness & Terrace Checklist'}
                  </h4>
                  <p className="text-xs text-slate-400">
                    {language === 'rw' ? 'Kurinda amatare n\'isuri mu karere ka' : 'Protect slope terraces & topsoil erosion in'} {telemetry.district}
                  </p>
                </div>
                <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded-xl">
                  {telemetry.mitigationChecklist.filter(c => completedItems[c.id] ?? c.completed).length} / {telemetry.mitigationChecklist.length} {language === 'rw' ? 'Byarangiye' : 'Done'}
                </span>
              </div>

              <div className="space-y-2.5">
                {telemetry.mitigationChecklist.map((item) => {
                  const isDone = completedItems[item.id] ?? item.completed;
                  return (
                    <div
                      key={item.id}
                      onClick={() => toggleChecklistItem(item.id)}
                      className={`p-3.5 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                        isDone
                          ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200'
                          : 'bg-slate-950 border-slate-800 text-slate-200 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <div className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-colors ${
                          isDone ? 'bg-emerald-500 border-emerald-400 text-slate-950' : 'border-slate-600'
                        }`}>
                          {isDone && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                        <span className="text-xs font-medium">
                          {item.text[currentLang] || item.text['en']}
                        </span>
                      </div>

                      <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
                        {isDone ? (language === 'rw' ? 'Byakozwe' : 'Completed') : (language === 'rw' ? 'Umutoro' : 'Pending')}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

        </div>

      </div>

      {/* SMS Alert Subscription Modal */}
      {showSmsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl relative text-slate-100 space-y-4">
            
            <button
              onClick={() => setShowSmsModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-xl bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center space-x-3 border-b border-slate-800 pb-3">
              <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <PhoneCall className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-white">
                  {language === 'rw' ? 'Ubusemburo bw\'SMS ya Meteo Rwanda' : 'Meteo Rwanda Daily SMS Alert'}
                </h3>
                <p className="text-xs text-slate-400">
                  {language === 'rw' ? 'Bona SMS ya saa 06:00 AM buri munsi mu Kinyarwanda' : 'Get 6:00 AM daily weather advisories in Kinyarwanda'}
                </p>
              </div>
            </div>

            {smsSubscribed ? (
              <div className="py-8 text-center space-y-3">
                <div className="w-12 h-12 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-emerald-300">
                  {language === 'rw' ? 'Wiyandikishije neza!' : 'Subscription Activated!'}
                </h4>
                <p className="text-xs text-slate-300 max-w-xs mx-auto">
                  {language === 'rw'
                    ? `Nimero ${phoneNumber} izajya ibona ubutumwa bw'iteganyagihe mu karere ka ${selectedDistrict} buri gitondo.`
                    : `Phone number ${phoneNumber} will receive daily 6:00 AM SMS weather advisories for ${selectedDistrict}.`}
                </p>
              </div>
            ) : (
              <form onSubmit={handleSmsSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {language === 'rw' ? 'Nimero ya Telefone (MTN / Airtel)' : 'Phone Number (MTN / Airtel)'}
                  </label>
                  <input
                    type="tel"
                    required
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-white focus:outline-none focus:border-emerald-500"
                    placeholder="+250 788 000 000"
                  />
                </div>

                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-[11px] text-slate-300 space-y-1">
                  <div className="flex items-center space-x-1 text-emerald-400 font-bold">
                    <Info className="w-3.5 h-3.5" />
                    <span>{language === 'rw' ? 'Ibitekerezo kuri Service:' : 'Service Details:'}</span>
                  </div>
                  <p>• {language === 'rw' ? 'Ni buntu ku bahinzi n\'aborozi bo mu Rwanda.' : '100% Free for verified Rwandan farmers.'}</p>
                  <p>• {language === 'rw' ? 'Ushobora guhagarika SMS wanditse STOP kuri 4123.' : 'Opt-out anytime by texting STOP to 4123.'}</p>
                </div>

                <button
                  type="submit"
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl text-xs transition-colors shadow"
                >
                  {language === 'rw' ? 'Emeza Wiyandikishe Ku Buntu' : 'Confirm Free Subscription'}
                </button>
              </form>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
