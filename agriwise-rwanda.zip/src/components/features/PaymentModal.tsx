import React, { useState } from 'react';
import { Language } from '../../types';
import { translations } from '../../data/translations';
import {
  Wallet,
  Smartphone,
  CheckCircle2,
  X,
  Lock,
  ArrowRight,
  ShieldCheck,
  Receipt
} from 'lucide-react';

interface PaymentModalProps {
  amountRwf: number;
  itemTitle: string;
  language: Language;
  onClose: () => void;
  onPaymentSuccess: (txRef: string) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  amountRwf,
  itemTitle,
  language,
  onClose,
  onPaymentSuccess,
}) => {
  const t = translations[language];

  const [paymentProvider, setPaymentProvider] = useState<'momo' | 'airtel'>('momo');
  const [phoneNumber, setPhoneNumber] = useState('+250 788 345 678');
  const [momoPin, setMomoPin] = useState('');
  const [step, setStep] = useState<'prompt' | 'pin' | 'success'>('prompt');
  const [txRef, setTxRef] = useState('');

  const handleInitiatePrompt = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('pin');
  };

  const handleConfirmPin = (e: React.FormEvent) => {
    e.preventDefault();
    const generatedRef = `MOMO-RW-${Math.floor(10000000 + Math.random() * 90000000)}`;
    setTxRef(generatedRef);
    setStep('success');
    onPaymentSuccess(generatedRef);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full text-white space-y-5 shadow-2xl relative">
        
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title */}
        <div className="flex items-center space-x-3 border-b border-slate-800 pb-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-base text-white">Mobile Money Checkout</h3>
            <p className="text-xs text-slate-400">MTN MoMo (*182#) & Airtel Money Payment</p>
          </div>
        </div>

        {/* Item Summary */}
        <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-1 text-xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase">Item / Service:</span>
          <p className="font-bold text-white text-sm">{itemTitle}</p>
          <div className="pt-1 flex justify-between font-black text-amber-300 text-sm">
            <span>Total Payable:</span>
            <span>{amountRwf.toLocaleString()} RWF</span>
          </div>
        </div>

        {/* STEP 1: Provider & Phone */}
        {step === 'prompt' && (
          <form onSubmit={handleInitiatePrompt} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-300 font-bold mb-1.5">Select Network Provider:</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentProvider('momo')}
                  className={`p-3 rounded-2xl border font-bold flex items-center justify-center space-x-2 transition-all ${
                    paymentProvider === 'momo'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500 shadow'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  <Smartphone className="w-4 h-4 text-amber-400" />
                  <span>MTN MoMo</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentProvider('airtel')}
                  className={`p-3 rounded-2xl border font-bold flex items-center justify-center space-x-2 transition-all ${
                    paymentProvider === 'airtel'
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500 shadow'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  <Smartphone className="w-4 h-4 text-rose-400" />
                  <span>Airtel Money</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-bold mb-1">Mobile Money Number (+250):</label>
              <input
                type="text"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="+250 788 000 000"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white font-mono font-bold text-sm"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-black py-3 rounded-xl shadow-lg flex items-center justify-center space-x-2 transition-all"
            >
              <span>Send USSD Payment Prompt</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* STEP 2: USSD PIN Simulation */}
        {step === 'pin' && (
          <form onSubmit={handleConfirmPin} className="space-y-4 text-xs animate-fade-in">
            <div className="p-4 bg-amber-950/60 border border-amber-500/40 rounded-2xl text-center space-y-2">
              <Lock className="w-8 h-8 text-amber-400 mx-auto animate-bounce" />
              <p className="font-bold text-amber-300">USSD Prompt Sent to {phoneNumber}</p>
              <p className="text-[11px] text-slate-300">
                Enter your 5-Digit Mobile Money PIN to approve {amountRwf.toLocaleString()} RWF payment.
              </p>
            </div>

            <div>
              <label className="block text-slate-300 font-bold mb-1">MoMo PIN (*182#):</label>
              <input
                type="password"
                maxLength={5}
                value={momoPin}
                onChange={(e) => setMomoPin(e.target.value)}
                placeholder="•••••"
                className="w-full bg-slate-950 border border-amber-500/50 rounded-xl px-3 py-3 text-center text-amber-300 font-mono font-bold text-xl tracking-widest focus:outline-none"
                required
              />
            </div>

            <button
              type="submit"
              disabled={momoPin.length < 4}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black py-3 rounded-xl shadow-lg flex items-center justify-center space-x-2 transition-all disabled:opacity-50"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Confirm & Transfer RWF</span>
            </button>
          </form>
        )}

        {/* STEP 3: Success Receipt */}
        {step === 'success' && (
          <div className="space-y-4 text-center text-xs animate-fade-in">
            <div className="w-14 h-14 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/40">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <h4 className="font-black text-lg text-white">Payment Successful!</h4>
              <p className="text-slate-400 text-xs mt-0.5">Transaction processed via MTN Mobile Money</p>
            </div>

            <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-left space-y-1 font-mono text-[11px]">
              <p><strong className="text-slate-400">Ref No:</strong> <span className="text-amber-300 font-bold">{txRef}</span></p>
              <p><strong className="text-slate-400">Amount:</strong> {amountRwf.toLocaleString()} RWF</p>
              <p><strong className="text-slate-400">Status:</strong> ESCROW RELEASED / COMPLETED</p>
            </div>

            <button
              onClick={onClose}
              className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold py-2.5 rounded-xl shadow"
            >
              Close Receipt
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
