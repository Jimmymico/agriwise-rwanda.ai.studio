import React, { useState } from 'react';
import {
  Cpu,
  Droplets,
  Thermometer,
  Sun,
  Wind,
  CloudRain,
  Activity,
  Zap,
  Radio,
  Wifi,
  WifiOff,
  BatteryCharging,
  AlertTriangle,
  CheckCircle2,
  Sliders,
  Sparkles,
  Bot,
  Play,
  RotateCcw,
  Volume2,
  MapPin,
  Flame,
  Gauge,
  Layers,
  HeartPulse,
  Plus,
  ArrowRight,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';
import {
  MOCK_IOT_DEVICES,
  MOCK_SOIL_TELEMETRY,
  MOCK_WEATHER_TELEMETRY,
  MOCK_IRRIGATION_TELEMETRY,
  MOCK_GREENHOUSE_TELEMETRY,
  MOCK_LIVESTOCK_TELEMETRY,
  MOCK_AUTOMATION_RULES,
  MOCK_IOT_ALERTS
} from '../../data/mockIoTData';
import {
  IoTDevice,
  SoilSensorTelemetry,
  WeatherStationTelemetry,
  IrrigationControllerTelemetry,
  GreenhouseTelemetry,
  LivestockCollarTelemetry,
  IoTAutomationRule,
  IoTAlertNotification
} from '../../types';

export const IoTSmartFarmDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<
    'overview' | 'twin_map' | 'irrigation' | 'greenhouse' | 'livestock' | 'devices' | 'rules' | 'ai_voice'
  >('overview');

  // Live Telemetry Simulation States
  const [soilState, setSoilState] = useState<SoilSensorTelemetry>(MOCK_SOIL_TELEMETRY);
  const [weatherState, setWeatherState] = useState<WeatherStationTelemetry>(MOCK_WEATHER_TELEMETRY);
  const [irrigationState, setIrrigationState] = useState<IrrigationControllerTelemetry>(MOCK_IRRIGATION_TELEMETRY);
  const [greenhouseState, setGreenhouseState] = useState<GreenhouseTelemetry>(MOCK_GREENHOUSE_TELEMETRY);
  const [livestockState, setLivestockState] = useState<LivestockCollarTelemetry>(MOCK_LIVESTOCK_TELEMETRY);
  const [devicesList, setDevicesList] = useState<IoTDevice[]>(MOCK_IOT_DEVICES);
  const [automationRules, setAutomationRules] = useState<IoTAutomationRule[]>(MOCK_AUTOMATION_RULES);
  const [alerts, setAlerts] = useState<IoTAlertNotification[]>(MOCK_IOT_ALERTS);

  // Connectivity & Edge Mode State
  const [isRuralOfflineMode, setIsRuralOfflineMode] = useState(false);
  const [offlineSyncQueue, setOfflineSyncQueue] = useState(0);

  // Gemini AI Analysis State
  const [isAiAnalyzing, setIsAiAnalyzing] = useState(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<{
    farmHealthScore: number;
    irrigationNeededNow: boolean;
    recommendedWaterLitersPerHa: number;
    optimalWateringWindowHours: number;
    diseaseFungalOutbreakRisk: string;
    soilNutrientBalanceStatus: string;
    automatedSolenoidAction: string;
    aiTelemetryAdvisory: string;
  } | null>(null);

  // AI Voice Query Simulation
  const [voiceQueryText, setVoiceQueryText] = useState("How is my farm soil and moisture today?");
  const [voiceResponse, setVoiceResponse] = useState<string | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Add Device Modal State
  const [showAddDeviceModal, setShowAddDeviceModal] = useState(false);
  const [newDeviceName, setNewDeviceName] = useState('');
  const [newDeviceType, setNewDeviceType] = useState<IoTDevice['deviceType']>('Soil Sensor Node');
  const [newDeviceMac, setNewDeviceMac] = useState('');

  // Manual Valve Override
  const toggleValveOverride = () => {
    setIrrigationState(prev => {
      const isCurrentlyOpen = prev.valveState.includes('OPEN');
      return {
        ...prev,
        valveState: isCurrentlyOpen ? 'CLOSED (Idle)' : 'OPEN (Watering)',
        waterFlowRateLitersMin: isCurrentlyOpen ? 0 : 45,
        totalWaterDeliveredTodayLiters: isCurrentlyOpen
          ? prev.totalWaterDeliveredTodayLiters
          : prev.totalWaterDeliveredTodayLiters + 250
      };
    });
  };

  // Run AI Telemetry Analysis
  const runAiAnalysis = async () => {
    setIsAiAnalyzing(true);
    try {
      const response = await fetch('/api/ai/iot-analytics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          farmName: 'Hakizimana Maize & Bean Plot A',
          soilMoisturePct: soilState.moisturePct,
          soilTempC: soilState.temperatureC,
          phLevel: soilState.phLevel,
          ambientTempC: weatherState.ambientTempC,
          humidityPct: weatherState.humidityPct,
          solarRadiationWM2: weatherState.solarRadiationWM2,
          evapotranspirationMmDay: weatherState.evapotranspirationMmDay
        })
      });
      const data = await response.json();
      setAiAnalysisResult(data);
    } catch (err) {
      console.error('IoT AI Analysis failed:', err);
      // Fallback response
      setAiAnalysisResult({
        farmHealthScore: soilState.moisturePct < 35 ? 78 : 92,
        irrigationNeededNow: soilState.moisturePct < 35,
        recommendedWaterLitersPerHa: soilState.moisturePct < 35 ? 1400 : 0,
        optimalWateringWindowHours: 6,
        diseaseFungalOutbreakRisk: 'Low',
        soilNutrientBalanceStatus: 'Optimal NPK (42-18-165 mg/kg)',
        automatedSolenoidAction: soilState.moisturePct < 35
          ? 'Trigger Drip Solenoid Valve #2 for 45 minutes at 17:30.'
          : 'Keep Solenoid Valve #2 in CLOSED standby mode.',
        aiTelemetryAdvisory: soilState.moisturePct < 35
          ? 'Soil moisture is at ' + soilState.moisturePct + '%, below the 35% agronomic cutoff. Immediate drip irrigation recommended.'
          : 'Soil moisture level (' + soilState.moisturePct + '%) is optimal. No immediate irrigation required.'
      });
    } finally {
      setIsAiAnalyzing(false);
    }
  };

  // Handle AI Voice Query
  const handleVoiceQuery = async (query: string) => {
    setIsSpeaking(true);
    setVoiceResponse(null);
    setTimeout(() => {
      let responseMsg = "";
      if (query.toLowerCase().includes('soil') || query.toLowerCase().includes('moisture')) {
        responseMsg = `Your soil moisture in Field A is currently ${soilState.moisturePct}%, which is ${
          soilState.moisturePct < 35 ? 'LOW. Drip irrigation valve #2 is scheduled to run.' : 'OPTIMAL.'
        } Soil temperature is ${soilState.temperatureC}°C.`;
      } else if (query.toLowerCase().includes('weather') || query.toLowerCase().includes('rain')) {
        responseMsg = `Weather station reports ${weatherState.ambientTempC}°C, humidity ${weatherState.humidityPct}%. Rain in 24h is 0mm. Evapotranspiration rate is ${weatherState.evapotranspirationMmDay} mm/day.`;
      } else if (query.toLowerCase().includes('livestock') || query.toLowerCase().includes('cow')) {
        responseMsg = `Girinka Friesian Cow #044 is HEALTHY. Body temperature is ${livestockState.bodyTempC}°C with ${livestockState.dailyRuminationHours} hours of rumination today.`;
      } else {
        responseMsg = `Farm overall IoT health score is 88/100. All 5 sensors (LoRaWAN & NB-IoT) are online. Soil moisture is ${soilState.moisturePct}%. No rainfall expected today.`;
      }
      setVoiceResponse(responseMsg);
      setIsSpeaking(false);
    }, 1200);
  };

  const handleAcknowledgeAlert = (alertId: string) => {
    setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, isAcknowledged: true } : a));
  };

  const handleCreateDevice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDeviceName) return;
    const created: IoTDevice = {
      id: `iot-${Date.now()}`,
      deviceName: newDeviceName,
      farmId: 'farm-001',
      farmName: 'Hakizimana Farm',
      deviceType: newDeviceType,
      status: 'Online',
      batteryPct: 100,
      signalStrengthDbm: -72,
      lastTelemetryTimestamp: 'Just Now',
      firmwareVersion: 'v1.0.0-OTA',
      macAddressOrDevEui: newDeviceMac || '70-B3-D5-7E-' + Math.floor(Math.random()*8999+1000),
      fieldLocation: 'Field B (Newly Added Sensor Node)'
    };
    setDevicesList(prev => [...prev, created]);
    setShowAddDeviceModal(false);
    setNewDeviceName('');
    setNewDeviceMac('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-emerald-700/60 rounded-xl border border-emerald-500/30 backdrop-blur-md">
                <Radio className="w-7 h-7 text-emerald-300 animate-pulse" />
              </div>
              <div>
                <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
                  AGRIWISE IoT Smart Farming System
                  <span className="text-xs bg-emerald-500/30 text-emerald-200 border border-emerald-400/40 px-2.5 py-0.5 rounded-full font-medium">
                    LoRaWAN & NB-IoT Telemetry
                  </span>
                </h1>
                <p className="text-emerald-200 text-sm mt-0.5">
                  Real-Time Soil Probes • Weather Stations • Autonomous Solenoid Valves • Greenhouse Climate & Livestock Collars
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Edge / Rural Connectivity Toggle */}
            <button
              onClick={() => {
                setIsRuralOfflineMode(!isRuralOfflineMode);
                if (!isRuralOfflineMode) {
                  setOfflineSyncQueue(3);
                } else {
                  setOfflineSyncQueue(0);
                }
              }}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all border ${
                isRuralOfflineMode
                  ? 'bg-amber-500/20 text-amber-200 border-amber-400/40'
                  : 'bg-emerald-700/40 text-emerald-100 border-emerald-500/30 hover:bg-emerald-700/60'
              }`}
            >
              {isRuralOfflineMode ? (
                <>
                  <WifiOff className="w-4 h-4 text-amber-300" />
                  Rural Offline Edge (Queue: {offlineSyncQueue})
                </>
              ) : (
                <>
                  <Wifi className="w-4 h-4 text-emerald-300" />
                  Live GSM/LoRa Sync Active
                </>
              )}
            </button>

            {/* Run AI Diagnostics Button */}
            <button
              onClick={runAiAnalysis}
              disabled={isAiAnalyzing}
              className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs shadow-lg transition-all border border-emerald-300/40 disabled:opacity-50"
            >
              <Sparkles className={`w-4 h-4 ${isAiAnalyzing ? 'animate-spin' : ''}`} />
              {isAiAnalyzing ? 'Analyzing Sensors...' : 'AI Sensor Analytics'}
            </button>
          </div>
        </div>
      </div>

      {/* Active Alerts Bar */}
      {alerts.some(a => !a.isAcknowledged) && (
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-500 flex-shrink-0" />
            <div>
              <span className="font-semibold text-amber-900 dark:text-amber-200 text-sm">
                Active Sensor Alert:
              </span>{' '}
              <span className="text-xs text-amber-800 dark:text-amber-300">
                {alerts.find(a => !a.isAcknowledged)?.message}
              </span>
            </div>
          </div>
          <button
            onClick={() => handleAcknowledgeAlert(alerts.find(a => !a.isAcknowledged)!.id)}
            className="text-xs bg-amber-500/20 text-amber-800 dark:text-amber-200 hover:bg-amber-500/30 font-medium px-3 py-1.5 rounded-lg transition-colors flex-shrink-0"
          >
            Acknowledge Alert
          </button>
        </div>
      )}

      {/* Main Navigation Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800">
        {[
          { id: 'overview', label: 'Real-Time Sensor Dashboard', icon: Gauge },
          { id: 'twin_map', label: 'Digital Farm Twin Integration', icon: Layers },
          { id: 'irrigation', label: 'Smart Drip Irrigation', icon: Droplets },
          { id: 'greenhouse', label: 'Smart Greenhouse Vault', icon: Flame },
          { id: 'livestock', label: 'Livestock Collar Health', icon: HeartPulse },
          { id: 'devices', label: 'Device & Node Management', icon: Cpu },
          { id: 'rules', label: 'Automation Rules', icon: Zap },
          { id: 'ai_voice', label: 'AI Voice & Advisory', icon: Bot }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Gemini AI Sensor Analytics Box (if run) */}
      {aiAnalysisResult && (
        <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-5 text-white shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-emerald-400 text-sm font-bold">
              <Sparkles className="w-5 h-5 animate-spin" />
              Gemini 3.6 Flash IoT Sensor Intelligence Summary
            </div>
            <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-3 py-1 rounded-full font-semibold">
              Farm Health Index: {aiAnalysisResult.farmHealthScore}/100
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700">
              <span className="text-xs text-slate-400 block mb-1">Irrigation Status</span>
              <p className="text-sm font-bold text-white flex items-center gap-2">
                {aiAnalysisResult.irrigationNeededNow ? (
                  <span className="text-amber-400 flex items-center gap-1">
                    <AlertTriangle className="w-4 h-4" /> Recommended (1,200 L/Ha)
                  </span>
                ) : (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4" /> Optimal Moisture Level
                  </span>
                )}
              </p>
            </div>

            <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700">
              <span className="text-xs text-slate-400 block mb-1">Automated Valve Action</span>
              <p className="text-xs font-mono text-emerald-300">
                {aiAnalysisResult.automatedSolenoidAction}
              </p>
            </div>

            <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700">
              <span className="text-xs text-slate-400 block mb-1">Fungal & Disease Risk</span>
              <p className="text-sm font-semibold text-slate-200">
                {aiAnalysisResult.diseaseFungalOutbreakRisk} (Humidity: {weatherState.humidityPct}%)
              </p>
            </div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-xl text-xs text-slate-300 leading-relaxed border border-slate-700/60">
            <strong className="text-emerald-400 block mb-1">Agronomic Telemetry Advisory:</strong>
            {aiAnalysisResult.aiTelemetryAdvisory}
          </div>
        </div>
      )}

      {/* TAB 1: OVERVIEW & REAL-TIME DASHBOARD */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Interactive Simulation Controls */}
          <div className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-emerald-500" />
                Live Sensor Telemetry Adjuster (Interactive Simulation)
              </h3>
              <button
                onClick={() => {
                  setSoilState(MOCK_SOIL_TELEMETRY);
                  setWeatherState(MOCK_WEATHER_TELEMETRY);
                }}
                className="text-xs text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 font-medium"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Reset Default
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="text-xs text-slate-600 dark:text-slate-300 font-semibold mb-1 flex justify-between">
                  <span>Soil Moisture Probe (Field A):</span>
                  <span className={`font-mono ${soilState.moisturePct < 35 ? 'text-amber-600 font-bold' : 'text-emerald-600'}`}>
                    {soilState.moisturePct}%
                  </span>
                </label>
                <input
                  type="range"
                  min="10"
                  max="90"
                  value={soilState.moisturePct}
                  onChange={(e) => setSoilState({ ...soilState, moisturePct: Number(e.target.value) })}
                  className="w-full accent-emerald-600 h-2 bg-slate-200 rounded-lg cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 block mt-1">
                  Threshold: Below 35% triggers automatic drip irrigation advisory.
                </span>
              </div>

              <div>
                <label className="text-xs text-slate-600 dark:text-slate-300 font-semibold mb-1 flex justify-between">
                  <span>Ambient Temperature (Weather Station):</span>
                  <span className="font-mono text-emerald-600 font-bold">{weatherState.ambientTempC}°C</span>
                </label>
                <input
                  type="range"
                  min="15"
                  max="40"
                  value={weatherState.ambientTempC}
                  onChange={(e) => setWeatherState({ ...weatherState, ambientTempC: Number(e.target.value) })}
                  className="w-full accent-emerald-600 h-2 bg-slate-200 rounded-lg cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 block mt-1">
                  High temp accelerates evapotranspiration water loss.
                </span>
              </div>

              <div>
                <label className="text-xs text-slate-600 dark:text-slate-300 font-semibold mb-1 flex justify-between">
                  <span>Relative Air Humidity:</span>
                  <span className="font-mono text-emerald-600 font-bold">{weatherState.humidityPct}%</span>
                </label>
                <input
                  type="range"
                  min="20"
                  max="95"
                  value={weatherState.humidityPct}
                  onChange={(e) => setWeatherState({ ...weatherState, humidityPct: Number(e.target.value) })}
                  className="w-full accent-emerald-600 h-2 bg-slate-200 rounded-lg cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 block mt-1">
                  Above 80% triggers fungal disease alert for beans.
                </span>
              </div>
            </div>
          </div>

          {/* Sensor Grid Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Soil Moisture */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Soil Moisture</span>
                <div className={`p-2 rounded-xl ${soilState.moisturePct < 35 ? 'bg-amber-100 text-amber-600' : 'bg-emerald-100 text-emerald-600'}`}>
                  <Droplets className="w-5 h-5" />
                </div>
              </div>
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono">
                {soilState.moisturePct}%
              </div>
              <div className="mt-2 flex items-center justify-between text-xs">
                <span className={`font-semibold ${soilState.moisturePct < 35 ? 'text-amber-600' : 'text-emerald-600'}`}>
                  {soilState.moisturePct < 35 ? 'Needs Irrigation' : 'Optimal Moisture'}
                </span>
                <span className="text-slate-400">Target: 40-70%</span>
              </div>
            </div>

            {/* Ambient Temperature */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Field Temperature</span>
                <div className="p-2 bg-orange-100 dark:bg-orange-950/40 text-orange-600 rounded-xl">
                  <Thermometer className="w-5 h-5" />
                </div>
              </div>
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono">
                {weatherState.ambientTempC}°C
              </div>
              <div className="mt-2 flex items-center justify-between text-xs">
                <span className="text-slate-500">Soil Temp: {soilState.temperatureC}°C</span>
                <span className="text-slate-400">Humidity: {weatherState.humidityPct}%</span>
              </div>
            </div>

            {/* Solar Radiation & Evapotranspiration */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Solar Radiation</span>
                <div className="p-2 bg-amber-100 dark:bg-amber-950/40 text-amber-600 rounded-xl">
                  <Sun className="w-5 h-5" />
                </div>
              </div>
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono">
                {weatherState.solarRadiationWM2} <span className="text-sm font-normal text-slate-400">W/m²</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-xs">
                <span className="text-slate-500">ET Rate: {weatherState.evapotranspirationMmDay} mm/day</span>
                <span className="text-emerald-600 font-medium">High Solar</span>
              </div>
            </div>

            {/* Soil pH & NPK Balance */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Soil NPK & pH</span>
                <div className="p-2 bg-indigo-100 dark:bg-indigo-950/40 text-indigo-600 rounded-xl">
                  <Activity className="w-5 h-5" />
                </div>
              </div>
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono">
                pH {soilState.phLevel}
              </div>
              <div className="mt-2 text-xs text-slate-500 flex justify-between">
                <span>N: {soilState.nitrogenMgKg} | P: {soilState.phosphorusMgKg} | K: {soilState.potassiumMgKg}</span>
              </div>
            </div>
          </div>

          {/* Detailed Telemetry Breakdown Panels */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Field A Soil Profile */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                  <Droplets className="w-5 h-5 text-emerald-600" />
                  Field A Dragino Probe Telemetry (Flowering Maize)
                </h3>
                <span className="text-xs font-mono bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300 px-2.5 py-1 rounded-md border border-emerald-300/40">
                  LoRaWAN -74 dBm
                </span>
              </div>

              <div className="space-y-4">
                {/* Moisture Bar */}
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-slate-600 dark:text-slate-300">Volumetric Water Content VWC</span>
                    <span className="text-emerald-600 font-bold">{soilState.moisturePct}%</span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-3 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        soilState.moisturePct < 35 ? 'bg-amber-500' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${soilState.moisturePct}%` }}
                    />
                  </div>
                </div>

                {/* Soil NPK Levels Grid */}
                <div className="grid grid-cols-3 gap-3 pt-2">
                  <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                    <span className="text-[11px] text-slate-500 block">Nitrogen (N)</span>
                    <span className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                      {soilState.nitrogenMgKg} mg/kg
                    </span>
                  </div>
                  <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                    <span className="text-[11px] text-slate-500 block">Phosphorus (P)</span>
                    <span className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                      {soilState.phosphorusMgKg} mg/kg
                    </span>
                  </div>
                  <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                    <span className="text-[11px] text-slate-500 block">Potassium (K)</span>
                    <span className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                      {soilState.potassiumMgKg} mg/kg
                    </span>
                  </div>
                </div>

                <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50 rounded-xl p-3.5 flex items-start gap-3">
                  <Bot className="w-5 h-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-emerald-900 dark:text-emerald-200 leading-relaxed">
                    <strong>AI Field Recommendation:</strong> Soil pH of 6.4 is ideal for maize root nutrient uptake. Nitrogen status is stable. Water stress detected due to high solar radiation.
                  </p>
                </div>
              </div>
            </div>

            {/* Weather & Microclimate Station */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                  <CloudRain className="w-5 h-5 text-teal-600" />
                  Milesight Microclimate Station Telemetry
                </h3>
                <span className="text-xs font-mono bg-teal-100 text-teal-800 dark:bg-teal-950/50 dark:text-teal-300 px-2.5 py-1 rounded-md border border-teal-300/40">
                  NB-IoT Online
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-3 p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                  <Wind className="w-5 h-5 text-teal-600" />
                  <div>
                    <span className="text-[11px] text-slate-500 block">Wind Speed</span>
                    <span className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                      {weatherState.windSpeedKmH} km/h
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                  <CloudRain className="w-5 h-5 text-teal-600" />
                  <div>
                    <span className="text-[11px] text-slate-500 block">Rainfall (24h)</span>
                    <span className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                      {weatherState.rainfall24hMm} mm
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                  <Sun className="w-5 h-5 text-amber-500" />
                  <div>
                    <span className="text-[11px] text-slate-500 block">Solar Intensity</span>
                    <span className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                      {weatherState.solarRadiationWM2} W/m²
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                  <Gauge className="w-5 h-5 text-indigo-500" />
                  <div>
                    <span className="text-[11px] text-slate-500 block">Evapotranspiration</span>
                    <span className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                      {weatherState.evapotranspirationMmDay} mm/day
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
                <span>Weather Station Battery: 100% (Solar Charged)</span>
                <span className="text-emerald-600 font-medium">Synced 2 Mins Ago</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DIGITAL FARM TWIN INTEGRATION */}
      {activeTab === 'twin_map' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Layers className="w-5 h-5 text-emerald-600" />
                  Digital Twin Spatial Map + Real-Time Sensor Overlay
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Virtual 2D farm boundaries synchronized with live LoRaWAN IoT telemetry nodes and soil moisture heatmaps.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300 px-3 py-1 rounded-full border border-emerald-300/40 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" /> Live Sensor Overlay Active
                </span>
              </div>
            </div>

            {/* Interactive Farm Map Canvas Simulation */}
            <div className="relative w-full h-[420px] bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-inner p-6 flex flex-col justify-between">
              {/* Map Grid Lines */}
              <div
                className="absolute inset-0 opacity-15 pointer-events-none"
                style={{
                  backgroundImage: 'radial-gradient(#10b981 1px, transparent 1px)',
                  backgroundSize: '24px 24px'
                }}
              />

              {/* Top Map Stats Overlay */}
              <div className="relative z-10 flex justify-between items-center text-xs">
                <div className="bg-slate-900/90 border border-slate-700/80 rounded-xl p-3 backdrop-blur-md text-white space-y-1">
                  <div className="font-bold text-emerald-400">Hakizimana Farm Plot A (2.5 Ha)</div>
                  <div className="text-[11px] text-slate-300">Coordinates: 1.3045° S, 30.3218° E</div>
                </div>

                <div className="bg-slate-900/90 border border-slate-700/80 rounded-xl p-3 backdrop-blur-md text-white flex items-center gap-4">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-amber-500" />
                    <span className="text-[11px] text-slate-300">Moisture &lt; 35% Zone</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-emerald-500" />
                    <span className="text-[11px] text-slate-300">Optimal Zone</span>
                  </div>
                </div>
              </div>

              {/* Sensor Node Markers on Virtual Map */}
              <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-6 my-auto">
                {/* Node 1: Field A Soil Probe */}
                <div className="bg-slate-900/85 border border-amber-500/50 rounded-xl p-4 backdrop-blur-md shadow-lg text-white space-y-2 hover:border-amber-400 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                      <Radio className="w-4 h-4 animate-pulse text-amber-400" /> Node #1 (Soil Probe)
                    </span>
                    <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded font-mono">
                      {soilState.moisturePct}% VWC
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300">
                    Field A East - Flowering Maize
                  </p>
                  <div className="text-[10px] text-slate-400 flex justify-between pt-1 border-t border-slate-800">
                    <span>Temp: {soilState.temperatureC}°C</span>
                    <span>pH: {soilState.phLevel}</span>
                  </div>
                </div>

                {/* Node 2: Solenoid Drip Valve #2 */}
                <div className="bg-slate-900/85 border border-emerald-500/50 rounded-xl p-4 backdrop-blur-md shadow-lg text-white space-y-2 hover:border-emerald-400 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                      <Droplets className="w-4 h-4 text-emerald-400" /> Valve #2 (Drip Header)
                    </span>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                      irrigationState.valveState.includes('OPEN') ? 'bg-emerald-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300'
                    }`}>
                      {irrigationState.valveState}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300">
                    Drip Line Header B
                  </p>
                  <div className="text-[10px] text-slate-400 flex justify-between pt-1 border-t border-slate-800">
                    <span>Flow: {irrigationState.waterFlowRateLitersMin} L/min</span>
                    <span>Mode: {irrigationState.controlMode}</span>
                  </div>
                </div>

                {/* Node 3: Solar Weather Station */}
                <div className="bg-slate-900/85 border border-teal-500/50 rounded-xl p-4 backdrop-blur-md shadow-lg text-white space-y-2 hover:border-teal-400 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-teal-400 flex items-center gap-1.5">
                      <Sun className="w-4 h-4 text-teal-400" /> Weather Station
                    </span>
                    <span className="text-[10px] bg-teal-500/20 text-teal-300 px-2 py-0.5 rounded font-mono">
                      {weatherState.ambientTempC}°C
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300">
                    Central Ridge Sensor Station
                  </p>
                  <div className="text-[10px] text-slate-400 flex justify-between pt-1 border-t border-slate-800">
                    <span>Humidity: {weatherState.humidityPct}%</span>
                    <span>Solar: {weatherState.solarRadiationWM2} W/m²</span>
                  </div>
                </div>
              </div>

              {/* Bottom Legend */}
              <div className="relative z-10 flex justify-between items-center text-[11px] text-slate-400 border-t border-slate-800/80 pt-3">
                <span>Spatial Map Scale: 1:500 • LoRaWAN Gateway Coverage: 100%</span>
                <span className="text-emerald-400 font-mono">Digital Twin Status: Synchronized (0.2s latency)</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: SMART IRRIGATION SYSTEM */}
      {activeTab === 'irrigation' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Droplets className="w-5 h-5 text-emerald-600" />
                  Automated Solar Solenoid Drip Irrigation Controller
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Autonomous AI moisture-triggered watering with manual override and mobile money water delivery metrics.
                </p>
              </div>

              {/* Manual Override Button */}
              <button
                onClick={toggleValveOverride}
                className={`flex items-center gap-2 font-bold px-5 py-2.5 rounded-xl text-xs shadow-md transition-all border ${
                  irrigationState.valveState.includes('OPEN')
                    ? 'bg-amber-500 hover:bg-amber-600 text-slate-950 border-amber-400'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-500'
                }`}
              >
                <Zap className="w-4 h-4" />
                {irrigationState.valveState.includes('OPEN') ? 'CLOSE VALVE #2 OVERRIDE' : 'OPEN SOLENOID VALVE #2'}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                <span className="text-xs text-slate-500 block mb-1">Current Solenoid Valve State</span>
                <span className={`text-base font-extrabold ${
                  irrigationState.valveState.includes('OPEN') ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-700 dark:text-slate-300'
                }`}>
                  {irrigationState.valveState}
                </span>
                <span className="text-[11px] text-slate-400 block mt-1">
                  Flow Rate: {irrigationState.waterFlowRateLitersMin} Liters/Min
                </span>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                <span className="text-xs text-slate-500 block mb-1">Water Delivered Today</span>
                <span className="text-base font-extrabold text-slate-900 dark:text-white font-mono">
                  {irrigationState.totalWaterDeliveredTodayLiters.toLocaleString()} Liters
                </span>
                <span className="text-[11px] text-slate-400 block mt-1">
                  Saved vs Flood Irrigation: ~1,800 Liters
                </span>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                <span className="text-xs text-slate-500 block mb-1">Next AI Autonomous Schedule</span>
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 block">
                  {irrigationState.nextScheduledWatering}
                </span>
                <span className="text-[11px] text-slate-400 block mt-1">
                  Condition: Soil Moisture &lt; 35%
                </span>
              </div>
            </div>

            {/* AI Automated Logic Diagram */}
            <div className="bg-gradient-to-br from-slate-900 to-emerald-950 p-6 rounded-2xl text-white border border-emerald-500/30">
              <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 mb-4 flex items-center gap-2">
                <Bot className="w-4 h-4" /> Autonomous Smart Irrigation Decision Logic
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center text-center">
                <div className="bg-slate-800/90 p-3.5 rounded-xl border border-slate-700">
                  <span className="text-xs text-slate-400 block">Step 1: Soil Telemetry</span>
                  <span className={`text-sm font-bold ${soilState.moisturePct < 35 ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {soilState.moisturePct}% Moisture
                  </span>
                </div>

                <div className="hidden md:flex justify-center text-emerald-400">
                  <ArrowRight className="w-5 h-5" />
                </div>

                <div className="bg-slate-800/90 p-3.5 rounded-xl border border-slate-700">
                  <span className="text-xs text-slate-400 block">Step 2: Weather Forecast</span>
                  <span className="text-sm font-bold text-teal-300">
                    Rainfall: {weatherState.rainfall24hMm}mm (No Rain)
                  </span>
                </div>

                <div className="hidden md:flex justify-center text-emerald-400">
                  <ArrowRight className="w-5 h-5" />
                </div>

                <div className="bg-slate-800/90 p-3.5 rounded-xl border border-slate-700">
                  <span className="text-xs text-slate-400 block">Step 3: Solenoid Action</span>
                  <span className="text-sm font-bold text-emerald-300">
                    {soilState.moisturePct < 35 ? 'TRIGGER VALVE #2' : 'HOLD VALVE CLOSED'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: SMART GREENHOUSE VAULT */}
      {activeTab === 'greenhouse' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Flame className="w-5 h-5 text-amber-500" />
                  Musanze Hydroponic Greenhouse Climate Vault
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Automated ambient temperature, CO2 enrichment, light intensity, and motorized roof vent actuators.
                </p>
              </div>

              <span className="text-xs bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300 px-3 py-1 rounded-full font-semibold border border-amber-300/40">
                Hydroponic Vault #1 Active
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                <span className="text-xs text-slate-500 block mb-1">Inside Temperature</span>
                <span className="text-2xl font-extrabold text-slate-900 dark:text-white font-mono">
                  {greenhouseState.insideTempC}°C
                </span>
                <span className="text-[11px] text-emerald-600 block mt-1">Target: 20-25°C</span>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                <span className="text-xs text-slate-500 block mb-1">Relative Humidity</span>
                <span className="text-2xl font-extrabold text-slate-900 dark:text-white font-mono">
                  {greenhouseState.insideHumidityPct}%
                </span>
                <span className="text-[11px] text-teal-600 block mt-1">Misting: {greenhouseState.mistingSystemStatus}</span>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                <span className="text-xs text-slate-500 block mb-1">Carbon Dioxide (CO2)</span>
                <span className="text-2xl font-extrabold text-slate-900 dark:text-white font-mono">
                  {greenhouseState.co2Ppm} <span className="text-sm font-normal text-slate-400">ppm</span>
                </span>
                <span className="text-[11px] text-emerald-600 block mt-1">Enriched Level</span>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                <span className="text-xs text-slate-500 block mb-1">Motorized Roof Vent</span>
                <span className="text-2xl font-extrabold text-slate-900 dark:text-white font-mono">
                  {greenhouseState.roofVentPositionPct}% Open
                </span>
                <span className="text-[11px] text-indigo-600 block mt-1">Automated Servo Actuator</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: LIVESTOCK COLLAR HEALTH */}
      {activeTab === 'livestock' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <HeartPulse className="w-5 h-5 text-rose-500" />
                  Girinka Smart Livestock Collar Telemetry
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  GPS animal pasture tracking, body temperature monitoring, rumination health metrics & tele-veterinary AI integration.
                </p>
              </div>

              <span className="text-xs bg-rose-100 text-rose-800 dark:bg-rose-950/50 dark:text-rose-300 px-3 py-1 rounded-full font-semibold border border-rose-300/40">
                Tag #044 Connected
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60 space-y-2">
                <span className="text-xs text-slate-500 block">Animal Profile</span>
                <h4 className="font-bold text-slate-900 dark:text-white text-base">
                  {livestockState.animalName}
                </h4>
                <div className="text-xs text-slate-500 space-y-1">
                  <p>Species: {livestockState.species}</p>
                  <p>Tag Code: Tag #044 (LoRa/BLE/GPS Collar)</p>
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60 space-y-2">
                <span className="text-xs text-slate-500 block">Body Temperature & Pulse</span>
                <div className="text-2xl font-extrabold text-slate-900 dark:text-white font-mono">
                  {livestockState.bodyTempC}°C
                </div>
                <div className="text-xs text-emerald-600 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" /> Normal Temp (Heart Rate: {livestockState.heartRateBpm} BPM)
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/60 space-y-2">
                <span className="text-xs text-slate-500 block">Daily Rumination Activity</span>
                <div className="text-2xl font-extrabold text-slate-900 dark:text-white font-mono">
                  {livestockState.dailyRuminationHours} Hours
                </div>
                <div className="text-xs text-slate-500">
                  Target: 7.0 - 9.5 Hours/Day (Optimal Digestion)
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: DEVICE MANAGEMENT SYSTEM */}
      {activeTab === 'devices' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-indigo-600" />
                  IoT Device & LoRaWAN Gateway Management
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Monitor hardware battery health, RSSI signal strength, DevEUI MAC addresses, and OTA firmware updates.
                </p>
              </div>

              <button
                onClick={() => setShowAddDeviceModal(true)}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-4 py-2 rounded-xl text-xs transition-all shadow-md"
              >
                <Plus className="w-4 h-4" /> Register New IoT Sensor Node
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    <th className="py-3 px-4">Device Name</th>
                    <th className="py-3 px-4">Type</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Battery</th>
                    <th className="py-3 px-4">Signal (RSSI)</th>
                    <th className="py-3 px-4">Location</th>
                    <th className="py-3 px-4">Firmware</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs text-slate-700 dark:text-slate-300">
                  {devicesList.map((dev) => (
                    <tr key={dev.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="py-3.5 px-4 font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                        <Radio className="w-4 h-4 text-emerald-600" />
                        {dev.deviceName}
                      </td>
                      <td className="py-3.5 px-4">{dev.deviceType}</td>
                      <td className="py-3.5 px-4">
                        <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300 text-[11px] font-medium px-2.5 py-0.5 rounded-full border border-emerald-300/40">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" /> {dev.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-mono font-semibold">
                        <div className="flex items-center gap-1.5">
                          <BatteryCharging className="w-4 h-4 text-emerald-600" />
                          {dev.batteryPct}%
                        </div>
                      </td>
                      <td className="py-3.5 px-4 font-mono text-slate-500">
                        {dev.signalStrengthDbm} dBm
                      </td>
                      <td className="py-3.5 px-4 text-slate-500">{dev.fieldLocation}</td>
                      <td className="py-3.5 px-4 font-mono text-slate-400">{dev.firmwareVersion}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: AUTOMATION RULES ENGINE */}
      {activeTab === 'rules' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Zap className="w-5 h-5 text-amber-500" />
                  AGRIWISE Sensor Automation Rules Engine
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Configure autonomous "IF Sensor Condition THEN Trigger Hardware Action" rules for irrigation, vents, and alerts.
                </p>
              </div>
            </div>

            <div className="space-y-4">
              {automationRules.map((rule) => (
                <div
                  key={rule.id}
                  className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/70 p-4 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 dark:text-white text-sm">
                        {rule.ruleName}
                      </span>
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300 font-semibold px-2 py-0.5 rounded">
                        Active Rule
                      </span>
                    </div>
                    <div className="text-xs text-slate-600 dark:text-slate-300 font-mono">
                      <strong>IF:</strong> {rule.sensorTriggerCondition}
                    </div>
                    <div className="text-xs text-emerald-600 dark:text-emerald-400 font-mono">
                      <strong>THEN:</strong> {rule.actionToExecute}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-[11px] text-slate-400">
                      Last Triggered: {rule.lastTriggeredTimestamp}
                    </span>
                    <button
                      onClick={() => {
                        setAutomationRules(prev =>
                          prev.map(r => (r.id === rule.id ? { ...r, isActive: !r.isActive } : r))
                        );
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                        rule.isActive
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {rule.isActive ? 'Enabled' : 'Disabled'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 8: AI VOICE & SENSOR ADVISORY */}
      {activeTab === 'ai_voice' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-6 text-white shadow-xl space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Bot className="w-6 h-6 text-emerald-400" />
                Kinyarwanda & English AI Voice Farm Telemetry Assistant
              </h3>
              <p className="text-xs text-emerald-200 mt-1">
                Ask simple spoken questions about your soil moisture, weather, irrigation, or livestock health.
              </p>
            </div>

            <div className="bg-slate-800 p-4 rounded-xl border border-slate-700 space-y-4">
              <label className="text-xs text-slate-300 font-semibold block">
                Sample Spoken Queries (Click to test):
              </label>

              <div className="flex flex-wrap gap-2">
                {[
                  "How is my farm soil and moisture today?",
                  "Is rain expected in Nyagatare tomorrow?",
                  "What is Girinka Cow #044 body temperature?",
                  "Should I start drip irrigation now?"
                ].map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setVoiceQueryText(q);
                      handleVoiceQuery(q);
                    }}
                    className="text-xs bg-slate-700 hover:bg-emerald-700 text-emerald-200 px-3 py-1.5 rounded-lg transition-colors border border-slate-600"
                  >
                    "{q}"
                  </button>
                ))}
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={voiceQueryText}
                  onChange={(e) => setVoiceQueryText(e.target.value)}
                  placeholder="Ask your IoT farm voice assistant..."
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
                <button
                  onClick={() => handleVoiceQuery(voiceQueryText)}
                  disabled={isSpeaking}
                  className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-5 py-2.5 rounded-xl text-xs flex items-center gap-2 transition-all shadow-md disabled:opacity-50"
                >
                  <Volume2 className={`w-4 h-4 ${isSpeaking ? 'animate-bounce' : ''}`} />
                  {isSpeaking ? 'Synthesizing...' : 'Ask AI Voice'}
                </button>
              </div>
            </div>

            {voiceResponse && (
              <div className="bg-emerald-950/60 border border-emerald-500/50 p-5 rounded-xl space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                  <Bot className="w-4 h-4" /> AGRIWISE AI Voice Response (Audio & Text):
                </div>
                <p className="text-sm text-emerald-100 font-medium leading-relaxed">
                  "{voiceResponse}"
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add Device Modal */}
      {showAddDeviceModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Register New IoT Sensor Node
              </h3>
              <button
                onClick={() => setShowAddDeviceModal(false)}
                className="text-slate-400 hover:text-slate-600 text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateDevice} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Device Identifier Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Field C Soil Probe #2"
                  value={newDeviceName}
                  onChange={(e) => setNewDeviceName(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Device Hardware Type
                </label>
                <select
                  value={newDeviceType}
                  onChange={(e) => setNewDeviceType(e.target.value as any)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                >
                  <option value="Soil Sensor Node">Soil Sensor Node (Moisture/NPK)</option>
                  <option value="Weather Station">Weather Station</option>
                  <option value="Smart Irrigation Controller">Smart Irrigation Solenoid</option>
                  <option value="Greenhouse Controller">Greenhouse Controller</option>
                  <option value="Livestock Collar Tag">Livestock Collar Tag</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  LoRaWAN DevEUI / MAC Address
                </label>
                <input
                  type="text"
                  placeholder="e.g. 70-B3-D5-7E-00-11-22-33"
                  value={newDeviceMac}
                  onChange={(e) => setNewDeviceMac(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddDeviceModal(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold"
                >
                  Register Node
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
