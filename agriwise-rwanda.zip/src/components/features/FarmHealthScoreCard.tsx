import React from 'react';
import { FarmHealthScoreBreakdown, Language } from '../../types';
import { Award, CheckCircle2, AlertTriangle, ArrowUpRight, ShieldCheck, Sprout, Layers, HeartPulse, FileCheck, Activity } from 'lucide-react';

interface FarmHealthScoreCardProps {
  healthScore: FarmHealthScoreBreakdown;
  language: Language;
}

export const FarmHealthScoreCard: React.FC<FarmHealthScoreCardProps> = ({
  healthScore,
  language,
}) => {
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-400 bg-emerald-950/80 border-emerald-500/50';
    if (score >= 60) return 'text-amber-400 bg-amber-950/80 border-amber-500/50';
    return 'text-rose-400 bg-rose-950/80 border-rose-500/50';
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6 shadow-xl relative overflow-hidden">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-4 border-b border-slate-800">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <Award className="w-6 h-6 text-emerald-400" />
            <h2 className="text-xl font-bold text-slate-100">
              {language === 'rw' ? 'Amanota y\'Ubuzima bw\'Isambu (AI Health Score)' : 'AI Farm Health Score Index'}
            </h2>
          </div>
          <p className="text-xs text-slate-400">
            {language === 'rw'
              ? 'Ubusesenguzi bukorwa na AI hakoreshejwe inyandiko z\'imirimo, ubutaka, imbuto n\'amatungo.'
              : 'Evaluated continuously via soil data, activity compliance, crop vitality, and vet records.'}
          </p>
        </div>

        {/* Big Circular Score */}
        <div className="flex items-center space-x-4">
          <div className={`p-4 rounded-2xl border-2 flex flex-col items-center justify-center min-w-[110px] ${getScoreColor(healthScore.overallScore)}`}>
            <span className="text-3xl font-extrabold tracking-tight">{healthScore.overallScore}%</span>
            <span className="text-[10px] font-bold uppercase tracking-wider mt-0.5">Overall Health</span>
          </div>
        </div>
      </div>

      {/* Sub-Metric Bar Charts */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium flex items-center space-x-1">
              <Sprout className="w-3.5 h-3.5 text-emerald-400" />
              <span>Crop Vitality</span>
            </span>
            <span className="font-bold text-emerald-400">{healthScore.cropVitalityScore}%</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-emerald-500 h-full rounded-full transition-all duration-500" style={{ width: `${healthScore.cropVitalityScore}%` }} />
          </div>
        </div>

        <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium flex items-center space-x-1">
              <Layers className="w-3.5 h-3.5 text-amber-400" />
              <span>Soil Organic</span>
            </span>
            <span className="font-bold text-amber-400">{healthScore.soilHealthScore}%</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-amber-500 h-full rounded-full transition-all duration-500" style={{ width: `${healthScore.soilHealthScore}%` }} />
          </div>
        </div>

        <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium flex items-center space-x-1">
              <HeartPulse className="w-3.5 h-3.5 text-rose-400" />
              <span>Livestock Care</span>
            </span>
            <span className="font-bold text-rose-400">{healthScore.livestockCareScore}%</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-rose-500 h-full rounded-full transition-all duration-500" style={{ width: `${healthScore.livestockCareScore}%` }} />
          </div>
        </div>

        <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium flex items-center space-x-1">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span>Activity Log</span>
            </span>
            <span className="font-bold text-cyan-400">{healthScore.activityComplianceScore}%</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-cyan-500 h-full rounded-full transition-all duration-500" style={{ width: `${healthScore.activityComplianceScore}%` }} />
          </div>
        </div>

        <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium flex items-center space-x-1">
              <FileCheck className="w-3.5 h-3.5 text-indigo-400" />
              <span>Documents Vault</span>
            </span>
            <span className="font-bold text-indigo-400">{healthScore.documentCompletenessScore}%</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-indigo-500 h-full rounded-full transition-all duration-500" style={{ width: `${healthScore.documentCompletenessScore}%` }} />
          </div>
        </div>
      </div>

      {/* Strengths & Recommendations Columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
        {/* Strengths */}
        <div className="p-4 bg-emerald-950/30 border border-emerald-800/40 rounded-xl space-y-3">
          <h3 className="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{language === 'rw' ? 'Ibyiza n\'Inyungu z\'Isambu (Farm Strengths)' : 'Farm Strengths & High Performers'}</span>
          </h3>
          <ul className="space-y-2 text-xs text-slate-200">
            {healthScore.strengths.map((str, idx) => (
              <li key={idx} className="flex items-start space-x-2">
                <span className="text-emerald-400 font-bold">•</span>
                <span>{str[language] || str.en}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* AI Recommendations */}
        <div className="p-4 bg-amber-950/30 border border-amber-800/40 rounded-xl space-y-3">
          <h3 className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>{language === 'rw' ? 'Ibyagufasha Kuzamura Amanota (Recommendations)' : 'Actionable AI Health Boosters'}</span>
          </h3>
          <ul className="space-y-2 text-xs text-slate-200">
            {healthScore.recommendations.map((rec, idx) => (
              <li key={idx} className="flex items-start space-x-2">
                <ArrowUpRight className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span>{rec[language] || rec.en}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};
