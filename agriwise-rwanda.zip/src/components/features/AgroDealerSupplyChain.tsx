import React, { useState, useEffect } from 'react';
import {
  Product,
  Category,
  InventoryMovement,
  AgroDealerProfile,
  AgroInputProduct,
  AgroInputOrder,
  SupplyChainStockAlert,
  User,
  Language,
  SaleDoc,
  SaleItemDoc
} from '../../types';
import {
  getProductsDoc,
  getCategoriesDoc,
  archiveProductDoc,
  getInventoryMovementsDoc,
  getSalesDoc,
  getSaleItemsDoc,
  cancelSaleTransaction
} from '../../services/firestoreService';
import { CategoryManagerModal } from '../inventory/CategoryManagerModal';
import { ProductFormModal } from '../inventory/ProductFormModal';
import { StockOperationModal } from '../inventory/StockOperationModal';
import { POSSaleModal } from '../sales/POSSaleModal';
import { CustomerManagerModal } from '../sales/CustomerManagerModal';
import { ReceiptModal } from '../sales/ReceiptModal';
import {
  SAMPLE_AGRO_DEALERS,
  SAMPLE_INPUT_PRODUCTS,
  SAMPLE_INPUT_ORDERS,
  SAMPLE_STOCK_ALERTS
} from '../../data/mockAgroDealerData';
import { translations } from '../../data/translations';
import {
  Store,
  Package,
  ShoppingCart,
  Truck,
  AlertTriangle,
  Sparkles,
  Plus,
  Search,
  CheckCircle2,
  ShieldCheck,
  DollarSign,
  Layers,
  Star,
  Clock,
  Filter,
  ArrowRight,
  ChevronRight,
  Info,
  Calendar,
  Building2,
  Tag,
  RefreshCw,
  Box,
  Edit,
  Trash2,
  History,
  FolderPlus,
  Users,
  Receipt,
  FileText,
  Ban,
  Printer,
  CreditCard,
  UserCheck
} from 'lucide-react';

interface AgroDealerSupplyChainProps {
  currentUser: User;
  language: Language;
  onInitiateMomoPayment: (amountRwf: number, title: string) => void;
}

export const AgroDealerSupplyChain: React.FC<AgroDealerSupplyChainProps> = ({
  currentUser,
  language,
  onInitiateMomoPayment,
}) => {
  const t = translations[language];

  // Active Dealer Profile
  const [dealer, setDealer] = useState<AgroDealerProfile>(SAMPLE_AGRO_DEALERS[0]);
  const [activeTab, setActiveTab] = useState<'inventory' | 'sales' | 'marketplace' | 'orders' | 'alerts' | 'ai_advisor'>('inventory');

  // Firestore Datasets
  const [firestoreProducts, setFirestoreProducts] = useState<Product[]>([]);
  const [firestoreCategories, setFirestoreCategories] = useState<Category[]>([]);
  const [movements, setMovements] = useState<InventoryMovement[]>([]);
  const [firestoreSales, setFirestoreSales] = useState<SaleDoc[]>([]);
  const [loadingFirestore, setLoadingFirestore] = useState(false);
  const [loadingSales, setLoadingSales] = useState(false);

  // Sub-tabs & Modals
  const [stockSubTab, setStockSubTab] = useState<'catalog' | 'audit_logs'>('catalog');
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showStockModal, setShowStockModal] = useState(false);
  const [selectedStockProduct, setSelectedStockProduct] = useState<Product | null>(null);

  // Sales & POS Modals
  const [showPOSModal, setShowPOSModal] = useState(false);
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [viewingReceiptSale, setViewingReceiptSale] = useState<SaleDoc | null>(null);
  const [viewingReceiptItems, setViewingReceiptItems] = useState<SaleItemDoc[]>([]);
  const [showReceiptModal, setShowReceiptModal] = useState(false);
  const [saleFilterStatus, setSaleFilterStatus] = useState<string>('all');
  const [cancellingSale, setCancellingSale] = useState<SaleDoc | null>(null);
  const [cancelReason, setCancelReason] = useState<string>('');
  const [cancelProcessing, setCancelProcessing] = useState<boolean>(false);

  const businessId = currentUser?.businessId;

  const loadFirestoreCatalog = async () => {
    if (!businessId) return;
    setLoadingFirestore(true);
    try {
      const [prods, cats, movs] = await Promise.all([
        getProductsDoc(businessId),
        getCategoriesDoc(businessId),
        getInventoryMovementsDoc(businessId)
      ]);
      setFirestoreProducts(prods);
      setFirestoreCategories(cats);
      setMovements(movs);
    } catch (err) {
      console.error('Error loading Firestore products:', err);
    } finally {
      setLoadingFirestore(false);
    }
  };

  const loadFirestoreSales = async () => {
    if (!businessId) return;
    setLoadingSales(true);
    try {
      const salesList = await getSalesDoc(businessId);
      setFirestoreSales(salesList);
    } catch (err) {
      console.error('Error loading Firestore sales:', err);
    } finally {
      setLoadingSales(false);
    }
  };

  useEffect(() => {
    if (businessId) {
      loadFirestoreCatalog();
      loadFirestoreSales();
    }
  }, [businessId]);

  const handleOpenReceipt = async (sale: SaleDoc) => {
    try {
      const items = await getSaleItemsDoc(sale.saleId, sale.businessId);
      setViewingReceiptSale(sale);
      setViewingReceiptItems(items);
      setShowReceiptModal(true);
    } catch (e) {
      console.error('Failed to load sale receipt items:', e);
    }
  };

  const handleConfirmCancelSale = async () => {
    if (!cancellingSale || !businessId || !cancelReason.trim()) return;
    setCancelProcessing(true);
    try {
      await cancelSaleTransaction({
        saleId: cancellingSale.saleId,
        businessId,
        cancelledByUid: currentUser.uid,
        cancelledByName: currentUser.name || 'Store Staff',
        reason: cancelReason.trim(),
      });
      setCancellingSale(null);
      setCancelReason('');
      await Promise.all([loadFirestoreCatalog(), loadFirestoreSales()]);
    } catch (err: any) {
      console.error('Failed to cancel sale:', err);
      alert(err.message || 'Failed to cancel sale transaction.');
    } finally {
      setCancelProcessing(false);
    }
  };

  // Datasets
  const [products, setProducts] = useState<AgroInputProduct[]>(SAMPLE_INPUT_PRODUCTS);
  const [orders, setOrders] = useState<AgroInputOrder[]>(SAMPLE_INPUT_ORDERS);
  const [alerts, setAlerts] = useState<SupplyChainStockAlert[]>(SAMPLE_STOCK_ALERTS);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // Shopping Cart State
  const [cart, setCart] = useState<{ product: AgroInputProduct; qty: number }[]>([]);
  const [showCartDrawer, setShowCartDrawer] = useState(false);

  // Add Product Modal
  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState<AgroInputProduct['category']>('Fertilizers');
  const [newProdBrand, setNewProdBrand] = useState('YaraMila');
  const [newProdPrice, setNewProdPrice] = useState(45000);
  const [newProdUnit, setNewProdUnit] = useState('50kg Bag');
  const [newProdStock, setNewProdStock] = useState(100);
  const [newProdExpiry, setNewProdExpiry] = useState('2028-06-30');

  // AI Recommendation State
  const [aiCrop, setAiCrop] = useState('Hybrid Maize');
  const [aiHectares, setAiHectares] = useState(2.0);
  const [aiDistrict, setAiDistrict] = useState('Nyagatare');
  const [aiSoil, setAiSoil] = useState('Clay-Loam');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiRecommendation, setAiRecommendation] = useState<any>(null);

  const fetchAiInputRecommendation = async () => {
    setAiLoading(true);
    try {
      const res = await fetch('/api/ai/input-recommendation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          crop: aiCrop,
          hectares: aiHectares,
          district: aiDistrict,
          soilType: aiSoil,
          language
        }),
      });
      const data = await res.json();
      setAiRecommendation(data);
    } catch (e) {
      console.error(e);
    } finally {
      setAiLoading(false);
    }
  };

  useEffect(() => {
    fetchAiInputRecommendation();
  }, [language]);

  // Handlers
  const handleAddToCart = (product: AgroInputProduct) => {
    const existing = cart.find(c => c.product.id === product.id);
    if (existing) {
      setCart(cart.map(c => c.product.id === product.id ? { ...c, qty: c.qty + 1 } : c));
    } else {
      setCart([...cart, { product, qty: 1 }]);
    }
  };

  const cartTotalAmount = cart.reduce((acc, c) => acc + c.product.pricePerUnitRwf * c.qty, 0);

  const handleCheckoutCart = () => {
    if (cart.length === 0) return;
    onInitiateMomoPayment(cartTotalAmount, `Farm Input Order (${cart.length} item types)`);
    
    // Log Order
    const newOrd: AgroInputOrder = {
      id: `ord-${Date.now().toString().slice(-4)}`,
      orderNumber: `AGRI-ORD-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      dealerId: dealer.id,
      dealerName: dealer.businessName,
      buyerName: currentUser.name || 'Smallholder Farmer',
      buyerPhone: '+250 788 111 222',
      buyerDistrict: dealer.district,
      items: cart.map(c => ({
        productId: c.product.id,
        productName: c.product.name,
        quantity: c.qty,
        unitPriceRwf: c.product.pricePerUnitRwf,
        totalRwf: c.product.pricePerUnitRwf * c.qty
      })),
      totalAmountRwf: cartTotalAmount,
      paymentStatus: 'MoMo Escrow Secured',
      deliveryMethod: 'Pickup at Agro-dealer Hub',
      deliveryStatus: 'Processing',
      createdAt: 'Just now'
    };

    setOrders([newOrd, ...orders]);
    setCart([]);
    setShowCartDrawer(false);
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const newProd: AgroInputProduct = {
      id: `prod-${Date.now().toString().slice(-4)}`,
      dealerId: dealer.id,
      dealerName: dealer.businessName,
      name: newProdName,
      category: newProdCategory,
      subcategory: newProdCategory,
      brand: newProdBrand,
      manufacturer: 'MINAGRI / RAB Certified Supplier',
      description: 'High-quality RAB certified agricultural input for optimum yield.',
      pricePerUnitRwf: Number(newProdPrice),
      unit: newProdUnit,
      stockQuantity: Number(newProdStock),
      reorderLevel: 20,
      expiryDate: newProdExpiry,
      rabApproved: true,
      rabCertificateNumber: `RAB-INPUT-${Math.floor(100 + Math.random() * 900)}`,
      storageCondition: 'Cool ventilated dry warehouse',
      recommendedCrops: ['Maize', 'Potatoes', 'Beans'],
      imageUrl: 'https://images.unsplash.com/photo-1628352081506-83c43123ed6d?auto=format&fit=crop&w=600&q=80'
    };

    setProducts([newProd, ...products]);
    setShowAddProductModal(false);
    setNewProdName('');
  };

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.brand.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* Enterprise Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden text-white">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center space-x-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold mb-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>RAB Licensed Certified Agro-dealer Hub</span>
            </div>

            <div className="flex items-center space-x-3">
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                {dealer.businessName}
              </h1>
              <span className="bg-slate-800 text-slate-300 border border-slate-700 text-xs px-2.5 py-1 rounded-lg font-mono">
                {dealer.registrationNumber}
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-400 max-w-3xl mt-1">
              Owner: <strong className="text-white">{dealer.ownerName}</strong> • District: <strong className="text-emerald-300">{dealer.district}</strong> ({dealer.sector}) • Contact: <strong className="text-teal-300">{dealer.phone}</strong>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setShowPOSModal(true)}
              className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-500/20 flex items-center space-x-1.5 transition-all"
            >
              <ShoppingCart className="w-4 h-4 text-slate-950" />
              <span>New POS Sale</span>
            </button>

            <button
              onClick={() => setShowCustomerModal(true)}
              className="bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 font-bold text-xs px-3.5 py-2.5 rounded-xl flex items-center space-x-1.5 transition-all"
            >
              <Users className="w-4 h-4 text-emerald-400" />
              <span>Customers CRM</span>
            </button>

            <button
              onClick={() => setShowCategoryModal(true)}
              className="bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 font-bold text-xs px-3.5 py-2.5 rounded-xl flex items-center space-x-1.5 transition-all"
            >
              <FolderPlus className="w-4 h-4 text-emerald-400" />
              <span>Manage Categories</span>
            </button>

            <button
              onClick={() => {
                setEditingProduct(null);
                setShowProductModal(true);
              }}
              className="bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 font-bold text-xs px-3.5 py-2.5 rounded-xl shadow flex items-center space-x-1.5 transition-all"
            >
              <Plus className="w-4 h-4 text-emerald-400" />
              <span>Add SKU</span>
            </button>

            <button
              onClick={() => setShowCartDrawer(true)}
              className="bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 font-bold text-xs px-3.5 py-2.5 rounded-xl flex items-center space-x-1.5 relative"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>Shop Cart ({cart.reduce((acc, c) => acc + c.qty, 0)})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Module Navigation Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2 flex flex-wrap items-center gap-2 text-xs">
        <button
          onClick={() => setActiveTab('inventory')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'inventory'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Box className="w-4 h-4" />
          <span>POS Stock Telemetry ({businessId ? firestoreProducts.length : products.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('sales')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'sales'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Receipt className="w-4 h-4 text-emerald-300" />
          <span>Sales & POS Receipts ({firestoreSales.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('marketplace')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'marketplace'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Store className="w-4 h-4" />
          <span>Farmer Input Shop</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'orders'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Truck className="w-4 h-4 text-blue-400" />
          <span>Fulfillment & Dispatch ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('alerts')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'alerts'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <AlertTriangle className="w-4 h-4 text-amber-300" />
          <span>Stock Alerts ({alerts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('ai_advisor')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'ai_advisor'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>AI Input Recommendation</span>
        </button>
      </div>

      {/* TAB 1: POS INVENTORY & STOCK TELEMETRY */}
      {activeTab === 'inventory' && (
        <div className="space-y-6">
          
          {/* Key Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Total Stock Value</span>
                <DollarSign className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-emerald-400 font-mono">
                {businessId
                  ? firestoreProducts.reduce((acc, p) => acc + (p.sellingPrice * p.quantity), 0).toLocaleString() + ' RWF'
                  : (dealer.totalStockValueRwf / 1000000).toFixed(1) + 'M RWF'
                }
              </div>
              <p className="text-[11px] text-slate-400 font-medium">
                {businessId ? `${firestoreProducts.length} Active SKUs` : `${dealer.totalInventoryItems} Certified Stock SKUs`}
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Total Inventory Items</span>
                <Box className="w-4 h-4 text-teal-400" />
              </div>
              <div className="text-2xl font-black text-white font-mono">
                {businessId
                  ? firestoreProducts.reduce((acc, p) => acc + p.quantity, 0).toLocaleString()
                  : dealer.totalInventoryItems
                } Units
              </div>
              <p className="text-[11px] text-teal-300 font-medium">Real-time Firestore State</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Active Categories</span>
                <Tag className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl font-black text-amber-300">
                {businessId ? firestoreCategories.length : 6} Categories
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Multi-tenant Isolation</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Stock Reorder Alerts</span>
                <AlertTriangle className="w-4 h-4 text-rose-400" />
              </div>
              <div className="text-2xl font-black text-rose-400">
                {businessId
                  ? firestoreProducts.filter(p => p.quantity <= p.minimumStockLevel).length
                  : alerts.length
                } Items
              </div>
              <p className="text-[11px] text-rose-300 font-medium">Below Alert Level</p>
            </div>
          </div>

          {/* Sub-tab Navigation: Catalog vs Audit Logs */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setStockSubTab('catalog')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                    stockSubTab === 'catalog'
                      ? 'bg-emerald-600 text-white shadow'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Product Catalog ({businessId ? firestoreProducts.length : products.length})
                </button>

                <button
                  onClick={() => setStockSubTab('audit_logs')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition ${
                    stockSubTab === 'audit_logs'
                      ? 'bg-emerald-600 text-white shadow'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <History className="w-3.5 h-3.5" />
                  <span>Stock Audit Trail ({movements.length})</span>
                </button>
              </div>

              {stockSubTab === 'catalog' && (
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Search stock SKU..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* TAB CONTENT: CATALOG */}
            {stockSubTab === 'catalog' && (
              <>
                {businessId ? (
                  /* Firestore Business Product Catalog */
                  firestoreProducts.filter(p => {
                    if (!searchQuery) return true;
                    const q = searchQuery.toLowerCase();
                    return p.name.toLowerCase().includes(q) || (p.sku && p.sku.toLowerCase().includes(q)) || p.categoryName.toLowerCase().includes(q);
                  }).length === 0 ? (
                    <div className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-10 text-center space-y-4">
                      <div className="w-12 h-12 bg-slate-800 text-slate-400 rounded-2xl flex items-center justify-center mx-auto border border-slate-700">
                        <Box className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">No Products in Catalog</h4>
                        <p className="text-xs text-slate-400 max-w-md mx-auto mt-1">
                          Your business production inventory is currently empty. Create your first product SKU or seed recommended categories to start tracking stock.
                        </p>
                      </div>
                      <div className="flex items-center justify-center space-x-3 pt-2">
                        <button
                          onClick={() => setShowCategoryModal(true)}
                          className="bg-slate-800 hover:bg-slate-700 text-emerald-300 font-bold text-xs px-4 py-2 rounded-xl border border-slate-700 flex items-center space-x-1.5 transition"
                        >
                          <FolderPlus className="w-4 h-4 text-emerald-400" />
                          <span>Manage Categories</span>
                        </button>
                        <button
                          onClick={() => {
                            setEditingProduct(null);
                            setShowProductModal(true);
                          }}
                          className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2 rounded-xl flex items-center space-x-1.5 transition shadow"
                        >
                          <Plus className="w-4 h-4" />
                          <span>Add Product SKU</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs text-slate-300">
                        <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase text-[10px]">
                          <tr>
                            <th className="p-3">Product / SKU</th>
                            <th className="p-3">Category</th>
                            <th className="p-3">Selling Price</th>
                            <th className="p-3">Cost Price</th>
                            <th className="p-3">In Stock</th>
                            <th className="p-3">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800">
                          {firestoreProducts
                            .filter(p => {
                              if (!searchQuery) return true;
                              const q = searchQuery.toLowerCase();
                              return p.name.toLowerCase().includes(q) || (p.sku && p.sku.toLowerCase().includes(q)) || p.categoryName.toLowerCase().includes(q);
                            })
                            .map((p) => (
                              <tr key={p.productId} className="hover:bg-slate-800/40">
                                <td className="p-3 font-bold text-white">
                                  <div>
                                    <span>{p.name}</span>
                                    <span className="text-[10px] text-slate-400 block font-mono">
                                      SKU: {p.sku || 'N/A'}
                                    </span>
                                  </div>
                                </td>
                                <td className="p-3 text-slate-300">
                                  <span className="bg-slate-800 border border-slate-700 text-slate-300 px-2 py-0.5 rounded-lg text-[10px]">
                                    {p.categoryName}
                                  </span>
                                </td>
                                <td className="p-3 font-black text-emerald-400 font-mono">
                                  {p.sellingPrice.toLocaleString()} RWF / {p.unit}
                                </td>
                                <td className="p-3 font-mono text-slate-400">
                                  {p.costPrice.toLocaleString()} RWF
                                </td>
                                <td className="p-3 font-bold">
                                  <span
                                    className={`px-2.5 py-1 rounded-full text-[11px] font-mono border ${
                                      p.quantity <= p.minimumStockLevel
                                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/30 font-black'
                                        : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'
                                    }`}
                                  >
                                    {p.quantity} {p.unit}
                                  </span>
                                </td>
                                <td className="p-3">
                                  <div className="flex items-center space-x-1.5">
                                    <button
                                      onClick={() => {
                                        setSelectedStockProduct(p);
                                        setShowStockModal(true);
                                      }}
                                      className="bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 border border-emerald-500/30 font-bold px-2.5 py-1 rounded-lg text-[10px] flex items-center space-x-1"
                                      title="Stock Operation"
                                    >
                                      <RefreshCw className="w-3 h-3" />
                                      <span>Stock Action</span>
                                    </button>

                                    <button
                                      onClick={() => {
                                        setEditingProduct(p);
                                        setShowProductModal(true);
                                      }}
                                      className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
                                      title="Edit SKU"
                                    >
                                      <Edit className="w-3.5 h-3.5" />
                                    </button>

                                    <button
                                      onClick={async () => {
                                        if (window.confirm(`Archive product "${p.name}"?`)) {
                                          await archiveProductDoc({
                                            productId: p.productId,
                                            businessId: businessId || '',
                                            updatedByUid: currentUser.uid,
                                            updatedByName: currentUser.name,
                                          });
                                          loadFirestoreCatalog();
                                        }
                                      }}
                                      className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition"
                                      title="Archive SKU"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                        </tbody>
                      </table>
                    </div>
                  )
                ) : (
                  /* Demo Fallback Table */
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs text-slate-300">
                      <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase text-[10px]">
                        <tr>
                          <th className="p-3">Product Name</th>
                          <th className="p-3">Category</th>
                          <th className="p-3">Unit Price</th>
                          <th className="p-3">In Stock</th>
                          <th className="p-3">RAB Approval</th>
                          <th className="p-3">Expiry Date</th>
                          <th className="p-3">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800">
                        {filteredProducts.map((p) => (
                          <tr key={p.id} className="hover:bg-slate-800/40">
                            <td className="p-3 font-bold text-white">
                              <div className="flex items-center space-x-2">
                                <img src={p.imageUrl} alt={p.name} className="w-8 h-8 rounded-lg object-cover" />
                                <div>
                                  <span>{p.name}</span>
                                  <span className="text-[10px] text-slate-400 block font-mono">{p.brand}</span>
                                </div>
                              </div>
                            </td>
                            <td className="p-3 text-slate-300">{p.category}</td>
                            <td className="p-3 font-black text-amber-300">{p.pricePerUnitRwf.toLocaleString()} RWF / {p.unit}</td>
                            <td className="p-3 font-bold">
                              <span className={`px-2 py-0.5 rounded-full ${
                                p.stockQuantity <= p.reorderLevel ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' : 'text-emerald-300'
                              }`}>
                                {p.stockQuantity} units
                              </span>
                            </td>
                            <td className="p-3">
                              {p.rabApproved ? (
                                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center space-x-1 w-fit">
                                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                                  <span>RAB Certified</span>
                                </span>
                              ) : (
                                <span className="text-slate-500">Standard</span>
                              )}
                            </td>
                            <td className="p-3 font-mono text-slate-400">{p.expiryDate}</td>
                            <td className="p-3">
                              <button
                                onClick={() => handleAddToCart(p)}
                                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1 rounded-lg text-[10px]"
                              >
                                + Add Cart
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}

            {/* TAB CONTENT: AUDIT LOGS */}
            {stockSubTab === 'audit_logs' && (
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Inventory Movements Audit Trail
                </h4>
                {movements.length === 0 ? (
                  <div className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-8 text-center text-slate-400 text-xs">
                    No inventory movements recorded yet. Stock deposits, sales, or adjustments will automatically generate an immutable audit log.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs text-slate-300">
                      <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase text-[10px]">
                        <tr>
                          <th className="p-3">Date / Time</th>
                          <th className="p-3">Type</th>
                          <th className="p-3">Quantity Delta</th>
                          <th className="p-3">Stock After</th>
                          <th className="p-3">Reason / Notes</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800 font-mono">
                        {movements.map((m) => (
                          <tr key={m.movementId} className="hover:bg-slate-800/40">
                            <td className="p-3 text-slate-400">
                              {new Date(m.createdAt).toLocaleString()}
                            </td>
                            <td className="p-3 font-bold">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] ${
                                  m.type === 'STOCK_IN'
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                    : m.type === 'ADJUSTMENT'
                                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                }`}
                              >
                                {m.type}
                              </span>
                            </td>
                            <td className="p-3 font-bold">
                              <span className={m.quantity >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                                {m.quantity >= 0 ? `+${m.quantity}` : m.quantity}
                              </span>
                            </td>
                            <td className="p-3 font-bold text-white">
                              {m.balanceAfter}
                            </td>
                            <td className="p-3 text-slate-300 font-sans">
                              {m.reason}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB: POS SALES & RECEIPTS LEDGER */}
      {activeTab === 'sales' && (
        <div className="space-y-6">
          {/* Sales KPIs Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Total POS Revenue</span>
                <DollarSign className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-emerald-400 font-mono">
                {firestoreSales
                  .filter(s => s.status === 'completed')
                  .reduce((acc, s) => acc + s.total, 0)
                  .toLocaleString()} RWF
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Authoritative Firestore Sales</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Completed Sales</span>
                <Receipt className="w-4 h-4 text-teal-400" />
              </div>
              <div className="text-2xl font-black text-white font-mono">
                {firestoreSales.filter(s => s.status === 'completed').length} Transactions
              </div>
              <p className="text-[11px] text-teal-300 font-medium">Atomic stock deductions</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Cancelled / Refunded</span>
                <Ban className="w-4 h-4 text-rose-400" />
              </div>
              <div className="text-2xl font-black text-rose-400">
                {firestoreSales.filter(s => s.status === 'cancelled').length} Sales
              </div>
              <p className="text-[11px] text-rose-300 font-medium">Stock auto-restored</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Quick Actions</span>
                <ShoppingCart className="w-4 h-4 text-amber-400" />
              </div>
              <div className="pt-1 flex space-x-2">
                <button
                  onClick={() => setShowPOSModal(true)}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2 rounded-xl flex items-center justify-center space-x-1 transition shadow"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>New Sale</span>
                </button>
                <button
                  onClick={() => setShowCustomerModal(true)}
                  className="bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 font-bold text-xs px-3 py-2 rounded-xl flex items-center justify-center transition"
                  title="Manage Customers"
                >
                  <Users className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Sales Transaction History Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-black flex items-center space-x-2">
                  <Receipt className="w-5 h-5 text-emerald-400" />
                  <span>Sales & POS Transactions Ledger</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Real-time sales invoices, atomic inventory deductions, customer assignments & printable receipts.
                </p>
              </div>

              {/* Status Filters */}
              <div className="flex items-center space-x-2 text-xs">
                <button
                  onClick={() => setSaleFilterStatus('all')}
                  className={`px-3 py-1.5 rounded-xl font-bold transition ${
                    saleFilterStatus === 'all' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  All ({firestoreSales.length})
                </button>
                <button
                  onClick={() => setSaleFilterStatus('completed')}
                  className={`px-3 py-1.5 rounded-xl font-bold transition ${
                    saleFilterStatus === 'completed' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Completed ({firestoreSales.filter(s => s.status === 'completed').length})
                </button>
                <button
                  onClick={() => setSaleFilterStatus('cancelled')}
                  className={`px-3 py-1.5 rounded-xl font-bold transition ${
                    saleFilterStatus === 'cancelled' ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Cancelled ({firestoreSales.filter(s => s.status === 'cancelled').length})
                </button>
              </div>
            </div>

            {loadingSales ? (
              <div className="flex items-center justify-center p-12 text-slate-400 text-xs">
                <RefreshCw className="w-5 h-5 animate-spin mr-2" />
                <span>Loading sales ledger...</span>
              </div>
            ) : firestoreSales.filter(s => saleFilterStatus === 'all' || s.status === saleFilterStatus).length === 0 ? (
              <div className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-10 text-center space-y-4">
                <div className="w-12 h-12 bg-slate-800 text-slate-400 rounded-2xl flex items-center justify-center mx-auto border border-slate-700">
                  <Receipt className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">No Sales Invoices Recorded</h4>
                  <p className="text-xs text-slate-400 max-w-md mx-auto mt-1">
                    Execute your first atomic POS transaction to log customer sales, generate printable receipts, and update stock counts automatically.
                  </p>
                </div>
                <button
                  onClick={() => setShowPOSModal(true)}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-5 py-2.5 rounded-xl inline-flex items-center space-x-1.5 transition shadow"
                >
                  <Plus className="w-4 h-4" />
                  <span>Launch POS Checkout</span>
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase text-[10px]">
                    <tr>
                      <th className="p-3">Receipt No.</th>
                      <th className="p-3">Customer</th>
                      <th className="p-3">Date & Time</th>
                      <th className="p-3">Payment Method</th>
                      <th className="p-3">Total Amount</th>
                      <th className="p-3">Status</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {firestoreSales
                      .filter(s => saleFilterStatus === 'all' || s.status === saleFilterStatus)
                      .map((sale) => (
                        <tr key={sale.saleId} className="hover:bg-slate-800/40 transition">
                          <td className="p-3 font-mono font-bold text-amber-400">
                            {sale.saleNumber}
                          </td>
                          <td className="p-3 font-medium text-white">
                            <div className="flex items-center space-x-1.5">
                              <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                              <span>{sale.customerName || 'Walk-in Customer'}</span>
                            </div>
                          </td>
                          <td className="p-3 text-slate-400">
                            {new Date(sale.createdAt).toLocaleString('en-GB', { dateStyle: 'short', timeStyle: 'short' })}
                          </td>
                          <td className="p-3 text-slate-300">
                            <span className="bg-slate-800 border border-slate-700 px-2 py-0.5 rounded-md text-[11px] font-mono">
                              {sale.paymentMethod}
                            </span>
                          </td>
                          <td className="p-3 font-black text-emerald-400 font-mono text-sm">
                            {sale.total.toLocaleString()} RWF
                          </td>
                          <td className="p-3">
                            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                              sale.status === 'completed'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            }`}>
                              {sale.status}
                            </span>
                          </td>
                          <td className="p-3 text-right space-x-2">
                            <button
                              onClick={() => handleOpenReceipt(sale)}
                              className="bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 font-bold px-2.5 py-1 rounded-lg text-[11px] inline-flex items-center space-x-1 transition"
                            >
                              <Printer className="w-3 h-3" />
                              <span>Receipt</span>
                            </button>
                            {sale.status === 'completed' && (
                              <button
                                onClick={() => setCancellingSale(sale)}
                                className="bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold px-2 py-1 rounded-lg text-[11px] inline-flex items-center space-x-1 transition"
                                title="Void Sale & Restore Stock"
                              >
                                <Ban className="w-3 h-3" />
                                <span>Void</span>
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: FARMER INPUT SHOPPING MARKETPLACE */}
      {activeTab === 'marketplace' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-black">Certified Farm Input Storefront</h3>
                <p className="text-xs text-slate-400">
                  Buy high-germination hybrid seeds, inorganic fertilizers, crop protection chemicals, and tools directly with MoMo Escrow protection.
                </p>
              </div>

              {/* Category Pills */}
              <div className="flex flex-wrap items-center gap-1.5 text-xs">
                {['All', 'Seeds', 'Fertilizers', 'Crop Protection', 'Livestock Feed & Pharma', 'Farm Tools & Equipment'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                      selectedCategory === cat ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Input Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((p) => (
                <div key={p.id} className="bg-slate-800 border border-slate-700 rounded-3xl overflow-hidden shadow-lg flex flex-col justify-between group hover:border-emerald-500/50 transition-all">
                  <div>
                    <div className="relative h-44 overflow-hidden">
                      <img src={p.imageUrl} alt={p.name} className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300" />
                      {p.rabApproved && (
                        <span className="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-md text-emerald-300 border border-emerald-500/40 text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center space-x-1">
                          <ShieldCheck className="w-3 h-3 text-emerald-400" />
                          <span>RAB Certified</span>
                        </span>
                      )}
                      <span className="absolute bottom-3 right-3 bg-slate-900/90 text-amber-300 font-black text-sm px-3 py-1 rounded-xl font-mono border border-amber-500/30">
                        {p.pricePerUnitRwf.toLocaleString()} RWF
                      </span>
                    </div>

                    <div className="p-5 space-y-2">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{p.category} • {p.unit}</span>
                      <h4 className="text-sm font-black text-white leading-snug">{p.name}</h4>
                      <p className="text-xs text-slate-300 line-clamp-2">{p.description}</p>
                      
                      <div className="text-[11px] text-slate-400 pt-1 space-y-1">
                        <div>Supplier: <strong className="text-white">{p.dealerName}</strong></div>
                        <div>Storage: <span className="text-teal-300">{p.storageCondition}</span></div>
                      </div>
                    </div>
                  </div>

                  <div className="p-5 pt-0">
                    <button
                      onClick={() => handleAddToCart(p)}
                      className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2.5 rounded-xl shadow flex items-center justify-center space-x-2 transition-all"
                    >
                      <ShoppingCart className="w-4 h-4" />
                      <span>Add to Cart</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ORDERS FULFILLMENT & DISPATCH */}
      {activeTab === 'orders' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <h3 className="text-base font-black">Input Orders & Transport Dispatch Pipeline</h3>
            <p className="text-xs text-slate-400">Track incoming farmer input orders, MoMo escrow payment locks, and last-mile delivery dispatches.</p>

            <div className="space-y-3">
              {orders.map((ord) => (
                <div key={ord.id} className="bg-slate-800 border border-slate-700 rounded-2xl p-5 space-y-3 text-xs text-white">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-700 pb-2">
                    <div>
                      <span className="text-amber-400 font-mono font-bold">{ord.orderNumber}</span>
                      <h4 className="text-sm font-black text-white">{ord.buyerName} ({ord.buyerDistrict})</h4>
                    </div>

                    <div className="text-right">
                      <span className="text-base font-black text-emerald-400">{ord.totalAmountRwf.toLocaleString()} RWF</span>
                      <span className="text-[10px] text-emerald-300 block">Status: {ord.paymentStatus}</span>
                    </div>
                  </div>

                  <div className="space-y-1 text-slate-300">
                    <span className="text-slate-400 font-bold block text-[10px]">Purchased Items:</span>
                    {ord.items.map((item, i) => (
                      <div key={i} className="flex justify-between text-xs">
                        <span>{item.quantity}x {item.productName}</span>
                        <span className="font-mono text-amber-300">{item.totalRwf.toLocaleString()} RWF</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-slate-400 text-[11px]">
                    <div>
                      Delivery Method: <strong className="text-white">{ord.deliveryMethod}</strong>
                      {ord.assignedTransporter && (
                        <span className="block text-teal-300">Carrier: {ord.assignedTransporter}</span>
                      )}
                    </div>

                    <span className="bg-blue-500/20 text-blue-300 border border-blue-500/30 px-3 py-1 rounded-full font-bold w-fit">
                      Dispatch: {ord.deliveryStatus}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: STOCK ALERTS & REORDER INTELLIGENCE */}
      {activeTab === 'alerts' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <h3 className="text-base font-black">Stock Shortage & Expiry Intelligence Alerts</h3>
            <p className="text-xs text-slate-400">Automated supply chain warnings generated from regional farmer planting schedules and seed germination windows.</p>

            <div className="space-y-3">
              {alerts.map((alt) => (
                <div key={alt.id} className="bg-slate-800 border border-slate-700 rounded-2xl p-4 space-y-2 text-xs text-white">
                  <div className="flex items-center justify-between">
                    <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                      alt.alertType === 'Low Stock Reorder' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    }`}>
                      {alt.alertType}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">{alt.date}</span>
                  </div>

                  <h4 className="text-sm font-black text-white">{alt.productName}</h4>
                  <p className="text-slate-300 leading-relaxed">{alt.message}</p>

                  <div className="pt-2 flex justify-between items-center text-[11px]">
                    <span className="text-slate-400">Current Stock: <strong className="text-white">{alt.currentStock} units</strong></span>
                    {alt.recommendedReorderQty > 0 && (
                      <button className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1 rounded-lg">
                        Submit Bulk Reorder ({alt.recommendedReorderQty} units)
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: AI SMART INPUT RECOMMENDATION */}
      {activeTab === 'ai_advisor' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex items-center space-x-2 text-amber-300 font-bold text-sm">
              <Sparkles className="w-5 h-5" />
              <span>AI Agronomic Farm Input Calculator & Dosage Engine</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Gemini 3.6 Flash calculates exact seed kilogram requirements, basal DAP/NPK fertilizer dosages, top-dressing Urea timing, and certified fungicide quantities based on target crop hectares and regional soil parameters.
            </p>

            {/* Input Form */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs bg-slate-800 p-4 rounded-2xl border border-slate-700">
              <div>
                <label className="block text-slate-400 font-bold mb-1">Target Crop:</label>
                <input
                  type="text"
                  value={aiCrop}
                  onChange={(e) => setAiCrop(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">Farm Land (Ha):</label>
                <input
                  type="number"
                  step="0.5"
                  value={aiHectares}
                  onChange={(e) => setAiHectares(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">District Location:</label>
                <input
                  type="text"
                  value={aiDistrict}
                  onChange={(e) => setAiDistrict(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="flex items-end">
                <button
                  onClick={fetchAiInputRecommendation}
                  disabled={aiLoading}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 rounded-xl shadow transition-all"
                >
                  {aiLoading ? 'Calculating...' : 'Recalculate Inputs'}
                </button>
              </div>
            </div>

            {/* AI Result Card */}
            {aiRecommendation && (
              <div className="bg-slate-800 border border-emerald-500/30 rounded-3xl p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-700 pb-3">
                  <span className="text-sm font-black text-emerald-300">Recommended Agronomic Input Package</span>
                  <span className="text-xs font-bold text-amber-300">AI Confidence: {aiRecommendation.aiConfidencePct}%</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div className="bg-slate-900 p-4 rounded-2xl space-y-1">
                    <span className="text-slate-400 block font-bold">Recommended Hybrid Seed:</span>
                    <span className="text-base font-black text-white">{aiRecommendation.recommendedSeedCategory}</span>
                    <span className="text-xs font-bold text-emerald-300 block">{aiRecommendation.recommendedSeedQtyKg} Kg Required</span>
                  </div>

                  <div className="bg-slate-900 p-4 rounded-2xl space-y-1">
                    <span className="text-slate-400 block font-bold">Basal Fertilizer (Planting):</span>
                    <span className="text-base font-black text-white">{aiRecommendation.recommendedBasalFertilizer}</span>
                    <span className="text-xs font-bold text-teal-300 block">{aiRecommendation.basalFertilizerQtyKg} Kg Required</span>
                  </div>

                  <div className="bg-slate-900 p-4 rounded-2xl space-y-1">
                    <span className="text-slate-400 block font-bold">Estimated Input Package Cost:</span>
                    <span className="text-base font-black text-amber-300 font-mono">{(aiRecommendation.estimatedInputCostRwf || 245000).toLocaleString()} RWF</span>
                  </div>
                </div>

                <div className="bg-emerald-950/40 border border-emerald-500/30 p-4 rounded-2xl text-xs space-y-1">
                  <span className="text-emerald-300 font-bold block">💡 Agronomic Application Advice:</span>
                  <p className="text-slate-200 leading-relaxed">{aiRecommendation.agronomicAdvice}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SHOPPING CART DRAWER */}
      {showCartDrawer && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex justify-end">
          <div className="bg-slate-900 border-l border-slate-800 w-full max-w-md h-full p-6 text-white space-y-6 shadow-2xl flex flex-col justify-between overflow-y-auto">
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-base font-black text-white flex items-center space-x-2">
                  <ShoppingCart className="w-5 h-5 text-amber-300" />
                  <span>Farm Input Checkout Cart</span>
                </h3>
                <button onClick={() => setShowCartDrawer(false)} className="text-slate-400 hover:text-white font-bold">✕</button>
              </div>

              {cart.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs font-bold">Your cart is empty. Add products from the storefront.</div>
              ) : (
                <div className="space-y-3">
                  {cart.map((c) => (
                    <div key={c.product.id} className="bg-slate-800 border border-slate-700 p-3 rounded-2xl flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-white block">{c.product.name}</span>
                        <span className="text-[10px] text-slate-400">{c.product.unit} • {c.product.pricePerUnitRwf.toLocaleString()} RWF</span>
                      </div>

                      <div className="flex items-center space-x-2">
                        <span className="font-black text-amber-300">{c.qty}x</span>
                        <span className="font-mono text-emerald-300 font-bold">{(c.product.pricePerUnitRwf * c.qty).toLocaleString()} RWF</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {cart.length > 0 && (
              <div className="space-y-4 pt-4 border-t border-slate-800">
                <div className="flex items-center justify-between text-sm font-bold">
                  <span>Total Amount (MoMo Escrow):</span>
                  <span className="text-lg font-black text-emerald-400 font-mono">{cartTotalAmount.toLocaleString()} RWF</span>
                </div>

                <button
                  onClick={handleCheckoutCart}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-xl shadow flex items-center justify-center space-x-2 text-xs"
                >
                  <DollarSign className="w-4 h-4" />
                  <span>Pay with MTN MoMo / Airtel Money</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ADD PRODUCT MODAL */}
      {showAddProductModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white">Add Certified Stock SKU</h3>
              <button onClick={() => setShowAddProductModal(false)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <form onSubmit={handleAddProduct} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Product Name:</label>
                <input
                  type="text"
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  placeholder="e.g. Urea 46% Nitrogen Granular"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Category:</label>
                  <select
                    value={newProdCategory}
                    onChange={(e) => setNewProdCategory(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="Seeds">Seeds</option>
                    <option value="Fertilizers">Fertilizers</option>
                    <option value="Crop Protection">Crop Protection</option>
                    <option value="Livestock Feed & Pharma">Livestock Feed</option>
                    <option value="Farm Tools & Equipment">Farm Tools</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Brand Name:</label>
                  <input
                    type="text"
                    value={newProdBrand}
                    onChange={(e) => setNewProdBrand(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Unit Price (RWF):</label>
                  <input
                    type="number"
                    value={newProdPrice}
                    onChange={(e) => setNewProdPrice(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Stock Quantity:</label>
                  <input
                    type="number"
                    value={newProdStock}
                    onChange={(e) => setNewProdStock(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>
              </div>

              <div className="pt-2 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddProductModal(false)}
                  className="flex-1 bg-slate-800 text-slate-300 font-bold py-2.5 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl shadow"
                >
                  Save Stock SKU
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CATEGORY MANAGER MODAL */}
      <CategoryManagerModal
        businessId={businessId || ''}
        userId={currentUser.uid}
        isOpen={showCategoryModal}
        onClose={() => setShowCategoryModal(false)}
        onCategoryAdded={loadFirestoreCatalog}
      />

      {/* PRODUCT FORM MODAL */}
      <ProductFormModal
        businessId={businessId || ''}
        userId={currentUser.uid}
        userName={currentUser.name}
        editingProduct={editingProduct}
        isOpen={showProductModal}
        onClose={() => {
          setShowProductModal(false);
          setEditingProduct(null);
        }}
        onSuccess={loadFirestoreCatalog}
      />

      {/* STOCK OPERATION MODAL */}
      <StockOperationModal
        product={selectedStockProduct}
        businessId={businessId || ''}
        userId={currentUser.uid}
        userName={currentUser.name}
        isOpen={showStockModal}
        onClose={() => {
          setShowStockModal(false);
          setSelectedStockProduct(null);
        }}
        onSuccess={loadFirestoreCatalog}
      />

      {/* POS SALE CHECKOUT MODAL */}
      <POSSaleModal
        businessId={businessId || ''}
        userId={currentUser.uid}
        userName={currentUser.name}
        products={firestoreProducts}
        isOpen={showPOSModal}
        onClose={() => setShowPOSModal(false)}
        onSaleCompleted={async (sale, items) => {
          await Promise.all([loadFirestoreCatalog(), loadFirestoreSales()]);
          setViewingReceiptSale(sale);
          setViewingReceiptItems(items);
          setShowReceiptModal(true);
        }}
      />

      {/* CUSTOMER CRM MODAL */}
      <CustomerManagerModal
        businessId={businessId || ''}
        userId={currentUser.uid}
        isOpen={showCustomerModal}
        onClose={() => setShowCustomerModal(false)}
      />

      {/* PRINTABLE RECEIPT MODAL */}
      <ReceiptModal
        sale={viewingReceiptSale}
        items={viewingReceiptItems}
        businessName={dealer.businessName}
        businessPhone={dealer.phone}
        businessAddress={`${dealer.district}, Rwanda`}
        isOpen={showReceiptModal}
        onClose={() => {
          setShowReceiptModal(false);
          setViewingReceiptSale(null);
          setViewingReceiptItems([]);
        }}
      />

      {/* SALE VOID / REFUND CONFIRMATION DIALOG */}
      {cancellingSale && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 text-white space-y-4 shadow-2xl">
            <div className="flex items-center space-x-3 text-rose-400">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/20 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-base text-white">Void Sale & Restore Stock</h3>
                <p className="text-xs text-rose-300 font-mono">{cancellingSale.saleNumber}</p>
              </div>
            </div>

            <p className="text-xs text-slate-300">
              Voiding this sale will mark transaction as cancelled and automatically replenish the associated product inventory back into your catalog.
            </p>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Reason for Cancellation / Refund <span className="text-rose-400">*</span>
              </label>
              <textarea
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                placeholder="e.g. Customer returned items, incorrect SKU scanned, payment dispute..."
                rows={3}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                required
              />
            </div>

            <div className="flex items-center space-x-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setCancellingSale(null);
                  setCancelReason('');
                }}
                disabled={cancelProcessing}
                className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs py-2.5 rounded-xl transition"
              >
                Keep Sale
              </button>
              <button
                type="button"
                onClick={handleConfirmCancelSale}
                disabled={cancelProcessing || !cancelReason.trim()}
                className="flex-1 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white font-bold text-xs py-2.5 rounded-xl shadow transition flex items-center justify-center space-x-1.5"
              >
                {cancelProcessing ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Processing...</span>
                  </>
                ) : (
                  <>
                    <Ban className="w-3.5 h-3.5" />
                    <span>Confirm Void</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
