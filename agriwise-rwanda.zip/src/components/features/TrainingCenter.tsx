import React from 'react';
import { Course, Language } from '../../types';
import { INITIAL_COURSES } from '../../data/mockData';
import { translations } from '../../data/translations';
import {
  GraduationCap,
  PlayCircle,
  Star,
  Users,
  Clock,
  CheckCircle2
} from 'lucide-react';

interface TrainingCenterProps {
  language: Language;
}

export const TrainingCenter: React.FC<TrainingCenterProps> = ({ language }) => {
  const t = translations[language];

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-white">
        <div>
          <div className="inline-flex items-center space-x-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold mb-1">
            <GraduationCap className="w-3.5 h-3.5 text-emerald-400" />
            <span>AgriWise Academy & Extension Services</span>
          </div>
          <h2 className="text-xl font-black">{t.navTraining}</h2>
          <p className="text-xs text-slate-400">Practical audio-visual lessons in Kinyarwanda, English, and French.</p>
        </div>
      </div>

      {/* Course Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {INITIAL_COURSES.map((course) => (
          <div
            key={course.id}
            className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-xl flex flex-col justify-between text-white"
          >
            <div>
              <div className="relative h-48 w-full bg-slate-950">
                <img
                  src={course.thumbnailUrl}
                  alt={course.title[language] || course.title.en}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-slate-950/40 flex items-center justify-center">
                  <PlayCircle className="w-14 h-14 text-emerald-400 hover:scale-110 transition-transform cursor-pointer" />
                </div>
                <span className="absolute top-2 right-2 bg-emerald-950 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  {course.category}
                </span>
              </div>

              <div className="p-5 space-y-2">
                <h3 className="text-base font-black text-white">{course.title[language] || course.title.en}</h3>
                <p className="text-xs text-slate-400 line-clamp-2">{course.description[language] || course.description.en}</p>

                <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800">
                  <span className="flex items-center space-x-1">
                    <Clock className="w-3.5 h-3.5 text-teal-400" />
                    <span>{course.durationMinutes} Mins</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Users className="w-3.5 h-3.5 text-blue-400" />
                    <span>{course.enrolledStudents.toLocaleString()} Enrolled</span>
                  </span>
                  <span className="flex items-center space-x-1 text-amber-300 font-bold">
                    <Star className="w-3.5 h-3.5 fill-amber-300" />
                    <span>{course.rating}</span>
                  </span>
                </div>
              </div>
            </div>

            <div className="p-5 pt-0">
              <button
                onClick={() => alert(`Starting course: ${course.title[language] || course.title.en}`)}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl text-xs shadow flex items-center justify-center space-x-2"
              >
                <PlayCircle className="w-4 h-4" />
                <span>Start Video Lesson (Free)</span>
              </button>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
