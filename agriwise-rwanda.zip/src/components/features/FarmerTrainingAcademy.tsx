import React, { useState } from 'react';
import {
  GraduationCap,
  BookOpen,
  Play,
  CheckCircle2,
  Award,
  Sparkles,
  Bot,
  Video,
  Download,
  Globe2,
  Trophy,
  Users,
  Building2,
  MessageSquare,
  Plus,
  HelpCircle,
  FileCheck,
  Zap,
  Star,
  Clock,
  ChevronRight,
  ShieldCheck,
  Share2,
  BarChart3,
  Bookmark
} from 'lucide-react';
import {
  MOCK_ACADEMY_COURSES,
  MOCK_FARMER_CERTIFICATES,
  MOCK_GAMIFICATION_PROFILE,
  MOCK_GOVT_PROGRAMS,
  MOCK_COMMUNITY_POSTS
} from '../../data/mockAcademyData';
import {
  AcademyCourse,
  AcademyLesson,
  FarmerCertificate,
  FarmerGamificationProfile,
  GovernmentTrainingProgram,
  CommunityDiscussionPost,
  CourseCategory,
  Language
} from '../../types';
import { FarmerLearningCenter } from './FarmerLearningCenter';

export const FarmerTrainingAcademy: React.FC = () => {
  const [activeTab, setActiveTab] = useState<
    'courses' | 'video_center' | 'classroom' | 'tutor' | 'certificates' | 'leaderboard' | 'govt_programs' | 'community' | 'creator'
  >('courses');

  // State
  const [courses, setCourses] = useState<AcademyCourse[]>(MOCK_ACADEMY_COURSES);
  const [selectedCourse, setSelectedCourse] = useState<AcademyCourse>(MOCK_ACADEMY_COURSES[0]);
  const [activeLesson, setActiveLesson] = useState<AcademyLesson>(MOCK_ACADEMY_COURSES[0].lessons[0]);
  const [certificates, setCertificates] = useState<FarmerCertificate[]>(MOCK_FARMER_CERTIFICATES);
  const [gamificationProfile, setGamificationProfile] = useState<FarmerGamificationProfile>(MOCK_GAMIFICATION_PROFILE);
  const [govtPrograms, setGovtPrograms] = useState<GovernmentTrainingProgram[]>(MOCK_GOVT_PROGRAMS);
  const [communityPosts, setCommunityPosts] = useState<CommunityDiscussionPost[]>(MOCK_COMMUNITY_POSTS);

  // Category Filter
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [learningLanguage, setLearningLanguage] = useState<'en' | 'rw' | 'fr'>('en');

  // Interactive Quiz State
  const [userSelectedQuizAnswer, setUserSelectedQuizAnswer] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);
  const [isQuizPassed, setIsQuizPassed] = useState<boolean>(false);

  // AI Tutor State
  const [tutorQuery, setTutorQuery] = useState("How can I increase hybrid maize yield and prevent Fall Armyworm infestation?");
  const [isTutorThinking, setIsTutorThinking] = useState(false);
  const [tutorResponse, setTutorResponse] = useState<{
    directAnswer: string;
    recommendedCourses: string[];
    practicalActionSteps: string[];
    rabCertifiedTip: string;
  } | null>(null);

  // Offline Download State
  const [offlineLessonsDownloaded, setOfflineLessonsDownloaded] = useState<string[]>(['lsn-101']);

  // Instructor Course Creation Form
  const [showCreateCourseModal, setShowCreateCourseModal] = useState(false);
  const [newCourseTitle, setNewCourseTitle] = useState('');
  const [newCourseCategory, setNewCourseCategory] = useState<CourseCategory>('Crop Production');

  // Trigger AI Tutor ("Mwalimu wa Ubuhinzi")
  const askAiTutor = async () => {
    if (!tutorQuery) return;
    setIsTutorThinking(true);
    try {
      const res = await fetch('/api/ai/academy-tutor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          farmerQuery: tutorQuery,
          farmerCrops: 'Maize & Irish Potato',
          district: 'Nyagatare District',
          language: learningLanguage
        })
      });
      const data = await res.json();
      setTutorResponse(data);
    } catch (err) {
      console.error('AI Academy Tutor error:', err);
      setTutorResponse({
        directAnswer: learningLanguage === 'rw'
          ? "Mwalimu wa Ubuhinzi: Ku bijyanye n'umusaruro w'ibigori, gukoresha imbuto y'indobanure RHM 104 n'ifumbire ya NPK kuri 75cm x 25cm bituma umusaruro wiyongera ho 40%."
          : "Mwalimu wa Ubuhinzi: To maximize hybrid maize yield, space certified RHM 104 seeds at 75cm x 25cm, apply basal NPK fertilizer during soil prep, and scout for early Fall Armyworm egg clusters in leaf whorls.",
        recommendedCourses: [
          "Modern Maize Cultivation & Fall Armyworm Pest Management",
          "Smart IoT Sensors & Drone Agriculture Masterclass"
        ],
        practicalActionSteps: [
          "Space rows at 75cm with 25cm seed distance.",
          "Apply 12.5 L/Ha RAB certified Neem bio-pesticide early morning.",
          "Log harvest sales on MoMo Pay to build credit rank."
        ],
        rabCertifiedTip: "RAB provides 50% subsidies on certified seed and fertilizer via Smart Nkunganire System (SNS)."
      });
    } finally {
      setIsTutorThinking(false);
    }
  };

  // Submit Quiz
  const handleQuizSubmit = (correctIdx: number) => {
    if (userSelectedQuizAnswer === null) return;
    setQuizSubmitted(true);
    if (userSelectedQuizAnswer === correctIdx) {
      setIsQuizPassed(true);
      // Award gamification points
      setGamificationProfile(prev => ({
        ...prev,
        totalLearningPoints: prev.totalLearningPoints + 150,
        quizzesPassedCount: prev.quizzesPassedCount + 1
      }));
    } else {
      setIsQuizPassed(false);
    }
  };

  // Toggle Offline Lesson Download
  const toggleOfflineDownload = (lessonId: string) => {
    if (offlineLessonsDownloaded.includes(lessonId)) {
      setOfflineLessonsDownloaded(prev => prev.filter(id => id !== lessonId));
    } else {
      setOfflineLessonsDownloaded(prev => [...prev, lessonId]);
    }
  };

  const filteredCourses = selectedCategory === 'All'
    ? courses
    : courses.filter(c => c.category === selectedCategory);

  return (
    <div className="space-y-6 pb-12">
      {/* Top Hero Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-950 text-white rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-emerald-700/60 rounded-xl border border-emerald-400/30 backdrop-blur-md">
              <GraduationCap className="w-8 h-8 text-emerald-300" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
                AGRIWISE Farmer Training Academy
                <span className="text-xs bg-emerald-500/30 text-emerald-200 border border-emerald-400/40 px-2.5 py-0.5 rounded-full font-medium">
                  RAB & MINAGRI Certified
                </span>
              </h1>
              <p className="text-emerald-200 text-sm mt-0.5">
                Practical Video Lessons • Bilingual AI Tutor ("Mwalimu") • RAB Verified Digital Skill Certificates
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Language Selector */}
            <div className="flex items-center gap-1 bg-slate-900/80 border border-emerald-400/30 rounded-xl p-1 text-xs">
              <Globe2 className="w-3.5 h-3.5 text-emerald-400 ml-1.5" />
              {(['en', 'rw', 'fr'] as const).map(lang => (
                <button
                  key={lang}
                  onClick={() => setLearningLanguage(lang)}
                  className={`px-2.5 py-1 rounded-lg font-bold uppercase transition-all ${
                    learningLanguage === lang ? 'bg-emerald-600 text-white shadow' : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {lang}
                </button>
              ))}
            </div>

            <button
              onClick={() => setActiveTab('tutor')}
              className="flex items-center gap-2 bg-gradient-to-r from-emerald-400 to-teal-500 hover:from-emerald-300 hover:to-teal-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-lg transition-all border border-emerald-300/40"
            >
              <Bot className="w-4 h-4" /> Ask AI Tutor ("Mwalimu")
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800">
        {[
          { id: 'courses', label: 'Course Catalog & Learning Paths', icon: BookOpen },
          { id: 'video_center', label: 'Agricultural Educational Videos', icon: Video },
          { id: 'classroom', label: 'Interactive Video Classroom & Quiz', icon: Play },
          { id: 'tutor', label: 'AI Farming Tutor ("Mwalimu")', icon: Bot },
          { id: 'certificates', label: 'Verified Digital Certificates', icon: Award },
          { id: 'leaderboard', label: 'Farmer Gamification & Leaderboard', icon: Trophy },
          { id: 'govt_programs', label: 'National Government Initiatives', icon: Building2 },
          { id: 'community', label: 'Farmer Knowledge Community', icon: MessageSquare },
          { id: 'creator', label: 'Expert Course Creator Studio', icon: Plus }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* TAB: AGRICULTURAL EDUCATIONAL VIDEOS */}
      {activeTab === 'video_center' && (
        <FarmerLearningCenter language={learningLanguage} />
      )}

      {/* TAB 1: COURSE CATALOG & LEARNING PATHS */}
      {activeTab === 'courses' && (
        <div className="space-y-6">
          {/* User Gamification Stats Summary Card */}
          <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white rounded-2xl p-5 border border-emerald-500/30 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-emerald-600/30 rounded-2xl border border-emerald-400/40 flex items-center justify-center text-2xl">
                🏆
              </div>
              <div>
                <span className="text-xs text-emerald-400 font-bold uppercase tracking-wider">Farmer Progress Rank</span>
                <h3 className="text-lg font-extrabold text-white">{gamificationProfile.currentRankBadge}</h3>
                <p className="text-xs text-slate-300">
                  District Rank: <strong className="text-emerald-300">#{gamificationProfile.districtRankPosition} in {gamificationProfile.districtName}</strong>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-6 text-center">
              <div>
                <span className="text-xs text-slate-400 block">Learning Points</span>
                <span className="text-2xl font-extrabold text-amber-400 font-mono">{gamificationProfile.totalLearningPoints} XP</span>
              </div>
              <div className="w-px h-8 bg-slate-700" />
              <div>
                <span className="text-xs text-slate-400 block">Certificates Earned</span>
                <span className="text-2xl font-extrabold text-emerald-400 font-mono">{gamificationProfile.coursesCompletedCount} RAB Seals</span>
              </div>
            </div>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {['All', 'Crop Production', 'Livestock & Poultry', 'Smart Tech & Drones', 'Agribusiness & Finance', 'Soil & Climate Resilience'].map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  selectedCategory === cat
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Course Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {filteredCourses.map(course => (
              <div key={course.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
                <div>
                  <div className="relative h-44 overflow-hidden">
                    <img
                      src={course.thumbnailUrl}
                      alt={course.title}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-md text-emerald-300 text-[10px] font-bold px-2.5 py-1 rounded-full border border-emerald-400/40">
                      {course.category}
                    </div>
                    {course.isRabCertified && (
                      <div className="absolute top-3 right-3 bg-emerald-600 text-white text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1 shadow">
                        <ShieldCheck className="w-3 h-3" /> RAB Certified
                      </div>
                    )}
                  </div>

                  <div className="p-5 space-y-3">
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {course.totalDurationHours} Hours</span>
                      <span className="flex items-center gap-1 text-amber-500 font-bold"><Star className="w-3.5 h-3.5 fill-current" /> {course.ratingScore}</span>
                      <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" /> {course.enrolledStudentsCount} Farmers</span>
                    </div>

                    <h3 className="font-bold text-slate-900 dark:text-white text-base line-clamp-2 leading-snug">
                      {course.title}
                    </h3>

                    <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2">
                      {course.description}
                    </p>

                    <div className="text-[11px] text-slate-500">
                      Instructor: <strong className="text-slate-700 dark:text-slate-200">{course.instructorName}</strong> ({course.instructorTitle})
                    </div>
                  </div>
                </div>

                <div className="p-5 pt-0">
                  <button
                    onClick={() => {
                      setSelectedCourse(course);
                      if (course.lessons.length > 0) setActiveLesson(course.lessons[0]);
                      setActiveTab('classroom');
                    }}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-xl text-xs transition-colors flex items-center justify-center gap-2 shadow-sm"
                  >
                    <Play className="w-4 h-4 fill-current" /> Enter Course Classroom
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: INTERACTIVE VIDEO CLASSROOM & QUIZ */}
      {activeTab === 'classroom' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-6 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div>
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block mb-1">
                  Active Course Classroom
                </span>
                <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
                  {selectedCourse.title}
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Taught by {selectedCourse.instructorName} • {selectedCourse.category}
                </p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => toggleOfflineDownload(activeLesson.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                    offlineLessonsDownloaded.includes(activeLesson.id)
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/50 dark:text-emerald-300'
                      : 'bg-slate-100 text-slate-700 border-slate-300 dark:bg-slate-800 dark:text-slate-300'
                  }`}
                >
                  <Download className="w-3.5 h-3.5" />
                  {offlineLessonsDownloaded.includes(activeLesson.id) ? 'Downloaded (Offline Ready)' : 'Download Lesson'}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Main Video & Content Area */}
              <div className="lg:col-span-2 space-y-5">
                {/* Simulated HTML5 Video Player */}
                <div className="relative aspect-video bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-lg flex items-center justify-center group">
                  <video
                    controls
                    className="w-full h-full object-cover"
                    src={activeLesson.videoUrl || "https://www.w3schools.com/html/mov_bbb.mp4"}
                  />
                  <div className="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-md text-white text-[11px] px-3 py-1 rounded-full font-bold border border-slate-700">
                    Lesson {activeLesson.lessonTitle}
                  </div>
                </div>

                {/* Lesson Summary & Notes */}
                <div className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                  <h4 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-emerald-600" /> Lesson Core Summary & Agronomic Protocol
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {activeLesson.summaryText}
                  </p>
                </div>

                {/* Interactive Quiz Assessment Section */}
                {activeLesson.quiz && (
                  <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 text-white p-6 rounded-2xl border border-emerald-500/30 shadow-md space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                        <HelpCircle className="w-4 h-4" /> End-of-Lesson Knowledge Check
                      </span>
                      <span className="text-xs font-mono bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-400/30">
                        +150 XP
                      </span>
                    </div>

                    <p className="text-sm font-bold text-white">
                      {activeLesson.quiz.questionText}
                    </p>

                    <div className="space-y-2">
                      {activeLesson.quiz.options.map((opt, idx) => (
                        <button
                          key={idx}
                          onClick={() => {
                            setUserSelectedQuizAnswer(idx);
                            setQuizSubmitted(false);
                          }}
                          className={`w-full text-left px-4 py-3 rounded-xl text-xs font-medium transition-all border ${
                            userSelectedQuizAnswer === idx
                              ? 'bg-emerald-600 text-white border-emerald-400 shadow'
                              : 'bg-slate-800/80 text-slate-200 border-slate-700 hover:bg-slate-700'
                          }`}
                        >
                          {String.fromCharCode(65 + idx)}. {opt}
                        </button>
                      ))}
                    </div>

                    <div className="pt-2 flex justify-between items-center">
                      <button
                        onClick={() => handleQuizSubmit(activeLesson.quiz!.correctAnswerIndex)}
                        disabled={userSelectedQuizAnswer === null}
                        className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs transition-colors disabled:opacity-50"
                      >
                        Submit Answer & Claim Certificate XP
                      </button>

                      {quizSubmitted && (
                        <span className={`text-xs font-bold flex items-center gap-1 ${isQuizPassed ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {isQuizPassed ? <CheckCircle2 className="w-4 h-4" /> : null}
                          {isQuizPassed ? 'Correct! +150 XP Earned!' : 'Incorrect answer. Try again!'}
                        </span>
                      )}
                    </div>

                    {quizSubmitted && (
                      <div className="text-xs bg-slate-800/90 p-3 rounded-xl border border-slate-700 text-slate-300">
                        <strong className="text-emerald-400 block mb-0.5">Explanation:</strong>
                        {activeLesson.quiz.explanation}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Course Playlist Sidebar */}
              <div className="space-y-4">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                  <Video className="w-4 h-4 text-emerald-600" /> Course Syllabus ({selectedCourse.lessons.length} Lessons)
                </h4>

                <div className="space-y-2">
                  {selectedCourse.lessons.map((lsn, index) => (
                    <button
                      key={lsn.id}
                      onClick={() => setActiveLesson(lsn)}
                      className={`w-full text-left p-3.5 rounded-xl text-xs transition-all border ${
                        activeLesson.id === lsn.id
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-400 text-emerald-900 dark:text-emerald-200 shadow-sm'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-bold">Lesson {index + 1}: {lsn.lessonTitle}</span>
                        <span className="text-[10px] font-mono text-slate-400">{lsn.durationMins}m</span>
                      </div>
                      <div className="flex items-center gap-2 text-[10px]">
                        {lsn.isCompleted ? (
                          <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-0.5">
                            <CheckCircle2 className="w-3 h-3" /> Completed
                          </span>
                        ) : (
                          <span className="text-slate-400">In Progress</span>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: AI FARMING TUTOR ("MWALIMU WA UBUHINZI") */}
      {activeTab === 'tutor' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Bot className="w-5 h-5 text-emerald-600" />
                  "Mwalimu wa Ubuhinzi" — AI Agricultural Education Tutor
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Ask agronomic questions in Kinyarwanda, English, or French. Powered by Gemini 3.6 Flash and aligned with RAB training manuals.
                </p>
              </div>

              <span className="text-xs bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300 px-3 py-1 rounded-full font-bold border border-emerald-300/40">
                Gemini 3.6 Flash Tutor Online
              </span>
            </div>

            <div className="space-y-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={tutorQuery}
                  onChange={(e) => setTutorQuery(e.target.value)}
                  placeholder="Ask Mwalimu e.g. How do I improve tomato yield and prevent blight?"
                  className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <button
                  onClick={askAiTutor}
                  disabled={isTutorThinking}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-5 py-3 rounded-xl text-xs transition-colors flex items-center gap-2 disabled:opacity-50"
                >
                  <Sparkles className={`w-4 h-4 ${isTutorThinking ? 'animate-spin' : ''}`} />
                  {isTutorThinking ? 'Consulting RAB Manuals...' : 'Ask Mwalimu'}
                </button>
              </div>

              {/* Preset Agronomic Questions */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs text-slate-500">
                <span className="font-semibold whitespace-nowrap">Suggested Questions:</span>
                {[
                  'How to control Fall Armyworm in Nyagatare?',
                  'What is optimal NPK ratio for seed potatoes in Musanze?',
                  'How to qualify for NAIS 50% insurance subsidy?'
                ].map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setTutorQuery(q);
                      askAiTutor();
                    }}
                    className="bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 hover:text-emerald-700 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 px-3 py-1 rounded-full whitespace-nowrap border border-slate-200 dark:border-slate-700 transition-all"
                  >
                    {q}
                  </button>
                ))}
              </div>

              {/* AI Response Box */}
              {tutorResponse && (
                <div className="bg-slate-900 border border-emerald-500/40 rounded-2xl p-6 text-white shadow-xl space-y-4">
                  <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                    <span className="text-xs font-bold text-emerald-400 flex items-center gap-2">
                      <Bot className="w-4 h-4" /> Mwalimu wa Ubuhinzi Response
                    </span>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full font-mono border border-emerald-400/30">
                      RAB Aligned Guidance
                    </span>
                  </div>

                  <p className="text-xs text-slate-200 leading-relaxed font-medium">
                    {tutorResponse.directAnswer}
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                    <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 space-y-2">
                      <span className="text-xs font-bold text-emerald-300 block">Recommended Action Steps:</span>
                      <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside">
                        {tutorResponse.practicalActionSteps.map((step, idx) => (
                          <li key={idx}>{step}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 space-y-2">
                      <span className="text-xs font-bold text-sky-300 block">Recommended Courses to Enroll:</span>
                      <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside">
                        {tutorResponse.recommendedCourses.map((crs, idx) => (
                          <li key={idx}>{crs}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="bg-emerald-950/60 border border-emerald-500/40 rounded-xl p-3 text-xs text-emerald-200">
                    <strong className="text-emerald-400 block mb-0.5">RAB Subsidized Tip:</strong>
                    {tutorResponse.rabCertifiedTip}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: RAB VERIFIED DIGITAL CERTIFICATES */}
      {activeTab === 'certificates' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Award className="w-5 h-5 text-emerald-600" />
                  Verified Digital Farmer Certificates & Skill Badges
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Verifiable digital credentials recognized by MINAGRI, BDF Rwanda, and financial institutions for loan credit scoring.
                </p>
              </div>

              <span className="text-xs bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300 px-3 py-1 rounded-full font-bold border border-emerald-300/40">
                2 Certificates Earned
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {certificates.map(cert => (
                <div key={cert.id} className="bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 text-white rounded-2xl p-6 border border-emerald-500/40 shadow-xl space-y-4 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

                  <div className="flex justify-between items-start border-b border-slate-700/80 pb-3">
                    <div>
                      <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-400 block">
                        Rwanda Agriculture Board (RAB)
                      </span>
                      <h4 className="text-sm font-extrabold text-white mt-0.5">{cert.skillBadgeTitle}</h4>
                    </div>

                    <ShieldCheck className="w-8 h-8 text-emerald-400" />
                  </div>

                  <div className="space-y-1">
                    <span className="text-[11px] text-slate-400 block">Course Completed:</span>
                    <p className="text-xs font-bold text-slate-200">{cert.courseTitle}</p>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Farmer Name:</span>
                      <span className="text-xs font-bold text-white">{cert.farmerName}</span>
                      <span className="text-[10px] text-slate-400 block mt-1">Issued Date: {cert.issueDate}</span>
                    </div>

                    <img
                      src={cert.verifiableQrCodeUrl}
                      alt="RAB QR Code Verification"
                      className="w-16 h-16 rounded-lg bg-white p-1 border border-slate-600"
                    />
                  </div>

                  <div className="pt-2 border-t border-slate-700/80 flex justify-between items-center text-[10px] text-slate-400">
                    <span className="font-mono">Cert #: {cert.certificateNumber}</span>
                    <button className="text-emerald-400 font-bold hover:underline flex items-center gap-1">
                      <Share2 className="w-3 h-3" /> Share Credential
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: FARMER GAMIFICATION & LEADERBOARD */}
      {activeTab === 'leaderboard' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="mb-6">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-500" />
                Nyagatare District Farmer Learning Leaderboard
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Top trained agro-innovators earning XP points, badges, and priority BDF micro-grant funding.
              </p>
            </div>

            <div className="space-y-3">
              {[
                { rank: 1, name: 'Aline Umutoni', district: 'Nyagatare', points: 1890, badge: 'Master Agro-Innovator', count: 5 },
                { rank: 2, name: 'Pascal Habimana', district: 'Nyagatare', points: 1450, badge: 'Smart Irrigation Tech', count: 4 },
                { rank: 3, name: 'Jean-Baptiste Hakizimana (You)', district: 'Nyagatare', points: 1250, badge: 'Master Agro-Innovator', count: 2 },
                { rank: 4, name: 'Marie-Rose Uwimana', district: 'Musanze', points: 1120, badge: 'Maize Master', count: 3 }
              ].map(item => (
                <div key={item.rank} className={`p-4 rounded-xl flex justify-between items-center border transition-all ${
                  item.rank === 3
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-400 text-slate-900 dark:text-white font-bold'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200'
                }`}>
                  <div className="flex items-center gap-3">
                    <span className={`w-8 h-8 rounded-full flex items-center justify-center font-extrabold text-xs ${
                      item.rank === 1 ? 'bg-amber-400 text-slate-950' : item.rank === 2 ? 'bg-slate-300 text-slate-950' : 'bg-emerald-600 text-white'
                    }`}>
                      #{item.rank}
                    </span>
                    <div>
                      <h4 className="text-xs font-bold">{item.name}</h4>
                      <span className="text-[11px] text-slate-500">{item.badge} • {item.district}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-sm font-extrabold text-amber-500 font-mono">{item.points} XP</span>
                    <span className="block text-[10px] text-slate-400">{item.count} Certs Earned</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: GOVERNMENT INITIATIVES */}
      {activeTab === 'govt_programs' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="mb-6">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-600" />
                MINAGRI & RAB National Government Training Programs
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                State-sponsored agricultural capacity-building programs for smallholders, youth, and cooperative leaders.
              </p>
            </div>

            <div className="space-y-4">
              {govtPrograms.map(prog => (
                <div key={prog.id} className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block">
                        {prog.sponsoringAgency}
                      </span>
                      <h4 className="font-bold text-slate-900 dark:text-white text-base mt-0.5">{prog.programTitle}</h4>
                    </div>

                    <span className="text-xs bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300 px-3 py-1 rounded-full font-bold">
                      {prog.status}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    Target Audience: <strong>{prog.targetAudience}</strong>
                  </p>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs pt-2">
                    <div>Enrolled: <strong className="font-mono text-emerald-600">{prog.enrolledCount.toLocaleString()} Farmers</strong></div>
                    <div>Completion Rate: <strong className="font-mono text-emerald-600">{prog.completionRatePct}%</strong></div>
                    <div>Start Date: <strong className="font-mono">{prog.startDate}</strong></div>
                    <div>End Date: <strong className="font-mono">{prog.endDate}</strong></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: FARMER KNOWLEDGE COMMUNITY */}
      {activeTab === 'community' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-emerald-600" />
                  Farmer Knowledge Sharing & Peer Forum
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Discuss agronomic lessons, pest control strategies, and cooperative success stories with extension officers.
                </p>
              </div>

              <button className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5">
                <Plus className="w-4 h-4" /> Start Discussion
              </button>
            </div>

            <div className="space-y-4">
              {communityPosts.map(post => (
                <div key={post.id} className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-slate-900 dark:text-white text-sm">{post.postTitle}</h4>
                      <span className="text-[11px] text-slate-500">
                        Posted by <strong>{post.authorName}</strong> ({post.authorRole}) • {post.createdTime}
                      </span>
                    </div>

                    <span className="text-[10px] bg-sky-100 text-sky-800 dark:bg-sky-950/50 dark:text-sky-300 px-2.5 py-0.5 rounded-full font-bold">
                      {post.topicTag}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {post.postContent}
                  </p>

                  <div className="flex items-center gap-4 text-xs text-slate-500 pt-2 border-t border-slate-200 dark:border-slate-700/60">
                    <button className="hover:text-emerald-600 flex items-center gap-1">
                      👍 {post.likesCount} Helpful Votes
                    </button>
                    <button className="hover:text-emerald-600 flex items-center gap-1">
                      💬 {post.commentsCount} Farmer Comments
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 8: EXPERT COURSE CREATOR STUDIO */}
      {activeTab === 'creator' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="mb-6">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-emerald-600" />
                Agro-Expert Course Creation Studio
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Upload video demonstrations, design end-of-lesson quizzes, and submit courses for RAB seal accreditation.
              </p>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/60 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-4 max-w-2xl">
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Course Title:
                </label>
                <input
                  type="text"
                  value={newCourseTitle}
                  onChange={(e) => setNewCourseTitle(e.target.value)}
                  placeholder="e.g. Hydroponic Greenhouse Tomato Cultivation"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Course Category:
                </label>
                <select
                  value={newCourseCategory}
                  onChange={(e) => setNewCourseCategory(e.target.value as CourseCategory)}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Crop Production">Crop Production</option>
                  <option value="Livestock & Poultry">Livestock & Poultry</option>
                  <option value="Smart Tech & Drones">Smart Tech & Drones</option>
                  <option value="Agribusiness & Finance">Agribusiness & Finance</option>
                  <option value="Soil & Climate Resilience">Soil & Climate Resilience</option>
                </select>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => {
                    if (!newCourseTitle) return;
                    const created: AcademyCourse = {
                      id: `crs-${Date.now()}`,
                      title: newCourseTitle,
                      category: newCourseCategory,
                      instructorName: 'Jean-Baptiste Hakizimana',
                      instructorTitle: 'Lead Agronomist & Farmer',
                      difficulty: 'Beginner',
                      totalDurationHours: 2.0,
                      totalLessonsCount: 2,
                      ratingScore: 5.0,
                      enrolledStudentsCount: 1,
                      thumbnailUrl: 'https://images.unsplash.com/photo-1592417817098-8f3d6eb231fc?q=80&w=800&auto=format&fit=crop',
                      description: 'Custom agronomic training course uploaded by certified instructor.',
                      skillsLearned: ['Greenhouse Climate Management', 'Bio-Fertilizer Prep'],
                      isRabCertified: false,
                      lessons: []
                    };
                    setCourses(prev => [created, ...prev]);
                    setNewCourseTitle('');
                    setActiveTab('courses');
                  }}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-5 py-2.5 rounded-xl text-xs transition-colors flex items-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" /> Submit Course for RAB Accreditation Review
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
