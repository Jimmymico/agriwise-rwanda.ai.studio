import React, { useState, useEffect } from 'react';
import {
  TransporterProfile,
  TransportFreightJob,
  AgriculturalWarehouse,
  User,
  Language
} from '../../types';
import {
  SAMPLE_TRANSPORTERS,
  SAMPLE_FREIGHT_JOBS,
  SAMPLE_AGRICULTURAL_WAREHOUSES
} from '../../data/mockLogisticsData';
import { translations } from '../../data/translations';
import {
  Truck,
  MapPin,
  Navigation,
  Clock,
  DollarSign,
  ShieldCheck,
  Plus,
  Search,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Star,
  Layers,
  Building2,
  Phone,
  Thermometer,
  Wind,
  Warehouse as WarehouseIcon,
  ChevronRight,
  ArrowRight,
  RefreshCw,
  Gauge,
  UserCheck,
  CreditCard,
  Radio
} from 'lucide-react';

interface AgriculturalLogisticsProps {
  currentUser: User;
  language: Language;
  onInitiateMomoPayment: (amountRwf: number, title: string) => void;
}

export const AgriculturalLogistics: React.FC<AgriculturalLogisticsProps> = ({
  currentUser,
  language,
  onInitiateMomoPayment,
}) => {
  const t = translations[language];

  // Active Transporter Profile (Simulated logged in transporter)
  const [transporters, setTransporters] = useState<TransporterProfile[]>(SAMPLE_TRANSPORTERS);
  const [activeTransporter, setActiveTransporter] = useState<TransporterProfile>(SAMPLE_TRANSPORTERS[0]);

  // Active Datasets
  const [jobs, setJobs] = useState<TransportFreightJob[]>(SAMPLE_FREIGHT_JOBS);
  const [warehouses, setWarehouses] = useState<AgriculturalWarehouse[]>(SAMPLE_AGRICULTURAL_WAREHOUSES);

  // Tabs
  const [activeTab, setActiveTab] = useState<'load_board' | 'gps_tracking' | 'post_request' | 'warehouses' | 'ai_optimizer' | 'transporters'>('load_board');

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCargoFilter, setSelectedCargoFilter] = useState<string>('All');

  // Post Delivery Request Modal & State
  const [showPostJobModal, setShowPostJobModal] = useState(false);
  const [newRequesterType, setNewRequesterType] = useState<'Farmer' | 'Cooperative' | 'Agro-dealer' | 'Grain Exporter'>('Cooperative');
  const [newCargoType, setNewCargoType] = useState<TransportFreightJob['cargoType']>('Maize Grain');
  const [newQuantityTons, setNewQuantityTons] = useState(5.0);
  const [newPickup, setNewPickup] = useState('Nyagatare Central Grain Silo');
  const [newDestination, setNewDestination] = useState('Kigali Minimex Flour Mill, Kicukiro');
  const [newDate, setNewDate] = useState('2026-08-06');
  const [newSpecialReq, setNewSpecialReq] = useState('Tarpaulin Rain Cover Required');
  const [newPriceRwf, setNewPriceRwf] = useState(180000);

  // Transporter Onboarding Modal
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [regCompany, setRegCompany] = useState('');
  const [regDriver, setRegDriver] = useState('');
  const [regPhone, setRegPhone] = useState('+250 788 ');
  const [regDistrict, setRegDistrict] = useState('Nyagatare');
  const [regVehicleType, setRegVehicleType] = useState<TransporterProfile['vehicleType']>('Fuso 5-Ton Truck');
  const [regPlate, setRegPlate] = useState('RAF ');
  const [regCapacity, setRegCapacity] = useState(5.0);

  // Active Tracked Job for GPS Live Simulator
  const [trackedJob, setTrackedJob] = useState<TransportFreightJob>(SAMPLE_FREIGHT_JOBS[0]);
  const [isSimulatingGps, setIsSimulatingGps] = useState(false);

  // AI Route Optimizer State
  const [aiPickup, setAiPickup] = useState('Nyagatare Karangazi Silo');
  const [aiDestination, setAiDestination] = useState('Kigali Minimex Mill');
  const [aiCargo, setAiCargo] = useState('Maize Grain');
  const [aiTons, setAiTons] = useState(5.0);
  const [aiCold, setAiCold] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<any>(null);

  const fetchAiLogisticsOptimization = async () => {
    setAiLoading(true);
    try {
      const res = await fetch('/api/ai/logistics-optimizer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pickupLocation: aiPickup,
          destination: aiDestination,
          cargoType: aiCargo,
          cargoWeightTons: aiTons,
          requiresColdStorage: aiCold,
          language
        }),
      });
      const data = await res.json();
      setAiResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setAiLoading(false);
    }
  };

  useEffect(() => {
    fetchAiLogisticsOptimization();
  }, [language]);

  // GPS Simulation Loop
  useEffect(() => {
    let interval: any;
    if (isSimulatingGps && trackedJob.status === 'In Transit') {
      interval = setInterval(() => {
        setTrackedJob(prev => {
          const nextEta = Math.max(0, prev.estimatedEtaMinutes - 5);
          const nextSpeed = Math.floor(55 + Math.random() * 15);
          return {
            ...prev,
            estimatedEtaMinutes: nextEta,
            currentGps: {
              ...prev.currentGps,
              speedKmH: nextSpeed,
              lat: prev.currentGps.lat - 0.002,
              lng: prev.currentGps.lng + 0.003,
              locationName: nextEta === 0 ? 'Arrived at Destination Point' : `En-route to Destination (${nextEta} min ETA)`
            },
            status: nextEta === 0 ? 'Delivered' : 'In Transit'
          };
        });
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [isSimulatingGps, trackedJob.status]);

  // Handlers
  const handleAcceptJob = (job: TransportFreightJob) => {
    const updated = jobs.map(j => {
      if (j.id === job.id) {
        return {
          ...j,
          status: 'Assigned' as const,
          assignedTransporterId: activeTransporter.id,
          assignedTransporterName: `${activeTransporter.companyName} (${activeTransporter.driverName})`,
          assignedVehiclePlate: activeTransporter.plateNumber
        };
      }
      return j;
    });
    setJobs(updated);
  };

  const handleUpdateJobStatus = (jobId: string, newStatus: TransportFreightJob['status']) => {
    setJobs(jobs.map(j => {
      if (j.id === jobId) {
        let paymentStat = j.paymentStatus;
        if (newStatus === 'Delivered') {
          paymentStat = 'Released';
        }
        return { ...j, status: newStatus, paymentStatus: paymentStat };
      }
      return j;
    }));
  };

  const handlePostJob = (e: React.FormEvent) => {
    e.preventDefault();
    const newJob: TransportFreightJob = {
      id: `job-${Date.now().toString().slice(-4)}`,
      jobCode: `AGRI-LOG-2026-${Math.floor(100 + Math.random() * 900)}`,
      requesterType: newRequesterType,
      requesterName: currentUser.name || 'Agri Cooperative Requester',
      requesterPhone: '+250 788 112 334',
      cargoType: newCargoType,
      quantityTons: Number(newQuantityTons),
      pickupLocation: newPickup,
      destination: newDestination,
      distanceKm: Math.floor(80 + Math.random() * 120),
      requestedDate: newDate,
      specialRequirements: [newSpecialReq],
      quotedPriceRwf: Number(newPriceRwf),
      status: 'Open for Bidding',
      paymentStatus: 'MoMo Escrow Secured',
      deliveryCode: Math.floor(1000 + Math.random() * 9000).toString(),
      currentGps: {
        lat: -1.9536,
        lng: 30.0605,
        locationName: newPickup,
        speedKmH: 0
      },
      estimatedEtaMinutes: 120,
      createdAt: 'Just now'
    };

    setJobs([newJob, ...jobs]);
    onInitiateMomoPayment(Number(newPriceRwf), `Freight Logistics Escrow (${newCargoType} - ${newQuantityTons}T)`);
    setShowPostJobModal(false);
  };

  const handleRegisterTransporter = (e: React.FormEvent) => {
    e.preventDefault();
    const newTr: TransporterProfile = {
      id: `tr-${Date.now().toString().slice(-4)}`,
      companyName: regCompany,
      driverName: regDriver,
      phone: regPhone,
      email: `${regDriver.toLowerCase().replace(/\s+/g, '')}@agriwise.rw`,
      district: regDistrict,
      sector: 'Central',
      ruraLicenseNumber: `RURA-TRANS-2026-${Math.floor(100 + Math.random() * 900)}`,
      vehicleType: regVehicleType,
      plateNumber: regPlate,
      maxCapacityTons: Number(regCapacity),
      rating: 5.0,
      totalReviews: 1,
      completedJobsCount: 0,
      verificationStatus: 'Approved',
      coldStorageEquipped: regVehicleType.includes('Refrigerated'),
      gpsTracked: true,
      baseRatePerKmRwf: 1500,
      totalEarningsRwf: 0,
      currentStatus: 'Available'
    };

    setTransporters([newTr, ...transporters]);
    setActiveTransporter(newTr);
    setShowRegisterModal(false);
  };

  const filteredJobs = jobs.filter(j => {
    const matchesSearch = j.cargoType.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          j.pickupLocation.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          j.destination.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCargo = selectedCargoFilter === 'All' || j.cargoType === selectedCargoFilter;
    return matchesSearch && matchesCargo;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* Enterprise Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden text-white">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center space-x-2 bg-blue-500/20 text-blue-300 border border-blue-500/30 px-3 py-1 rounded-full text-xs font-bold mb-2">
              <ShieldCheck className="w-4 h-4 text-blue-400" />
              <span>RURA Licensed Agricultural Logistics Platform</span>
            </div>

            <div className="flex items-center space-x-3">
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                Transport & Agricultural Logistics Hub
              </h1>
              <span className="bg-slate-800 text-slate-300 border border-slate-700 text-xs px-2.5 py-1 rounded-lg font-mono">
                {activeTransporter.plateNumber}
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-400 max-w-3xl mt-1">
              Active Carrier: <strong className="text-white">{activeTransporter.companyName}</strong> ({activeTransporter.driverName}) • Vehicle: <strong className="text-emerald-300">{activeTransporter.vehicleType}</strong> ({activeTransporter.maxCapacityTons}T Capacity)
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={activeTransporter.id}
              onChange={(e) => {
                const tr = transporters.find(t => t.id === e.target.value);
                if (tr) setActiveTransporter(tr);
              }}
              className="bg-slate-800 text-blue-300 border border-slate-700 font-bold text-xs px-3 py-2.5 rounded-xl"
            >
              {transporters.map(t => (
                <option key={t.id} value={t.id}>{t.companyName} ({t.plateNumber})</option>
              ))}
            </select>

            <button
              onClick={() => setShowRegisterModal(true)}
              className="bg-slate-800 hover:bg-slate-700 text-teal-300 border border-slate-700 font-bold text-xs px-3.5 py-2.5 rounded-xl flex items-center space-x-1.5"
            >
              <UserCheck className="w-4 h-4 text-teal-400" />
              <span>Join Transporter Network</span>
            </button>

            <button
              onClick={() => setShowPostJobModal(true)}
              className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow flex items-center space-x-1.5 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Post Freight Load</span>
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2 flex flex-wrap items-center gap-2 text-xs">
        <button
          onClick={() => setActiveTab('load_board')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'load_board'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Truck className="w-4 h-4" />
          <span>Freight Load Board ({jobs.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('gps_tracking')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'gps_tracking'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
          <span>GPS Live Telemetry</span>
        </button>

        <button
          onClick={() => setActiveTab('warehouses')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'warehouses'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <WarehouseIcon className="w-4 h-4 text-amber-300" />
          <span>Silos & Warehouses ({warehouses.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('transporters')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'transporters'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <UserCheck className="w-4 h-4 text-teal-300" />
          <span>Carrier Directory ({transporters.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('ai_optimizer')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'ai_optimizer'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>AI Smart Route & Cost Engine</span>
        </button>
      </div>

      {/* TAB 1: FREIGHT LOAD BOARD */}
      {activeTab === 'load_board' && (
        <div className="space-y-6">
          
          {/* Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Active Carrier Earnings</span>
                <DollarSign className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-emerald-400 font-mono">
                {(activeTransporter.totalEarningsRwf / 1000000).toFixed(1)}M RWF
              </div>
              <p className="text-[11px] text-slate-400 font-medium">{activeTransporter.completedJobsCount} Delivered Freight Trips</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Available Open Loads</span>
                <Truck className="w-4 h-4 text-blue-400" />
              </div>
              <div className="text-2xl font-black text-white">{jobs.filter(j => j.status === 'Open for Bidding').length} Freight Jobs</div>
              <p className="text-[11px] text-blue-300 font-medium">Ready for Driver Acceptance</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>RURA Carrier License</span>
                <ShieldCheck className="w-4 h-4 text-teal-400" />
              </div>
              <div className="text-lg font-black text-teal-300 font-mono">{activeTransporter.ruraLicenseNumber}</div>
              <p className="text-[11px] text-slate-400 font-medium">Verification: {activeTransporter.verificationStatus}</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Driver Rating</span>
                <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
              </div>
              <div className="text-2xl font-black text-amber-300">{activeTransporter.rating} / 5.0</div>
              <p className="text-[11px] text-slate-400 font-medium">From {activeTransporter.totalReviews} Shippers</p>
            </div>
          </div>

          {/* Freight Board List */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-black">Open Freight Requests & Deliveries</h3>
                <p className="text-xs text-slate-400">Agricultural produce, seeds, fertilizers, and cold-chain cargo moving across Rwanda.</p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search pickup/destination..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Jobs Cards */}
            <div className="space-y-4">
              {filteredJobs.map((job) => (
                <div key={job.id} className="bg-slate-800 border border-slate-700 rounded-3xl p-5 space-y-3 shadow-lg hover:border-blue-500/50 transition-all">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-700 pb-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-500/20 border border-blue-500/30 rounded-2xl flex items-center justify-center text-blue-400 font-bold">
                        <Truck className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-amber-400 font-mono font-bold text-xs">{job.jobCode}</span>
                          <span className="bg-slate-900 text-slate-300 border border-slate-700 text-[10px] px-2 py-0.5 rounded-full font-bold">
                            {job.requesterType}: {job.requesterName}
                          </span>
                        </div>
                        <h4 className="text-base font-black text-white">{job.quantityTons} Tons • {job.cargoType}</h4>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-xl font-black text-emerald-400 font-mono">
                        {job.quotedPriceRwf.toLocaleString()} RWF
                      </div>
                      <span className="text-[10px] text-emerald-300 font-bold block">Escrow: {job.paymentStatus}</span>
                    </div>
                  </div>

                  {/* Route & Requirements */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs bg-slate-900/60 p-3.5 rounded-2xl border border-slate-700/60">
                    <div className="space-y-1">
                      <span className="text-slate-400 font-bold block text-[10px]">📍 Pickup Location:</span>
                      <p className="text-white font-medium">{job.pickupLocation}</p>
                    </div>

                    <div className="space-y-1">
                      <span className="text-slate-400 font-bold block text-[10px]">🚩 Destination:</span>
                      <p className="text-white font-medium">{job.destination}</p>
                    </div>

                    <div className="space-y-1">
                      <span className="text-slate-400 font-bold block text-[10px]">🛣 Distance & Date:</span>
                      <p className="text-teal-300 font-mono font-bold">{job.distanceKm} km • {job.requestedDate}</p>
                    </div>
                  </div>

                  {/* Status & Action */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
                    <div className="flex items-center space-x-2 text-xs">
                      <span className={`px-3 py-1 rounded-full font-bold text-[11px] ${
                        job.status === 'Open for Bidding' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                        job.status === 'In Transit' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30' :
                        job.status === 'Delivered' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                        'bg-slate-700 text-slate-300'
                      }`}>
                        Status: {job.status}
                      </span>

                      {job.assignedTransporterName && (
                        <span className="text-slate-400 text-[11px]">
                          Assigned: <strong className="text-white">{job.assignedTransporterName}</strong>
                        </span>
                      )}
                    </div>

                    <div className="flex items-center space-x-2">
                      {job.status === 'Open for Bidding' && (
                        <button
                          onClick={() => handleAcceptJob(job)}
                          className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2 rounded-xl text-xs shadow"
                        >
                          Accept & Dispatch Load
                        </button>
                      )}

                      {job.status === 'Assigned' && (
                        <button
                          onClick={() => handleUpdateJobStatus(job.id, 'In Transit')}
                          className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded-xl text-xs shadow"
                        >
                          Confirm Cargo Picked Up
                        </button>
                      )}

                      {job.status === 'In Transit' && (
                        <>
                          <button
                            onClick={() => {
                              setTrackedJob(job);
                              setActiveTab('gps_tracking');
                              setIsSimulatingGps(true);
                            }}
                            className="bg-emerald-700 hover:bg-emerald-600 text-white font-bold px-3 py-2 rounded-xl text-xs flex items-center space-x-1"
                          >
                            <Radio className="w-3.5 h-3.5 animate-pulse" />
                            <span>Track GPS Live</span>
                          </button>

                          <button
                            onClick={() => handleUpdateJobStatus(job.id, 'Delivered')}
                            className="bg-teal-600 hover:bg-teal-500 text-white font-bold px-3 py-2 rounded-xl text-xs shadow"
                          >
                            Release Escrow Payment
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: GPS LIVE TELEMETRY & ROUTE TRACKING SIMULATOR */}
      {activeTab === 'gps_tracking' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center space-x-2">
                  <Radio className="w-5 h-5 text-emerald-400 animate-pulse" />
                  <h3 className="text-base font-black">GPS Real-time Freight Telemetry & Route Tracker</h3>
                </div>
                <p className="text-xs text-slate-400">Live vehicle location, speed monitoring, and arrival ETA for in-transit agricultural cargo.</p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setIsSimulatingGps(!isSimulatingGps)}
                  className={`font-bold text-xs px-4 py-2 rounded-xl shadow transition-all ${
                    isSimulatingGps ? 'bg-amber-600 text-white' : 'bg-emerald-600 text-white'
                  }`}
                >
                  {isSimulatingGps ? 'Pause GPS Telemetry' : 'Start Live GPS Movement'}
                </button>
              </div>
            </div>

            {/* Active Tracked Job Display */}
            <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-amber-400 font-mono font-bold text-xs">{trackedJob.jobCode}</span>
                  <h4 className="text-xl font-black text-white">{trackedJob.cargoType} ({trackedJob.quantityTons} Tons)</h4>
                  <p className="text-xs text-slate-300">Carrier: <strong className="text-emerald-300">{trackedJob.assignedTransporterName || 'Nyagatare Freight Logistics'}</strong> • Truck: <span className="font-mono text-white">{trackedJob.assignedVehiclePlate || 'RAF 481 A'}</span></p>
                </div>

                <div className="bg-slate-900 p-4 rounded-2xl border border-slate-700 flex items-center space-x-4 text-xs font-mono">
                  <div>
                    <span className="text-slate-400 block text-[10px]">CURRENT SPEED:</span>
                    <span className="text-xl font-black text-teal-300">{trackedJob.currentGps.speedKmH} km/h</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">ESTIMATED ETA:</span>
                    <span className="text-xl font-black text-amber-300">{trackedJob.estimatedEtaMinutes} Min</span>
                  </div>
                </div>
              </div>

              {/* Simulated Visual Route Progress Bar */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-slate-400">📍 {trackedJob.pickupLocation}</span>
                  <span className="text-emerald-300">📍 Current: {trackedJob.currentGps.locationName}</span>
                  <span className="text-slate-400">🏁 {trackedJob.destination}</span>
                </div>

                <div className="w-full bg-slate-900 h-4 rounded-full overflow-hidden p-0.5 border border-slate-700">
                  <div
                    className="bg-gradient-to-r from-blue-500 via-teal-400 to-emerald-400 h-full rounded-full transition-all duration-1000"
                    style={{ width: `${Math.min(100, Math.max(10, ((150 - trackedJob.estimatedEtaMinutes) / 150) * 100))}%` }}
                  />
                </div>
              </div>

              {/* Map & Coordinates Card */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3 text-xs">
                <div className="flex justify-between items-center text-slate-400 text-[11px] font-mono">
                  <span>GPS LATITUDE: {trackedJob.currentGps.lat.toFixed(4)}</span>
                  <span>GPS LONGITUDE: {trackedJob.currentGps.lng.toFixed(4)}</span>
                  <span>DELIVERY OTP CODE: <strong className="text-amber-400 font-black">{trackedJob.deliveryCode}</strong></span>
                </div>

                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 text-slate-300 text-xs leading-relaxed space-y-1">
                  <span className="text-emerald-400 font-bold block">🛡 MoMo Escrow Protection Status:</span>
                  <p>Freight fee of <strong className="text-white font-mono">{trackedJob.quotedPriceRwf.toLocaleString()} RWF</strong> is locked in MoMo Escrow. Funds will automatically release to transporter once delivery OTP ({trackedJob.deliveryCode}) is validated at destination.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: GRAIN SILOS & AGRICULTURAL WAREHOUSES */}
      {activeTab === 'warehouses' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-6">
            <div>
              <h3 className="text-base font-black">Strategic Agricultural Warehouses & Grain Silos</h3>
              <p className="text-xs text-slate-400">Track regional storage capacity, temperature, humidity levels, and warehouse receipt credit facilities.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {warehouses.map((wh) => {
                const occupancyPct = Math.round((wh.occupiedSpaceTons / wh.totalCapacityTons) * 100);
                return (
                  <div key={wh.id} className="bg-slate-800 border border-slate-700 rounded-3xl p-5 space-y-4 shadow-lg flex flex-col justify-between">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="bg-slate-900 text-emerald-300 border border-slate-700 text-[10px] font-bold px-2.5 py-1 rounded-full">
                          {wh.district} District
                        </span>
                        <span className="text-amber-300 font-mono font-bold text-xs">{wh.storageFeePerTonDayRwf} RWF / Ton / Day</span>
                      </div>

                      <h4 className="text-sm font-black text-white leading-snug">{wh.name}</h4>
                      <p className="text-xs text-slate-300">Manager: <strong className="text-white">{wh.managerName}</strong> ({wh.managerPhone})</p>

                      {/* Storage Gauge */}
                      <div className="space-y-1 pt-1">
                        <div className="flex justify-between text-[11px] font-bold">
                          <span className="text-slate-400">Space Occupied</span>
                          <span className="text-emerald-300">{wh.occupiedSpaceTons} / {wh.totalCapacityTons} Tons ({occupancyPct}%)</span>
                        </div>
                        <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden border border-slate-700">
                          <div
                            className={`h-full rounded-full ${occupancyPct > 80 ? 'bg-rose-500' : 'bg-emerald-500'}`}
                            style={{ width: `${occupancyPct}%` }}
                          />
                        </div>
                      </div>

                      {/* Telemetry Tele-sensors */}
                      <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                        <div className="bg-slate-900 p-2.5 rounded-xl flex items-center space-x-2">
                          <Thermometer className="w-4 h-4 text-amber-400" />
                          <div>
                            <span className="text-slate-400 block text-[9px]">TEMP</span>
                            <span className="font-bold text-white">{wh.temperatureCelsius}°C</span>
                          </div>
                        </div>

                        <div className="bg-slate-900 p-2.5 rounded-xl flex items-center space-x-2">
                          <Wind className="w-4 h-4 text-blue-400" />
                          <div>
                            <span className="text-slate-400 block text-[9px]">HUMIDITY</span>
                            <span className="font-bold text-white">{wh.humidityPercent}%</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-700">
                      <button className="w-full bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs py-2 rounded-xl transition-all">
                        Reserve Warehouse Storage Space
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: TRANSPORTER CARRIER DIRECTORY */}
      {activeTab === 'transporters' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <h3 className="text-base font-black">Licensed Agricultural Transporters Directory</h3>
            <p className="text-xs text-slate-400">RURA certified agricultural logistics carriers across Rwanda.</p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {transporters.map((tr) => (
                <div key={tr.id} className="bg-slate-800 border border-slate-700 rounded-3xl p-5 space-y-3 shadow-lg flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="bg-slate-900 text-teal-300 text-[10px] font-mono px-2 py-0.5 rounded-full border border-slate-700">
                        {tr.ruraLicenseNumber}
                      </span>
                      <span className="text-amber-300 font-bold text-xs flex items-center space-x-1">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                        <span>{tr.rating}</span>
                      </span>
                    </div>

                    <h4 className="text-sm font-black text-white">{tr.companyName}</h4>
                    <p className="text-xs text-slate-300">Driver: <strong className="text-white">{tr.driverName}</strong> • Phone: <span className="text-teal-300 font-mono">{tr.phone}</span></p>

                    <div className="text-xs text-slate-400 space-y-1">
                      <div>Vehicle: <strong className="text-white">{tr.vehicleType}</strong> ({tr.plateNumber})</div>
                      <div>Max Capacity: <span className="text-emerald-300 font-bold">{tr.maxCapacityTons} Tons</span></div>
                      <div>Base Rate: <span className="text-amber-300 font-mono">{tr.baseRatePerKmRwf} RWF / km</span></div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-700 flex justify-between items-center text-xs">
                    <span className="text-slate-400 font-bold">{tr.completedJobsCount} Delivered Jobs</span>
                    <button className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-1.5 rounded-xl text-[11px]">
                      Book Carrier
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: AI SMART ROUTE & COST ENGINE */}
      {activeTab === 'ai_optimizer' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex items-center space-x-2 text-amber-300 font-bold text-sm">
              <Sparkles className="w-5 h-5" />
              <span>AI Transport Route & Freight Cost Calculation Engine</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Gemini 3.6 Flash analyzes regional road terrain, cargo weight, cold-chain requirements, and fuel consumption to compute exact freight costs and optimal bypass routes in Rwanda.
            </p>

            {/* Input Form */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs bg-slate-800 p-4 rounded-2xl border border-slate-700">
              <div>
                <label className="block text-slate-400 font-bold mb-1">Pickup Location:</label>
                <input
                  type="text"
                  value={aiPickup}
                  onChange={(e) => setAiPickup(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">Destination:</label>
                <input
                  type="text"
                  value={aiDestination}
                  onChange={(e) => setAiDestination(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">Cargo Weight (Tons):</label>
                <input
                  type="number"
                  step="0.5"
                  value={aiTons}
                  onChange={(e) => setAiTons(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="flex items-end">
                <button
                  onClick={fetchAiLogisticsOptimization}
                  disabled={aiLoading}
                  className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 rounded-xl shadow transition-all"
                >
                  {aiLoading ? 'Optimizing Route...' : 'Calculate Route & Cost'}
                </button>
              </div>
            </div>

            {/* AI Result Card */}
            {aiResult && (
              <div className="bg-slate-800 border border-blue-500/30 rounded-3xl p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-700 pb-3">
                  <span className="text-sm font-black text-blue-300">Optimized Freight Logistics Plan</span>
                  <span className="text-xs font-bold text-amber-300">AI Confidence: {aiResult.aiConfidencePct}%</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div className="bg-slate-900 p-4 rounded-2xl space-y-1">
                    <span className="text-slate-400 block font-bold">Recommended Carrier:</span>
                    <span className="text-base font-black text-white">{aiResult.recommendedTransporterName}</span>
                    <span className="text-xs font-bold text-emerald-300 block">{aiResult.recommendedVehicleType}</span>
                  </div>

                  <div className="bg-slate-900 p-4 rounded-2xl space-y-1">
                    <span className="text-slate-400 block font-bold">Estimated Freight Cost:</span>
                    <span className="text-xl font-black text-emerald-400 font-mono">{aiResult.estimatedCostRwf.toLocaleString()} RWF</span>
                    <span className="text-[11px] text-slate-400 block">Fuel Cost Est: {aiResult.fuelCostEstimateRwf.toLocaleString()} RWF</span>
                  </div>

                  <div className="bg-slate-900 p-4 rounded-2xl space-y-1">
                    <span className="text-slate-400 block font-bold">Trip Duration & Savings:</span>
                    <span className="text-base font-black text-teal-300">{aiResult.estimatedDurationMinutes} Minutes</span>
                    <span className="text-xs font-bold text-amber-300 block">Save {aiResult.alternativeRouteSavingsMinutes} min via bypass</span>
                  </div>
                </div>

                <div className="bg-blue-950/40 border border-blue-500/30 p-4 rounded-2xl text-xs space-y-1">
                  <span className="text-blue-300 font-bold block">🗺 Route Summary & Road Conditions:</span>
                  <p className="text-white font-medium">{aiResult.optimalRouteSummary}</p>
                  <p className="text-slate-300 pt-1">{aiResult.roadConditionNote}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* POST FREIGHT JOB MODAL */}
      {showPostJobModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white">Post Freight Transport Load</h3>
              <button onClick={() => setShowPostJobModal(false)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <form onSubmit={handlePostJob} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Cargo Type:</label>
                  <select
                    value={newCargoType}
                    onChange={(e) => setNewCargoType(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="Maize Grain">Maize Grain</option>
                    <option value="Kinigi Seed Potatoes">Kinigi Seed Potatoes</option>
                    <option value="NPK Fertilizers">NPK Fertilizers</option>
                    <option value="Fresh Beans">Fresh Beans</option>
                    <option value="Dairy Milk Canisters">Dairy Milk</option>
                    <option value="Raw Coffee Cherries">Raw Coffee</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Weight (Tons):</label>
                  <input
                    type="number"
                    step="0.5"
                    value={newQuantityTons}
                    onChange={(e) => setNewQuantityTons(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Pickup Location:</label>
                <input
                  type="text"
                  value={newPickup}
                  onChange={(e) => setNewPickup(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Destination:</label>
                <input
                  type="text"
                  value={newDestination}
                  onChange={(e) => setNewDestination(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Date:</label>
                  <input
                    type="date"
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Quoted Price (RWF):</label>
                  <input
                    type="number"
                    value={newPriceRwf}
                    onChange={(e) => setNewPriceRwf(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>
              </div>

              <div className="pt-2 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowPostJobModal(false)}
                  className="flex-1 bg-slate-800 text-slate-300 font-bold py-2.5 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 rounded-xl shadow"
                >
                  Post & Lock MoMo Escrow
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REGISTER TRANSPORTER MODAL */}
      {showRegisterModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white">Transporter Network Registration</h3>
              <button onClick={() => setShowRegisterModal(false)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <form onSubmit={handleRegisterTransporter} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Company / Carrier Name:</label>
                <input
                  type="text"
                  value={regCompany}
                  onChange={(e) => setRegCompany(e.target.value)}
                  placeholder="e.g. Musanze Agro Freight Ltd"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Driver Name:</label>
                  <input
                    type="text"
                    value={regDriver}
                    onChange={(e) => setRegDriver(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Phone Number:</label>
                  <input
                    type="text"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Vehicle Type:</label>
                  <select
                    value={regVehicleType}
                    onChange={(e) => setRegVehicleType(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="Fuso 5-Ton Truck">Fuso 5-Ton Truck</option>
                    <option value="Daihatsu 3-Ton Truck">Daihatsu 3-Ton Truck</option>
                    <option value="Coaster Heavy Freight (10T)">Coaster Freight (10T)</option>
                    <option value="Refrigerated Cold-Chain Van (2T)">Cold-Chain Van (2T)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Plate Number:</label>
                  <input
                    type="text"
                    value={regPlate}
                    onChange={(e) => setRegPlate(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>
              </div>

              <div className="pt-2 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowRegisterModal(false)}
                  className="flex-1 bg-slate-800 text-slate-300 font-bold py-2.5 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-teal-600 hover:bg-teal-500 text-white font-bold py-2.5 rounded-xl shadow"
                >
                  Submit RURA License Info
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
