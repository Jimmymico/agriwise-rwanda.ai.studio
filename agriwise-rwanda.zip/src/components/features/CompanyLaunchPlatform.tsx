import React, { useState } from 'react';
import { User, Language } from '../../types';
import { translations } from '../../data/translations';
import {
  RELEASE_V1_HIGHLIGHTS,
  LAUNCH_CHECKLIST_ITEMS,
  ROADMAP_MILESTONES,
} from '../../data/launchData';
import {
  Rocket,
  CheckCircle2,
  Award,
  Sparkles,
  Bot,
  RefreshCw,
  Globe2,
  ShieldCheck,
  Server,
  Smartphone,
  Users,
  FileCheck,
  TrendingUp,
  Cpu,
  Zap,
  Building2,
  CheckSquare,
  ChevronRight,
  Send,
  Flag,
} from 'lucide-react';

interface CompanyLaunchPlatformProps {
  currentUser: User;
  language: Language;
}

export const CompanyLaunchPlatform: React.FC<CompanyLaunchPlatformProps> = ({
  currentUser,
  language,
}) => {
  const [activeTab, setActiveTab] = useState<
    'v1_release' | 'launch_checklist' | 'product_roadmap' | 'ceo_declaration' | 'ai_launch_copilot'
  >('v1_release');

  const [launchPhase, setLaunchPhase] = useState<string>('Official Version 1.0 Production Release');
  const [targetRegion, setTargetRegion] = useState<string>('Rwanda, Kenya & East African Community (EAC)');

  const [isAiLaunchConsulting, setIsAiLaunchConsulting] = useState<boolean>(false);
  const [aiLaunchResult, setAiLaunchResult] = useState<any>(null);

  const t = translations[language] || translations['rw'];

  const handleRunAiLaunchConsult = async () => {
    setIsAiLaunchConsulting(true);
    try {
      const res = await fetch('/api/ai/launch-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          launchPhase,
          targetRegion,
          language,
        }),
      });
      const data = await res.json();
      setAiLaunchResult(data);
    } catch (err) {
      console.error('Failed to run AI launch consult:', err);
    } finally {
      setIsAiLaunchConsulting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-emerald-500/15 border border-emerald-400/30 px-3 py-1 rounded-full text-xs font-bold text-emerald-300">
              <Rocket className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span>STEP 50 • OFFICIAL COMPANY LAUNCH & PRODUCT RELEASE</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              AGRIWISE Version 1.0 Official Production Release
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 font-medium leading-relaxed">
              Certified for full pan-African launch across 27 core modules, featuring offline polygon mapping, Gemini 3.6 AI vision diagnostics, MoMo escrow trading, and GKE serverless cloud infrastructure.
            </p>
          </div>

          {/* Official Launch Status Badge */}
          <div className="flex items-center gap-3 bg-slate-900/90 border border-emerald-500/50 p-3.5 rounded-2xl shadow-xl">
            <div className="w-10 h-10 rounded-xl bg-emerald-950 border border-emerald-500/50 flex items-center justify-center text-emerald-400 font-bold">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                Company Status
              </span>
              <span className="text-sm font-black text-emerald-400 font-mono">OFFICIALLY LAUNCHED</span>
            </div>
          </div>
        </div>

        {/* Global Key Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-6 pt-6 border-t border-emerald-500/20 text-xs">
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Platform Readiness</span>
            <span className="text-lg font-black text-emerald-400 font-mono">100% Ready</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Core Modules Built</span>
            <span className="text-lg font-black text-teal-400 font-mono">27 Modules</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Test Pass Rate</span>
            <span className="text-lg font-black text-emerald-300 font-mono">99.8% Passed</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Target Run-Rate ARR</span>
            <span className="text-lg font-black text-amber-400 font-mono">$1.51M / Yr</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">SLA Availability</span>
            <span className="text-lg font-black text-blue-400 font-mono">99.99% Uptime</span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex overflow-x-auto gap-2 bg-slate-900/90 p-2 rounded-2xl border border-slate-800 custom-scrollbar text-xs font-bold">
        {[
          { id: 'v1_release', label: 'Version 1.0 Release Notes', icon: Rocket },
          { id: 'launch_checklist', label: 'Launch Readiness Checklist', icon: CheckSquare },
          { id: 'product_roadmap', label: '5-Year Product Roadmap', icon: TrendingUp },
          { id: 'ceo_declaration', label: 'CEO Executive Declaration', icon: Award },
          { id: 'ai_launch_copilot', label: 'Gemini AI Launch Copilot', icon: Bot, badge: 'Gemini 3.6' },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.badge && (
                <span className="text-[9px] bg-emerald-500/30 text-emerald-300 border border-emerald-400/30 px-1.5 py-0.5 rounded-full uppercase">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: VERSION 1.0 RELEASE NOTES */}
      {activeTab === 'v1_release' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Rocket className="w-5 h-5 text-emerald-400" />
                AGRIWISE Version 1.0 Major System Deliverables
              </h2>
              <p className="text-xs text-slate-400">
                Summary of key capabilities production-deployed across the AGRIWISE ecosystem.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {RELEASE_V1_HIGHLIGHTS.map((highlight, idx) => (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-mono font-bold text-emerald-400 text-xs">
                      {highlight.moduleNumber}
                    </span>
                    <span className="bg-emerald-950 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                      {highlight.category}
                    </span>
                  </div>

                  <h3 className="font-bold text-white text-base leading-tight">
                    {highlight.featureName}
                  </h3>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {highlight.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs">
                  <span className="text-slate-400">Status:</span>
                  <span className="font-mono font-bold text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    {highlight.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: LAUNCH READINESS CHECKLIST */}
      {activeTab === 'launch_checklist' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <div className="p-3 bg-emerald-950 border border-emerald-500/30 rounded-2xl text-emerald-400">
              <CheckSquare className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">
                Final Launch Operations Sign-Off Checklist
              </h2>
              <p className="text-xs text-slate-400">
                100% completed verification across infrastructure, legal, compliance, security, and distribution.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {LAUNCH_CHECKLIST_ITEMS.map((item, idx) => (
              <div
                key={idx}
                className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 text-xs"
              >
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-emerald-400 block uppercase tracking-wider">
                    {item.category}
                  </span>
                  <h3 className="font-bold text-white text-sm">{item.itemTitle}</h3>
                  <span className="text-slate-400 text-[11px]">Owner: {item.owner}</span>
                </div>

                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3.5 py-1.5 rounded-full font-bold flex items-center gap-1.5 shrink-0">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  VERIFIED & COMPLETED
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: 5-YEAR PRODUCT ROADMAP */}
      {activeTab === 'product_roadmap' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-400" />
                AGRIWISE Future Product & Innovation Roadmap
              </h2>
              <p className="text-xs text-slate-400">
                Strategic evolution from Rwanda launch to pan-African agricultural intelligence engine.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {ROADMAP_MILESTONES.map((milestone, idx) => (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4"
              >
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-800 pb-3">
                  <div>
                    <span className="text-xs text-emerald-400 font-mono font-bold block">
                      Target Timeline: {milestone.targetDate}
                    </span>
                    <h3 className="font-black text-white text-lg font-mono">
                      {milestone.version} — {milestone.focusArea}
                    </h3>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-1">
                  {milestone.keyDeliverables.map((deliv, i) => (
                    <div
                      key={i}
                      className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 flex items-start gap-2 text-slate-300"
                    >
                      <ChevronRight className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{deliv}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: CEO DECLARATION */}
      {activeTab === 'ceo_declaration' && (
        <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 border border-emerald-500/40 rounded-3xl p-8 shadow-2xl space-y-6 relative overflow-hidden">
          <div className="flex items-center gap-4 border-b border-emerald-500/20 pb-6">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-0.5 shadow-xl">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-emerald-400 font-black text-2xl">
                AW
              </div>
            </div>
            <div>
              <span className="text-xs text-emerald-400 font-mono font-bold uppercase tracking-wider block">
                Official Executive Statement
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                AGRIWISE Executive Board & CEO Launch Certification
              </h2>
            </div>
          </div>

          <div className="space-y-4 text-sm text-slate-200 leading-relaxed">
            <p className="font-medium text-base text-emerald-300">
              "To our Farmers, Cooperative Leaders, Government Partners, Financial Partners, and Global Investors:"
            </p>

            <p>
              It is with immense pride that the Executive Leadership Team hereby certifies <strong>AGRIWISE Version 1.0</strong> as fully built, rigorously tested, secured, and ready for commercial production deployment across Rwanda and East Africa.
            </p>

            <p>
              By combining offline-first GIS polygon mapping, multi-lingual Kinyarwanda/Swahili Gemini 3.6 AI disease diagnostics, MTN Mobile Money escrow trading, and alternative credit scoring, AGRIWISE empowers millions of smallholder farmers while delivering high-margin enterprise software to agricultural supply chains.
            </p>

            <div className="p-4 bg-slate-950/80 border border-emerald-500/40 rounded-2xl text-xs font-mono text-emerald-400 font-bold">
              "AGRIWISE Version 1.0 is ready for production deployment."
            </div>
          </div>

          <div className="pt-6 border-t border-emerald-500/20 flex flex-wrap justify-between items-center gap-4 text-xs">
            <div>
              <span className="text-slate-400 block">Chief Executive Officer (CEO)</span>
              <span className="font-bold text-white">AGRIWISE Executive Committee</span>
            </div>

            <div className="text-right">
              <span className="text-slate-400 block">Certification Date</span>
              <span className="font-mono font-bold text-emerald-400">2026-08-06 • Kigali, Rwanda</span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: GEMINI AI LAUNCH COPILOT */}
      {activeTab === 'ai_launch_copilot' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950 border border-emerald-500/30 rounded-3xl p-6 shadow-2xl space-y-5">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-0.5 shadow-lg">
                <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                  <Bot className="w-6 h-6 text-emerald-400" />
                </div>
              </div>
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  Gemini 3.6 Flash CEO Launch & Growth Director
                </h2>
                <p className="text-xs text-slate-300">
                  Synthesize press release messaging, farmer cooperative rollout directives, and investor launch briefings.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Launch Phase & Milestones:
                </label>
                <input
                  type="text"
                  value={launchPhase}
                  onChange={(e) => setLaunchPhase(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl p-3 text-slate-100 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Target Launch Markets:
                </label>
                <input
                  type="text"
                  value={targetRegion}
                  onChange={(e) => setTargetRegion(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl p-3 text-slate-100 font-medium"
                />
              </div>
            </div>

            <button
              onClick={handleRunAiLaunchConsult}
              disabled={isAiLaunchConsulting}
              className="bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black px-6 py-3 rounded-2xl shadow-xl transition-all flex items-center gap-2 text-xs uppercase tracking-wide"
            >
              {isAiLaunchConsulting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Synthesizing CEO Launch Directives...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-slate-950" />
                  <span>Run Gemini Official Launch Briefing</span>
                </>
              )}
            </button>

            {aiLaunchResult && (
              <div className="bg-slate-950 border border-emerald-500/40 rounded-2xl p-5 space-y-4 animate-in fade-in text-xs">
                <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                  <span className="font-bold text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    Launch Strategy Verified: {aiLaunchResult.releaseStatus}
                  </span>
                  <span className="bg-emerald-950 border border-emerald-500/30 text-emerald-300 px-2.5 py-1 rounded-full font-mono font-bold">
                    Readiness: {aiLaunchResult.readinessScorePct}%
                  </span>
                </div>

                <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-emerald-300 font-medium leading-relaxed font-mono">
                  "{aiLaunchResult.ceoLaunchDeclaration}"
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                    <span className="font-bold text-teal-400 block">Marketing & Farmer Onboarding:</span>
                    <p className="text-slate-300">{aiLaunchResult.marketingDirectives}</p>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                    <span className="font-bold text-amber-400 block">Investor Deck Key Highlight:</span>
                    <p className="text-slate-300">{aiLaunchResult.investorHighlights}</p>
                  </div>
                </div>

                <div className="pt-2">
                  <span className="font-bold text-slate-300 block mb-1">Key Launch Verification Accomplishments:</span>
                  <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                    {aiLaunchResult.launchHighlights?.map((item: string, idx: number) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
