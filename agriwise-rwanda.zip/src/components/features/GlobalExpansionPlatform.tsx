import React, { useState } from 'react';
import { User, Language } from '../../types';
import { translations } from '../../data/translations';
import {
  GLOBAL_COUNTRIES,
  CROSS_BORDER_TRADE_LISTINGS,
  INTERNATIONAL_PARTNERS,
  GLOBAL_REGIONAL_ANALYTICS,
} from '../../data/globalExpansionData';
import {
  Globe,
  Globe2,
  Building2,
  Ship,
  Coins,
  ShieldCheck,
  Bot,
  Sparkles,
  TrendingUp,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  Users,
  FileCheck2,
  ArrowRight,
  RefreshCw,
  Search,
  Lock,
  Layers,
  Flag,
  ChevronRight,
  ExternalLink,
  Sliders,
  DollarSign,
  Activity
} from 'lucide-react';

interface GlobalExpansionPlatformProps {
  currentUser: User;
  language: Language;
}

export const GlobalExpansionPlatform: React.FC<GlobalExpansionPlatformProps> = ({
  currentUser,
  language,
}) => {
  const [activeTab, setActiveTab] = useState<
    'country_nodes' | 'regional_gis' | 'cross_border_trade' | 'ai_trade_advisor' | 'partners' | 'security_sovereignty'
  >('country_nodes');

  const [selectedCountryCode, setSelectedCountryCode] = useState<string>('RW');
  const [tradeQuery, setTradeQuery] = useState<string>(
    'What are the phytosanitary certification and EAC customs tariff requirements for exporting Rwandan Irish Potatoes and Coffee to Kenya and Uganda?'
  );
  const [isAiConsulting, setIsAiConsulting] = useState<boolean>(false);
  const [aiResponse, setAiResponse] = useState<any>(null);

  const t = translations[language] || translations['rw'];

  const selectedCountry =
    GLOBAL_COUNTRIES.find((c) => c.code === selectedCountryCode) || GLOBAL_COUNTRIES[0];

  const handleAskGlobalAi = async () => {
    setIsAiConsulting(true);
    try {
      const res = await fetch('/api/ai/global-intelligence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetCountry: selectedCountry.name,
          query: tradeQuery,
          language,
        }),
      });
      const data = await res.json();
      setAiResponse(data);
    } catch (err) {
      console.error('Failed to query global AI:', err);
    } finally {
      setIsAiConsulting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-950 via-emerald-950 to-blue-950 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-emerald-500/15 border border-emerald-400/30 px-3 py-1 rounded-full text-xs font-bold text-emerald-300">
              <Globe className="w-3.5 h-3.5 text-emerald-400 animate-spin-slow" />
              <span>STEP 41 • MULTI-COUNTRY PLATFORM & GLOBAL EXPANSION ARCHITECTURE</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              AGRIWISE Global Operating System
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 font-medium leading-relaxed">
              Multi-tenant global SaaS platform architecture connecting African smallholders, regional trade corridors (EAC & AfCFTA), multi-currency payments, local agricultural ministries, and multilateral development partners.
            </p>
          </div>

          {/* Quick Active Country Selector Badge */}
          <div className="flex items-center gap-3 bg-slate-900/90 border border-emerald-500/40 p-3.5 rounded-2xl shadow-lg">
            <span className="text-3xl">{selectedCountry.flagEmoji}</span>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                Active Country Node
              </span>
              <span className="text-sm font-black text-white">{selectedCountry.name} ({selectedCountry.currencyCode})</span>
            </div>
          </div>
        </div>

        {/* Global Key Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-emerald-500/20 text-xs">
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Global Farmer Network</span>
            <span className="text-lg font-black text-emerald-400 font-mono">27.9M Farmers</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Mapped Arable Land</span>
            <span className="text-lg font-black text-teal-400 font-mono">31.8M Hectares</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Active Country Nodes</span>
            <span className="text-lg font-black text-amber-400 font-mono">8 African Nations</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Cross-Border Volume</span>
            <span className="text-lg font-black text-blue-400 font-mono">$1.305 Billion</span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex overflow-x-auto gap-2 bg-slate-900/90 p-2 rounded-2xl border border-slate-800 custom-scrollbar text-xs font-bold">
        {[
          { id: 'country_nodes', label: 'Country Nodes (8)', icon: Globe2 },
          { id: 'regional_gis', label: 'Global GIS & Analytics', icon: Layers },
          { id: 'cross_border_trade', label: 'Cross-Border Trade (AfCFTA)', icon: Ship },
          { id: 'ai_trade_advisor', label: 'AI Global Trade Advisor', icon: Bot, badge: 'Gemini 3.6' },
          { id: 'partners', label: 'Multilateral Partners (FAO/WFP)', icon: Building2 },
          { id: 'security_sovereignty', label: 'Data Sovereignty & Security', icon: ShieldCheck },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.badge && (
                <span className="text-[9px] bg-emerald-500/30 text-emerald-300 border border-emerald-400/30 px-1.5 py-0.5 rounded-full uppercase">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: COUNTRY NODES */}
      {activeTab === 'country_nodes' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Flag className="w-5 h-5 text-emerald-400" />
                Active Multi-Tenant Country Nodes
              </h2>
              <p className="text-xs text-slate-400">
                Configure country-specific currency rates, official local languages, ministry regulations, and payment gateways.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {GLOBAL_COUNTRIES.map((c) => {
              const isSelected = selectedCountryCode === c.code;
              return (
                <div
                  key={c.id}
                  onClick={() => setSelectedCountryCode(c.code)}
                  className={`p-5 rounded-2xl border transition-all cursor-pointer relative overflow-hidden space-y-3 ${
                    isSelected
                      ? 'bg-slate-900 border-emerald-500 ring-2 ring-emerald-500/30 shadow-xl'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                  }`}
                >
                  {/* Status Badge */}
                  <div className="flex justify-between items-center">
                    <span className="text-3xl">{c.flagEmoji}</span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        c.status === 'Active Node'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          : c.status === 'Pilot Phase'
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                          : 'bg-blue-500/20 text-blue-300 border-blue-500/30'
                      }`}
                    >
                      {c.status}
                    </span>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-base flex items-center gap-2">
                      {c.name} ({c.code})
                    </h3>
                    <p className="text-xs text-emerald-400 font-mono font-semibold">
                      1 USD = {c.exchangeRateToUsd.toLocaleString()} {c.currencyCode}
                    </p>
                  </div>

                  <div className="space-y-1 text-xs text-slate-300 pt-2 border-t border-slate-800">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Farmers:</span>
                      <span className="font-mono font-bold text-slate-200">
                        {(c.totalFarmersRegistered / 1000000).toFixed(2)}M
                      </span>
                    </div>

                    <div className="flex justify-between">
                      <span className="text-slate-400">Arable Land:</span>
                      <span className="font-mono font-bold text-slate-200">
                        {(c.totalHectaresMapped / 1000000).toFixed(2)}M Ha
                      </span>
                    </div>

                    <div className="flex justify-between">
                      <span className="text-slate-400">Cooperatives:</span>
                      <span className="font-mono font-bold text-slate-200">
                        {c.activeCooperativesCount.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <div className="pt-2">
                    <span className="text-[10px] font-bold text-slate-400 block mb-1">Payment Options:</span>
                    <div className="flex flex-wrap gap-1">
                      {c.paymentGateways.map((gw, i) => (
                        <span key={i} className="text-[9px] bg-slate-950 text-slate-300 border border-slate-800 px-1.5 py-0.5 rounded-md">
                          {gw}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Detailed Selected Country Config Dashboard */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <span className="text-4xl">{selectedCountry.flagEmoji}</span>
                <div>
                  <h3 className="text-lg font-bold text-white">
                    {selectedCountry.name} Node Configuration Overview
                  </h3>
                  <p className="text-xs text-slate-400">
                    Data Residency: <span className="text-emerald-400 font-mono">{selectedCountry.dataResidencyRegion}</span>
                  </p>
                </div>
              </div>

              <span className="text-xs bg-emerald-950 border border-emerald-500/40 text-emerald-300 px-3 py-1 rounded-xl font-mono">
                Ministry: {selectedCountry.agriMinistryName}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
                <span className="font-bold text-slate-300 block flex items-center gap-1.5">
                  <Globe className="w-4 h-4 text-emerald-400" />
                  Official Languages
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {selectedCountry.officialLanguages.map((lang, idx) => (
                    <span key={idx} className="bg-slate-900 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded-xl font-bold">
                      {lang}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
                <span className="font-bold text-slate-300 block flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-teal-400" />
                  Primary Strategic Crops
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {selectedCountry.primaryCrops.map((crop, idx) => (
                    <span key={idx} className="bg-slate-900 text-teal-300 border border-teal-500/30 px-2.5 py-1 rounded-xl font-bold">
                      {crop}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
                <span className="font-bold text-slate-300 block flex items-center gap-1.5">
                  <Coins className="w-4 h-4 text-amber-400" />
                  Local Currency & Gateways
                </span>
                <p className="text-slate-300">
                  Code: <strong className="text-white font-mono">{selectedCountry.currencyCode}</strong> ({selectedCountry.currencySymbol})
                </p>
                <p className="text-slate-400 text-[11px]">
                  Exchange: 1 USD = {selectedCountry.exchangeRateToUsd} {selectedCountry.currencyCode}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: GLOBAL REGIONAL ANALYTICS & GIS */}
      {activeTab === 'regional_gis' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-emerald-400" />
                Global Regional Agricultural Intelligence Map
              </h2>
              <p className="text-xs text-slate-400">
                Macro regional grain balances, arable land aggregation, and climate risk early warnings across East and West African agricultural corridors.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {GLOBAL_REGIONAL_ANALYTICS.map((reg, idx) => (
              <div key={idx} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                <div className="flex justify-between items-start border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="text-base font-bold text-white">{reg.regionName}</h3>
                    <span className="text-xs text-slate-400">{reg.memberCountriesCount} Member Nations</span>
                  </div>

                  <span
                    className={`text-xs font-bold px-3 py-1 rounded-full border ${
                      reg.droughtRiskAlertLevel === 'Moderate'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                        : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                    }`}
                  >
                    Drought Risk: {reg.droughtRiskAlertLevel}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
                    <span className="text-slate-400 block">Smallholder Farmers</span>
                    <span className="text-base font-black text-emerald-400 font-mono">
                      {(reg.totalSmallholderFarmers / 1000000).toFixed(1)}M
                    </span>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
                    <span className="text-slate-400 block">Arable Land</span>
                    <span className="text-base font-black text-teal-400 font-mono">
                      {(reg.totalArableLandHectares / 1000000).toFixed(1)}M Ha
                    </span>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
                    <span className="text-slate-400 block">Annual Grain Yield</span>
                    <span className="text-base font-black text-amber-400 font-mono">
                      {(reg.annualGrainProductionTons / 1000000).toFixed(1)}M Tons
                    </span>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
                    <span className="text-slate-400 block">Trade Volume</span>
                    <span className="text-base font-black text-blue-400 font-mono">
                      ${(reg.crossBorderTradeVolumeUsd / 1000000).toFixed(0)}M USD
                    </span>
                  </div>
                </div>

                <div className="pt-2 text-xs">
                  <span className="text-slate-400 font-bold block mb-1">Dominant Climate Zones:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {reg.dominantClimateZones.map((cz, i) => (
                      <span key={i} className="bg-slate-950 text-slate-300 border border-slate-800 px-2.5 py-1 rounded-xl">
                        {cz}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: CROSS BORDER TRADE */}
      {activeTab === 'cross_border_trade' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Ship className="w-5 h-5 text-emerald-400" />
                Cross-Border Agricultural Trade Portal (AfCFTA & EAC)
              </h2>
              <p className="text-xs text-slate-400">
                Duty-free commodity shipments with verified phytosanitary certificates, EAC origin declaration, and cross-border MoMo Escrow protection.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {CROSS_BORDER_TRADE_LISTINGS.map((listing) => (
              <div
                key={listing.id}
                className="bg-slate-900 border border-slate-800 hover:border-emerald-500/40 rounded-3xl p-5 shadow-xl space-y-4 transition-all"
              >
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-emerald-950 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                      <Ship className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-white text-base">{listing.cropName}</h3>
                      <p className="text-xs text-slate-400 flex items-center gap-2">
                        <span>{listing.originCountryCode} ➔ {listing.destinationCountryCode}</span>
                        <span>•</span>
                        <span className="text-emerald-400 font-semibold">{listing.quantityTons} Tons</span>
                      </p>
                    </div>
                  </div>

                  <span
                    className={`text-xs font-bold px-3 py-1 rounded-full border ${
                      listing.shipmentStatus === 'Delivered'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                        : listing.shipmentStatus === 'In Transit'
                        ? 'bg-blue-500/20 text-blue-300 border-blue-500/30'
                        : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                    }`}
                  >
                    {listing.shipmentStatus}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                  <div>
                    <span className="text-slate-400 block">Exporter:</span>
                    <span className="font-bold text-slate-200">{listing.exporterName}</span>
                  </div>

                  <div>
                    <span className="text-slate-400 block">Importer:</span>
                    <span className="font-bold text-slate-200">{listing.importerName}</span>
                  </div>

                  <div>
                    <span className="text-slate-400 block">Value (USD / Local):</span>
                    <span className="font-black text-emerald-400 font-mono">
                      ${listing.totalValueUsd.toLocaleString()} USD ({listing.currencyLocal})
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-400 block">Est. Arrival Date:</span>
                    <span className="font-bold text-slate-300">{listing.estimatedArrivalDate}</span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800 text-xs">
                  <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
                      <CheckCircle2 className="w-4 h-4" />
                      Phytosanitary Clean Certificate
                    </span>
                    <span className="flex items-center gap-1.5 text-teal-400 font-medium">
                      <FileCheck2 className="w-4 h-4" />
                      EAC Customs Duty-Free Cleared
                    </span>
                  </div>

                  <button className="bg-slate-950 hover:bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-3.5 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5">
                    <span>View Waybill & Customs Dossier</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: AI GLOBAL TRADE ADVISOR */}
      {activeTab === 'ai_trade_advisor' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950 border border-emerald-500/30 rounded-3xl p-6 shadow-2xl space-y-5">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-0.5 shadow-lg">
                <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                  <Bot className="w-6 h-6 text-emerald-400" />
                </div>
              </div>
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  Gemini 3.6 Flash Global Trade & Expansion Copilot
                </h2>
                <p className="text-xs text-slate-300">
                  Ask AI about phytosanitary clearances, AfCFTA tariffs, cross-border logistics routes, and currency exchange risk mitigation across African markets.
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-bold text-slate-300">
                Target Export Market / Expansion Query:
              </label>
              <textarea
                value={tradeQuery}
                onChange={(e) => setTradeQuery(e.target.value)}
                rows={3}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-2xl p-4 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
                placeholder="Ask about cross-border agricultural exports, tariffs, or phytosanitary standards..."
              />

              <button
                onClick={handleAskGlobalAi}
                disabled={isAiConsulting}
                className="bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black px-6 py-3 rounded-2xl shadow-xl transition-all flex items-center gap-2 text-xs uppercase tracking-wide"
              >
                {isAiConsulting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Analyzing International Trade Protocol...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-slate-950" />
                    <span>Consult Global Trade AI</span>
                  </>
                )}
              </button>
            </div>

            {aiResponse && (
              <div className="bg-slate-950 border border-emerald-500/40 rounded-2xl p-5 space-y-4 animate-in fade-in">
                <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                  <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    AI Analysis Result for {aiResponse.targetCountry}
                  </span>
                  <span className="text-[10px] bg-slate-900 border border-slate-800 text-slate-300 px-2.5 py-1 rounded-full font-mono">
                    Tariff: {aiResponse.customsTariffPct}% • Risk: {aiResponse.currencyExchangeRiskScore}
                  </span>
                </div>

                <div className="space-y-2 text-xs">
                  <p className="text-slate-200 leading-relaxed font-medium">
                    {aiResponse.strategicAdvisoryText}
                  </p>

                  <div className="pt-2">
                    <span className="font-bold text-slate-300 block mb-1">Recommended Transport Corridor:</span>
                    <p className="text-emerald-300 font-mono text-[11px] bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                      {aiResponse.recommendedLogisticsRoute}
                    </p>
                  </div>

                  <div className="pt-2">
                    <span className="font-bold text-slate-300 block mb-1">Phytosanitary Clearance Steps:</span>
                    <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                      {aiResponse.phytosanitaryRequirements?.map((req: string, i: number) => (
                        <li key={i}>{req}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: MULTILATERAL PARTNERS */}
      {activeTab === 'partners' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-400" />
                Multilateral Development & Donor Partners
              </h2>
              <p className="text-xs text-slate-400">
                Grant funding programs, food security reserves, and smallholder empowerment initiatives funded by FAO, WFP, AfDB, and AGRA.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {INTERNATIONAL_PARTNERS.map((partner) => (
              <div
                key={partner.id}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4"
              >
                <div className="flex justify-between items-start border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="font-bold text-white text-base">{partner.name}</h3>
                    <span className="text-xs text-emerald-400 font-semibold">{partner.type}</span>
                  </div>

                  <span className="text-xs bg-slate-800 text-slate-200 border border-slate-700 px-3 py-1 rounded-full font-bold">
                    {partner.status}
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed font-medium">
                  {partner.focusArea}
                </p>

                <div className="grid grid-cols-2 gap-3 text-xs bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
                  <div>
                    <span className="text-slate-400 block">Grant Funding Allocated:</span>
                    <span className="font-black text-emerald-400 font-mono text-sm">
                      ${(partner.grantFundingUsd / 1000000).toFixed(1)}M USD
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-400 block">Beneficiary Farmers:</span>
                    <span className="font-black text-teal-400 font-mono text-sm">
                      {(partner.beneficiaryFarmersCount / 1000000).toFixed(2)}M Farmers
                    </span>
                  </div>
                </div>

                <div className="text-xs pt-1">
                  <span className="text-slate-400 font-bold block mb-1">Participating Country Nodes:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {partner.participatingCountries.map((cc, i) => (
                      <span key={i} className="bg-slate-950 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-md font-mono font-bold">
                        {cc}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 6: SECURITY & DATA SOVEREIGNTY */}
      {activeTab === 'security_sovereignty' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <div className="p-3 bg-emerald-950 border border-emerald-500/30 rounded-2xl text-emerald-400">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">
                Multi-Tenant Data Sovereignty & Encryption Governance
              </h2>
              <p className="text-xs text-slate-400">
                Guaranteeing farmer data privacy, national agricultural sovereignty, and GDPR compliance across all operating country nodes.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
              <span className="font-bold text-emerald-400 block flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4" />
                Data Residency Isolation
              </span>
              <p className="text-slate-300">
                Farmer profiles, land polygon GPS coordinates, and yield logs are pinned strictly to the country node's cloud region (e.g. Kigali, Nairobi, Lagos).
              </p>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
              <span className="font-bold text-teal-400 block flex items-center gap-1.5">
                <Lock className="w-4 h-4" />
                AES-256 Payload Encryption
              </span>
              <p className="text-slate-300">
                All financial, cross-border escrow, and Mobile Money API transactions are protected with end-to-end hardware security modules (HSM).
              </p>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
              <span className="font-bold text-amber-400 block flex items-center gap-1.5">
                <Users className="w-4 h-4" />
                Hierarchical RBAC Controls
              </span>
              <p className="text-slate-300">
                Strict boundary enforcement separating Global Admin, Country Ministry Admin, District Agronomist, Cooperative Leader, and Individual Farmer.
              </p>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
