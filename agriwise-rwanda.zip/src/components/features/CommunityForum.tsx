import React, { useState } from 'react';
import { CommunityPost, User, Language } from '../../types';
import { INITIAL_POSTS } from '../../data/mockData';
import { translations } from '../../data/translations';
import {
  Users,
  MessageSquare,
  ThumbsUp,
  Plus,
  CheckCircle2,
  HelpCircle,
  ShieldCheck
} from 'lucide-react';

interface CommunityForumProps {
  currentUser: User;
  language: Language;
}

export const CommunityForum: React.FC<CommunityForumProps> = ({ currentUser, language }) => {
  const t = translations[language];
  const [posts, setPosts] = useState<CommunityPost[]>(INITIAL_POSTS);
  const [showPostModal, setShowPostModal] = useState(false);

  const [postTitle, setPostTitle] = useState('');
  const [postContent, setPostContent] = useState('');

  const handleLike = (id: string) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, likes: p.likes + 1 } : p))
    );
  };

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!postTitle.trim() || !postContent.trim()) return;

    const created: CommunityPost = {
      id: `post_${Date.now()}`,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorRole: currentUser.role,
      authorDistrict: currentUser.district,
      authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      title: postTitle,
      content: postContent,
      category: 'General Agronomy',
      likes: 1,
      commentsCount: 0,
      createdAt: 'Just now',
      isSolved: false,
    };

    setPosts([created, ...posts]);
    setPostTitle('');
    setPostContent('');
    setShowPostModal(false);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-white">
        <div>
          <div className="inline-flex items-center space-x-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold mb-1">
            <Users className="w-3.5 h-3.5 text-emerald-400" />
            <span>Inzobere n'Abahinzi Network</span>
          </div>
          <h2 className="text-xl font-black">{t.navCommunity}</h2>
          <p className="text-xs text-slate-400">Ask questions, share experiences, and get verified RAB expert answers.</p>
        </div>

        <button
          onClick={() => setShowPostModal(true)}
          className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg flex items-center space-x-2 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Ask Question / Post</span>
        </button>
      </div>

      {/* Feed */}
      <div className="space-y-4">
        {posts.map((post) => (
          <div
            key={post.id}
            className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-3 text-white"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <img
                  src={post.authorAvatar}
                  alt={post.authorName}
                  className="w-10 h-10 rounded-xl object-cover border border-emerald-500/40"
                />
                <div>
                  <h4 className="font-bold text-sm text-white">{post.authorName}</h4>
                  <p className="text-[10px] text-slate-400">
                    📍 {post.authorDistrict} District • <span className="text-emerald-400 capitalize">{post.authorRole}</span> • {post.createdAt}
                  </p>
                </div>
              </div>

              {post.isSolved && (
                <span className="bg-emerald-950 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center space-x-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  <span>Expert Answered</span>
                </span>
              )}
            </div>

            <div className="space-y-1">
              <h3 className="text-sm font-black text-white">{post.title}</h3>
              <p className="text-xs text-slate-300 leading-relaxed">{post.content}</p>
            </div>

            {/* Verified Expert Answer Box */}
            {post.verifiedExpertAnswer && (
              <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-2xl text-xs space-y-1">
                <span className="font-bold text-emerald-400 flex items-center space-x-1">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Verified RAB Agronomist Answer:</span>
                </span>
                <p className="text-slate-200 text-[11px] leading-relaxed">
                  {post.verifiedExpertAnswer}
                </p>
              </div>
            )}

            {/* Post Footer */}
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <button
                onClick={() => handleLike(post.id)}
                className="flex items-center space-x-1.5 hover:text-emerald-400 transition-colors"
              >
                <ThumbsUp className="w-4 h-4" />
                <span className="font-bold">{post.likes} Helpful</span>
              </button>

              <div className="flex items-center space-x-1">
                <MessageSquare className="w-4 h-4 text-blue-400" />
                <span>{post.commentsCount} Comments</span>
              </div>
            </div>

          </div>
        ))}
      </div>

      {/* Post Modal */}
      {showPostModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full text-white space-y-4 shadow-2xl">
            <h3 className="text-base font-black">Ask Farmer Community</h3>

            <form onSubmit={handleCreatePost} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Title / Question:</label>
                <input
                  type="text"
                  value={postTitle}
                  onChange={(e) => setPostTitle(e.target.value)}
                  placeholder="e.g. Best fertilizer timing for Irish potatoes?"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Detailed Explanation:</label>
                <textarea
                  rows={4}
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                  placeholder="Explain your farm situation, location, and symptoms..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div className="pt-3 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowPostModal(false)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 rounded-xl shadow"
                >
                  Publish Post
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
