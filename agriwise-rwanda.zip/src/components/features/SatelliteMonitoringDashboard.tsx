import React, { useState } from 'react';
import {
  User,
  Language,
  FarmSatelliteMonitoringRecord,
  SatelliteNdviTimelinePoint
} from '../../types';
import {
  MOCK_FARM_SATELLITE_RECORDS,
  MOCK_NDVI_TIMELINE
} from '../../data/mockSatelliteData';
import { translations } from '../../data/translations';
import {
  Globe,
  Radio,
  Sparkles,
  Map,
  Activity,
  Layers,
  Search,
  Droplets,
  Sun,
  ShieldAlert,
  BarChart3,
  TrendingUp,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Eye,
  FileSpreadsheet,
  Zap,
  Sliders,
  Cpu
} from 'lucide-react';

interface SatelliteMonitoringDashboardProps {
  currentUser: User;
  language: Language;
}

export const SatelliteMonitoringDashboard: React.FC<SatelliteMonitoringDashboardProps> = ({
  currentUser,
  language,
}) => {
  const t = translations[language];

  // Active Tab
  const [activeTab, setActiveTab] = useState<'satellite_gis' | 'ndvi_analytics' | 'drought_early_warning' | 'ai_yield_forecast' | 'gov_satellite'>('satellite_gis');

  // Datasets
  const [farmRecords] = useState<FarmSatelliteMonitoringRecord[]>(MOCK_FARM_SATELLITE_RECORDS);
  const [selectedFarm, setSelectedFarm] = useState<FarmSatelliteMonitoringRecord>(MOCK_FARM_SATELLITE_RECORDS[0]);
  const [ndviTimeline] = useState<SatelliteNdviTimelinePoint[]>(MOCK_NDVI_TIMELINE);

  // Map Filter Layer
  const [activeBandLayer, setActiveBandLayer] = useState<'ndvi' | 'ndwi' | 'chlorophyll' | 'rgb'>('ndvi');

  // AI Satellite Prediction State
  const [aiLoading, setAiLoading] = useState(false);
  const [aiPrediction, setAiPrediction] = useState<any>(null);

  // Toast State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Run AI Satellite Multispectral Analysis
  const runAiSatelliteAnalysis = async (farm: FarmSatelliteMonitoringRecord) => {
    setAiLoading(true);
    try {
      const res = await fetch('/api/ai/satellite-yield', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          farmName: farm.farmName,
          district: farm.district,
          cropType: farm.cropType,
          hectares: farm.farmAreaHectares,
          currentNdvi: farm.ndviScore,
          ndwiWaterStress: farm.ndwiWaterStressIndex,
          soilMoisturePct: farm.soilMoisturePct,
          language
        }),
      });
      const data = await res.json();
      setAiPrediction(data);
    } catch (e) {
      console.error('AI Satellite Yield error:', e);
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-emerald-600 text-white font-bold text-xs px-4 py-3 rounded-2xl shadow-2xl flex items-center space-x-2 animate-bounce">
          <CheckCircle2 className="w-5 h-5 text-white" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Satellite Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden text-white">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center space-x-2 bg-teal-500/20 text-teal-300 border border-teal-500/30 px-3 py-1 rounded-full text-xs font-bold mb-2">
              <Globe className="w-4 h-4 text-teal-400" />
              <span>Sentinel-2 Multispectral & PlanetScope Constellation Telemetry</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Satellite Farm Monitoring & Advanced Remote Sensing
            </h1>

            <p className="text-xs sm:text-sm text-slate-400 max-w-3xl mt-1">
              Real-time spaceborne optical imagery analysis, NDVI vegetation vigor tracking, water stress detection, drought risk heatmaps, and AI yield forecasting for Rwanda.
            </p>
          </div>

          <div className="flex items-center space-x-2 bg-slate-800 border border-slate-700 px-3.5 py-2.5 rounded-2xl text-xs font-mono">
            <Radio className="w-4 h-4 text-teal-400 animate-pulse" />
            <span className="text-slate-300">Constellation Status: <strong className="text-emerald-400">ONLINE (Sentinel-2)</strong></span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2 flex flex-wrap items-center gap-2 text-xs">
        <button
          onClick={() => setActiveTab('satellite_gis')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'satellite_gis'
              ? 'bg-teal-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Map className="w-4 h-4 text-emerald-300" />
          <span>Interactive GIS Map</span>
        </button>

        <button
          onClick={() => setActiveTab('ndvi_analytics')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'ndvi_analytics'
              ? 'bg-teal-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Activity className="w-4 h-4 text-amber-300" />
          <span>NDVI & Water Stress</span>
        </button>

        <button
          onClick={() => setActiveTab('drought_early_warning')}
          className={`flex-1 min-w-[150px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'drought_early_warning'
              ? 'bg-teal-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Droplets className="w-4 h-4 text-blue-300" />
          <span>Drought Early Warning</span>
        </button>

        <button
          onClick={() => setActiveTab('ai_yield_forecast')}
          className={`flex-1 min-w-[150px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'ai_yield_forecast'
              ? 'bg-teal-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>AI Yield Forecast</span>
        </button>

        <button
          onClick={() => setActiveTab('gov_satellite')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'gov_satellite'
              ? 'bg-teal-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Layers className="w-4 h-4 text-purple-300" />
          <span>National Macro Layers</span>
        </button>
      </div>

      {/* TAB 1: INTERACTIVE SATELLITE GIS MAP & SPECTRAL BANDS */}
      {activeTab === 'satellite_gis' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-black flex items-center space-x-2">
                  <Globe className="w-5 h-5 text-teal-400" />
                  <span>Multispectral Satellite Farm Layer Canvas</span>
                </h3>
                <p className="text-xs text-slate-400">High-resolution multispectral band rendering for registered farm boundaries.</p>
              </div>

              {/* Band Layer Toggles */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setActiveBandLayer('ndvi')}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
                    activeBandLayer === 'ndvi' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  NDVI (Vegetation Vigor)
                </button>

                <button
                  onClick={() => setActiveBandLayer('ndwi')}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
                    activeBandLayer === 'ndwi' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  NDWI (Water Stress)
                </button>

                <button
                  onClick={() => setActiveBandLayer('chlorophyll')}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
                    activeBandLayer === 'chlorophyll' ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Canopy Chlorophyll
                </button>

                <button
                  onClick={() => setActiveBandLayer('rgb')}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
                    activeBandLayer === 'rgb' ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  True Color (RGB)
                </button>
              </div>
            </div>

            {/* Simulated Satellite Map Canvas Grid */}
            <div className="bg-slate-950 border border-slate-800 rounded-3xl p-6 min-h-[420px] relative overflow-hidden flex flex-col justify-between">
              
              <div className="absolute inset-0 bg-[radial-gradient(#0f172a_1px,transparent_1px)] [background-size:16px_16px] opacity-60 pointer-events-none" />

              {/* Map Controls */}
              <div className="relative z-10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 bg-slate-900/90 backdrop-blur border border-slate-800 p-3 rounded-2xl text-xs">
                <div className="flex items-center space-x-2">
                  <Eye className="w-4 h-4 text-teal-400" />
                  <span className="font-bold">Active Layer: <strong className="text-teal-300 uppercase">{activeBandLayer}</strong></span>
                </div>
                <span className="text-slate-400 font-mono text-[11px]">Orbit Resolution: 10m Ground Sample Distance (GSD)</span>
              </div>

              {/* Farm Grid Representation */}
              <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
                {farmRecords.map((farm) => (
                  <div
                    key={farm.id}
                    onClick={() => {
                      setSelectedFarm(farm);
                      runAiSatelliteAnalysis(farm);
                    }}
                    className={`p-4 rounded-2xl border text-xs space-y-3 cursor-pointer transition-all shadow-xl ${
                      selectedFarm.id === farm.id
                        ? 'bg-slate-900 border-teal-500 shadow-teal-500/10'
                        : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex justify-between items-start font-bold">
                      <span className="text-white text-sm">{farm.farmName}</span>
                      <span className="text-emerald-400 font-mono">{farm.farmAreaHectares} Ha</span>
                    </div>

                    <p className="text-[11px] text-slate-300">{farm.farmerName} • {farm.district} ({farm.cropType})</p>

                    <div className="grid grid-cols-2 gap-2 font-mono text-[11px] bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                      <div>
                        <span className="text-slate-400 block text-[10px]">NDVI VIGOR:</span>
                        <span className="text-emerald-400 font-bold">{farm.ndviScore}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">PREDICTED YIELD:</span>
                        <span className="text-teal-300 font-bold">{farm.predictedYieldTonsPerHa} T/Ha</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Bottom GIS Status Footer */}
              <div className="relative z-10 bg-slate-900/90 backdrop-blur border border-slate-800 p-3 rounded-2xl flex justify-between items-center text-xs text-slate-300">
                <span className="font-mono text-[11px]">Selected Farm: <strong className="text-white">{selectedFarm.farmName}</strong></span>
                <span className="text-emerald-400 font-bold">Sentinel-2 Pass Date: {selectedFarm.lastSatellitePassDate}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: NDVI VEGETATION INDEX & WATER STRESS ANALYTICS */}
      {activeTab === 'ndvi_analytics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Active Farm Detail Panel */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4 lg:col-span-1">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-black text-emerald-400">{selectedFarm.farmName}</h3>
                <p className="text-xs text-slate-400">{selectedFarm.farmerName} • {selectedFarm.district} District</p>
              </div>

              <div className="space-y-3 text-xs font-mono">
                <div className="bg-slate-800 p-3.5 rounded-2xl border border-slate-700 flex justify-between items-center">
                  <span className="text-slate-400">NDVI Vigor Score:</span>
                  <span className="text-2xl font-black text-emerald-400">{selectedFarm.ndviScore}</span>
                </div>

                <div className="bg-slate-800 p-3.5 rounded-2xl border border-slate-700 flex justify-between items-center">
                  <span className="text-slate-400">NDWI Water Stress:</span>
                  <span className="text-xl font-black text-blue-300">{selectedFarm.ndwiWaterStressIndex}</span>
                </div>

                <div className="bg-slate-800 p-3.5 rounded-2xl border border-slate-700 flex justify-between items-center">
                  <span className="text-slate-400">Soil Moisture:</span>
                  <span className="text-xl font-black text-teal-300">{selectedFarm.soilMoisturePct}%</span>
                </div>

                <div className="bg-slate-800 p-3.5 rounded-2xl border border-slate-700 flex justify-between items-center">
                  <span className="text-slate-400">Canopy Chlorophyll:</span>
                  <span className="text-xl font-black text-amber-300">{selectedFarm.canopyChlorophyllMgM2} mg/m²</span>
                </div>
              </div>

              <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 text-xs space-y-2">
                <span className="text-teal-400 font-bold block">💡 Satellite Agronomic Recommendation:</span>
                <p className="text-slate-300 leading-relaxed">{selectedFarm.recommendedAction}</p>
              </div>
            </div>

            {/* Historical NDVI Timeline Chart Simulation */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4 lg:col-span-2">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-black">Seasonal NDVI Vegetation Growth Curve</h3>
                <p className="text-xs text-slate-400">Historical canopy chlorophyll progression over the 2026 Season A cultivation cycle.</p>
              </div>

              <div className="space-y-3">
                {ndviTimeline.map((pt, idx) => (
                  <div key={idx} className="bg-slate-800 p-3 rounded-2xl border border-slate-700 flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400 font-bold">{pt.date}</span>
                    <div className="w-48 bg-slate-900 h-2.5 rounded-full overflow-hidden mx-3">
                      <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${pt.ndviScore * 100}%` }} />
                    </div>
                    <span className="text-emerald-400 font-bold text-sm">{pt.ndviScore} NDVI</span>
                    <span className="text-slate-400 text-[11px]">{pt.rainfallMm} mm Rain</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: DROUGHT EARLY WARNING & CLIMATE VULNERABILITY */}
      {activeTab === 'drought_early_warning' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-6">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-base font-black flex items-center space-x-2">
                <Droplets className="w-5 h-5 text-blue-400" />
                <span>Satellite Drought & Rainfall Deficit Early Warning System</span>
              </h3>
              <p className="text-xs text-slate-400">Combines Sentinel-2 optical imagery with soil moisture satellite radar sensors to detect dry spells before visual crop damage occurs.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-slate-800 border border-slate-700 rounded-3xl p-5 space-y-3 text-xs shadow-lg">
                <span className="bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold px-2.5 py-1 rounded-full text-[10px]">
                  HIGH DROUGHT RISK ZONE
                </span>
                <h4 className="text-base font-black text-white">Eastern Province (Nyagatare & Kayonza)</h4>
                <p className="text-slate-300">21 Consecutive days with &lt; 5mm rainfall. Soil moisture levels dropped to 38%.</p>
                <div className="bg-slate-900 p-3 rounded-2xl border border-slate-700 text-[11px] text-amber-300">
                  ⚠️ Action Required: Activate valley dam solar irrigation pumps.
                </div>
              </div>

              <div className="bg-slate-800 border border-slate-700 rounded-3xl p-5 space-y-3 text-xs shadow-lg">
                <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold px-2.5 py-1 rounded-full text-[10px]">
                  MODERATE RISK ZONE
                </span>
                <h4 className="text-base font-black text-white">Southern Province (Huye & Gisagara)</h4>
                <p className="text-slate-300">Intermittent rainfall. Marshland paddy water levels stable at 82% NDWI.</p>
                <div className="bg-slate-900 p-3 rounded-2xl border border-slate-700 text-[11px] text-teal-300">
                  ℹ️ Action Required: Monitor Akanyaru river intake valves.
                </div>
              </div>

              <div className="bg-slate-800 border border-slate-700 rounded-3xl p-5 space-y-3 text-xs shadow-lg">
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold px-2.5 py-1 rounded-full text-[10px]">
                  OPTIMAL MOISTURE ZONE
                </span>
                <h4 className="text-base font-black text-white">Northern Province (Musanze & Nyabihu)</h4>
                <p className="text-slate-300">Volcanic soil moisture optimal at 62%. Canopy chlorophyll high.</p>
                <div className="bg-slate-900 p-3 rounded-2xl border border-slate-700 text-[11px] text-emerald-300">
                  ✅ Status: Optimal potato seed growth conditions.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: AI SATELLITE YIELD PREDICTION ENGINE */}
      {activeTab === 'ai_yield_forecast' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-black flex items-center space-x-2">
                  <Sparkles className="w-5 h-5 text-amber-400" />
                  <span>AI Crop Yield Forecast Engine (Gemini 3.6 Flash)</span>
                </h3>
                <p className="text-xs text-slate-400">Deep learning predictions based on satellite multispectral index history.</p>
              </div>

              <button
                onClick={() => runAiSatelliteAnalysis(selectedFarm)}
                disabled={aiLoading}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2 rounded-xl shadow transition-all flex items-center space-x-1.5"
              >
                {aiLoading ? (
                  <span>Analyzing Orbital Bands...</span>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>Run AI Yield Forecast</span>
                  </>
                )}
              </button>
            </div>

            {/* AI Yield Prediction Output */}
            {aiPrediction ? (
              <div className="bg-slate-800 border border-emerald-500/30 rounded-3xl p-6 space-y-4">
                <div className="flex justify-between items-center border-b border-slate-700 pb-3">
                  <span className="text-sm font-black text-emerald-300">Yield Forecast Output</span>
                  <span className="text-xs font-mono font-bold text-amber-300">AI Confidence: {aiPrediction.aiConfidencePct}%</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
                  <div className="bg-slate-900 p-4 rounded-2xl space-y-1 border border-slate-700">
                    <span className="text-slate-400 block text-[10px]">PROJECTED TON / HA:</span>
                    <span className="text-3xl font-black text-emerald-400">{aiPrediction.predictedYieldTonsPerHa} T/Ha</span>
                  </div>

                  <div className="bg-slate-900 p-4 rounded-2xl space-y-1 border border-slate-700">
                    <span className="text-slate-400 block text-[10px]">TOTAL HARVEST FORECAST:</span>
                    <span className="text-2xl font-black text-teal-300">{aiPrediction.totalPredictedHarvestTons} Tons</span>
                  </div>

                  <div className="bg-slate-900 p-4 rounded-2xl space-y-1 border border-slate-700">
                    <span className="text-slate-400 block text-[10px]">HISTORICAL VARIANCE:</span>
                    <span className="text-2xl font-black text-blue-300">+{aiPrediction.historicalYieldVariancePct}% Harvest</span>
                  </div>
                </div>

                <div className="bg-emerald-950/40 border border-emerald-500/30 p-4 rounded-2xl text-xs space-y-1">
                  <span className="text-emerald-300 font-bold block">🛰 AI Satellite Agronomic Insight:</span>
                  <p className="text-slate-200 leading-relaxed">{aiPrediction.satelliteActionableInsight}</p>
                </div>
              </div>
            ) : (
              <div className="bg-slate-800 p-8 rounded-3xl border border-slate-700 text-center text-xs text-slate-400 space-y-2">
                <Sparkles className="w-8 h-8 text-amber-400 mx-auto animate-bounce" />
                <p>Click "Run AI Yield Forecast" to calculate exact harvest metrics using Sentinel-2 orbital imagery.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: GOVERNMENT NATIONAL SATELLITE AGGREGATION */}
      {activeTab === 'gov_satellite' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-6">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-base font-black flex items-center space-x-2">
                <Layers className="w-5 h-5 text-purple-400" />
                <span>National Macro Satellite Aggregation for MINAGRI</span>
              </h3>
              <p className="text-xs text-slate-400">1.45 Million Cultivated Hectares monitored in real-time across Rwanda.</p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
              <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 space-y-1">
                <span className="text-slate-400 block text-[10px]">NATIONAL NDVI AVG</span>
                <span className="text-2xl font-black text-emerald-400">0.72</span>
              </div>

              <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 space-y-1">
                <span className="text-slate-400 block text-[10px]">OPTIMAL GROWTH AREA</span>
                <span className="text-2xl font-black text-teal-300">1.12M Ha</span>
              </div>

              <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 space-y-1">
                <span className="text-slate-400 block text-[10px]">WATER STRESS AREA</span>
                <span className="text-2xl font-black text-amber-300">210K Ha</span>
              </div>

              <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 space-y-1">
                <span className="text-slate-400 block text-[10px]">PREDICTED HARVEST</span>
                <span className="text-2xl font-black text-blue-300">3.82M Tons</span>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
