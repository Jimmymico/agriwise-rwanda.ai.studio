import React, { useState } from 'react';
import { RegisteredFarm, Language, GPSPoint } from '../../types';
import { Tractor, Plus, Edit2, Trash2, MapPin, Layers, Droplets, Sun, ShieldCheck, CheckCircle, X, Compass, Image } from 'lucide-react';

interface FarmRegistrationProps {
  farms: RegisteredFarm[];
  onAddFarm: (farm: RegisteredFarm) => void;
  onUpdateFarm: (farm: RegisteredFarm) => void;
  onDeleteFarm: (farmId: string) => void;
  language: Language;
}

export const FarmRegistration: React.FC<FarmRegistrationProps> = ({
  farms,
  onAddFarm,
  onUpdateFarm,
  onDeleteFarm,
  language,
}) => {
  const [selectedFarm, setSelectedFarm] = useState<RegisteredFarm | null>(farms[0] || null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  // Form State
  const [farmName, setFarmName] = useState('');
  const [district, setDistrict] = useState('Musanze');
  const [sector, setSector] = useState('Kinigi');
  const [cell, setCell] = useState('Kampanga');
  const [sizeHectares, setSizeHectares] = useState(1.5);
  const [ownership, setOwnership] = useState<RegisteredFarm['landOwnershipType']>('Owned (Title Deed)');
  const [soilType, setSoilType] = useState<RegisteredFarm['soilType']>('Volcanic (Rich Organic)');
  const [waterSource, setWaterSource] = useState<RegisteredFarm['waterSource']>('Rainfed');
  const [farmingMethod, setFarmingMethod] = useState<RegisteredFarm['farmingMethod']>('Organic Certified');
  const [photoUrl, setPhotoUrl] = useState('https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&auto=format&fit=crop&q=80');

  // Polygon boundary simulator
  const defaultBoundary: GPSPoint[] = [
    { lat: -1.432, lng: 29.589 },
    { lat: -1.435, lng: 29.593 },
    { lat: -1.439, lng: 29.588 },
    { lat: -1.433, lng: 29.584 },
  ];

  const resetForm = () => {
    setFarmName('');
    setDistrict('Musanze');
    setSector('Kinigi');
    setCell('Kampanga');
    setSizeHectares(1.5);
    setOwnership('Owned (Title Deed)');
    setSoilType('Volcanic (Rich Organic)');
    setWaterSource('Rainfed');
    setFarmingMethod('Organic Certified');
    setPhotoUrl('https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&auto=format&fit=crop&q=80');
    setIsEditing(false);
  };

  const handleOpenEdit = (farm: RegisteredFarm) => {
    setFarmName(farm.farmName);
    setDistrict(farm.district);
    setSector(farm.sector);
    setCell(farm.cell || '');
    setSizeHectares(farm.sizeHectares);
    setOwnership(farm.landOwnershipType);
    setSoilType(farm.soilType);
    setWaterSource(farm.waterSource);
    setFarmingMethod(farm.farmingMethod);
    setPhotoUrl(farm.photoUrls[0] || '');
    setIsEditing(true);
    setShowAddModal(true);
  };

  const handleSaveFarm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!farmName.trim()) return;

    if (isEditing && selectedFarm) {
      const updated: RegisteredFarm = {
        ...selectedFarm,
        farmName,
        district,
        sector,
        cell,
        sizeHectares: Number(sizeHectares),
        landOwnershipType: ownership,
        soilType,
        waterSource,
        farmingMethod,
        photoUrls: [photoUrl],
      };
      onUpdateFarm(updated);
      setSelectedFarm(updated);
    } else {
      const newFarm: RegisteredFarm = {
        id: `farm_${Date.now()}`,
        farmerId: 'user_1',
        farmName,
        district,
        sector,
        cell,
        sizeHectares: Number(sizeHectares),
        gpsCoordinates: defaultBoundary,
        landOwnershipType: ownership,
        soilType,
        waterSource,
        farmingMethod,
        photoUrls: [photoUrl],
        createdAt: new Date().toISOString().split('T')[0],
        healthScore: 85,
      };
      onAddFarm(newFarm);
      setSelectedFarm(newFarm);
    }

    setShowAddModal(false);
    resetForm();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-md">
        <div>
          <div className="flex items-center space-x-2">
            <Tractor className="w-6 h-6 text-emerald-400" />
            <h1 className="text-xl font-bold text-slate-100">
              {language === 'rw' ? 'Kwandikisha & Gucunga Amasambu' : 'Digital Farm Registration Manager'}
            </h1>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            {language === 'rw'
              ? 'Andikisha isambu yawe, ubuso mu ma hekitari, uburyo bwo gufumbira, no kuziba imbibi za GPS.'
              : 'Register and manage your farm plots with GPS boundaries, soil profiles, and RAB land deeds.'}
          </p>
        </div>

        <button
          onClick={() => {
            resetForm();
            setShowAddModal(true);
          }}
          className="flex items-center space-x-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-lg transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>{language === 'rw' ? 'Andikisha Isambu Nshya' : 'Register New Farm Plot'}</span>
        </button>
      </div>

      {/* Farm Selection Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {farms.map((farm) => {
          const isSelected = selectedFarm?.id === farm.id;
          return (
            <div
              key={farm.id}
              onClick={() => setSelectedFarm(farm)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden ${
                isSelected
                  ? 'bg-slate-900 border-emerald-500 shadow-xl ring-1 ring-emerald-500/50'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="relative h-32 rounded-xl overflow-hidden mb-3">
                <img
                  src={farm.photoUrls[0] || 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&auto=format&fit=crop&q=80'}
                  alt={farm.farmName}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
                <span className="absolute top-2 right-2 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500 text-slate-950 shadow">
                  Health: {farm.healthScore}%
                </span>
                <span className="absolute bottom-2 left-2 text-xs font-bold text-white flex items-center space-x-1">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{farm.district}, {farm.sector}</span>
                </span>
              </div>

              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-100 truncate">{farm.farmName}</h3>
                <span className="text-xs font-bold text-emerald-400">{farm.sizeHectares} Ha</span>
              </div>

              <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800 pt-2">
                <span>{farm.soilType.split(' ')[0]} Soil</span>
                <span>{farm.waterSource}</span>
                <span className="text-emerald-300 font-medium">{farm.landOwnershipType.split(' ')[0]}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Farm Detail View */}
      {selectedFarm && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <div className="flex items-center space-x-3">
                <h2 className="text-xl font-bold text-slate-100">{selectedFarm.farmName}</h2>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {selectedFarm.farmingMethod}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                📍 {selectedFarm.cell || 'Kampanga'} Cell, {selectedFarm.sector} Sector, {selectedFarm.district} District • Created {selectedFarm.createdAt}
              </p>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => handleOpenEdit(selectedFarm)}
                className="flex items-center space-x-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold"
              >
                <Edit2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Edit Plot</span>
              </button>
              {farms.length > 1 && (
                <button
                  onClick={() => {
                    onDeleteFarm(selectedFarm.id);
                    setSelectedFarm(farms.find((f) => f.id !== selectedFarm.id) || null);
                  }}
                  className="flex items-center space-x-1.5 px-3 py-2 bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800/50 rounded-xl text-xs font-semibold"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex items-center space-x-3">
              <Compass className="w-8 h-8 text-emerald-400" />
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold">Total Plot Area</span>
                <p className="text-base font-bold text-slate-100">{selectedFarm.sizeHectares} Hectares</p>
              </div>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex items-center space-x-3">
              <Layers className="w-8 h-8 text-amber-400" />
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold">Soil Classification</span>
                <p className="text-xs font-bold text-slate-100">{selectedFarm.soilType}</p>
              </div>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex items-center space-x-3">
              <Droplets className="w-8 h-8 text-cyan-400" />
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold">Water Source</span>
                <p className="text-xs font-bold text-slate-100">{selectedFarm.waterSource}</p>
              </div>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex items-center space-x-3">
              <ShieldCheck className="w-8 h-8 text-emerald-400" />
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold">Land Ownership</span>
                <p className="text-xs font-bold text-slate-100">{selectedFarm.landOwnershipType}</p>
              </div>
            </div>
          </div>

          {/* GPS Coordinates & Map Boundary Section */}
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-emerald-400" />
                <span>GPS Boundary Coordinates ({selectedFarm.gpsCoordinates.length} Boundary Points)</span>
              </h4>
              <span className="text-[11px] text-emerald-400 font-mono">Precision: ± 0.5m</span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {selectedFarm.gpsCoordinates.map((pt, idx) => (
                <div key={idx} className="p-2 bg-slate-900 border border-slate-800 rounded-lg text-[11px] font-mono text-slate-300">
                  Point #{idx + 1}: {pt.lat.toFixed(4)}, {pt.lng.toFixed(4)}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Farm Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-2xl p-6 space-y-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => {
                setShowAddModal(false);
                resetForm();
              }}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
                <Tractor className="w-5 h-5 text-emerald-400" />
                <span>{isEditing ? 'Edit Farm Plot Registration' : 'Register New Farm Plot'}</span>
              </h3>
            </div>

            <form onSubmit={handleSaveFarm} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Farm Plot Name</label>
                <input
                  type="text"
                  value={farmName}
                  onChange={(e) => setFarmName(e.target.value)}
                  placeholder="e.g. Kinigi Volcanic Terrace Plot #2"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">District</label>
                  <input
                    type="text"
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Sector</label>
                  <input
                    type="text"
                    value={sector}
                    onChange={(e) => setSector(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Cell</label>
                  <input
                    type="text"
                    value={cell}
                    onChange={(e) => setCell(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Farm Size (Hectares)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={sizeHectares}
                    onChange={(e) => setSizeHectares(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Land Ownership Type</label>
                  <select
                    value={ownership}
                    onChange={(e) => setOwnership(e.target.value as RegisteredFarm['landOwnershipType'])}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  >
                    <option value="Owned (Title Deed)">Owned (Title Deed)</option>
                    <option value="Leased / Rented">Leased / Rented</option>
                    <option value="Customary / Family">Customary / Family</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Soil Type</label>
                  <select
                    value={soilType}
                    onChange={(e) => setSoilType(e.target.value as RegisteredFarm['soilType'])}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  >
                    <option value="Volcanic (Rich Organic)">Volcanic (Rich Organic)</option>
                    <option value="Sandy Loam">Sandy Loam</option>
                    <option value="Clay Heavy">Clay Heavy</option>
                    <option value="Lateritic Slopes">Lateritic Slopes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Water Source</label>
                  <select
                    value={waterSource}
                    onChange={(e) => setWaterSource(e.target.value as RegisteredFarm['waterSource'])}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  >
                    <option value="Rainfed">Rainfed</option>
                    <option value="Marshland Canal">Marshland Canal</option>
                    <option value="River Pump">River Pump</option>
                    <option value="Solar Drip Irrigation">Solar Drip Irrigation</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Farming Method</label>
                  <select
                    value={farmingMethod}
                    onChange={(e) => setFarmingMethod(e.target.value as RegisteredFarm['farmingMethod'])}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  >
                    <option value="Organic Certified">Organic Certified</option>
                    <option value="Conventional">Conventional</option>
                    <option value="Integrated / Mixed">Integrated / Mixed</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Photo Image URL</label>
                <input
                  type="text"
                  value={photoUrl}
                  onChange={(e) => setPhotoUrl(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white font-semibold rounded-xl hover:bg-emerald-500 shadow-lg"
                >
                  {isEditing ? 'Save Changes' : 'Register Farm'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
