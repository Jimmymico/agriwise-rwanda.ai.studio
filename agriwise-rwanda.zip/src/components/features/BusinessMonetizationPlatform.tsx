import React, { useState } from 'react';
import { User, Language } from '../../types';
import { translations } from '../../data/translations';
import {
  PRICING_PLANS,
  REVENUE_STREAMS,
  FINANCIAL_KPIS,
  FIVE_YEAR_PROJECTIONS,
} from '../../data/businessData';
import {
  DollarSign,
  TrendingUp,
  BarChart3,
  Award,
  Users,
  Building2,
  Globe,
  Zap,
  CheckCircle2,
  Sparkles,
  Bot,
  RefreshCw,
  PieChart,
  ShieldCheck,
  Briefcase,
  ArrowRight,
  Layers,
  Percent,
  Coins,
  CreditCard,
  Target,
} from 'lucide-react';

interface BusinessMonetizationPlatformProps {
  currentUser: User;
  language: Language;
}

export const BusinessMonetizationPlatform: React.FC<BusinessMonetizationPlatformProps> = ({
  currentUser,
  language,
}) => {
  const [activeTab, setActiveTab] = useState<
    'pricing' | 'revenue_streams' | 'financial_kpis' | 'five_year_plan' | 'ai_business_copilot'
  >('pricing');

  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('annual');
  const [targetCustomerSegment, setTargetCustomerSegment] = useState<string>('Cooperative & Smallholder Farmers');
  const [monetizationFocus, setMonetizationFocus] = useState<string>(
    'Freemium Conversion, MoMo Escrow Take Rate & Bank Micro-loan Commissions'
  );

  const [isAiConsulting, setIsAiConsulting] = useState<boolean>(false);
  const [aiBizResult, setAiBizResult] = useState<any>(null);

  const t = translations[language] || translations['rw'];

  const handleRunAiBusinessConsult = async () => {
    setIsAiConsulting(true);
    try {
      const res = await fetch('/api/ai/business-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetCustomerSegment,
          monetizationFocus,
          language,
        }),
      });
      const data = await res.json();
      setAiBizResult(data);
    } catch (err) {
      console.error('Failed to run AI business consult:', err);
    } finally {
      setIsAiConsulting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-amber-500/15 border border-amber-400/30 px-3 py-1 rounded-full text-xs font-bold text-amber-300">
              <DollarSign className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>STEP 48 • BUSINESS MODEL & MONETIZATION STRATEGY</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              AGRIWISE Commercial Architecture & Financial Model
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 font-medium leading-relaxed">
              Freemium smallholder inclusion, tiered SaaS subscription plans, marketplace MoMo escrow commissions (2.5%), bank credit referral fees, and pan-African unit economics.
            </p>
          </div>

          {/* Quick ARR Badge */}
          <div className="flex items-center gap-3 bg-slate-900/90 border border-amber-500/40 p-3.5 rounded-2xl shadow-xl">
            <div className="w-10 h-10 rounded-xl bg-amber-950 border border-amber-500/40 flex items-center justify-center text-amber-400 font-bold">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                Run-Rate ARR Target
              </span>
              <span className="text-sm font-black text-amber-400 font-mono">
                ${(FINANCIAL_KPIS.arrUsd / 1000000).toFixed(2)}M / Year
              </span>
            </div>
          </div>
        </div>

        {/* Financial Highlights Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-6 pt-6 border-t border-amber-500/20 text-xs">
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Monthly Recurring (MRR)</span>
            <span className="text-lg font-black text-amber-400 font-mono">
              ${(FINANCIAL_KPIS.mrrUsd / 1000).toFixed(0)}k / mo
            </span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Gross Profit Margin</span>
            <span className="text-lg font-black text-emerald-400 font-mono">
              {FINANCIAL_KPIS.grossMarginPct}% Margin
            </span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">LTV : CAC Ratio</span>
            <span className="text-lg font-black text-teal-400 font-mono">
              {FINANCIAL_KPIS.ltvToCacRatio}x Ratio
            </span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">CAC Payback Period</span>
            <span className="text-lg font-black text-blue-400 font-mono">
              {FINANCIAL_KPIS.paybackPeriodMonths} Months
            </span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Monthly User Churn</span>
            <span className="text-lg font-black text-slate-200 font-mono">
              {FINANCIAL_KPIS.monthlyChurnRatePct}% Churn
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex overflow-x-auto gap-2 bg-slate-900/90 p-2 rounded-2xl border border-slate-800 custom-scrollbar text-xs font-bold">
        {[
          { id: 'pricing', label: 'Subscription Tiers & Freemium', icon: CreditCard },
          { id: 'revenue_streams', label: '5 Core Revenue Streams', icon: PieChart },
          { id: 'financial_kpis', label: 'Unit Economics & KPIs', icon: BarChart3 },
          { id: 'five_year_plan', label: '5-Year Pan-African Growth', icon: TrendingUp },
          { id: 'ai_business_copilot', label: 'Gemini AI Business Copilot', icon: Bot, badge: 'Gemini 3.6' },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-amber-600 to-emerald-600 text-white shadow-lg'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.badge && (
                <span className="text-[9px] bg-emerald-500/30 text-emerald-300 border border-emerald-400/30 px-1.5 py-0.5 rounded-full uppercase">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: SUBSCRIPTION TIERS & FREEMIUM */}
      {activeTab === 'pricing' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-amber-400" />
                SaaS Subscription Tiers & Product-Led Growth (PLG)
              </h2>
              <p className="text-xs text-slate-400">
                Smallholder farmers access free core tools; premium tiers monetize cooperatives, commercial estates, and government agencies.
              </p>
            </div>

            {/* Monthly / Annual Billing Toggle */}
            <div className="flex items-center gap-2 bg-slate-900 p-1.5 rounded-2xl border border-slate-800 text-xs font-bold">
              <button
                onClick={() => setBillingCycle('monthly')}
                className={`px-3 py-1.5 rounded-xl transition-all ${
                  billingCycle === 'monthly' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400'
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setBillingCycle('annual')}
                className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
                  billingCycle === 'annual' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400'
                }`}
              >
                <span>Annual</span>
                <span className="text-[9px] bg-emerald-950 text-emerald-300 px-1.5 py-0.5 rounded-full border border-emerald-500/30 uppercase">
                  Save 17%
                </span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {PRICING_PLANS.map((plan) => {
              const price = billingCycle === 'annual'
                ? Math.round(plan.priceAnnualUsd / 12)
                : plan.priceMonthlyUsd;

              return (
                <div
                  key={plan.id}
                  className={`bg-slate-900 border rounded-3xl p-5 shadow-xl flex flex-col justify-between space-y-4 relative ${
                    plan.recommendedBadge
                      ? 'border-amber-500/60 ring-2 ring-amber-500/20'
                      : 'border-slate-800'
                  }`}
                >
                  {plan.recommendedBadge && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-amber-500 to-emerald-500 text-slate-950 text-[9px] font-black uppercase px-3 py-1 rounded-full shadow-lg">
                      {plan.recommendedBadge}
                    </span>
                  )}

                  <div className="space-y-2">
                    <h3 className="font-bold text-white text-base">{plan.name}</h3>
                    <p className="text-[11px] text-slate-400 min-h-[32px]">{plan.targetAudience}</p>

                    <div className="pt-2">
                      <span className="text-3xl font-black text-white font-mono">${price}</span>
                      <span className="text-xs text-slate-400 font-medium"> / month</span>
                    </div>

                    <div className="text-[11px] space-y-1 text-slate-300 pt-2 border-t border-slate-800 font-mono">
                      <div className="flex justify-between">
                        <span>AI Queries:</span>
                        <span className="font-bold text-emerald-400">{plan.includedAiQueriesPerMonth}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Farm Polygons:</span>
                        <span className="font-bold text-teal-400">{plan.maxMappedFarms}</span>
                      </div>
                    </div>

                    <ul className="space-y-1.5 pt-3 text-[11px] text-slate-300">
                      {plan.features.map((feat, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button className="w-full bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-white font-bold py-2.5 rounded-xl text-xs transition-all">
                    {plan.priceMonthlyUsd === 0 ? 'Start Free' : 'Select Plan'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: REVENUE STREAMS */}
      {activeTab === 'revenue_streams' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <PieChart className="w-5 h-5 text-amber-400" />
                Diversified Pan-African Revenue Engine
              </h2>
              <p className="text-xs text-slate-400">
                Combining recurring SaaS subscriptions, transaction commissions, loan referral fees, and enterprise API licensing.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {REVENUE_STREAMS.map((stream, idx) => (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4"
              >
                <div className="border-b border-slate-800 pb-3 flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-white text-base">{stream.streamName}</h3>
                    <span className="text-xs text-amber-400 font-mono font-bold">
                      ${(stream.mrrContributionUsd / 1000).toFixed(1)}k / mo MRR
                    </span>
                  </div>

                  <span className="bg-amber-950 border border-amber-500/30 text-amber-300 px-2.5 py-1 rounded-full text-xs font-mono font-bold">
                    {stream.percentageOfTotal}%
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">{stream.description}</p>

                <div className="flex justify-between items-center text-xs pt-2 border-t border-slate-800 font-mono">
                  <span className="text-slate-400">YoY Growth Rate:</span>
                  <span className="font-bold text-emerald-400">+{stream.annualGrowthRatePct}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: FINANCIAL KPIS */}
      {activeTab === 'financial_kpis' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-amber-400" />
                Enterprise Unit Economics & Profitability Metrics
              </h2>
              <p className="text-xs text-slate-400">
                Key performance metrics demonstrating high gross margins and low payback duration.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-2">
              <span className="text-xs text-slate-400 font-bold block">Annual Recurring (ARR)</span>
              <span className="text-3xl font-black text-amber-400 font-mono">
                ${(FINANCIAL_KPIS.arrUsd / 1000000).toFixed(2)}M
              </span>
              <span className="text-[10px] text-slate-400 block">Run-rate across 8 African countries</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-2">
              <span className="text-xs text-slate-400 font-bold block">Gross Margin %</span>
              <span className="text-3xl font-black text-emerald-400 font-mono">
                {FINANCIAL_KPIS.grossMarginPct}%
              </span>
              <span className="text-[10px] text-slate-400 block">Cloud software scalability</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-2">
              <span className="text-xs text-slate-400 font-bold block">Customer LTV : CAC</span>
              <span className="text-3xl font-black text-teal-400 font-mono">
                {FINANCIAL_KPIS.ltvToCacRatio}x
              </span>
              <span className="text-[10px] text-slate-400 block">LTV: ${FINANCIAL_KPIS.ltvUsd} / CAC: ${FINANCIAL_KPIS.cacUsd}</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-2">
              <span className="text-xs text-slate-400 font-bold block">Payback Period</span>
              <span className="text-3xl font-black text-blue-400 font-mono">
                {FINANCIAL_KPIS.paybackPeriodMonths} Mo
              </span>
              <span className="text-[10px] text-slate-400 block">Rapid CAC payback cycle</span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: 5-YEAR PLAN */}
      {activeTab === 'five_year_plan' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <div className="p-3 bg-amber-950 border border-amber-500/30 rounded-2xl text-amber-400">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">
                5-Year Pan-African Growth & Revenue Roadmap (2026 - 2030)
              </h2>
              <p className="text-xs text-slate-400">
                Scaling from Rwanda & East Africa to 15 African markets, reaching 8 million farmers and $105M ARR.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {FIVE_YEAR_PROJECTIONS.map((proj) => (
              <div
                key={proj.year}
                className="bg-slate-950 p-5 rounded-2xl border border-slate-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-black text-amber-400 font-mono">Year {proj.year}</span>
                    <span className="bg-amber-950 border border-amber-500/30 text-amber-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                      {proj.expansionCountries} Active Countries
                    </span>
                  </div>
                  <p className="text-slate-300 font-mono">
                    Farmers: {(proj.activeFarmersCount / 1000000).toFixed(2)}M • Cooperatives: {proj.activeCooperativesCount.toLocaleString()}
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-4 text-right">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Annual Revenue</span>
                    <span className="font-mono font-bold text-amber-400 text-sm">
                      ${(proj.annualRevenueUsd / 1000000).toFixed(1)}M
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-400 block">Gross Profit</span>
                    <span className="font-mono font-bold text-emerald-400 text-sm">
                      ${(proj.grossProfitUsd / 1000000).toFixed(1)}M
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-400 block">EBITDA Margin</span>
                    <span className="font-mono font-bold text-teal-400 text-sm">
                      ${(proj.ebitdaUsd / 1000000).toFixed(1)}M
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: GEMINI AI BUSINESS COPILOT */}
      {activeTab === 'ai_business_copilot' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-amber-950 border border-amber-500/30 rounded-3xl p-6 shadow-2xl space-y-5">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-emerald-400 p-0.5 shadow-lg">
                <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                  <Bot className="w-6 h-6 text-amber-400" />
                </div>
              </div>
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  Gemini 3.6 Flash AgriTech Revenue & Investor Advisor
                </h2>
                <p className="text-xs text-slate-300">
                  Model customer acquisition scenarios, optimize marketplace take rates, and generate investor pitch deck key highlights.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Target Customer Segment:
                </label>
                <input
                  type="text"
                  value={targetCustomerSegment}
                  onChange={(e) => setTargetCustomerSegment(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl p-3 text-slate-100 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Monetization Strategy Focus:
                </label>
                <input
                  type="text"
                  value={monetizationFocus}
                  onChange={(e) => setMonetizationFocus(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl p-3 text-slate-100 font-medium"
                />
              </div>
            </div>

            <button
              onClick={handleRunAiBusinessConsult}
              disabled={isAiConsulting}
              className="bg-gradient-to-r from-amber-500 via-emerald-500 to-amber-600 hover:from-amber-400 hover:to-emerald-400 text-slate-950 font-black px-6 py-3 rounded-2xl shadow-xl transition-all flex items-center gap-2 text-xs uppercase tracking-wide"
            >
              {isAiConsulting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Generating Revenue Strategy...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-slate-950" />
                  <span>Run Gemini Commercial Strategy Analysis</span>
                </>
              )}
            </button>

            {aiBizResult && (
              <div className="bg-slate-950 border border-amber-500/40 rounded-2xl p-5 space-y-4 animate-in fade-in text-xs">
                <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                  <span className="font-bold text-amber-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    Commercial Analysis for {aiBizResult.targetSegment}
                  </span>
                  <span className="bg-amber-950 border border-amber-500/30 text-amber-300 px-2.5 py-1 rounded-full font-mono font-bold">
                    Recommended: {aiBizResult.recommendedTier}
                  </span>
                </div>

                <p className="text-slate-200 leading-relaxed font-medium">
                  {aiBizResult.strategicSummary}
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                    <span className="font-bold text-emerald-400 block">Pricing Optimization Guidance:</span>
                    <p className="text-slate-300">{aiBizResult.pricingOptimizationTip}</p>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                    <span className="font-bold text-teal-400 block">Investor Deck Pitch Highlight:</span>
                    <p className="text-slate-300">{aiBizResult.investorPitchHighlight}</p>
                  </div>
                </div>

                <div className="pt-2">
                  <span className="font-bold text-slate-300 block mb-1">Freemium Conversion Action Plan:</span>
                  <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                    {aiBizResult.conversionTactics?.map((tactic: string, idx: number) => (
                      <li key={idx}>{tactic}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
