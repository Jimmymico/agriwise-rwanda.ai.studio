import React, { useState } from 'react';
import { FarmerProfileDetails, Language, User } from '../../types';
import { UserCheck, ShieldCheck, MapPin, Phone, Mail, Award, Edit3, Save, CheckCircle2, Sprout, Briefcase, Bell, Lock } from 'lucide-react';
import { ProfilePhotoUploader } from '../profile/ProfilePhotoUploader';
import { ProfileAvatar } from '../profile/ProfileAvatar';

interface FarmerProfileSystemProps {
  currentUser: User;
  profile: FarmerProfileDetails;
  onUpdateProfile: (updated: FarmerProfileDetails) => void;
  language: Language;
}

export const FarmerProfileSystem: React.FC<FarmerProfileSystemProps> = ({
  currentUser,
  profile,
  onUpdateProfile,
  language,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<FarmerProfileDetails>(profile);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handlePhotoUpdated = (newUrl: string) => {
    const updated = { ...formData, photoUrl: newUrl };
    setFormData(updated);
    onUpdateProfile(updated);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(formData);
    setIsEditing(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 4000);
  };

  const activityOptions = ['Crop Farming', 'Livestock Raising', 'Agro-Forestry', 'Horticulture', 'Aquaculture'] as const;

  const toggleActivity = (activity: typeof activityOptions[number]) => {
    if (formData.mainActivities.includes(activity)) {
      setFormData({
        ...formData,
        mainActivities: formData.mainActivities.filter((a) => a !== activity),
      });
    } else {
      setFormData({
        ...formData,
        mainActivities: [...formData.mainActivities, activity],
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 border border-emerald-800/40 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
            <ProfilePhotoUploader
              userId={currentUser.id}
              userName={formData.fullName}
              currentPhotoUrl={formData.photoUrl}
              onPhotoChange={handlePhotoUpdated}
              language={language}
              size="xl"
              showVerifiedBadge={true}
              verified={true}
              variant="compact"
              id="farmer-header-photo-uploader"
            />
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-2xl font-bold text-white">{formData.fullName}</h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  RAB Verified Farmer
                </span>
              </div>
              <p className="text-slate-400 text-sm flex items-center space-x-2 mt-1">
                <MapPin className="w-4 h-4 text-emerald-400" />
                <span>
                  {formData.village}, {formData.cell}, {formData.sector}, {formData.district} District
                </span>
              </p>
              <div className="flex items-center space-x-4 text-xs text-slate-300 mt-2">
                <span className="flex items-center space-x-1">
                  <Briefcase className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{formData.farmingExperienceYears} Years Experience</span>
                </span>
                <span className="flex items-center space-x-1">
                  <Sprout className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{formData.totalFarmAreaHectares} Ha Mapped Land</span>
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={() => setIsEditing(!isEditing)}
            className="flex items-center space-x-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold transition-all shadow-md"
          >
            {isEditing ? <Save className="w-4 h-4" /> : <Edit3 className="w-4 h-4" />}
            <span>{isEditing ? (language === 'rw' ? 'Kansera' : 'Cancel Edit') : (language === 'rw' ? 'Hindura Umwirondoro' : 'Edit Profile')}</span>
          </button>
        </div>

        {savedSuccess && (
          <div className="mt-4 p-3 bg-emerald-950/80 border border-emerald-500/60 rounded-xl flex items-center space-x-2 text-emerald-200 text-xs font-medium animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>
              {language === 'rw'
                ? 'Umwirondoro wusubiwemo neza no kubikwa mu rwego rw\'ubuhinzi!'
                : 'Farmer profile details updated and saved successfully!'}
            </span>
          </div>
        )}
      </div>

      {/* Main Profile Form / View Grid */}
      {isEditing ? (
        <form onSubmit={handleSave} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6 shadow-lg">
          <div className="border-b border-slate-800 pb-4 flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
              <UserCheck className="w-5 h-5 text-emerald-400" />
              <span>{language === 'rw' ? 'Hindura Umwirondoro w\'Umuhinzi' : 'Edit Agricultural Profile Details'}</span>
            </h2>
            <span className="text-xs text-slate-400">* Required for Government & Bank Credit Verification</span>
          </div>

          {/* Personal Info Grid */}
          <div>
            <h3 className="text-sm font-semibold text-emerald-400 mb-3 uppercase tracking-wider">
              1. Personal & Contact Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Phone Number (MoMo)</label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Email Address</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">District</label>
                <input
                  type="text"
                  value={formData.district}
                  onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Sector</label>
                <input
                  type="text"
                  value={formData.sector}
                  onChange={(e) => setFormData({ ...formData, sector: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Cell & Village</label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="Cell"
                    value={formData.cell}
                    onChange={(e) => setFormData({ ...formData, cell: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-2 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                  <input
                    type="text"
                    placeholder="Village"
                    value={formData.village}
                    onChange={(e) => setFormData({ ...formData, village: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-2 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">National ID Number (NIDA)</label>
                <input
                  type="text"
                  value={formData.nationalIdNumber || ''}
                  onChange={(e) => setFormData({ ...formData, nationalIdNumber: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                  placeholder="1 19XX 8 XXXXXXX X XX"
                />
              </div>

              <div className="md:col-span-3">
                <label className="block text-xs font-medium text-slate-300 mb-2">
                  {language === 'rw' ? 'Ifoto y\'Umwirondoro' : language === 'fr' ? 'Photo de Profil' : 'Profile Photo'}
                </label>
                <ProfilePhotoUploader
                  userId={currentUser.id}
                  userName={formData.fullName}
                  currentPhotoUrl={formData.photoUrl}
                  onPhotoChange={handlePhotoUpdated}
                  language={language}
                  size="lg"
                  showVerifiedBadge={true}
                  verified={true}
                  variant="card"
                  id="farmer-form-photo-uploader"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Preferred Language</label>
                <select
                  value={formData.preferredLanguage}
                  onChange={(e) => setFormData({ ...formData, preferredLanguage: e.target.value as Language })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                >
                  <option value="rw">Kinyarwanda</option>
                  <option value="en">English</option>
                  <option value="fr">Français</option>
                </select>
              </div>
            </div>
          </div>

          {/* Agricultural Profile Grid */}
          <div>
            <h3 className="text-sm font-semibold text-emerald-400 mb-3 uppercase tracking-wider">
              2. Agricultural & Farming Experience
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Farming Experience (Years)</label>
                <input
                  type="number"
                  value={formData.farmingExperienceYears}
                  onChange={(e) => setFormData({ ...formData, farmingExperienceYears: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Total Mapped Land (Hectares)</label>
                <input
                  type="number"
                  step="0.1"
                  value={formData.totalFarmAreaHectares}
                  onChange={(e) => setFormData({ ...formData, totalFarmAreaHectares: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Cooperative Membership</label>
                <input
                  type="text"
                  value={formData.cooperativeMembership || ''}
                  onChange={(e) => setFormData({ ...formData, cooperativeMembership: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                  placeholder="e.g. Abahizi Kinigi Potato Cooperative"
                />
              </div>
            </div>

            {/* Activities checkboxes */}
            <div className="mt-4">
              <label className="block text-xs font-medium text-slate-300 mb-2">Main Farming Activities</label>
              <div className="flex flex-wrap gap-2">
                {activityOptions.map((activity) => {
                  const isChecked = formData.mainActivities.includes(activity);
                  return (
                    <button
                      type="button"
                      key={activity}
                      onClick={() => toggleActivity(activity)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all ${
                        isChecked
                          ? 'bg-emerald-600/30 border-emerald-500 text-emerald-200'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      {isChecked ? '✓ ' : '+ '} {activity}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-xs font-medium text-slate-300 mb-1">Farming Goals & Vision</label>
              <textarea
                rows={3}
                value={formData.farmingGoals}
                onChange={(e) => setFormData({ ...formData, farmingGoals: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                placeholder="Describe your 1-3 year farming yield and commercial targets..."
              />
            </div>
          </div>

          {/* 4. Notification & Email Preferences */}
          <div>
            <h3 className="text-sm font-semibold text-emerald-400 mb-3 uppercase tracking-wider flex items-center space-x-2">
              <Bell className="w-4 h-4" />
              <span>4. Email & Notification Delivery Preferences</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <label className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-xl cursor-pointer hover:border-slate-700">
                <div>
                  <span className="font-semibold text-slate-200 block">General Email Notifications</span>
                  <span className="text-[11px] text-slate-400">Receive transactional updates via SMTP email</span>
                </div>
                <input
                  type="checkbox"
                  checked={formData.notificationPreferences?.emailNotifications !== false}
                  onChange={(e) => setFormData({
                    ...formData,
                    notificationPreferences: {
                      emailNotifications: e.target.checked,
                      systemNotifications: formData.notificationPreferences?.systemNotifications !== false,
                      salesNotifications: formData.notificationPreferences?.salesNotifications !== false,
                      paymentNotifications: formData.notificationPreferences?.paymentNotifications !== false,
                      securityAlerts: true,
                      updatedAt: new Date().toISOString()
                    }
                  })}
                  className="rounded border-slate-700 text-emerald-500 focus:ring-emerald-500 w-4 h-4"
                />
              </label>

              <label className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-xl cursor-pointer hover:border-slate-700">
                <div>
                  <span className="font-semibold text-slate-200 block">Sales & Order Invoices</span>
                  <span className="text-[11px] text-slate-400">Receipts and sales summaries via email</span>
                </div>
                <input
                  type="checkbox"
                  checked={formData.notificationPreferences?.salesNotifications !== false}
                  onChange={(e) => setFormData({
                    ...formData,
                    notificationPreferences: {
                      emailNotifications: formData.notificationPreferences?.emailNotifications !== false,
                      systemNotifications: formData.notificationPreferences?.systemNotifications !== false,
                      salesNotifications: e.target.checked,
                      paymentNotifications: formData.notificationPreferences?.paymentNotifications !== false,
                      securityAlerts: true,
                      updatedAt: new Date().toISOString()
                    }
                  })}
                  className="rounded border-slate-700 text-emerald-500 focus:ring-emerald-500 w-4 h-4"
                />
              </label>

              <label className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-xl cursor-pointer hover:border-slate-700">
                <div>
                  <span className="font-semibold text-slate-200 block">Payment & MoMo Alerts</span>
                  <span className="text-[11px] text-slate-400">Payout, dividend & escrow notifications</span>
                </div>
                <input
                  type="checkbox"
                  checked={formData.notificationPreferences?.paymentNotifications !== false}
                  onChange={(e) => setFormData({
                    ...formData,
                    notificationPreferences: {
                      emailNotifications: formData.notificationPreferences?.emailNotifications !== false,
                      systemNotifications: formData.notificationPreferences?.systemNotifications !== false,
                      salesNotifications: formData.notificationPreferences?.salesNotifications !== false,
                      paymentNotifications: e.target.checked,
                      securityAlerts: true,
                      updatedAt: new Date().toISOString()
                    }
                  })}
                  className="rounded border-slate-700 text-emerald-500 focus:ring-emerald-500 w-4 h-4"
                />
              </label>

              <div className="flex items-center justify-between p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl opacity-90">
                <div>
                  <div className="flex items-center space-x-1.5">
                    <span className="font-semibold text-slate-200">Account Security Alerts</span>
                    <Lock className="w-3 h-3 text-amber-400" />
                  </div>
                  <span className="text-[11px] text-slate-400">Critical security & password alerts (Mandatory)</span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded">
                  ALWAYS ON
                </span>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-lg flex items-center space-x-2"
            >
              <Save className="w-4 h-4" />
              <span>Save Farmer Profile</span>
            </button>
          </div>
        </form>
      ) : (
        /* Read-only Profile View */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Card 1: Personal & Contact */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-slate-200 flex items-center space-x-2 pb-2 border-b border-slate-800">
              <UserCheck className="w-4 h-4 text-emerald-400" />
              <span>Personal Information</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Full Name</span>
                <span className="font-semibold text-slate-100">{formData.fullName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Phone (MoMo)</span>
                <span className="font-semibold text-emerald-400 flex items-center space-x-1">
                  <Phone className="w-3 h-3 inline mr-1" />
                  {formData.phone}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Email</span>
                <span className="font-semibold text-slate-200 flex items-center space-x-1">
                  <Mail className="w-3 h-3 inline mr-1" />
                  {formData.email}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">District & Sector</span>
                <span className="font-semibold text-slate-200">
                  {formData.district}, {formData.sector}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Cell & Village</span>
                <span className="font-semibold text-slate-200">
                  {formData.cell}, {formData.village}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">National ID</span>
                <span className="font-mono text-slate-300">{formData.nationalIdNumber || '1 1988 8 0034125 1 23'}</span>
              </div>
            </div>
          </div>

          {/* Card 2: Agricultural Activities & Scope */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-slate-200 flex items-center space-x-2 pb-2 border-b border-slate-800">
              <Sprout className="w-4 h-4 text-emerald-400" />
              <span>Agricultural Profile</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Farming Experience</span>
                <span className="font-semibold text-emerald-300">{formData.farmingExperienceYears} Years</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Total Farm Size</span>
                <span className="font-semibold text-slate-200">{formData.totalFarmAreaHectares} Hectares</span>
              </div>
              <div className="py-1 border-b border-slate-800/60">
                <span className="text-slate-400 block mb-1">Main Activities</span>
                <div className="flex flex-wrap gap-1.5">
                  {formData.mainActivities.map((act) => (
                    <span key={act} className="px-2 py-0.5 bg-emerald-950/60 text-emerald-300 border border-emerald-800/60 rounded-md text-[11px]">
                      {act}
                    </span>
                  ))}
                </div>
              </div>
              <div className="py-1 border-b border-slate-800/60">
                <span className="text-slate-400 block mb-1">Primary Crops</span>
                <div className="flex flex-wrap gap-1.5">
                  {formData.mainCrops.map((crop) => (
                    <span key={crop} className="px-2 py-0.5 bg-slate-800 text-slate-200 rounded-md text-[11px]">
                      🌾 {crop}
                    </span>
                  ))}
                </div>
              </div>
              <div className="py-1">
                <span className="text-slate-400 block mb-1">Livestock Types</span>
                <div className="flex flex-wrap gap-1.5">
                  {formData.livestockTypes.map((anim) => (
                    <span key={anim} className="px-2 py-0.5 bg-slate-800 text-amber-200 rounded-md text-[11px]">
                      🐄 {anim}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Card 3: Goals & Cooperative Status */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-slate-200 flex items-center space-x-2 pb-2 border-b border-slate-800">
              <Award className="w-4 h-4 text-emerald-400" />
              <span>Cooperative & Goals</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">Registered Cooperative</span>
                <p className="text-emerald-300 font-semibold">{formData.cooperativeMembership || 'Independent Farmer'}</p>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">Farming Targets & Vision</span>
                <p className="text-slate-200 leading-relaxed italic">{formData.farmingGoals}</p>
              </div>

              <div className="p-3 bg-emerald-950/40 border border-emerald-800/50 rounded-xl flex items-center space-x-3">
                <ShieldCheck className="w-8 h-8 text-emerald-400 shrink-0" />
                <div>
                  <h4 className="font-bold text-emerald-200 text-xs">AgriCredit Score Linked</h4>
                  <p className="text-[11px] text-emerald-400/80">Profile data is synced with Rab & BK Agribusiness loan scoring.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Card 4: Notification & Email Settings */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-slate-200 flex items-center space-x-2 pb-2 border-b border-slate-800">
              <Bell className="w-4 h-4 text-emerald-400" />
              <span>Email & Alerts</span>
            </h3>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Email Updates</span>
                <span className={`font-bold px-2 py-0.5 rounded text-[10px] ${formData.notificationPreferences?.emailNotifications !== false ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-slate-800 text-slate-400'}`}>
                  {formData.notificationPreferences?.emailNotifications !== false ? 'ENABLED' : 'PAUSED'}
                </span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Invoices & Sales</span>
                <span className={`font-bold px-2 py-0.5 rounded text-[10px] ${formData.notificationPreferences?.salesNotifications !== false ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-slate-800 text-slate-400'}`}>
                  {formData.notificationPreferences?.salesNotifications !== false ? 'ENABLED' : 'PAUSED'}
                </span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Payment Alerts</span>
                <span className={`font-bold px-2 py-0.5 rounded text-[10px] ${formData.notificationPreferences?.paymentNotifications !== false ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-slate-800 text-slate-400'}`}>
                  {formData.notificationPreferences?.paymentNotifications !== false ? 'ENABLED' : 'PAUSED'}
                </span>
              </div>
              <div className="flex justify-between items-center py-1">
                <span className="text-slate-400 flex items-center space-x-1">
                  <span>Security Alerts</span>
                  <Lock className="w-3 h-3 text-amber-400 inline" />
                </span>
                <span className="font-bold px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800">
                  LOCKED ON
                </span>
              </div>

              <div className="p-2.5 bg-slate-950/80 border border-slate-800 rounded-xl mt-3">
                <p className="text-[11px] text-slate-400 leading-tight">
                  <Mail className="w-3 h-3 inline text-emerald-400 mr-1" />
                  Primary delivery destination: <span className="text-slate-200 font-semibold">{formData.email || 'Account Email'}</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
