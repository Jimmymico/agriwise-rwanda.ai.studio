import React, { useState, useEffect } from 'react';
import { User, Language } from '../../types';
import {
  FooterConfig,
  getFooterConfig,
  updateFooterConfig,
  resetFooterConfigToDefault,
  isValidUrl,
  DEFAULT_FOOTER_CONFIG,
} from '../../services/footerConfigService';
import {
  ShieldCheck,
  MapPin,
  Mail,
  Phone,
  Clock,
  Heart,
  Globe2,
  Lock,
  FileText,
  Save,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  Info,
  Sparkles,
  Sliders,
} from 'lucide-react';

interface JimmyMicoProProps {
  currentUser?: User;
  language?: Language;
}

export const JimmyMicoPro: React.FC<JimmyMicoProProps> = ({ currentUser }) => {
  const isAuthorized = currentUser?.role === 'admin' || currentUser?.role === 'system_owner';

  const [formData, setFormData] = useState<FooterConfig>(() => getFooterConfig());
  const [initialData, setInitialData] = useState<FooterConfig>(() => getFooterConfig());
  const [activeSection, setActiveSection] = useState<
    'all' | 'contact' | 'hours' | 'connect' | 'social' | 'legal'
  >('all');
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);
  const [isDirty, setIsDirty] = useState(false);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    const config = getFooterConfig();
    setFormData(config);
    setInitialData(config);
  }, []);

  const handleInputChange = (field: keyof FooterConfig, value: any) => {
    setFormData((prev) => {
      const next = { ...prev, [field]: value };
      setIsDirty(JSON.stringify(next) !== JSON.stringify(initialData));
      return next;
    });
    // Clear error
    if (validationErrors[field as string]) {
      setValidationErrors((prev) => {
        const next = { ...prev };
        delete next[field as string];
        return next;
      });
    }
  };

  const handleSocialChange = (index: number, key: 'url' | 'enabled', value: any) => {
    setFormData((prev) => {
      const updatedSocial = [...prev.socialLinks];
      updatedSocial[index] = {
        ...updatedSocial[index],
        [key]: value,
      };
      const next = { ...prev, socialLinks: updatedSocial };
      setIsDirty(JSON.stringify(next) !== JSON.stringify(initialData));
      return next;
    });

    const errorKey = `social_${index}`;
    if (validationErrors[errorKey]) {
      setValidationErrors((prev) => {
        const next = { ...prev };
        delete next[errorKey];
        return next;
      });
    }
  };

  const validate = (): boolean => {
    const errors: Record<string, string> = {};

    if (!formData.address.trim()) {
      errors.address = 'Address cannot be empty';
    }
    if (!formData.displayEmail.trim()) {
      errors.displayEmail = 'Display email cannot be empty';
    }
    if (!formData.primaryPhone.trim()) {
      errors.primaryPhone = 'Primary phone cannot be empty';
    }
    if (!formData.openingHours.trim()) {
      errors.openingHours = 'Opening hours cannot be empty';
    }
    if (!formData.connectHeading.trim()) {
      errors.connectHeading = 'Connect heading cannot be empty';
    }

    // Validate social links
    formData.socialLinks.forEach((link, idx) => {
      if (link.enabled && link.url && !isValidUrl(link.url)) {
        errors[`social_${idx}`] = `Invalid URL for ${link.name}`;
      }
    });

    // Validate legal links
    if (formData.privacyPolicyUrl && !isValidUrl(formData.privacyPolicyUrl)) {
      errors.privacyPolicyUrl = 'Invalid URL format (must be http://, https://, or relative)';
    }
    if (formData.termsOfServiceUrl && !isValidUrl(formData.termsOfServiceUrl)) {
      errors.termsOfServiceUrl = 'Invalid URL format (must be http://, https://, or relative)';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSave = (sectionName: string = 'All Sections') => {
    if (!validate()) {
      setStatusMessage({
        type: 'error',
        text: 'Please correct the validation errors before saving.',
      });
      return;
    }

    const result = updateFooterConfig(formData, currentUser, sectionName);
    if (result.success) {
      setInitialData(result.config);
      setFormData(result.config);
      setIsDirty(false);
      setStatusMessage({
        type: 'success',
        text: 'Footer configuration saved successfully and published live.',
      });
      setTimeout(() => setStatusMessage(null), 5000);
    } else {
      setStatusMessage({
        type: 'error',
        text: result.error || 'Failed to save footer configuration.',
      });
    }
  };

  const handleCancel = () => {
    setFormData(initialData);
    setIsDirty(false);
    setValidationErrors({});
    setStatusMessage({
      type: 'info',
      text: 'Unsaved changes discarded.',
    });
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const handleResetToDefault = () => {
    if (
      window.confirm(
        'Are you sure you want to reset all Footer content to the factory default values?'
      )
    ) {
      const result = resetFooterConfigToDefault(currentUser);
      if (result.success) {
        setFormData(result.config);
        setInitialData(result.config);
        setIsDirty(false);
        setValidationErrors({});
        setStatusMessage({
          type: 'success',
          text: 'Footer configuration successfully reset to default values.',
        });
        setTimeout(() => setStatusMessage(null), 5000);
      } else {
        setStatusMessage({
          type: 'error',
          text: result.error || 'Failed to reset footer configuration.',
        });
      }
    }
  };

  if (!isAuthorized) {
    return (
      <div className="bg-slate-900 border border-rose-800/60 rounded-3xl p-8 text-center space-y-4">
        <div className="w-12 h-12 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center justify-center mx-auto text-rose-400">
          <AlertTriangle className="w-6 h-6" />
        </div>
        <h3 className="text-lg font-bold text-white">Access Restricted</h3>
        <p className="text-sm text-slate-400 max-w-md mx-auto">
          The <strong>Jimmy MICO PRO</strong> Footer Management module is restricted to authorized
          administrators (<code>admin</code> and <code>system_owner</code>).
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Module Title Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950/90 border border-slate-800 p-6 sm:p-8 rounded-3xl shadow-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-1.5">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl text-emerald-400">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-black text-white tracking-tight">Jimmy MICO PRO</h2>
                <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full font-bold uppercase">
                  Admin Exclusive
                </span>
              </div>
              <p className="text-xs font-semibold text-emerald-400/90 tracking-wide uppercase mt-0.5">
                Footer Content Management
              </p>
            </div>
          </div>
          <p className="text-xs text-slate-400 max-w-2xl pt-1">
            Customize, manage, and publish real-time contact details, operating hours, social
            links, and legal references displayed on the official AGRIWISE website Footer.
          </p>
        </div>

        {/* Global Actions */}
        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={handleResetToDefault}
            className="px-3.5 py-2 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white text-xs font-bold transition-all flex items-center gap-1.5"
            title="Reset all fields to factory defaults"
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
            <span>Reset to Default</span>
          </button>
          <button
            type="button"
            onClick={handleCancel}
            disabled={!isDirty}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => handleSave(activeSection === 'all' ? 'All Sections' : activeSection)}
            disabled={!isDirty}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-lg flex items-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Changes</span>
          </button>
        </div>
      </div>

      {/* Status Feedback Banner */}
      {statusMessage && (
        <div
          className={`p-4 rounded-2xl border flex items-center gap-3 text-xs font-medium animate-in fade-in duration-200 ${
            statusMessage.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : statusMessage.type === 'error'
              ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
              : 'bg-slate-800 border-slate-700 text-slate-300'
          }`}
        >
          {statusMessage.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
          {statusMessage.type === 'error' && <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />}
          {statusMessage.type === 'info' && <Info className="w-4 h-4 text-teal-400 shrink-0" />}
          <div className="flex-1">{statusMessage.text}</div>
        </div>
      )}

      {/* Section Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
        {[
          { id: 'all', label: 'All Sections', icon: Sliders },
          { id: 'contact', label: '1. Contact Information', icon: MapPin },
          { id: 'hours', label: '2. Business Hours', icon: Clock },
          { id: 'connect', label: '3. Connect & Support', icon: Heart },
          { id: 'social', label: '4. Social Media Links', icon: Globe2 },
          { id: 'legal', label: '5. Legal Links', icon: ShieldCheck },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSection(tab.id as any)}
              className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
                activeSection === tab.id
                  ? 'bg-emerald-600 text-white shadow-lg'
                  : 'bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* 1. CONTACT INFORMATION */}
      {/* ========================================================================= */}
      {(activeSection === 'all' || activeSection === 'contact') && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 space-y-6 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400">
                <MapPin className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-white">1. Contact Information</h3>
                <p className="text-[11px] text-slate-400">
                  Manage physical address, primary/secondary contact numbers, and email routing.
                </p>
              </div>
            </div>
            <span className="text-[10px] text-slate-500 font-mono">Column 4 of Footer</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Address Text */}
            <div className="md:col-span-2 space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                <span>Physical Address Text</span>
              </label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                placeholder="Kigali Innovation City, KG 7 Ave, Kigali, Rwanda"
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 outline-none transition-all"
              />
              {validationErrors.address && (
                <p className="text-[10px] text-rose-400">{validationErrors.address}</p>
              )}
            </div>

            {/* Display Email */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-teal-400" />
                <span>Display Email</span>
              </label>
              <input
                type="email"
                value={formData.displayEmail}
                onChange={(e) => handleInputChange('displayEmail', e.target.value)}
                placeholder="info@agriwise.rw"
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 outline-none transition-all"
              />
              {validationErrors.displayEmail && (
                <p className="text-[10px] text-rose-400">{validationErrors.displayEmail}</p>
              )}
            </div>

            {/* Mailto Target */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-teal-400" />
                <span>Email Address / mailto Target</span>
              </label>
              <input
                type="email"
                value={formData.mailtoEmail}
                onChange={(e) => handleInputChange('mailtoEmail', e.target.value)}
                placeholder="info@agriwise.rw"
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 outline-none transition-all"
              />
            </div>

            {/* Primary Phone */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>Primary Phone</span>
              </label>
              <input
                type="text"
                value={formData.primaryPhone}
                onChange={(e) => handleInputChange('primaryPhone', e.target.value)}
                placeholder="+250 788 000 000"
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 outline-none transition-all"
              />
              {validationErrors.primaryPhone && (
                <p className="text-[10px] text-rose-400">{validationErrors.primaryPhone}</p>
              )}
            </div>

            {/* Secondary Phone */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>Secondary Phone</span>
              </label>
              <input
                type="text"
                value={formData.secondaryPhone}
                onChange={(e) => handleInputChange('secondaryPhone', e.target.value)}
                placeholder="+250 788 123 456"
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 outline-none transition-all"
              />
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. BUSINESS HOURS */}
      {/* ========================================================================= */}
      {(activeSection === 'all' || activeSection === 'hours') && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 space-y-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-400">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-white">2. Business Hours</h3>
                <p className="text-[11px] text-slate-400">
                  Opening and operating hours displayed to farmers and enterprise partners.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Opening Hours Text</span>
            </label>
            <input
              type="text"
              value={formData.openingHours}
              onChange={(e) => handleInputChange('openingHours', e.target.value)}
              placeholder="Mon - Sat: 7:00 AM - 7:00 PM (CAT)"
              className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 outline-none transition-all"
            />
            {validationErrors.openingHours && (
              <p className="text-[10px] text-rose-400">{validationErrors.openingHours}</p>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. CONNECT & SUPPORT */}
      {/* ========================================================================= */}
      {(activeSection === 'all' || activeSection === 'connect') && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 space-y-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-400">
                <Heart className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-white">3. Connect & Support Section</h3>
                <p className="text-[11px] text-slate-400">
                  Heading and advisory description introducing official social media and support channels.
                </p>
              </div>
            </div>
            <span className="text-[10px] text-slate-500 font-mono">Column 5 Header</span>
          </div>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">Section Heading</label>
              <input
                type="text"
                value={formData.connectHeading}
                onChange={(e) => handleInputChange('connectHeading', e.target.value)}
                placeholder="Connect & Support"
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 outline-none transition-all"
              />
              {validationErrors.connectHeading && (
                <p className="text-[10px] text-rose-400">{validationErrors.connectHeading}</p>
              )}
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">Description Text</label>
              <textarea
                rows={2}
                value={formData.connectDescription}
                onChange={(e) => handleInputChange('connectDescription', e.target.value)}
                placeholder="Follow AGRIWISE on official social networks for real-time agronomic advisories."
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 outline-none transition-all resize-none"
              />
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. SOCIAL MEDIA LINKS */}
      {/* ========================================================================= */}
      {(activeSection === 'all' || activeSection === 'social') && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 space-y-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500/10 border border-blue-500/30 rounded-xl text-blue-400">
                <Globe2 className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-white">4. Social Media Networks</h3>
                <p className="text-[11px] text-slate-400">
                  Configure destination URLs and visibility for existing official social channels.
                </p>
              </div>
            </div>
            <span className="text-[10px] text-slate-500 font-mono">5 Supported Channels</span>
          </div>

          <div className="space-y-3">
            {formData.socialLinks.map((social, index) => {
              const errorKey = `social_${index}`;
              return (
                <div
                  key={social.id}
                  className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3 min-w-[160px]">
                    <span className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center font-mono font-bold text-xs text-emerald-400 shrink-0">
                      {social.icon}
                    </span>
                    <div>
                      <span className="font-bold text-xs text-white block">{social.name}</span>
                      <span className="text-[10px] text-slate-500 uppercase">{social.id}</span>
                    </div>
                  </div>

                  <div className="flex-1 space-y-1">
                    <input
                      type="url"
                      value={social.url}
                      disabled={!social.enabled}
                      onChange={(e) => handleSocialChange(index, 'url', e.target.value)}
                      placeholder={`https://${social.id}.com/agriwise`}
                      className={`w-full bg-slate-900 border rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-600 outline-none transition-all ${
                        validationErrors[errorKey]
                          ? 'border-rose-500'
                          : 'border-slate-800 focus:border-emerald-500'
                      } ${!social.enabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                    />
                    {validationErrors[errorKey] && (
                      <p className="text-[10px] text-rose-400">{validationErrors[errorKey]}</p>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-300 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={social.enabled}
                        onChange={(e) => handleSocialChange(index, 'enabled', e.target.checked)}
                        className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 bg-slate-900 border-slate-700"
                      />
                      <span className={social.enabled ? 'text-emerald-400' : 'text-slate-500'}>
                        {social.enabled ? 'Enabled' : 'Disabled'}
                      </span>
                    </label>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. LEGAL LINKS */}
      {/* ========================================================================= */}
      {(activeSection === 'all' || activeSection === 'legal') && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 space-y-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-teal-500/10 border border-teal-500/30 rounded-xl text-teal-400">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-white">5. Legal & Compliance Links</h3>
                <p className="text-[11px] text-slate-400">
                  Configure custom URLs for Privacy Policy and Terms of Service (leaves empty to use built-in compliant dialog modals).
                </p>
              </div>
            </div>
            <span className="text-[10px] text-slate-500 font-mono">GDPR & NPSA Compliant</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Privacy Policy URL */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                <span>Privacy Policy Destination URL</span>
              </label>
              <input
                type="text"
                value={formData.privacyPolicyUrl}
                onChange={(e) => handleInputChange('privacyPolicyUrl', e.target.value)}
                placeholder="Leave empty for built-in popup modal, or https://agriwise.rw/privacy"
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 outline-none transition-all"
              />
              {validationErrors.privacyPolicyUrl && (
                <p className="text-[10px] text-rose-400">{validationErrors.privacyPolicyUrl}</p>
              )}
            </div>

            {/* Terms of Service URL */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-teal-400" />
                <span>Terms of Service Destination URL</span>
              </label>
              <input
                type="text"
                value={formData.termsOfServiceUrl}
                onChange={(e) => handleInputChange('termsOfServiceUrl', e.target.value)}
                placeholder="Leave empty for built-in popup modal, or https://agriwise.rw/terms"
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 outline-none transition-all"
              />
              {validationErrors.termsOfServiceUrl && (
                <p className="text-[10px] text-rose-400">{validationErrors.termsOfServiceUrl}</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Save Bottom Floating / Footer Action Bar */}
      {isDirty && (
        <div className="sticky bottom-6 z-20 bg-slate-950/95 backdrop-blur-md border border-emerald-500/40 p-4 rounded-2xl shadow-2xl flex items-center justify-between gap-4 animate-in slide-in-from-bottom-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
            <span className="text-xs font-bold text-white">You have unsaved changes in Footer Configuration</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCancel}
              className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-bold transition-all"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => handleSave(activeSection === 'all' ? 'All Sections' : activeSection)}
              className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-lg flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Changes</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
