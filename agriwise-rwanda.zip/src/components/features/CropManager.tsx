import React, { useState } from 'react';
import { CropRecord, Language } from '../../types';
import { INITIAL_CROPS } from '../../data/mockData';
import { translations } from '../../data/translations';
import {
  Sprout,
  Plus,
  Calendar,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Clock,
  Layers
} from 'lucide-react';

interface CropManagerProps {
  language: Language;
}

export const CropManager: React.FC<CropManagerProps> = ({ language }) => {
  const t = translations[language];
  const [crops, setCrops] = useState<CropRecord[]>(INITIAL_CROPS);
  const [showAddModal, setShowAddModal] = useState(false);

  const [newCropName, setNewCropName] = useState('Beans (Bush Variety)');
  const [newAcreage, setNewAcreage] = useState(1.2);
  const [newExpectedYield, setNewExpectedYield] = useState(3.5);

  const handleAddCrop = (e: React.FormEvent) => {
    e.preventDefault();
    const created: CropRecord = {
      id: `crop_${Date.now()}`,
      farmerId: 'user_1',
      cropName: newCropName,
      variety: 'Certified Rwanda Seed A',
      acreageHectares: Number(newAcreage),
      plantingDate: new Date().toISOString().split('T')[0],
      stage: 'germination',
      expectedHarvestDate: '2026-11-15',
      expectedYieldTons: Number(newExpectedYield),
      status: 'healthy',
      notes: 'Planted with organic compost and baseline NPK.'
    };
    setCrops([created, ...crops]);
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-white">
        <div>
          <div className="inline-flex items-center space-x-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold mb-1">
            <Sprout className="w-3.5 h-3.5 text-emerald-400" />
            <span>Digital Farm Records</span>
          </div>
          <h2 className="text-xl font-black">{t.navCropManager}</h2>
          <p className="text-xs text-slate-400">Track growth stages, fertilizer applications, and projected yields.</p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg flex items-center space-x-2 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Add Crop Planting Record</span>
        </button>
      </div>

      {/* Crops List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {crops.map((crop) => (
          <div
            key={crop.id}
            className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 text-white relative overflow-hidden"
          >
            <div className="flex items-start justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{crop.variety}</span>
                <h3 className="text-base font-black text-white">{crop.cropName}</h3>
              </div>
              <span
                className={`text-xs font-bold px-2.5 py-1 rounded-full border ${
                  crop.status === 'healthy'
                    ? 'bg-emerald-950 text-emerald-300 border-emerald-500/30'
                    : 'bg-amber-950 text-amber-300 border-amber-500/30'
                }`}
              >
                {crop.status === 'healthy' ? 'Healthy Growth' : 'Attention Needed'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800">
                <span className="text-slate-400 block text-[10px] font-bold uppercase">Acreage</span>
                <span className="text-sm font-black text-emerald-400">{crop.acreageHectares} Ha</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800">
                <span className="text-slate-400 block text-[10px] font-bold uppercase">Expected Yield</span>
                <span className="text-sm font-black text-amber-300">{crop.expectedYieldTons} Tons</span>
              </div>
            </div>

            {/* Growth Stage Progress */}
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between font-medium">
                <span className="text-slate-400 capitalize">Growth Stage: <strong className="text-white">{crop.stage}</strong></span>
                <span className="text-emerald-400 font-bold">75% Complete</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full w-3/4 rounded-full"></div>
              </div>
            </div>

            <div className="text-[11px] text-slate-300 space-y-1 bg-slate-950 p-3 rounded-2xl border border-slate-800">
              <p><strong className="text-slate-400">Planted:</strong> {crop.plantingDate} • <strong className="text-slate-400">Harvest:</strong> {crop.expectedHarvestDate}</p>
              {crop.notes && <p className="text-slate-400 italic">"{crop.notes}"</p>}
            </div>

          </div>
        ))}
      </div>

      {/* Add Crop Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full text-white space-y-4 shadow-2xl">
            <h3 className="text-base font-black">Register New Planting</h3>

            <form onSubmit={handleAddCrop} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Crop Name:</label>
                <input
                  type="text"
                  value={newCropName}
                  onChange={(e) => setNewCropName(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Acreage (Hectares):</label>
                <input
                  type="number"
                  step="0.1"
                  value={newAcreage}
                  onChange={(e) => setNewAcreage(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Expected Yield (Tons):</label>
                <input
                  type="number"
                  step="0.1"
                  value={newExpectedYield}
                  onChange={(e) => setNewExpectedYield(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  required
                />
              </div>

              <div className="pt-3 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 rounded-xl shadow"
                >
                  Save Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
