import React, { useState, useEffect, useRef } from 'react';
import { Language, GPSPoint, SavedFarmBoundary } from '../../types';
import { translations } from '../../data/translations';
import {
  MapPin,
  Sprout,
  Compass,
  Zap,
  TrendingUp,
  AlertTriangle,
  RotateCcw,
  CheckCircle2,
  Play,
  Pause,
  Square,
  Undo2,
  Trash2,
  Save,
  Edit3,
  Wifi,
  WifiOff,
  RefreshCw,
  Layers,
  Info,
  Navigation,
  Globe2,
  Loader2,
  FileText,
  ChevronRight,
  Maximize2
} from 'lucide-react';

interface MapMyFarmProps {
  language: Language;
  onSaveToProfile?: (areaHa: number, crops: string[]) => void;
}

// ----------------------------------------------------------------------
// Geodesic Area & Distance Helper Functions (WGS84 Ellipsoid Approximation)
// ----------------------------------------------------------------------

const EARTH_RADIUS_METERS = 6378137; // WGS84 Equatorial radius in meters

/**
 * Calculates exact geodesic polygon area using Spherical Excess (Gauss-Shoelace formula)
 */
export const calculateGeodesicArea = (coords: GPSPoint[]): {
  sqMeters: number;
  hectares: number;
  ares: number;
} => {
  if (coords.length < 3) return { sqMeters: 0, hectares: 0, ares: 0 };

  let totalAngle = 0;
  const numPoints = coords.length;

  for (let i = 0; i < numPoints; i++) {
    const j = (i + 1) % numPoints;
    const lat1 = (coords[i].lat * Math.PI) / 180;
    const lat2 = (coords[j].lat * Math.PI) / 180;
    const lng1 = (coords[i].lng * Math.PI) / 180;
    const lng2 = (coords[j].lng * Math.PI) / 180;

    totalAngle += (lng2 - lng1) * (2 + Math.sin(lat1) + Math.sin(lat2));
  }

  const areaSqMeters = Math.abs((totalAngle * EARTH_RADIUS_METERS * EARTH_RADIUS_METERS) / 2);
  const hectares = Number((areaSqMeters / 10000).toFixed(3));
  const ares = Number((areaSqMeters / 100).toFixed(1));

  return {
    sqMeters: Math.round(areaSqMeters),
    hectares,
    ares,
  };
};

/**
 * Calculates distance between two GPSPoints using the Haversine formula
 */
export const calculateHaversineDistance = (p1: GPSPoint, p2: GPSPoint): number => {
  const dLat = ((p2.lat - p1.lat) * Math.PI) / 180;
  const dLng = ((p2.lng - p1.lng) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((p1.lat * Math.PI) / 180) *
      Math.cos((p2.lat * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return EARTH_RADIUS_METERS * c; // meters
};

/**
 * Calculates total perimeter length around the polygon
 */
export const calculatePerimeterMeters = (coords: GPSPoint[]): number => {
  if (coords.length < 2) return 0;
  let totalDist = 0;
  for (let i = 0; i < coords.length; i++) {
    const j = (i + 1) % coords.length;
    totalDist += calculateHaversineDistance(coords[i], coords[j]);
  }
  return Math.round(totalDist);
};

export const MapMyFarm: React.FC<MapMyFarmProps> = ({ language, onSaveToProfile }) => {
  const t = translations[language] || translations['rw'];

  // Default Musanze district farm points
  const INITIAL_POINTS: GPSPoint[] = [
    { lat: -1.4392, lng: 29.5891, accuracy: 4.2 },
    { lat: -1.4405, lng: 29.5912, accuracy: 3.8 },
    { lat: -1.4421, lng: 29.5898, accuracy: 4.5 },
    { lat: -1.4408, lng: 29.5879, accuracy: 3.5 },
  ];

  // Core Mapping States
  const [points, setPoints] = useState<GPSPoint[]>(INITIAL_POINTS);
  const [currentPosition, setCurrentPosition] = useState<GPSPoint | null>(null);
  const [distanceWalkedMeters, setDistanceWalkedMeters] = useState<number>(185);

  // Status Machine: 'idle' | 'tracking' | 'paused' | 'finished' | 'editing'
  const [mappingState, setMappingState] = useState<
    'idle' | 'tracking' | 'paused' | 'finished' | 'editing'
  >('idle');

  // GPS Watcher Ref
  const watchIdRef = useRef<number | null>(null);
  const [gpsAccuracy, setGpsAccuracy] = useState<number | null>(3.5);
  const [gpsWarning, setGpsWarning] = useState<string | null>(null);

  // Farm Form Metadata
  const [farmName, setFarmName] = useState<string>('Isambu y’Amasaka n’Ibirayi (Kinigi)');
  const [district, setDistrict] = useState<string>('Musanze');
  const [sector, setSector] = useState<string>('Kinigi');
  const [cropType, setCropType] = useState<string>('Irish Potatoes (Kinigi)');
  const [notes, setNotes] = useState<string>('Volcanic soil parcel near Volcanoes National Park buffer.');

  // UI / Map Visualizer Modes
  const [mapMode, setMapMode] = useState<'satellite' | 'terrain' | 'vector'>('satellite');
  const [draggedPointIndex, setDraggedPointIndex] = useState<number | null>(null);

  // Digital Farm Twin: Saved Boundaries Storage
  const [savedFarms, setSavedFarms] = useState<SavedFarmBoundary[]>([]);
  const [editingFarmId, setEditingFarmId] = useState<string | null>(null);

  // Offline Sync State
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState<string | null>(null);

  // AI Advisory States
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [aiReport, setAiReport] = useState<any>(null);

  // Calculate area metrics dynamically
  const areaMetrics = calculateGeodesicArea(points);
  const perimeterMeters = calculatePerimeterMeters(points);

  // Load saved farms from localStorage on mount
  useEffect(() => {
    const handleOnlineStatus = () => setIsOnline(true);
    const handleOfflineStatus = () => setIsOnline(false);

    window.addEventListener('online', handleOnlineStatus);
    window.addEventListener('offline', handleOfflineStatus);

    const storedFarms = localStorage.getItem('agriwise_saved_farms');
    if (storedFarms) {
      try {
        setSavedFarms(JSON.parse(storedFarms));
      } catch (e) {
        console.error('Failed to parse saved farms from localStorage', e);
      }
    } else {
      // Seed initial sample farm
      const defaultFarm: SavedFarmBoundary = {
        id: 'FARM-001-KIG',
        farmName: 'Musanze Volcanic Potato Farm',
        district: 'Musanze',
        sector: 'Kinigi',
        points: INITIAL_POINTS,
        areaSqMeters: 18500,
        areaHectares: 1.85,
        perimeterMeters: 560,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        syncedToCloud: true,
        cropType: 'Irish Potatoes (Kinigi)',
        notes: 'Volcanic rich parcel with 98% germination score.',
      };
      setSavedFarms([defaultFarm]);
      localStorage.setItem('agriwise_saved_farms', JSON.stringify([defaultFarm]));
    }

    return () => {
      window.removeEventListener('online', handleOnlineStatus);
      window.removeEventListener('offline', handleOfflineStatus);
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  // Save updated savedFarms state to localStorage
  const persistFarms = (updatedFarms: SavedFarmBoundary[]) => {
    setSavedFarms(updatedFarms);
    localStorage.setItem('agriwise_saved_farms', JSON.stringify(updatedFarms));
  };

  // ----------------------------------------------------------------------
  // 1. Live GPS Tracking Logic with Noise Filter & WatchPosition
  // ----------------------------------------------------------------------

  const startGpsWatch = () => {
    if (!navigator.geolocation) {
      alert('Geolocation API is not supported on your browser or device.');
      return;
    }

    setMappingState('tracking');
    setGpsWarning(null);

    watchIdRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        const accuracy = pos.coords.accuracy;
        setGpsAccuracy(Math.round(accuracy));

        const newPt: GPSPoint = {
          lat: Number(pos.coords.latitude.toFixed(6)),
          lng: Number(pos.coords.longitude.toFixed(6)),
          accuracy: Math.round(accuracy),
          elevation: pos.coords.altitude ? Math.round(pos.coords.altitude) : undefined,
          timestamp: Date.now(),
        };

        setCurrentPosition(newPt);

        // Filter 1: Reject points with weak accuracy > 15 meters
        if (accuracy > 15) {
          setGpsWarning(
            `⚠️ Weak GPS signal (±${Math.round(
              accuracy
            )}m). Stand in open field for higher accuracy.`
          );
          return;
        }

        setGpsWarning(null);

        // Append point if tracking is active
        setPoints((prev) => {
          if (prev.length > 0) {
            const lastPt = prev[prev.length - 1];
            const dist = calculateHaversineDistance(lastPt, newPt);

            // Filter 2: Ignore jitter < 1 meter
            if (dist < 1.0) return prev;

            setDistanceWalkedMeters((d) => d + Math.round(dist));
          }
          return [...prev, newPt];
        });
      },
      (err) => {
        console.warn('GPS Watch Error:', err.message);
        setGpsWarning(`GPS Error: ${err.message}. Using simulated field location.`);
      },
      {
        enableHighAccuracy: true,
        timeout: 12000,
        maximumAge: 0,
      }
    );
  };

  const pauseGpsWatch = () => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    setMappingState('paused');
  };

  const resumeGpsWatch = () => {
    startGpsWatch();
  };

  const finishMapping = () => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    setMappingState('finished');
  };

  const undoLastPoint = () => {
    if (points.length === 0) return;
    setPoints((prev) => prev.slice(0, prev.length - 1));
  };

  const clearMapping = () => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    setPoints([]);
    setDistanceWalkedMeters(0);
    setMappingState('idle');
    setEditingFarmId(null);
  };

  // Simulate Walk Step (for testing on desktop/laptop without physically walking)
  const handleSimulateWalkStep = () => {
    const lastPt = points[points.length - 1] || { lat: -1.4392, lng: 29.5891 };
    // Small random step (~10-20 meters)
    const stepLat = lastPt.lat + (Math.random() - 0.4) * 0.0003;
    const stepLng = lastPt.lng + (Math.random() - 0.4) * 0.0003;

    const simulatedPt: GPSPoint = {
      lat: Number(stepLat.toFixed(6)),
      lng: Number(stepLng.toFixed(6)),
      accuracy: 3.2,
      timestamp: Date.now(),
    };

    const stepDist = calculateHaversineDistance(lastPt, simulatedPt);
    setDistanceWalkedMeters((d) => d + Math.round(stepDist));
    setPoints((prev) => [...prev, simulatedPt]);
    setCurrentPosition(simulatedPt);
  };

  // Manual Click on Interactive Map Canvas to Add/Move Points
  const handleMapCanvasClick = (e: React.MouseEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Map SVG relative coordinates back to Musanze lat/lng
    const lat = -1.438 + (y / rect.height) * -0.008;
    const lng = 29.585 + (x / rect.width) * 0.008;

    const newPt: GPSPoint = {
      lat: Number(lat.toFixed(6)),
      lng: Number(lng.toFixed(6)),
      accuracy: 2.5,
      timestamp: Date.now(),
    };

    if (draggedPointIndex !== null) {
      // Move dragged point
      setPoints((prev) => {
        const next = [...prev];
        next[draggedPointIndex] = newPt;
        return next;
      });
      setDraggedPointIndex(null);
    } else if (mappingState === 'tracking' || mappingState === 'idle' || mappingState === 'editing') {
      setPoints((prev) => [...prev, newPt]);
    }
  };

  // ----------------------------------------------------------------------
  // 2. Save Farm Boundary to Local & Cloud Queue
  // ----------------------------------------------------------------------

  const handleSaveFarmBoundary = async () => {
    if (points.length < 3) {
      alert('Please record at least 3 GPS boundary vertices to form a valid farm polygon.');
      return;
    }

    const areaRes = calculateGeodesicArea(points);
    const perimMeters = calculatePerimeterMeters(points);

    const newFarm: SavedFarmBoundary = {
      id: editingFarmId || `FARM-${Date.now().toString().slice(-6)}-${district.toUpperCase()}`,
      farmName: farmName || `Farm parcel ${district}`,
      district,
      sector,
      points,
      areaSqMeters: areaRes.sqMeters,
      areaHectares: areaRes.hectares,
      perimeterMeters: perimMeters,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      syncedToCloud: isOnline,
      cropType,
      notes,
    };

    const existingIndex = savedFarms.findIndex((f) => f.id === newFarm.id);
    let updatedList: SavedFarmBoundary[] = [];

    if (existingIndex >= 0) {
      updatedList = [...savedFarms];
      updatedList[existingIndex] = newFarm;
    } else {
      updatedList = [newFarm, ...savedFarms];
    }

    persistFarms(updatedList);

    if (onSaveToProfile) {
      onSaveToProfile(areaRes.hectares, [cropType]);
    }

    // Trigger Cloud Sync if Online
    if (isOnline) {
      try {
        setIsSyncing(true);
        await fetch('/api/farms/sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ farms: [newFarm] }),
        });
        setSyncStatusMsg('✅ Saved and synchronized with AGRIWISE cloud database!');
      } catch (err) {
        setSyncStatusMsg('Saved locally. Will sync when network reconnects.');
      } finally {
        setIsSyncing(false);
      }
    } else {
      setSyncStatusMsg('Saved locally offline. Queued for auto-sync.');
    }

    setMappingState('idle');
    setEditingFarmId(null);
  };

  // Load a Saved Farm back onto the Map for Editing
  const handleReopenFarmForEditing = (farm: SavedFarmBoundary) => {
    setEditingFarmId(farm.id);
    setFarmName(farm.farmName);
    setDistrict(farm.district);
    setSector(farm.sector);
    setCropType(farm.cropType || 'Irish Potatoes');
    setNotes(farm.notes || '');
    setPoints(farm.points);
    setMappingState('editing');
  };

  const handleDeleteSavedFarm = (id: string) => {
    if (window.confirm('Are you sure you want to delete this saved farm boundary?')) {
      const filtered = savedFarms.filter((f) => f.id !== id);
      persistFarms(filtered);
    }
  };

  // Synchronize Offline Queued Farms
  const handleSyncAllOfflineFarms = async () => {
    if (!isOnline) {
      alert('Device is currently offline. Please connect to Wi-Fi or Cellular network.');
      return;
    }

    setIsSyncing(true);
    try {
      const res = await fetch('/api/farms/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ farms: savedFarms }),
      });
      const data = await res.json();
      if (data.success) {
        const syncedList = savedFarms.map((f) => ({ ...f, syncedToCloud: true }));
        persistFarms(syncedList);
        setSyncStatusMsg(`Successfully synced ${data.syncedCount} farms to cloud!`);
      }
    } catch (err) {
      setSyncStatusMsg('Sync failed. Retrying on next connection.');
    } finally {
      setIsSyncing(false);
    }
  };

  // ----------------------------------------------------------------------
  // 3. AI Soil & Agronomic Advisory Integration
  // ----------------------------------------------------------------------

  const handleRunAiAnalysis = async () => {
    setIsAnalyzing(true);
    try {
      const res = await fetch('/api/ai/map-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          boundaryPoints: points,
          sizeHectares: areaMetrics.hectares,
          district,
          currentCrop: cropType,
          language,
        }),
      });
      const data = await res.json();
      setAiReport(data);
    } catch (err) {
      console.error('AI Advisory Error:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16 font-sans">
      
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden text-white">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold">
              <Compass className="w-3.5 h-3.5 text-emerald-400" />
              <span>SMART FARM GPS BOUNDARY MAPPER</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Interactive GPS Farm Mapping & Digital Twin
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 font-medium max-w-2xl">
              Walk around your farm boundary to continuously record high-accuracy GPS coordinates, measure exact area ($m^2$ & $ha$), and generate cloud-synchronized farm profiles.
            </p>
          </div>

          {/* Network & GPS Signal Status */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-800 px-3 py-2 rounded-2xl text-xs font-bold">
              {isOnline ? (
                <>
                  <Wifi className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-400">Online Sync Ready</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-4 h-4 text-amber-400" />
                  <span className="text-amber-400">Offline Mode</span>
                </>
              )}
            </div>

            {gpsAccuracy !== null && (
              <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-800 px-3 py-2 rounded-2xl text-xs font-bold">
                <Navigation className="w-4 h-4 text-teal-400 animate-pulse" />
                <span className="text-slate-200">
                  Signal: <strong className="text-emerald-400 font-mono">±{gpsAccuracy}m</strong>
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Real-time Dynamic Stats Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-6 pt-6 border-t border-emerald-500/20 text-xs">
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Area (Hectares)</span>
            <span className="text-lg sm:text-xl font-black text-emerald-400 font-mono">
              {areaMetrics.hectares} Ha
            </span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Area (Square Meters)</span>
            <span className="text-lg sm:text-xl font-black text-teal-300 font-mono">
              {areaMetrics.sqMeters.toLocaleString()} m²
            </span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Perimeter Length</span>
            <span className="text-lg sm:text-xl font-black text-blue-300 font-mono">
              {perimeterMeters} m
            </span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-medium">Distance Walked</span>
            <span className="text-lg sm:text-xl font-black text-amber-300 font-mono">
              {distanceWalkedMeters} m
            </span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800 col-span-2 sm:col-span-1">
            <span className="text-slate-400 block font-medium">Recorded Vertices</span>
            <span className="text-lg sm:text-xl font-black text-rose-300 font-mono">
              {points.length} Points
            </span>
          </div>
        </div>
      </div>

      {/* GPS Warning Banner if Signal Weak */}
      {gpsWarning && (
        <div className="bg-amber-950/80 border border-amber-500/50 p-4 rounded-2xl text-amber-300 text-xs flex items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
            <span>{gpsWarning}</span>
          </div>
          <button
            onClick={() => setGpsWarning(null)}
            className="text-amber-400 hover:text-white font-bold underline text-[11px]"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Interactive Mapping Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2-Columns: Interactive Satellite & Polygon Canvas */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4 flex flex-col justify-between">
          
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800 text-xs">
            <div className="flex items-center gap-2 text-white font-bold">
              <MapPin className="w-4 h-4 text-emerald-400" />
              <span>Live Farm Polygon Canvas ({district} District)</span>
            </div>

            {/* Map Layers Mode Toggle */}
            <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
              {(['satellite', 'terrain', 'vector'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setMapMode(mode)}
                  className={`px-3 py-1 rounded-lg text-[11px] font-bold capitalize transition-all ${
                    mapMode === mode
                      ? 'bg-emerald-600 text-white shadow'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          {/* Interactive SVG Canvas */}
          <div className="relative w-full h-80 sm:h-[420px] bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-inner group">
            
            {/* Background Texture based on Map Mode */}
            {mapMode === 'satellite' && (
              <div className="absolute inset-0 bg-[radial-gradient(#15803d_1px,transparent_1px)] [background-size:16px_16px] opacity-40" />
            )}
            {mapMode === 'terrain' && (
              <div className="absolute inset-0 bg-[radial-gradient(#0284c7_1px,transparent_1px)] [background-size:24px_24px] opacity-30" />
            )}
            {mapMode === 'vector' && (
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:2rem_2rem] opacity-40" />
            )}

            <div className="absolute top-3 left-3 bg-slate-900/90 backdrop-blur border border-slate-700/80 px-3 py-1.5 rounded-xl text-[11px] text-slate-200 shadow z-10 flex items-center gap-2">
              <Globe2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>
                <strong>{district}</strong> • Sector: {sector}
              </span>
            </div>

            {/* Instruction tooltip */}
            <div className="absolute top-3 right-3 bg-slate-900/90 backdrop-blur border border-slate-700 px-3 py-1.5 rounded-xl text-[10px] text-slate-300 z-10">
              💡 Tap/click map to add or move boundary vertices
            </div>

            <svg
              className="w-full h-full cursor-crosshair relative z-0"
              onClick={handleMapCanvasClick}
              viewBox="0 0 400 300"
            >
              {/* Draw Closed Polygon when >= 3 points */}
              {points.length >= 3 && (
                <polygon
                  points={points
                    .map((pt) => {
                      const x = ((pt.lng - 29.585) / 0.008) * 400;
                      const y = ((pt.lat - -1.438) / -0.008) * 300;
                      return `${x},${y}`;
                    })
                    .join(' ')}
                  fill={mappingState === 'finished' ? 'rgba(16, 185, 129, 0.35)' : 'rgba(16, 185, 129, 0.20)'}
                  stroke="#10b981"
                  strokeWidth={mappingState === 'finished' ? '3' : '2'}
                  strokeDasharray={mappingState === 'tracking' ? '4 2' : undefined}
                />
              )}

              {/* Draw Edges & Distance Labels */}
              {points.map((pt, idx) => {
                const nextPt = points[(idx + 1) % points.length];
                const x1 = ((pt.lng - 29.585) / 0.008) * 400;
                const y1 = ((pt.lat - -1.438) / -0.008) * 300;
                const x2 = ((nextPt.lng - 29.585) / 0.008) * 400;
                const y2 = ((nextPt.lat - -1.438) / -0.008) * 300;

                const edgeDistMeters = Math.round(calculateHaversineDistance(pt, nextPt));
                const midX = (x1 + x2) / 2;
                const midY = (y1 + y2) / 2;

                return (
                  <g key={idx}>
                    <line
                      x1={x1}
                      y1={y1}
                      x2={x2}
                      y2={y2}
                      stroke="#059669"
                      strokeWidth="2"
                    />

                    {/* Edge Distance Label */}
                    {points.length > 1 && (
                      <text
                        x={midX}
                        y={midY - 4}
                        fill="#6ee7b7"
                        fontSize="8"
                        fontWeight="bold"
                        textAnchor="middle"
                        className="pointer-events-none drop-shadow"
                      >
                        {edgeDistMeters}m
                      </text>
                    )}

                    {/* Vertex Point Handle */}
                    <circle
                      cx={x1}
                      cy={y1}
                      r={draggedPointIndex === idx ? '8' : '6'}
                      fill={idx === 0 ? '#f59e0b' : '#10b981'}
                      stroke="#ffffff"
                      strokeWidth="2"
                      onClick={(e) => {
                        e.stopPropagation();
                        setDraggedPointIndex(idx);
                      }}
                      className="cursor-pointer hover:scale-125 transition-transform"
                    />
                    <text
                      x={x1 + 8}
                      y={y1 - 8}
                      fill="#34d399"
                      fontSize="9"
                      fontWeight="bold"
                    >
                      P{idx + 1}
                    </text>
                  </g>
                );
              })}

              {/* Pulsing Current Position Marker */}
              {currentPosition && (
                <g>
                  <circle
                    cx={((currentPosition.lng - 29.585) / 0.008) * 400}
                    cy={((currentPosition.lat - -1.438) / -0.008) * 300}
                    r="12"
                    fill="rgba(239, 68, 68, 0.25)"
                    className="animate-ping"
                  />
                  <circle
                    cx={((currentPosition.lng - 29.585) / 0.008) * 400}
                    cy={((currentPosition.lat - -1.438) / -0.008) * 300}
                    r="6"
                    fill="#ef4444"
                    stroke="#ffffff"
                    strokeWidth="2"
                  />
                </g>
              )}
            </svg>

            {/* Bottom Status Indicator Bar */}
            <div className="absolute bottom-3 left-3 right-3 bg-slate-900/95 backdrop-blur border border-slate-700 p-3 rounded-2xl flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2">
                <span
                  className={`w-3 h-3 rounded-full ${
                    mappingState === 'tracking'
                      ? 'bg-emerald-400 animate-ping'
                      : mappingState === 'paused'
                      ? 'bg-amber-400'
                      : mappingState === 'finished'
                      ? 'bg-blue-400'
                      : 'bg-slate-500'
                  }`}
                />
                <span className="font-bold text-white uppercase text-[11px] tracking-wider">
                  Status: {mappingState.toUpperCase()}
                </span>
              </div>

              <div className="flex items-center gap-3 text-slate-300 font-mono text-[11px]">
                <span>
                  Points: <strong>{points.length}</strong>
                </span>
                <span>•</span>
                <span>
                  Perimeter: <strong>{perimeterMeters}m</strong>
                </span>
                <span>•</span>
                <span>
                  Area: <strong>{areaMetrics.hectares} Ha</strong> ({areaMetrics.sqMeters.toLocaleString()} m²)
                </span>
              </div>
            </div>

          </div>

          {/* TOUCH-FRIENDLY MAPPING CONTROL ACTION BUTTONS */}
          <div className="grid grid-cols-2 sm:grid-cols-6 gap-2.5 pt-2">
            
            {mappingState === 'idle' || mappingState === 'finished' ? (
              <button
                onClick={startGpsWatch}
                className="col-span-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black py-3 px-4 rounded-2xl shadow-lg flex items-center justify-center gap-2 text-xs transition-all active:scale-95"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Start Mapping</span>
              </button>
            ) : mappingState === 'tracking' ? (
              <button
                onClick={pauseGpsWatch}
                className="col-span-2 bg-amber-600 hover:bg-amber-500 text-white font-black py-3 px-4 rounded-2xl shadow-lg flex items-center justify-center gap-2 text-xs transition-all active:scale-95"
              >
                <Pause className="w-4 h-4 fill-white" />
                <span>Pause Mapping</span>
              </button>
            ) : (
              <button
                onClick={resumeGpsWatch}
                className="col-span-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black py-3 px-4 rounded-2xl shadow-lg flex items-center justify-center gap-2 text-xs transition-all active:scale-95"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Resume Mapping</span>
              </button>
            )}

            <button
              onClick={finishMapping}
              disabled={points.length < 3}
              className="bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-3 rounded-2xl shadow flex items-center justify-center gap-1.5 text-xs transition-all disabled:opacity-40"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Finish</span>
            </button>

            <button
              onClick={undoLastPoint}
              disabled={points.length === 0}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold py-3 px-3 rounded-2xl border border-slate-700 flex items-center justify-center gap-1.5 text-xs transition-all disabled:opacity-40"
            >
              <Undo2 className="w-4 h-4" />
              <span>Undo</span>
            </button>

            <button
              onClick={handleSimulateWalkStep}
              className="bg-teal-900/60 hover:bg-teal-800/80 text-teal-300 font-semibold py-3 px-3 rounded-2xl border border-teal-700/60 flex items-center justify-center gap-1.5 text-xs transition-all"
            >
              <Navigation className="w-4 h-4 text-teal-400" />
              <span>+ Walk Step</span>
            </button>

            <button
              onClick={clearMapping}
              className="bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 font-semibold py-3 px-3 rounded-2xl border border-rose-800/60 flex items-center justify-center gap-1.5 text-xs transition-all"
            >
              <Trash2 className="w-4 h-4" />
              <span>Clear</span>
            </button>

          </div>

        </div>

        {/* Right Column: Save Farm Boundary Form & AI Analysis Trigger */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5 text-white flex flex-col justify-between">
          
          <div className="space-y-4">
            <div className="pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Save className="w-4 h-4 text-emerald-400" />
                <span>Save Farm Boundary Profile</span>
              </h3>
              <p className="text-xs text-slate-400">
                Register polygon geometry to Digital Farm Twin
              </p>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Farm Name / Parcel Title:
                </label>
                <input
                  type="text"
                  value={farmName}
                  onChange={(e) => setFarmName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl p-2.5 text-white outline-none font-medium"
                  placeholder="e.g. Musanze Potato Field #1"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">District:</label>
                  <select
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl p-2.5 text-white outline-none font-medium"
                  >
                    <option value="Musanze">Musanze</option>
                    <option value="Nyagatare">Nyagatare</option>
                    <option value="Huye">Huye</option>
                    <option value="Rubavu">Rubavu</option>
                    <option value="Bugesera">Bugesera</option>
                    <option value="Rwamagana">Rwamagana</option>
                    <option value="Gicumbi">Gicumbi</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Sector:</label>
                  <input
                    type="text"
                    value={sector}
                    onChange={(e) => setSector(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl p-2.5 text-white outline-none font-medium"
                    placeholder="Sector name"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Target Crop / Land Use:</label>
                <select
                  value={cropType}
                  onChange={(e) => setCropType(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl p-2.5 text-white outline-none font-medium"
                >
                  <option value="Irish Potatoes (Kinigi)">Irish Potatoes (Kinigi)</option>
                  <option value="Hybrid Maize (H513)">Hybrid Maize (H513)</option>
                  <option value="Bush Beans">Bush Beans</option>
                  <option value="Coffee Arabica">Coffee Arabica</option>
                  <option value="Tea Plantation">Tea Plantation</option>
                  <option value="Cassava">Cassava</option>
                  <option value="Pasture / Grazing">Pasture / Grazing</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Parcel Notes / Observations:</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl p-2.5 text-white outline-none font-medium resize-none"
                  placeholder="Volcanic soil notes or irrigation details..."
                />
              </div>
            </div>

            {/* Calculated Results Summary Box */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-emerald-500/30 space-y-2 text-xs">
              <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider block">
                Official Area Certification
              </span>
              <div className="flex justify-between items-baseline font-mono">
                <span className="text-slate-400">Total Area:</span>
                <span className="text-base font-black text-emerald-400">
                  {areaMetrics.hectares} Ha ({areaMetrics.sqMeters.toLocaleString()} m²)
                </span>
              </div>
              <div className="flex justify-between items-baseline font-mono">
                <span className="text-slate-400">Perimeter:</span>
                <span className="text-sm font-bold text-teal-300">{perimeterMeters} Meters</span>
              </div>
            </div>
          </div>

          <div className="space-y-2.5 pt-3 border-t border-slate-800">
            <button
              onClick={handleSaveFarmBoundary}
              disabled={points.length < 3}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-4 rounded-2xl shadow-lg flex items-center justify-center gap-2 text-xs transition-all disabled:opacity-40"
            >
              <Save className="w-4 h-4" />
              <span>Save Boundary to Profile</span>
            </button>

            <button
              onClick={handleRunAiAnalysis}
              disabled={isAnalyzing || points.length < 3}
              className="w-full bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-500 hover:to-blue-500 text-white font-bold py-2.5 px-4 rounded-2xl shadow flex items-center justify-center gap-2 text-xs transition-all disabled:opacity-40"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Generating Soil Advisory...</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 text-amber-300" />
                  <span>Calculate Soil & Yield Advisory</span>
                </>
              )}
            </button>

            {syncStatusMsg && (
              <p className="text-[11px] text-emerald-400 text-center font-bold animate-in fade-in">
                {syncStatusMsg}
              </p>
            )}
          </div>

        </div>

      </div>

      {/* DIGITAL FARM TWIN: SAVED FARMS MANAGEMENT PANEL */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5 text-white">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-emerald-950 border border-emerald-500/30 rounded-2xl text-emerald-400">
              <Sprout className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">
                Digital Farm Twin — Saved Farm Boundaries
              </h2>
              <p className="text-xs text-slate-400">
                Manage saved GPS boundaries, reopen parcels for editing, and sync offline updates.
              </p>
            </div>
          </div>

          <button
            onClick={handleSyncAllOfflineFarms}
            disabled={isSyncing || !isOnline}
            className="bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-emerald-500/30 px-4 py-2.5 rounded-2xl text-xs font-bold flex items-center gap-2 transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Synchronizing...' : 'Sync All Offline Boundaries'}</span>
          </button>
        </div>

        {savedFarms.length === 0 ? (
          <div className="text-center py-8 text-slate-400 text-xs">
            No farm boundaries saved yet. Walk your boundary above and click "Save Boundary to Profile".
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {savedFarms.map((farm) => (
              <div
                key={farm.id}
                className="bg-slate-950 border border-slate-800 hover:border-emerald-500/40 p-5 rounded-3xl space-y-4 shadow-lg transition-all flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[10px] font-mono text-emerald-400 font-bold block">
                        ID: {farm.id}
                      </span>
                      <h3 className="font-bold text-white text-base leading-tight">
                        {farm.farmName}
                      </h3>
                    </div>
                    {farm.syncedToCloud ? (
                      <span className="bg-emerald-950 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        Cloud Synced
                      </span>
                    ) : (
                      <span className="bg-amber-950 text-amber-300 border border-amber-500/30 text-[10px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                        <WifiOff className="w-3 h-3 text-amber-400" />
                        Offline Local
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-400">
                    District: <strong className="text-slate-200">{farm.district}</strong> • Sector:{' '}
                    <strong className="text-slate-200">{farm.sector}</strong>
                  </p>

                  <div className="grid grid-cols-2 gap-2 pt-2 text-xs font-mono">
                    <div className="bg-slate-900 p-2 rounded-xl border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Size</span>
                      <span className="font-bold text-emerald-400">{farm.areaHectares} Ha</span>
                    </div>
                    <div className="bg-slate-900 p-2 rounded-xl border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Perimeter</span>
                      <span className="font-bold text-teal-300">{farm.perimeterMeters} m</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 flex justify-between items-center gap-2">
                  <button
                    onClick={() => handleReopenFarmForEditing(farm)}
                    className="bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/40 px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Edit Boundary</span>
                  </button>

                  <button
                    onClick={() => handleDeleteSavedFarm(farm.id)}
                    className="text-rose-400 hover:text-rose-300 p-1.5 rounded-xl hover:bg-rose-950/50 transition-colors"
                    title="Delete saved farm"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* AI ADVISORY REPORT MODAL / PANEL */}
      {aiReport && (
        <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl p-6 shadow-2xl space-y-6 text-white animate-in fade-in">
          <div className="flex flex-wrap items-center justify-between pb-4 border-b border-slate-800 gap-2">
            <div>
              <div className="inline-flex items-center gap-1.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-0.5 rounded-full text-[11px] font-bold mb-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>AI Advisory Generated for {district}</span>
              </div>
              <h3 className="text-lg font-black text-white">
                Agronomic Soil & Financial Advisory Report
              </h3>
            </div>
            <div className="text-right text-xs">
              <span className="text-slate-400">Soil Type:</span>{' '}
              <span className="text-emerald-300 font-bold">{aiReport.soilProfile}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
            {/* Recommended Crops */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-emerald-400 flex items-center gap-1.5">
                <Sprout className="w-4 h-4" />
                <span>Recommended Crops</span>
              </h4>
              <div className="space-y-2">
                {aiReport.recommendedCrops?.map((c: any, idx: number) => (
                  <div key={idx} className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                    <div className="flex items-center justify-between font-bold text-white mb-1">
                      <span>{c.name}</span>
                      <span className="text-emerald-400">{c.suitabilityScore}% match</span>
                    </div>
                    <p className="text-[11px] text-slate-400">{c.reason}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Inputs & Seed Plan */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-teal-400 flex items-center gap-1.5">
                <FileText className="w-4 h-4" />
                <span>Input & Seed Requirement</span>
              </h4>
              <div className="space-y-2 text-slate-300">
                <div className="flex justify-between p-2 bg-slate-900 rounded-xl">
                  <span>Certified Seeds Needed:</span>
                  <span className="font-bold text-white">{aiReport.seedRequirementKg} Kg</span>
                </div>
                <div className="flex justify-between p-2 bg-slate-900 rounded-xl">
                  <span>NPK 17-17-17:</span>
                  <span className="font-bold text-emerald-400">
                    {aiReport.fertilizerPlan?.npkKg} Kg
                  </span>
                </div>
                <div className="flex justify-between p-2 bg-slate-900 rounded-xl">
                  <span>Urea Top-Dressing:</span>
                  <span className="font-bold text-teal-400">
                    {aiReport.fertilizerPlan?.ureaKg} Kg
                  </span>
                </div>
              </div>
            </div>

            {/* Financial Projection */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-amber-400 flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4" />
                <span>Seasonal Revenue Forecast</span>
              </h4>
              <div className="space-y-2">
                <div className="flex justify-between p-2 bg-slate-900 rounded-xl">
                  <span className="text-slate-400">Projected Yield:</span>
                  <span className="font-bold text-white">{aiReport.expectedYieldTons} Tons</span>
                </div>
                <div className="flex justify-between p-2 bg-slate-900 rounded-xl">
                  <span className="text-slate-400">Est. Gross Income:</span>
                  <span className="font-bold text-emerald-400 font-mono">
                    {Number(aiReport.estimatedRevenueRwf).toLocaleString()} RWF
                  </span>
                </div>
                <div className="flex justify-between p-2 bg-emerald-950/60 border border-emerald-500/40 rounded-xl font-mono">
                  <span className="font-bold text-white">Net Profit:</span>
                  <span className="font-black text-amber-300 text-sm">
                    {Number(aiReport.estimatedProfitRwf).toLocaleString()} RWF
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
