import React, { useState, useEffect } from 'react';
import {
  Video,
  Play,
  Search,
  Filter,
  Eye,
  Clock,
  MapPin,
  Users,
  ShieldCheck,
  Sparkles,
  Layers,
  ChevronRight,
  RefreshCw,
  Award,
  CheckCircle,
  X,
  Share2,
  Bookmark
} from 'lucide-react';
import { EducationalVideo, EducationalVideoFilterOptions, Language } from '../../types';
import {
  AGRICULTURAL_VIDEO_CATEGORIES,
  TARGET_AUDIENCE_OPTIONS,
  RWANDAN_CROPS_OPTIONS,
  RWANDAN_DISTRICTS_OPTIONS
} from '../../data/educationalVideoCategories';
import {
  fetchPublishedEducationalVideos,
  incrementEducationalVideoViews,
  filterEducationalVideos
} from '../../services/educationalVideoService';
import { translations } from '../../data/translations';

interface FarmerLearningCenterProps {
  language: Language;
}

export const FarmerLearningCenter: React.FC<FarmerLearningCenterProps> = ({ language }) => {
  const t = translations[language] || translations.rw;

  const [videos, setVideos] = useState<EducationalVideo[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selectedVideo, setSelectedVideo] = useState<EducationalVideo | null>(null);

  // Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedTopic, setSelectedTopic] = useState<string>('ALL');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('ALL');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('ALL');
  const [selectedCrop, setSelectedCrop] = useState<string>('ALL');

  // Load published videos
  const loadPublishedVideos = async () => {
    setIsLoading(true);
    try {
      const data = await fetchPublishedEducationalVideos();
      setVideos(data);
      if (data.length > 0 && !selectedVideo) {
        setSelectedVideo(data[0]);
      }
    } catch (err) {
      console.error('Failed to load published educational videos:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadPublishedVideos();
  }, []);

  const handleSelectVideo = (video: EducationalVideo) => {
    setSelectedVideo(video);
    incrementEducationalVideoViews(video.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Duration Formatter
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs < 10 ? '0' : ''}${secs}s`;
  };

  // Filtering
  const filterOptions: EducationalVideoFilterOptions = {
    searchQuery,
    category: selectedCategory,
    topic: selectedTopic,
    language: selectedLanguage,
    status: 'PUBLISHED',
    district: selectedDistrict,
    crop: selectedCrop !== 'ALL' ? selectedCrop : undefined
  };

  const filteredVideos = filterEducationalVideos(videos, filterOptions);
  const relatedVideos = selectedVideo
    ? videos.filter((v) => v.id !== selectedVideo.id && (v.category === selectedVideo.category || v.crop === selectedVideo.crop)).slice(0, 5)
    : [];

  return (
    <div id="farmer-video-learning-center" className="space-y-6 max-w-7xl mx-auto pb-12 font-sans">
      {/* Hero Header */}
      <div className="bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-950 border border-emerald-800/40 rounded-3xl p-6 sm:p-8 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-bold uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>{t.videoTrainingContent || 'Agricultural Educational Content'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {t.videoLearningCenterTitle || "Farmer's Agricultural Video Learning Center"}
            </h1>
            <p className="text-sm text-emerald-200/90 max-w-2xl">
              {t.videoLearningCenterSubtitle ||
                'Watch certified agronomic demonstrations, pest control masterclasses, and post-harvest techniques in Kinyarwanda, English, and French.'}
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={loadPublishedVideos}
              className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 transition flex items-center gap-2 text-xs font-semibold"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-emerald-400' : ''}`} />
              <span>{t.syncStatus || 'Refresh'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Video Theatre / Player Section */}
      {selectedVideo && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl grid grid-cols-1 lg:grid-cols-3 gap-0">
          {/* Main Video View (2 cols) */}
          <div className="lg:col-span-2 flex flex-col justify-between bg-black">
            <div className="relative aspect-video w-full bg-black">
              <video
                key={selectedVideo.id}
                src={selectedVideo.videoUrl}
                poster={selectedVideo.thumbnailUrl}
                controls
                playsInline
                className="w-full h-full object-contain"
              >
                Your browser does not support the video element.
              </video>
            </div>

            {/* Video Details Bar */}
            <div className="p-6 bg-slate-900 border-t border-slate-800 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="px-3 py-1 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700/50 font-bold">
                    {selectedVideo.category}
                  </span>
                  <span className="px-3 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700 font-medium">
                    {selectedVideo.topic}
                  </span>
                  <span className="px-2.5 py-0.5 rounded uppercase font-extrabold bg-slate-800 text-slate-200 border border-slate-700 text-[11px]">
                    {selectedVideo.language}
                  </span>
                </div>

                <div className="flex items-center gap-3 text-xs text-slate-400">
                  <span className="flex items-center gap-1.5">
                    <Eye className="w-4 h-4 text-emerald-400" />
                    <span>{selectedVideo.viewsCount || 0} views</span>
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-slate-400" />
                    <span>{formatDuration(selectedVideo.duration)}</span>
                  </span>
                </div>
              </div>

              <h2 className="text-xl font-bold text-white leading-snug">
                {selectedVideo.title}
              </h2>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-line">
                {selectedVideo.description}
              </p>

              {/* Badges / Meta */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-800/80 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-semibold block">Target Audience</span>
                  <span className="text-slate-200 font-medium">{selectedVideo.targetAudience}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-semibold block">Region / District</span>
                  <span className="text-slate-200 font-medium">{selectedVideo.district || 'All Rwanda'}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-semibold block">Crop / Commodity</span>
                  <span className="text-slate-200 font-medium">{selectedVideo.crop || selectedVideo.livestock || 'General'}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-semibold block">{t.videoCertificationStatus || 'Content Type'}</span>
                  {selectedVideo.certificationStatus === 'RAB_CERTIFIED' ? (
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <Award className="w-3.5 h-3.5" />
                      {t.videoCertifiedRab || 'RAB Certified'}
                    </span>
                  ) : selectedVideo.certificationStatus === 'MINAGRI_CERTIFIED' ? (
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <Award className="w-3.5 h-3.5" />
                      {t.videoCertifiedMinagri || 'MINAGRI Certified'}
                    </span>
                  ) : (
                    <span className="text-slate-300 font-medium">{t.videoEducationalBadge || 'Educational Video'}</span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Related Videos Playlist (1 col) */}
          <div className="p-6 bg-slate-950/60 border-t lg:border-t-0 lg:border-l border-slate-800 flex flex-col justify-between space-y-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-4">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>{t.videoRelatedVideos || 'Related Educational Lessons'}</span>
              </h3>

              <div className="space-y-3">
                {relatedVideos.length > 0 ? (
                  relatedVideos.map((rel) => (
                    <div
                      key={rel.id}
                      onClick={() => handleSelectVideo(rel)}
                      className="flex items-center gap-3 p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800/80 cursor-pointer transition group"
                    >
                      <div className="w-20 h-12 bg-slate-950 rounded-lg overflow-hidden shrink-0 relative">
                        <img
                          src={rel.thumbnailUrl}
                          alt={rel.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src =
                              'https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=800&auto=format&fit=crop&q=80';
                          }}
                        />
                        <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                          <Play className="w-3.5 h-3.5 text-white fill-current" />
                        </div>
                      </div>
                      <div className="min-w-0 flex-1">
                        <h4 className="text-xs font-semibold text-white line-clamp-1 group-hover:text-emerald-300 transition">
                          {rel.title}
                        </h4>
                        <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                          <span>{formatDuration(rel.duration)}</span>
                          <span>•</span>
                          <span className="text-emerald-400 truncate">{rel.category}</span>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-slate-500 italic">No other related videos in this specific category.</p>
                )}
              </div>
            </div>

            {/* Guidance Banner */}
            <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-800/50 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>{t.videoTrainingContent || 'Agricultural Educational Guidance'}</span>
              </div>
              <p className="text-[11px] text-emerald-200/80 leading-relaxed">
                {t.videoLearningCenterSubtitle || 'Practical instructional videos and farming demonstrations designed for Rwandan farmers and cooperatives.'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.videoSearchPlaceholder || 'Search videos by title, crop, district, or topic...'}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Category Select */}
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="py-2 px-3 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="ALL">{t.videoFilterAllCategories || 'All Categories'}</option>
              {AGRICULTURAL_VIDEO_CATEGORIES.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>

            {/* Language Select */}
            <select
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="py-2 px-3 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="ALL">{t.videoFilterAllLanguages || 'All Languages'}</option>
              <option value="rw">Kinyarwanda</option>
              <option value="en">English</option>
              <option value="fr">Français</option>
            </select>

            {/* Crop Select */}
            <select
              value={selectedCrop}
              onChange={(e) => setSelectedCrop(e.target.value)}
              className="py-2 px-3 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="ALL">All Crops</option>
              {RWANDAN_CROPS_OPTIONS.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Videos Grid */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <Video className="w-5 h-5 text-emerald-400" />
          <span>{t.videoLatestVideos || 'All Educational Videos'} ({filteredVideos.length})</span>
        </h3>

        {isLoading ? (
          <div className="py-16 text-center text-slate-400 flex flex-col items-center justify-center space-y-3">
            <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin" />
            <p className="text-xs">Loading educational videos...</p>
          </div>
        ) : filteredVideos.length === 0 ? (
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-12 text-center text-slate-400 space-y-3">
            <Video className="w-10 h-10 text-slate-600 mx-auto" />
            <p className="text-sm font-medium text-slate-300">
              {t.videoNoVideosFound || 'No educational videos match your filters.'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filteredVideos.map((video) => {
              const isCurrent = selectedVideo?.id === video.id;
              return (
                <div
                  key={video.id}
                  onClick={() => handleSelectVideo(video)}
                  className={`bg-slate-900 border rounded-2xl overflow-hidden shadow-md cursor-pointer transition transform hover:-translate-y-1 group flex flex-col justify-between ${
                    isCurrent ? 'border-emerald-500 ring-2 ring-emerald-500/20' : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="relative aspect-video bg-slate-950 overflow-hidden">
                    <img
                      src={video.thumbnailUrl}
                      alt={video.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src =
                          'https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=800&auto=format&fit=crop&q=80';
                      }}
                    />
                    <div className="absolute inset-0 bg-slate-950/30 group-hover:bg-slate-950/10 transition flex items-center justify-center">
                      <div className="w-10 h-10 rounded-full bg-emerald-600/90 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition">
                        <Play className="w-4 h-4 fill-current ml-0.5" />
                      </div>
                    </div>

                    <div className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded-md bg-black/80 text-white text-[11px] font-medium flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>{formatDuration(video.duration)}</span>
                    </div>

                    <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded bg-slate-900/90 text-slate-200 text-[10px] font-bold uppercase border border-slate-700">
                      {video.language}
                    </div>
                  </div>

                  <div className="p-4 space-y-2 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-1.5 text-[11px] font-medium text-emerald-400">
                        <span>{video.category}</span>
                      </div>

                      <h4 className="font-semibold text-white text-sm line-clamp-2 leading-snug group-hover:text-emerald-300 transition mt-1">
                        {video.title}
                      </h4>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3 text-slate-500" />
                        <span>{video.viewsCount || 0} views</span>
                      </span>

                      {video.crop && (
                        <span className="px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-300 text-[10px] border border-emerald-800/40">
                          {video.crop.split(' ')[0]}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
