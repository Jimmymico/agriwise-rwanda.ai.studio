import React, { useState, useEffect } from 'react';
import {
  GovernmentUserRole,
  NationalAgStats,
  RegionalAgStats,
  GovDiseaseAlert,
  GovFoodSecurityAlert,
  GovPolicyScenario,
  User,
  Language
} from '../../types';
import {
  MOCK_NATIONAL_STATS,
  MOCK_REGIONAL_STATS,
  MOCK_DISEASE_ALERTS,
  MOCK_FOOD_SECURITY_ALERTS,
  MOCK_POLICY_SCENARIOS
} from '../../data/mockGovPolicyData';
import { translations } from '../../data/translations';
import {
  Building,
  Users,
  Sprout,
  Landmark,
  ShieldAlert,
  PieChart,
  BarChart3,
  Map,
  Sparkles,
  Layers,
  FileSpreadsheet,
  Download,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Search,
  RefreshCw,
  TrendingUp,
  Sliders,
  DollarSign,
  Globe,
  Radio,
  FileText,
  UserCheck
} from 'lucide-react';

interface GovernmentPolicyDashboardProps {
  currentUser: User;
  language: Language;
}

export const GovernmentPolicyDashboard: React.FC<GovernmentPolicyDashboardProps> = ({
  currentUser,
  language,
}) => {
  const t = translations[language];

  // Active Role State
  const [activeRole, setActiveRole] = useState<GovernmentUserRole>('National Agriculture Administrator');

  // Datasets
  const [nationalStats] = useState<NationalAgStats>(MOCK_NATIONAL_STATS);
  const [regionalStats] = useState<RegionalAgStats[]>(MOCK_REGIONAL_STATS);
  const [diseaseAlerts, setDiseaseAlerts] = useState<GovDiseaseAlert[]>(MOCK_DISEASE_ALERTS);
  const [foodAlerts] = useState<GovFoodSecurityAlert[]>(MOCK_FOOD_SECURITY_ALERTS);

  // Tabs
  const [activeTab, setActiveTab] = useState<'overview' | 'gis_map' | 'food_disease' | 'ai_simulation' | 'reports'>('overview');

  // Filters
  const [selectedProvinceFilter, setSelectedProvinceFilter] = useState<string>('All');
  const [mapLayer, setMapLayer] = useState<'production' | 'drought' | 'disease' | 'irrigation'>('production');

  // AI Policy Simulator Form State
  const [simTitle, setSimTitle] = useState('20% Fertilizer Subsidy & Irrigation Expansion Policy');
  const [simProvince, setSimProvince] = useState('Eastern Province');
  const [simCrop, setSimCrop] = useState('Maize Grain');
  const [simFertilizerSubPct, setSimFertilizerSubPct] = useState(20);
  const [simIrrigationHa, setSimIrrigationHa] = useState(1500);
  const [simLoading, setSimLoading] = useState(false);
  const [simResult, setSimResult] = useState<any>(MOCK_POLICY_SCENARIOS[0]);

  // Report Export Toast State
  const [exportToast, setExportToast] = useState<string | null>(null);

  const runAiPolicySimulation = async () => {
    setSimLoading(true);
    try {
      const res = await fetch('/api/ai/policy-simulation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          policyTitle: simTitle,
          targetProvince: simProvince,
          targetCrop: simCrop,
          fertilizerSubsidyPctChange: simFertilizerSubPct,
          irrigationInvestmentHectares: simIrrigationHa,
          language
        }),
      });
      const data = await res.json();
      setSimResult(data);
    } catch (e) {
      console.error('AI Policy Simulation call error:', e);
    } finally {
      setSimLoading(false);
    }
  };

  const triggerExport = (format: 'PDF' | 'Excel' | 'CSV') => {
    setExportToast(`Exporting MINAGRI Strategic Report as ${format}... File ready in downloads.`);
    setTimeout(() => setExportToast(null), 4000);
  };

  const filteredRegional = regionalStats.filter(r =>
    selectedProvinceFilter === 'All' || r.province === selectedProvinceFilter
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* Toast Notification */}
      {exportToast && (
        <div className="fixed top-20 right-6 z-50 bg-emerald-600 text-white font-bold text-xs px-4 py-3 rounded-2xl shadow-2xl flex items-center space-x-2 animate-bounce">
          <CheckCircle2 className="w-5 h-5 text-white" />
          <span>{exportToast}</span>
        </div>
      )}

      {/* Enterprise Government Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden text-white">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center space-x-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold mb-2">
              <Landmark className="w-4 h-4 text-emerald-400" />
              <span>MINAGRI / RAB National Agricultural Policy Command Center</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Government Policy & Agricultural Intelligence System
            </h1>

            <p className="text-xs sm:text-sm text-slate-400 max-w-3xl mt-1">
              National agricultural data aggregation, GIS spatial crop modeling, disease surveillance, and AI socio-economic policy simulation for Rwanda.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="bg-slate-800 border border-slate-700 rounded-2xl p-2.5 flex items-center space-x-2 text-xs">
              <UserCheck className="w-4 h-4 text-teal-400" />
              <span className="text-slate-400 font-bold">Role:</span>
              <select
                value={activeRole}
                onChange={(e) => setActiveRole(e.target.value as GovernmentUserRole)}
                className="bg-slate-900 text-teal-300 font-bold border border-slate-700 rounded-xl px-2 py-1 focus:outline-none"
              >
                <option value="National Agriculture Administrator">National Administrator</option>
                <option value="District Agriculture Officer">District Officer</option>
                <option value="Sector Agriculture Officer">Sector Officer</option>
                <option value="Food Security Analyst">Food Security Analyst</option>
                <option value="Research Institution">Research Institution</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2 flex flex-wrap items-center gap-2 text-xs">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'overview'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>National Overview</span>
        </button>

        <button
          onClick={() => setActiveTab('gis_map')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'gis_map'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Map className="w-4 h-4 text-teal-300" />
          <span>GIS Spatial Agricultural Map</span>
        </button>

        <button
          onClick={() => setActiveTab('food_disease')}
          className={`flex-1 min-w-[150px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'food_disease'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <ShieldAlert className="w-4 h-4 text-amber-300" />
          <span>Food Security & Disease Alerts</span>
        </button>

        <button
          onClick={() => setActiveTab('ai_simulation')}
          className={`flex-1 min-w-[150px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'ai_simulation'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>AI Policy Scenario Engine</span>
        </button>

        <button
          onClick={() => setActiveTab('reports')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'reports'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4 text-blue-300" />
          <span>Executive Reports & Data Export</span>
        </button>
      </div>

      {/* TAB 1: NATIONAL OVERVIEW & MACRO STATS */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          
          {/* Top Macro Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Registered Smallholders</span>
                <Users className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-emerald-400 font-mono">
                {(nationalStats.totalRegisteredFarmers / 1000000).toFixed(2)}M
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Mapped Farms: {nationalStats.totalMappedFarms.toLocaleString()}</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Total Cultivated Land</span>
                <Sprout className="w-4 h-4 text-teal-400" />
              </div>
              <div className="text-2xl font-black text-white font-mono">
                {(nationalStats.totalCultivatedHectares / 1000000).toFixed(2)}M Ha
              </div>
              <p className="text-[11px] text-teal-300 font-medium">Across 5 Provinces & 30 Districts</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>Annual Harvest Output</span>
                <BarChart3 className="w-4 h-4 text-blue-400" />
              </div>
              <div className="text-2xl font-black text-blue-300 font-mono">
                {(nationalStats.totalAnnualYieldTons / 1000000).toFixed(2)}M Tons
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Marketplace: {(nationalStats.totalMarketplaceVolumeRwf / 1000000000).toFixed(1)}B RWF</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-lg space-y-1 text-white">
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                <span>RCA Co-Ops & RAB Dealers</span>
                <Building className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl font-black text-amber-300 font-mono">
                {nationalStats.totalActiveCooperatives} Co-Ops
              </div>
              <p className="text-[11px] text-slate-400 font-medium">{nationalStats.totalRabAgrodealers} Licensed Agro-dealers</p>
            </div>
          </div>

          {/* Commodity Crop Breakdown & Livestock Numbers */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Crop Distribution Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-base font-black flex items-center space-x-2">
                  <PieChart className="w-5 h-5 text-emerald-400" />
                  <span>National Crop Cultivation Breakdown (% Land)</span>
                </h3>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex justify-between font-bold text-slate-300 mb-1">
                    <span>Maize Grain ({nationalStats.cropDistributionPct.maize}%)</span>
                    <span className="text-emerald-400">406,000 Hectares</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${nationalStats.cropDistributionPct.maize}%` }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between font-bold text-slate-300 mb-1">
                    <span>Fresh Beans ({nationalStats.cropDistributionPct.beans}%)</span>
                    <span className="text-teal-400">348,000 Hectares</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div className="bg-teal-500 h-full rounded-full" style={{ width: `${nationalStats.cropDistributionPct.beans}%` }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between font-bold text-slate-300 mb-1">
                    <span>Kinigi Irish Potatoes ({nationalStats.cropDistributionPct.irishPotatoes}%)</span>
                    <span className="text-amber-400">261,000 Hectares</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div className="bg-amber-500 h-full rounded-full" style={{ width: `${nationalStats.cropDistributionPct.irishPotatoes}%` }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between font-bold text-slate-300 mb-1">
                    <span>Marshland Rice ({nationalStats.cropDistributionPct.rice}%)</span>
                    <span className="text-blue-400">203,000 Hectares</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div className="bg-blue-500 h-full rounded-full" style={{ width: `${nationalStats.cropDistributionPct.rice}%` }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between font-bold text-slate-300 mb-1">
                    <span>Export Coffee & Tea ({nationalStats.cropDistributionPct.coffeeTea}%)</span>
                    <span className="text-purple-400">145,000 Hectares</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div className="bg-purple-500 h-full rounded-full" style={{ width: `${nationalStats.cropDistributionPct.coffeeTea}%` }} />
                  </div>
                </div>
              </div>
            </div>

            {/* National Livestock Head Count Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-base font-black flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-teal-400" />
                  <span>National Livestock Population Census</span>
                </h3>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs">
                <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 space-y-1">
                  <span className="text-slate-400 block font-bold">Cattle Head Count (Girinka)</span>
                  <span className="text-2xl font-black text-emerald-400 font-mono">
                    {(nationalStats.livestockHeadCount.cattle / 1000000).toFixed(2)}M
                  </span>
                  <span className="text-[10px] text-slate-400 block">72% Tagged with RFID Twins</span>
                </div>

                <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 space-y-1">
                  <span className="text-slate-400 block font-bold">Goats & Sheep</span>
                  <span className="text-2xl font-black text-amber-300 font-mono">
                    {((nationalStats.livestockHeadCount.goats + nationalStats.livestockHeadCount.sheep) / 1000000).toFixed(2)}M
                  </span>
                  <span className="text-[10px] text-slate-400 block">Goats: 2.2M • Sheep: 680k</span>
                </div>

                <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 space-y-1">
                  <span className="text-slate-400 block font-bold">Poultry (Layers & Broilers)</span>
                  <span className="text-2xl font-black text-blue-300 font-mono">
                    {(nationalStats.livestockHeadCount.poultry / 1000000).toFixed(1)}M
                  </span>
                  <span className="text-[10px] text-slate-400 block">Commercial & Backyard Flocks</span>
                </div>

                <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 space-y-1">
                  <span className="text-slate-400 block font-bold">Milk Production Volume</span>
                  <span className="text-2xl font-black text-teal-300 font-mono">
                    840,000 L/Day
                  </span>
                  <span className="text-[10px] text-teal-400 block">Inyange Dairy Supply Secured</span>
                </div>
              </div>
            </div>
          </div>

          {/* Regional Performance Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-black">Provincial & District Agricultural Performance</h3>
                <p className="text-xs text-slate-400">Aggregated yield forecasts, drought risk indices, and irrigation coverage by region.</p>
              </div>

              <div className="flex items-center space-x-2">
                <span className="text-xs text-slate-400 font-bold">Province:</span>
                <select
                  value={selectedProvinceFilter}
                  onChange={(e) => setSelectedProvinceFilter(e.target.value)}
                  className="bg-slate-800 text-white border border-slate-700 rounded-xl px-3 py-1.5 text-xs font-bold"
                >
                  <option value="All">All Provinces</option>
                  <option value="Eastern Province">Eastern Province</option>
                  <option value="Northern Province">Northern Province</option>
                  <option value="Southern Province">Southern Province</option>
                  <option value="Western Province">Western Province</option>
                  <option value="Kigali City">Kigali City</option>
                </select>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 font-bold uppercase text-[10px]">
                    <th className="p-3">Province / District</th>
                    <th className="p-3">Farmers</th>
                    <th className="p-3">Cultivated Ha</th>
                    <th className="p-3">Main Crops</th>
                    <th className="p-3">Forecast Harvest</th>
                    <th className="p-3">Drought Risk</th>
                    <th className="p-3">Irrigation Coverage</th>
                    <th className="p-3">Subsidy Usage</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {filteredRegional.map((reg) => (
                    <tr key={reg.id} className="hover:bg-slate-800/50 transition-all">
                      <td className="p-3 font-bold text-white">
                        <div>{reg.district} District</div>
                        <span className="text-[10px] text-slate-400 font-normal">{reg.province}</span>
                      </td>
                      <td className="p-3 font-mono text-emerald-300 font-bold">{reg.registeredFarmersCount.toLocaleString()}</td>
                      <td className="p-3 font-mono text-white">{reg.cultivatedHectares.toLocaleString()} Ha</td>
                      <td className="p-3 text-slate-300">{reg.mainCrops.join(', ')}</td>
                      <td className="p-3 font-mono text-teal-300 font-bold">{reg.expectedHarvestTons.toLocaleString()} Tons</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          reg.droughtRiskLevel === 'High' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                          reg.droughtRiskLevel === 'Moderate' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                          'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        }`}>
                          {reg.droughtRiskLevel}
                        </span>
                      </td>
                      <td className="p-3 font-mono text-blue-300 font-bold">{reg.irrigationCoveragePct}%</td>
                      <td className="p-3 font-mono text-amber-300 font-bold">{reg.inputSubsidyUtilizationPct}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: GIS SPATIAL MAP & CROP ZONES */}
      {activeTab === 'gis_map' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-black flex items-center space-x-2">
                  <Map className="w-5 h-5 text-teal-400" />
                  <span>National Interactive GIS Agricultural Layer Map</span>
                </h3>
                <p className="text-xs text-slate-400">Real-time spatial visualization of crop zones, drought vulnerability, pest outbreaks, and irrigation dams across Rwanda.</p>
              </div>

              {/* Map Layer Toggles */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setMapLayer('production')}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
                    mapLayer === 'production' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Production Density
                </button>

                <button
                  onClick={() => setMapLayer('drought')}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
                    mapLayer === 'drought' ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Drought Risk Heatmap
                </button>

                <button
                  onClick={() => setMapLayer('disease')}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
                    mapLayer === 'disease' ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Disease Outbreak Clusters
                </button>

                <button
                  onClick={() => setMapLayer('irrigation')}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
                    mapLayer === 'irrigation' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Irrigation Dams & Marshlands
                </button>
              </div>
            </div>

            {/* Simulated Interactive GIS Map Grid Canvas */}
            <div className="bg-slate-950 border border-slate-800 rounded-3xl p-6 min-h-[420px] relative overflow-hidden flex flex-col justify-between">
              
              {/* Map Canvas Background Grid */}
              <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-40 pointer-events-none" />

              {/* Top Map Layer Indicator */}
              <div className="relative z-10 flex justify-between items-center bg-slate-900/80 backdrop-blur border border-slate-800 p-3 rounded-2xl text-xs">
                <div className="flex items-center space-x-2">
                  <Radio className="w-4 h-4 text-teal-400 animate-pulse" />
                  <span className="font-bold text-white">Active Layer: <strong className="text-teal-300 uppercase">{mapLayer}</strong></span>
                </div>
                <span className="text-slate-400 text-[11px] font-mono">Rwanda Coordinate Reference System (UTM Zone 35S)</span>
              </div>

              {/* Map Regional Pins & Heat Nodes */}
              <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 my-6">
                
                {/* Eastern Node */}
                <div className={`p-4 rounded-2xl border text-xs space-y-2 transition-all ${
                  mapLayer === 'drought' ? 'bg-rose-950/60 border-rose-500/50 text-rose-200' : 'bg-slate-900/90 border-slate-700 text-white'
                }`}>
                  <div className="flex justify-between font-bold">
                    <span>📍 Nyagatare & Kayonza (East)</span>
                    <span className="text-amber-300 font-mono">210,000 Ha</span>
                  </div>
                  <p className="text-[11px] text-slate-300">Primary Maize & Livestock Belt. Valley dams: 12 Active.</p>
                  {mapLayer === 'drought' && <div className="text-rose-400 font-bold text-[10px]">⚠️ High Rainfall Shortage Risk</div>}
                  {mapLayer === 'disease' && <div className="text-amber-300 font-bold text-[10px]">🐛 Fall Armyworm Alert (89 Cases)</div>}
                </div>

                {/* Northern Node */}
                <div className={`p-4 rounded-2xl border text-xs space-y-2 transition-all ${
                  mapLayer === 'disease' ? 'bg-rose-950/60 border-rose-500/50 text-rose-200' : 'bg-slate-900/90 border-slate-700 text-white'
                }`}>
                  <div className="flex justify-between font-bold">
                    <span>📍 Musanze & Burera (North)</span>
                    <span className="text-emerald-300 font-mono">145,000 Ha</span>
                  </div>
                  <p className="text-[11px] text-slate-300">Kinigi Seed Potato & Volcanic Soil Zone.</p>
                  {mapLayer === 'disease' && <div className="text-rose-400 font-bold text-[10px]">🚨 Potato Late Blight Outbreak (142 Cases)</div>}
                  {mapLayer === 'irrigation' && <div className="text-blue-300 font-bold text-[10px]">💧 Gravity Spring Water Schemes Active</div>}
                </div>

                {/* Southern Node */}
                <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-700 text-xs space-y-2 text-white">
                  <div className="flex justify-between font-bold">
                    <span>📍 Huye & Nyamagabe (South)</span>
                    <span className="text-teal-300 font-mono">180,000 Ha</span>
                  </div>
                  <p className="text-[11px] text-slate-300">Marshland Rice & Coffee Washing Stations.</p>
                  {mapLayer === 'irrigation' && <div className="text-blue-300 font-bold text-[10px]">🌊 Akanyaru River Marshlands (38% Irrigated)</div>}
                </div>
              </div>

              {/* Bottom GIS Controls Legend */}
              <div className="relative z-10 bg-slate-900/80 backdrop-blur border border-slate-800 p-3 rounded-2xl flex flex-wrap justify-between items-center text-xs text-slate-300 gap-2">
                <div className="flex items-center space-x-4">
                  <span className="flex items-center space-x-1">
                    <span className="w-3 h-3 bg-emerald-500 rounded-full inline-block" />
                    <span>High Yield</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <span className="w-3 h-3 bg-amber-500 rounded-full inline-block" />
                    <span>Moderate Alert</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <span className="w-3 h-3 bg-rose-500 rounded-full inline-block" />
                    <span>Outbreak / Drought Zone</span>
                  </span>
                </div>

                <div className="text-[11px] text-slate-400">
                  Data Feed: Sentinel-2 Satellite Multispectral & Farmer Twin Sensors
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: FOOD SECURITY & DISEASE SURVEILLANCE ALERTS */}
      {activeTab === 'food_disease' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Food Security Early Warnings */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-base font-black flex items-center space-x-2">
                  <ShieldAlert className="w-5 h-5 text-amber-400" />
                  <span>National Food Security Risk Forecasts</span>
                </h3>
              </div>

              <div className="space-y-4">
                {foodAlerts.map((fs) => (
                  <div key={fs.id} className="bg-slate-800 border border-slate-700 rounded-2xl p-5 space-y-3 shadow-lg">
                    <div className="flex items-center justify-between">
                      <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold px-2.5 py-1 rounded-full">
                        Risk Type: {fs.riskType}
                      </span>
                      <span className="text-slate-400 text-xs font-mono">{fs.alertDate}</span>
                    </div>

                    <h4 className="text-sm font-black text-white">{fs.district} District ({fs.province})</h4>
                    <p className="text-xs text-slate-300 leading-relaxed">{fs.impactDescription}</p>

                    <div className="grid grid-cols-2 gap-2 text-xs bg-slate-900 p-3 rounded-xl border border-slate-700 font-mono">
                      <div>
                        <span className="text-slate-400 block text-[10px]">ESTIMATED DEFICIT:</span>
                        <span className="text-rose-400 font-bold text-sm">-{fs.estimatedProductionDeficitPct}% Harvest</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">GRAIN RESERVE REQUIREMENT:</span>
                        <span className="text-amber-300 font-bold text-sm">{fs.strategicGrainReserveRequirementTons.toLocaleString()} Tons</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Crop & Livestock Disease Outbreak Surveillance */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-base font-black flex items-center space-x-2">
                  <Flame className="w-5 h-5 text-rose-400" />
                  <span>Disease & Pest Outbreak Surveillance (RAB / AI Vision)</span>
                </h3>
              </div>

              <div className="space-y-4">
                {diseaseAlerts.map((dis) => (
                  <div key={dis.id} className="bg-slate-800 border border-slate-700 rounded-2xl p-5 space-y-3 shadow-lg">
                    <div className="flex items-center justify-between">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                        dis.severity === 'Outbreak Alert' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                        'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}>
                        {dis.severity}
                      </span>
                      <span className="text-rose-400 font-mono font-bold text-xs">{dis.confirmedCasesCount} Cases</span>
                    </div>

                    <h4 className="text-sm font-black text-white">{dis.diseaseName}</h4>
                    <p className="text-xs text-slate-300">Target Crop: <strong className="text-emerald-300">{dis.cropAffected}</strong> • Location: <span className="text-white font-bold">{dis.district} ({dis.sector})</span></p>

                    <div className="bg-slate-900 p-3 rounded-xl border border-slate-700 text-xs space-y-1">
                      <span className="text-teal-400 font-bold block">🛡 Recommended RAB Emergency Intervention:</span>
                      <p className="text-slate-300">{dis.recommendedAction}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: AI POLICY SIMULATION & SCENARIO ENGINE */}
      {activeTab === 'ai_simulation' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-6">
            <div className="flex items-center space-x-2 text-amber-300 font-bold text-sm">
              <Sparkles className="w-5 h-5" />
              <span>MINAGRI AI Agricultural Policy Intervention Simulator (Gemini 3.6 Flash)</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Model socio-economic outcomes, crop yield multiplier effects, smallholder income shifts, and national import deficit reductions before enacting government agricultural policies.
            </p>

            {/* Policy Parameters Form */}
            <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-3 text-xs bg-slate-800 p-4 rounded-2xl border border-slate-700">
              <div className="sm:col-span-2">
                <label className="block text-slate-400 font-bold mb-1">Policy Intervention Title:</label>
                <input
                  type="text"
                  value={simTitle}
                  onChange={(e) => setSimTitle(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">Target Province:</label>
                <select
                  value={simProvince}
                  onChange={(e) => setSimProvince(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                >
                  <option value="Eastern Province">Eastern Province</option>
                  <option value="Northern Province">Northern Province</option>
                  <option value="Southern Province">Southern Province</option>
                  <option value="Western Province">Western Province</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">Target Crop:</label>
                <select
                  value={simCrop}
                  onChange={(e) => setSimCrop(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                >
                  <option value="Maize Grain">Maize Grain</option>
                  <option value="Kinigi Seed Potatoes">Kinigi Potatoes</option>
                  <option value="Marshland Rice">Marshland Rice</option>
                  <option value="Fresh Beans">Fresh Beans</option>
                </select>
              </div>

              <div className="flex items-end">
                <button
                  onClick={runAiPolicySimulation}
                  disabled={simLoading}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 rounded-xl shadow transition-all flex items-center justify-center space-x-1.5"
                >
                  {simLoading ? (
                    <span>Simulating...</span>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>Simulate Policy</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Sliders */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 bg-slate-800/50 p-4 rounded-2xl border border-slate-700 text-xs">
              <div className="space-y-2">
                <div className="flex justify-between font-bold">
                  <span className="text-slate-300">Fertilizer Subsidy Adjustment:</span>
                  <span className="text-emerald-400 font-mono">+{simFertilizerSubPct}% Subsidy</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="50"
                  step="5"
                  value={simFertilizerSubPct}
                  onChange={(e) => setSimFertilizerSubPct(Number(e.target.value))}
                  className="w-full accent-emerald-500"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between font-bold">
                  <span className="text-slate-300">Valley Dam Irrigation Expansion:</span>
                  <span className="text-blue-400 font-mono">{simIrrigationHa.toLocaleString()} Hectares</span>
                </div>
                <input
                  type="range"
                  min="200"
                  max="5000"
                  step="100"
                  value={simIrrigationHa}
                  onChange={(e) => setSimIrrigationHa(Number(e.target.value))}
                  className="w-full accent-blue-500"
                />
              </div>
            </div>

            {/* AI Policy Result Display Card */}
            {simResult && (
              <div className="bg-slate-800 border border-emerald-500/30 rounded-3xl p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-700 pb-3">
                  <span className="text-sm font-black text-emerald-300">Policy Impact & Socio-Economic Forecast</span>
                  <span className="text-xs font-bold text-amber-300">Gemini 3.6 Flash Projection</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div className="bg-slate-900 p-4 rounded-2xl space-y-1 border border-slate-700">
                    <span className="text-slate-400 block font-bold">Projected Yield Increase:</span>
                    <span className="text-2xl font-black text-emerald-400 font-mono">+{simResult.projectedYieldIncreasePct}% Harvest</span>
                    <span className="text-[11px] text-slate-400 block">Across {simProvince}</span>
                  </div>

                  <div className="bg-slate-900 p-4 rounded-2xl space-y-1 border border-slate-700">
                    <span className="text-slate-400 block font-bold">National Economic Output:</span>
                    <span className="text-xl font-black text-teal-300 font-mono">
                      {(simResult.projectedEconomicReturnRwf / 1000000000).toFixed(2)} Billion RWF
                    </span>
                    <span className="text-[11px] text-teal-400 block">Smallholder Income: +{simResult.farmerIncomeImpactPct}%</span>
                  </div>

                  <div className="bg-slate-900 p-4 rounded-2xl space-y-1 border border-slate-700">
                    <span className="text-slate-400 block font-bold">Import Deficit Reduction:</span>
                    <span className="text-2xl font-black text-blue-300 font-mono">-{simResult.nationalFoodDeficitReductionPct}% Deficit</span>
                    <span className="text-[11px] text-slate-400 block">Timeline: 12 Months Implementation</span>
                  </div>
                </div>

                <div className="bg-emerald-950/40 border border-emerald-500/30 p-4 rounded-2xl text-xs space-y-2">
                  <span className="text-emerald-300 font-bold block">📜 AI Strategic Analysis & Budget Advice:</span>
                  <p className="text-slate-200 leading-relaxed">{simResult.aiAnalysisSummary}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: EXECUTIVE REPORTS & DATA EXPORT */}
      {activeTab === 'reports' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl text-white space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-black flex items-center space-x-2">
                  <FileSpreadsheet className="w-5 h-5 text-blue-400" />
                  <span>MINAGRI Government Policy & Statistical Reports Center</span>
                </h3>
                <p className="text-xs text-slate-400">Export verified agricultural intelligence datasets for MINAGRI, World Bank, FAO, and cabinet briefings.</p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => triggerExport('PDF')}
                  className="bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow flex items-center space-x-1.5"
                >
                  <Download className="w-4 h-4" />
                  <span>Export PDF Report</span>
                </button>

                <button
                  onClick={() => triggerExport('Excel')}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow flex items-center space-x-1.5"
                >
                  <Download className="w-4 h-4" />
                  <span>Export Excel (.XLSX)</span>
                </button>
              </div>
            </div>

            {/* Pre-generated Report Template Options */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-slate-800 border border-slate-700 rounded-3xl p-5 space-y-3 shadow-lg flex flex-col justify-between">
                <div className="space-y-2">
                  <span className="text-emerald-300 text-[10px] font-bold font-mono uppercase bg-slate-900 px-2 py-0.5 rounded-full border border-slate-700">
                    Monthly Intelligence
                  </span>
                  <h4 className="text-sm font-black text-white">August 2026 National Food Production & Grain Yield Report</h4>
                  <p className="text-xs text-slate-300">Detailed breakdown of 1.45M cultivated hectares, regional harvest projections, and grain silo reserve levels.</p>
                </div>
                <button
                  onClick={() => triggerExport('PDF')}
                  className="w-full bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs py-2 rounded-xl transition-all"
                >
                  Generate & Download
                </button>
              </div>

              <div className="bg-slate-800 border border-slate-700 rounded-3xl p-5 space-y-3 shadow-lg flex flex-col justify-between">
                <div className="space-y-2">
                  <span className="text-amber-300 text-[10px] font-bold font-mono uppercase bg-slate-900 px-2 py-0.5 rounded-full border border-slate-700">
                    Epidemiology Surveillance
                  </span>
                  <h4 className="text-sm font-black text-white">Q3 Crop Pest & Livestock Disease Outbreak Assessment</h4>
                  <p className="text-xs text-slate-300">RAB surveillance data on Potato Late Blight and Fall Armyworm, fungicide spray allocations, and quarantine zones.</p>
                </div>
                <button
                  onClick={() => triggerExport('PDF')}
                  className="w-full bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs py-2 rounded-xl transition-all"
                >
                  Generate & Download
                </button>
              </div>

              <div className="bg-slate-800 border border-slate-700 rounded-3xl p-5 space-y-3 shadow-lg flex flex-col justify-between">
                <div className="space-y-2">
                  <span className="text-teal-300 text-[10px] font-bold font-mono uppercase bg-slate-900 px-2 py-0.5 rounded-full border border-slate-700">
                    Socio-Economic Audit
                  </span>
                  <h4 className="text-sm font-black text-white">RAB Input Subsidy & Smallholder Income Multiplier Audit</h4>
                  <p className="text-xs text-slate-300">Financial distribution audit across 2,850 Agro-dealers and 1.24M registered smallholder Mobile Money accounts.</p>
                </div>
                <button
                  onClick={() => triggerExport('PDF')}
                  className="w-full bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs py-2 rounded-xl transition-all"
                >
                  Generate & Download
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
