import React, { useState, useEffect } from 'react';
import { User, Language, NavigationTab } from '../types';
import { translations } from '../data/translations';
import { defaultWeatherProvider, DistrictWeatherTelemetry } from '../services/weatherProvider';
import {
  MapPin,
  Award,
  Sprout,
  DollarSign,
  Scan,
  Bot,
  Mic,
  Store,
  CloudSun,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  Lightbulb,
  CheckCircle2
} from 'lucide-react';

interface DashboardProps {
  currentUser: User;
  language: Language;
  onNavigate: (tab: NavigationTab) => void;
  onInitiateMomoPayment: (amountRwf: number, title: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  currentUser,
  language,
  onNavigate,
  onInitiateMomoPayment,
}) => {
  const t = translations[language];
  const [weatherTelemetry, setWeatherTelemetry] = useState<DistrictWeatherTelemetry | null>(null);

  useEffect(() => {
    let isMounted = true;
    defaultWeatherProvider.getWeatherForDistrict(currentUser.district || 'Musanze').then((data) => {
      if (isMounted) setWeatherTelemetry(data);
    });
    return () => {
      isMounted = false;
    };
  }, [currentUser.district]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 border border-emerald-500/30 p-6 sm:p-8 shadow-2xl text-white">
        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center space-x-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>RAB & MINAGRI Verified Ecosystem • Season 2026B</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-black">
            {t.welcomeMsg}, {currentUser.name}!
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
            Manage your {currentUser.farmSizeHectares || 2.5} Hectare farm in {currentUser.district} District, {currentUser.sector} Sector. Use AI insights, mobile money, and satellite precision.
          </p>

          <div className="pt-2 flex flex-wrap gap-2">
            <button
              onClick={() => onNavigate('disease_detector')}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg flex items-center space-x-2 transition-all"
            >
              <Scan className="w-4 h-4 text-amber-300" />
              <span>{t.diseaseTitle}</span>
            </button>

            <button
              onClick={() => onNavigate('map_my_farm')}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs px-4 py-2.5 rounded-xl border border-slate-700 flex items-center space-x-2 transition-all"
            >
              <MapPin className="w-4 h-4 text-emerald-400" />
              <span>{t.navMapMyFarm}</span>
            </button>

            <button
              onClick={() => onNavigate('voice_assistant')}
              className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow flex items-center space-x-2 transition-all"
            >
              <Mic className="w-4 h-4" />
              <span>Voice AI (Kinyarwanda)</span>
            </button>
          </div>
        </div>

        {/* Subtle decorative background circles */}
        <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
      </div>

      {/* 4 Core Summary Stat Widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Stat 1: Farm Size */}
        <div
          onClick={() => onNavigate('map_my_farm')}
          className="bg-slate-900 border border-slate-800 hover:border-emerald-500/40 p-5 rounded-3xl shadow-xl space-y-2 cursor-pointer transition-all text-white group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">GPS Farm Area</span>
            <div className="w-9 h-9 rounded-2xl bg-emerald-950 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
              <MapPin className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-white">{currentUser.farmSizeHectares || 2.5} <span className="text-xs font-semibold text-slate-400">Ha</span></p>
          <p className="text-[11px] text-emerald-400 font-semibold flex items-center space-x-1">
            <span>Verified GPS Boundary</span>
            <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
          </p>
        </div>

        {/* Stat 2: AgriCredit Score */}
        <div
          onClick={() => onNavigate('credit_score')}
          className="bg-slate-900 border border-slate-800 hover:border-amber-500/40 p-5 rounded-3xl shadow-xl space-y-2 cursor-pointer transition-all text-white group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">AgriCredit Rating</span>
            <div className="w-9 h-9 rounded-2xl bg-amber-950 text-amber-300 border border-amber-500/30 flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-amber-300">{currentUser.creditScore || 780} <span className="text-xs font-semibold text-slate-400">/ 850</span></p>
          <p className="text-[11px] text-amber-300 font-semibold flex items-center space-x-1">
            <span>Pre-approved Loan Ready</span>
            <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
          </p>
        </div>

        {/* Stat 3: Active Crops */}
        <div
          onClick={() => onNavigate('crop_manager')}
          className="bg-slate-900 border border-slate-800 hover:border-blue-500/40 p-5 rounded-3xl shadow-xl space-y-2 cursor-pointer transition-all text-white group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Active Crops</span>
            <div className="w-9 h-9 rounded-2xl bg-blue-950 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <Sprout className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-white">3 <span className="text-xs font-semibold text-slate-400">Varieties</span></p>
          <p className="text-[11px] text-blue-400 font-semibold flex items-center space-x-1">
            <span>Irish Potato & Maize</span>
            <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
          </p>
        </div>

        {/* Stat 4: MoMo Balance */}
        <div
          onClick={() => onNavigate('financials')}
          className="bg-slate-900 border border-slate-800 hover:border-teal-500/40 p-5 rounded-3xl shadow-xl space-y-2 cursor-pointer transition-all text-white group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">MoMo Farm Balance</span>
            <div className="w-9 h-9 rounded-2xl bg-teal-950 text-teal-300 border border-teal-500/30 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <p className="text-xl font-black text-emerald-400">{currentUser.momoBalanceRwf?.toLocaleString() || '1,850,000'} <span className="text-xs font-semibold text-slate-400">RWF</span></p>
          <p className="text-[11px] text-teal-300 font-semibold flex items-center space-x-1">
            <span>View Financial Log</span>
            <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
          </p>
        </div>

      </div>

      {/* Main Grid: AI Action Cards & Weather Micro Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: AI Advisor Feed */}
        <div className="lg:col-span-2 space-y-4">
          
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 text-white">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2">
                <Bot className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-sm text-white">Today's AI Agronomy Insights ({currentUser.district})</h3>
              </div>
              <button
                onClick={() => onNavigate('ai_assistant')}
                className="text-xs text-emerald-400 hover:underline font-bold"
              >
                Open AI Chat →
              </button>
            </div>

            <div className="space-y-3 text-xs">
              
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-start space-x-3">
                <Lightbulb className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-white mb-0.5">Musanze Potato Fertilizer Application Window</h4>
                  <p className="text-slate-300 leading-relaxed">
                    Soil moisture is currently optimal in Kinigi sector. Apply NPK 17-17-17 at 250 kg/Ha before tomorrow's expected afternoon showers.
                  </p>
                </div>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-start space-x-3">
                <AlertTriangle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-white mb-0.5">Fall Armyworm Pest Warning in Maize</h4>
                  <p className="text-slate-300 leading-relaxed">
                    Neighboring farms in Nyagatare & Gatsibo report armyworm egg hatches. Inspect leaf whorls daily and run an AI Disease Scan if spots appear.
                  </p>
                </div>
              </div>

            </div>
          </div>

          {/* Quick Hub Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs text-white">
            <button
              onClick={() => onNavigate('marketplace')}
              className="p-4 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-2xl text-left space-y-2 transition-all group"
            >
              <Store className="w-6 h-6 text-emerald-400 group-hover:scale-110 transition-transform" />
              <span className="font-bold block">Marketplace</span>
              <span className="text-[10px] text-slate-400 block">Buy seeds, fertilizers & sell produce</span>
            </button>

            <button
              onClick={() => onNavigate('disease_detector')}
              className="p-4 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-2xl text-left space-y-2 transition-all group"
            >
              <Scan className="w-6 h-6 text-teal-400 group-hover:scale-110 transition-transform" />
              <span className="font-bold block">AI Disease Scan</span>
              <span className="text-[10px] text-slate-400 block">Camera crop diagnosis</span>
            </button>

            <button
              onClick={() => onNavigate('livestock_manager')}
              className="p-4 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-2xl text-left space-y-2 transition-all group"
            >
              <CheckCircle2 className="w-6 h-6 text-blue-400 group-hover:scale-110 transition-transform" />
              <span className="font-bold block">Herd Registry</span>
              <span className="text-[10px] text-slate-400 block">Vaccinations & daily milk yield</span>
            </button>
          </div>

        </div>

        {/* Right Column: Micro-Climate Weather & Market Prices */}
        <div className="space-y-4">
          
          {/* Weather Widget Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3 text-white">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                <CloudSun className="w-4 h-4 text-amber-400" />
                <span>Weather ({weatherTelemetry?.district || currentUser.district})</span>
              </span>
              <button
                onClick={() => onNavigate('weather')}
                className="text-[11px] text-emerald-400 font-bold hover:underline"
              >
                7-Day Forecast →
              </button>
            </div>

            <div className="flex items-center justify-between pt-1">
              <div>
                <p className="text-2xl font-black text-white">
                  {weatherTelemetry ? `${weatherTelemetry.tempC}°C` : '21°C'}
                </p>
                <p className="text-[11px] text-blue-300">
                  {weatherTelemetry?.condition.text || 'Scattered Showers'}
                </p>
              </div>
              <CloudSun className="w-10 h-10 text-amber-400" />
            </div>

            <p className="text-[11px] text-slate-400 bg-slate-950 p-2.5 rounded-xl border border-slate-800 leading-relaxed">
              🌧️ {weatherTelemetry ? `${weatherTelemetry.humidityPct}% Humidity • ${weatherTelemetry.windows.planting.label[language as 'rw'|'en'|'fr'] || weatherTelemetry.windows.planting.label['en']}` : 'Ideal soil moisture for planting in Musanze.'}
            </p>
          </div>

          {/* e-Soko Market Prices */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3 text-white">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-white">e-Soko Daily Market Prices</span>
              <span className="text-[10px] text-slate-400">MINAGRI Live</span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between p-2 bg-slate-950 rounded-xl border border-slate-800">
                <span className="font-semibold text-slate-200">Irish Potato (Kinigi)</span>
                <span className="font-bold text-emerald-400">420 RWF/kg</span>
              </div>

              <div className="flex items-center justify-between p-2 bg-slate-950 rounded-xl border border-slate-800">
                <span className="font-semibold text-slate-200">Dry Maize (Grade A)</span>
                <span className="font-bold text-emerald-400">380 RWF/kg</span>
              </div>

              <div className="flex items-center justify-between p-2 bg-slate-950 rounded-xl border border-slate-800">
                <span className="font-semibold text-slate-200">Fresh Milk (Coop)</span>
                <span className="font-bold text-amber-300">350 RWF/L</span>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
