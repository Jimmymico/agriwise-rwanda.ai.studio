import React, { useState, useEffect } from 'react';
import { Language } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { parseFirebaseActionParams } from '../../utils/firebaseActionParser';
import {
  KeyRound,
  ShieldCheck,
  Mail,
  Lock,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  RotateCw,
  Home,
  Check,
  XCircle,
  Inbox,
  FolderArchive,
  Tag,
  ExternalLink,
  Eye,
  EyeOff
} from 'lucide-react';

interface ForgotPasswordPageProps {
  language: Language;
  onNavigateToLogin: () => void;
  onNavigateToHome: () => void;
}

type ResetStep = 'REQUEST' | 'EMAIL_SENT' | 'NEW_PASSWORD' | 'RESET_COMPLETED';

export const ForgotPasswordPage: React.FC<ForgotPasswordPageProps> = ({
  language,
  onNavigateToLogin,
  onNavigateToHome,
}) => {
  const isRw = language === 'rw';
  const { sendPasswordReset, verifyResetCode, confirmPasswordResetWithCode } = useAuth();

  // Step state
  const [step, setStep] = useState<ResetStep>('REQUEST');

  // Input states
  const [emailInput, setEmailInput] = useState('');
  const [submittedEmail, setSubmittedEmail] = useState('');
  const [oobCode, setOobCode] = useState<string | null>(null);

  // New Password State (When action code is present from Firebase reset link)
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [verifiedEmailFromCode, setVerifiedEmailFromCode] = useState<string | null>(null);

  // Feedback states
  const [errorMsg, setErrorMsg] = useState('');
  const [infoMsg, setInfoMsg] = useState('');
  const [loading, setLoading] = useState(false);
  const [isVerifyingCode, setIsVerifyingCode] = useState(false);

  // Resend cooldown timer (60 seconds)
  const [resendCooldown, setResendCooldown] = useState(0);

  // Check URL query parameters & hash for Firebase action link (oobCode)
  useEffect(() => {
    try {
      const fbAction = parseFirebaseActionParams();
      if (fbAction.isPasswordReset && fbAction.oobCode) {
        setOobCode(fbAction.oobCode);
        setStep('NEW_PASSWORD');
        handleVerifyActionCode(fbAction.oobCode);
      }
    } catch (e) {
      console.warn('Failed to parse Firebase action params on ForgotPasswordPage:', e);
    }
  }, []);

  // Cooldown countdown timer
  useEffect(() => {
    let timer: any;
    if (resendCooldown > 0) {
      timer = setInterval(() => {
        setResendCooldown((prev) => Math.max(0, prev - 1));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [resendCooldown]);

  // Verify action code when user lands on link with oobCode
  const handleVerifyActionCode = async (code: string) => {
    setIsVerifyingCode(true);
    setErrorMsg('');
    try {
      const res = await verifyResetCode(code, language);
      if (res.success && res.email) {
        setVerifiedEmailFromCode(res.email);
      } else {
        setErrorMsg(
          res.error ||
            (isRw
              ? 'Iyi link yo guhindura ijambo ry\'ibanga ntabwo yemewe cyangwa yararangiye. Nyamuneka saba indi nshya.'
              : 'This password reset link is invalid or has expired. Please request a new one.')
        );
      }
    } catch (err: any) {
      setErrorMsg(
        err?.message ||
          (isRw
            ? 'Iyi link yo guhindura ijambo ry\'ibanga ntabwo yemewe cyangwa yararangiye. Nyamuneka saba indi nshya.'
            : 'This password reset link is invalid or has expired. Please request a new one.')
      );
    } finally {
      setIsVerifyingCode(false);
    }
  };

  // STEP 1: Submit Email for Real Firebase Password Reset Link
  const handleSendResetEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;

    setErrorMsg('');
    setInfoMsg('');

    const targetEmail = emailInput.trim().toLowerCase();
    if (!targetEmail || !targetEmail.includes('@')) {
      setErrorMsg(
        isRw
          ? 'Nyamuneka shyiramo aderesi ya e-mail yemewe (urugero: user@gmail.com).'
          : 'Please enter a valid email address (e.g. user@gmail.com).'
      );
      return;
    }

    setLoading(true);
    try {
      const res = await sendPasswordReset(targetEmail, language);
      if (res.success) {
        setSubmittedEmail(targetEmail);
        setStep('EMAIL_SENT'); // STATE A: ONLY show email sent confirmation, NOT password changed!
        setResendCooldown(60);
      } else {
        setErrorMsg(res.error || (isRw ? 'Ntibyashobotse kohereza e-mail. Ongera ugerageze.' : 'Failed to send reset email. Please try again.'));
      }
    } catch (err: any) {
      console.error('Password reset request error:', err);
      setErrorMsg(err?.message || (isRw ? 'Habaye ikibazo mu kohereza e-mail.' : 'An error occurred while sending reset email.'));
    } finally {
      setLoading(false);
    }
  };

  // Resend Reset Email
  const handleResendResetEmail = async () => {
    if (resendCooldown > 0 || loading || !submittedEmail) return;

    setErrorMsg('');
    setInfoMsg('');
    setLoading(true);

    try {
      const res = await sendPasswordReset(submittedEmail, language);
      if (res.success) {
        setResendCooldown(60);
        setInfoMsg(
          isRw
            ? `E-mail yo guhindura ijambo ry'ibanga yongeye koherezwa kuri ${submittedEmail}.`
            : `Password reset email was resent to ${submittedEmail}.`
        );
      } else {
        setErrorMsg(res.error || (isRw ? 'Ntibyashobotse kongera kohereza e-mail.' : 'Failed to resend reset email.'));
      }
    } catch (err: any) {
      setErrorMsg(err?.message || (isRw ? 'Habaye ikibazo mu kongera kohereza.' : 'Failed to resend.'));
    } finally {
      setLoading(false);
    }
  };

  // STEP 3: Complete Password Reset with Firebase Action Code (STATE B)
  const handleCompleteResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading || !oobCode) return;

    setErrorMsg('');

    if (newPassword.length < 6) {
      setErrorMsg(isRw ? 'Ijambo ry\'ibanga rigomba kugira byibuze inyuguti 6.' : 'Password must be at least 6 characters long.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setErrorMsg(isRw ? 'Amajambo y\'ibanga yombi ntabwo ahura.' : 'Passwords do not match.');
      return;
    }

    setLoading(true);
    try {
      const res = await confirmPasswordResetWithCode(oobCode, newPassword, language);
      if (res.success) {
        setOobCode(null);
        setNewPassword('');
        setConfirmPassword('');
        try {
          window.history.replaceState({}, document.title, window.location.pathname);
        } catch {}
        setStep('RESET_COMPLETED'); // STATE B: Password actually changed in Firebase Auth!
      } else {
        setErrorMsg(res.error || (isRw ? 'Ntibyashobotse guhindura ijambo ry\'ibanga.' : 'Failed to reset password.'));
      }
    } catch (err: any) {
      console.error('Password reset completion error:', err);
      setErrorMsg(err?.message || (isRw ? 'Habaye ikibazo mu guhindura ijambo ry\'ibanga.' : 'An error occurred while completing reset.'));
    } finally {
      setLoading(false);
    }
  };

  // Password validation rules
  const passHasMinLength = newPassword.length >= 8;
  const passHasUpper = /[A-Z]/.test(newPassword);
  const passHasLower = /[a-z]/.test(newPassword);
  const passHasNumber = /[0-9]/.test(newPassword);
  const passHasSpecial = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(newPassword);
  const passwordsMatch = newPassword.length > 0 && newPassword === confirmPassword;

  return (
    <div className="min-h-[85vh] flex flex-col justify-center items-center py-8 px-4 font-sans text-slate-100">
      <div className="w-full max-w-xl bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 sm:p-10 shadow-2xl relative space-y-6">
        
        {/* Top Header Navigation */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <button
            type="button"
            id="forgot-pass-back-btn"
            onClick={step === 'EMAIL_SENT' ? () => setStep('REQUEST') : onNavigateToLogin}
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-emerald-400 font-bold transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-emerald-400" />
            <span>
              {step === 'EMAIL_SENT'
                ? isRw ? 'Guhindura E-mail' : 'Change Email'
                : isRw ? 'Subira Kwinjira (Login)' : 'Back to Login'}
            </span>
          </button>

          <span className="text-[10px] font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded-full uppercase flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            <span>FIREBASE SECURE RESET</span>
          </span>
        </div>

        {/* Global Error Alert */}
        {errorMsg && (
          <div className="p-4 bg-rose-950/90 border border-rose-500/60 rounded-2xl flex items-start gap-3 text-rose-200 text-xs font-medium animate-fadeIn shadow-lg">
            <AlertCircle className="w-5 h-5 shrink-0 text-rose-400 mt-0.5" />
            <div className="space-y-1">
              <span className="font-bold text-rose-300 block">
                {isRw ? 'Ikibazo mu Guhindura Ijambo ry\'Ibanga' : 'Password Reset Error'}
              </span>
              <p>{errorMsg}</p>
            </div>
          </div>
        )}

        {/* Global Info Alert */}
        {infoMsg && (
          <div className="p-3 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl flex items-center gap-2.5 text-emerald-200 text-xs font-medium animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{infoMsg}</span>
          </div>
        )}

        {/* ========================================================================= */}
        {/* STEP 1: REQUEST PASSWORD RESET EMAIL                                      */}
        {/* ========================================================================= */}
        {step === 'REQUEST' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="text-center space-y-2">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-lg">
                <KeyRound className="w-7 h-7" />
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                {isRw ? 'Wibagiwe Ijambo ry\'Ibanga?' : 'Forgot your password?'}
              </h1>
              <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                {isRw
                  ? 'Injiza aderesi yawe ya Gmail / E-mail ibaruye kuri AGRIWISE. Twohereza link y\'umutekano ya Firebase yo gushyiraho ijambo ry\'ibanga rishya.'
                  : 'Enter your registered Gmail / Email address associated with your AGRIWISE account. We will send a secure Firebase reset link to create a new password.'}
              </p>
            </div>

            <form onSubmit={handleSendResetEmail} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1.5 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-emerald-400" />
                  <span>
                    {isRw
                      ? 'Aderesi ya E-mail (Gmail / Email):'
                      : 'Email Address (Gmail / Email):'}
                  </span>
                </label>
                <input
                  type="email"
                  id="forgot-password-email-input"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  placeholder="user@gmail.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3.5 text-white outline-none focus:border-emerald-500 transition-colors font-medium text-sm"
                  required
                  autoFocus
                />
              </div>

              <button
                type="submit"
                id="send-reset-email-btn"
                disabled={loading || !emailInput.trim()}
                className="w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black py-3.5 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 text-sm uppercase tracking-wide disabled:opacity-50 cursor-pointer"
              >
                {loading ? (
                  <>
                    <RotateCw className="w-5 h-5 animate-spin" />
                    <span>{isRw ? 'KOHEREZA LINK...' : 'SENDING RESET EMAIL...'}</span>
                  </>
                ) : (
                  <>
                    <span>{isRw ? 'KOHEREZA LINK KURI E-MAIL' : 'SEND RESET EMAIL'}</span>
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>
            </form>

            <div className="border-t border-slate-800 pt-4 text-center">
              <button
                type="button"
                id="forgot-pass-login-link"
                onClick={onNavigateToLogin}
                className="text-xs text-slate-400 hover:text-emerald-400 font-bold transition-colors inline-flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>{isRw ? 'Uribuka ijambo ry\'ibanga? Subira Kwinjira' : 'Remembered your password? Back to Login'}</span>
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* STEP 2 / STATE A: RESET EMAIL SENT (CONFIRMATION ONLY)                    */}
        {/* ========================================================================= */}
        {step === 'EMAIL_SENT' && (
          <div className="space-y-6 text-center animate-fadeIn py-2">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-500/20 border-2 border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-xl">
              <Mail className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                {isRw ? 'Ubutumwa Bwohererejwe kuri E-mail' : 'Password Reset Email Sent'}
              </h2>
              <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                {isRw
                  ? 'Ubutumwa bwo guhindura ijambo ry\'ibanga bwoherejwe kuri:'
                  : 'A password reset email has been sent to:'}
              </p>
              <div className="inline-block bg-slate-950 border border-emerald-500/40 px-4 py-1.5 rounded-full text-emerald-300 font-mono font-bold text-xs shadow-inner">
                {submittedEmail}
              </div>
            </div>

            <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl text-left space-y-3 text-xs">
              <p className="text-slate-200 font-semibold leading-relaxed">
                {isRw
                  ? 'Fungura Gmail yawe maze ukande kuri link ya Firebase yo guhindura ijambo ry\'ibanga rishya.'
                  : 'Check your Gmail inbox and follow the password reset link to create a new password.'}
              </p>

              <div className="border-t border-slate-800/80 pt-2.5 space-y-2 text-[11px] text-slate-400">
                <span className="font-bold text-slate-300 uppercase tracking-wider block text-[10px]">
                  {isRw ? 'Nyamuneka reba muri iyi myanya:' : 'Please check these folders in your email:'}
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 font-medium">
                  <div className="flex items-center gap-1.5 bg-slate-900 p-2 rounded-xl border border-slate-800">
                    <Inbox className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Inbox</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-slate-900 p-2 rounded-xl border border-slate-800">
                    <FolderArchive className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Spam / Junk</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-slate-900 p-2 rounded-xl border border-slate-800">
                    <Tag className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                    <span>Promotions</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3 pt-2">
              <button
                type="button"
                id="reset-sent-goto-login-btn"
                onClick={onNavigateToLogin}
                className="w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black py-3.5 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 text-sm uppercase tracking-wide cursor-pointer"
              >
                <span>{isRw ? 'SUBIRA KWINJIRA (BACK TO LOGIN)' : 'BACK TO LOGIN'}</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              <div className="flex items-center justify-between gap-2 text-xs pt-1">
                <button
                  type="button"
                  id="reset-sent-change-email-btn"
                  onClick={() => setStep('REQUEST')}
                  className="text-slate-400 hover:text-white font-bold transition-colors inline-flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>{isRw ? 'Guhindura E-mail' : 'Change Email'}</span>
                </button>

                <button
                  type="button"
                  id="reset-sent-resend-btn"
                  onClick={handleResendResetEmail}
                  disabled={resendCooldown > 0 || loading}
                  className="inline-flex items-center gap-1.5 text-emerald-400 hover:text-emerald-300 font-bold transition-colors disabled:opacity-40 cursor-pointer"
                >
                  <RotateCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  <span>
                    {resendCooldown > 0
                      ? isRw
                        ? `Ongera wohereze (${resendCooldown}s)`
                        : `Resend in (${resendCooldown}s)`
                      : isRw
                      ? 'Ongera Woherereze E-mail'
                      : 'Resend Reset Email'}
                  </span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* STEP 3: NEW PASSWORD FORM (WHEN ACTION CODE IS ACCESSED IN APP)            */}
        {/* ========================================================================= */}
        {step === 'NEW_PASSWORD' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="text-center space-y-2">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-lg">
                <Lock className="w-7 h-7" />
              </div>
              <h2 className="text-2xl font-black text-white tracking-tight">
                {isRw ? 'Kurema Ijambo ry\'Ibanga Rishya' : 'Create New Password'}
              </h2>
              <p className="text-xs text-slate-300 max-w-md mx-auto">
                {verifiedEmailFromCode ? (
                  <span>
                    {isRw ? 'Ugiye guhindura ijambo ry\'ibanga rya ' : 'Resetting password for '}
                    <strong className="text-emerald-300">{verifiedEmailFromCode}</strong>
                  </span>
                ) : (
                  <span>
                    {isRw
                      ? 'Injiza ijambo ry\'ibanga rishya ryujuje ibipimo by\'umutekano.'
                      : 'Enter a strong new password to complete your Firebase password reset.'}
                  </span>
                )}
              </p>
            </div>

            {isVerifyingCode ? (
              <div className="p-8 text-center space-y-3">
                <RotateCw className="w-8 h-8 animate-spin mx-auto text-emerald-400" />
                <p className="text-xs text-slate-300">
                  {isRw ? 'Gusuzuma link y\'umutekano ya Firebase...' : 'Verifying Firebase reset link...'}
                </p>
              </div>
            ) : errorMsg && !verifiedEmailFromCode ? (
              <div className="p-6 bg-slate-950 border border-rose-500/40 rounded-2xl text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-rose-500/20 text-rose-400 mx-auto flex items-center justify-center">
                  <AlertCircle className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-white">
                    {isRw ? 'Link Ntabwo Yemewe Cyangwa Yararangiye' : 'Invalid or Expired Reset Link'}
                  </h3>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto">
                    {isRw
                      ? 'Link yo guhindura ijambo ry\'ibanga ikoreshwa rimwe gusa kandi ifite igihe ntarengwa cyo gukoreshwa. Nyamuneka saba indi nshya.'
                      : 'Firebase password reset links can only be used once and expire after a limited time. Please request a fresh reset link.'}
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMsg('');
                      setStep('REQUEST');
                    }}
                    className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-3 rounded-xl transition-all text-xs"
                  >
                    {isRw ? 'Saba Indi Link Nshya' : 'Request New Reset Link'}
                  </button>
                  <button
                    type="button"
                    onClick={onNavigateToLogin}
                    className="flex-1 bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 rounded-xl transition-all text-xs"
                  >
                    {isRw ? 'Subira Kwinjira' : 'Back to Login'}
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleCompleteResetSubmit} className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-300 font-bold mb-1.5">
                    {isRw ? 'Ijambo ry\'Ibanga Rishya (New Password):' : 'New Password:'}
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      id="reset-new-password-input"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3.5 pr-10 text-white outline-none focus:border-emerald-500 transition-colors font-mono text-sm"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1.5">
                    {isRw ? 'Emeza Ijambo ry\'Ibanga Rishya (Confirm Password):' : 'Confirm New Password:'}
                  </label>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    id="reset-confirm-password-input"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3.5 text-white outline-none focus:border-emerald-500 transition-colors font-mono text-sm"
                    required
                  />
                </div>

                {/* Password Policy Checklist */}
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 text-[11px]">
                  <span className="font-bold text-slate-300 uppercase tracking-wider block border-b border-slate-800 pb-1.5 text-[10px]">
                    {isRw ? 'Ibipimo by\'Umutekano (Password Requirements)' : 'Password Policy Checklist'}
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 font-medium">
                    <div className={`flex items-center gap-1.5 ${passHasMinLength ? 'text-emerald-400' : 'text-slate-500'}`}>
                      {passHasMinLength ? <Check className="w-3.5 h-3.5 shrink-0" /> : <XCircle className="w-3.5 h-3.5 shrink-0" />}
                      <span>{isRw ? 'Byibuze inyuguti 8' : 'Minimum 8 characters'}</span>
                    </div>

                    <div className={`flex items-center gap-1.5 ${passHasUpper ? 'text-emerald-400' : 'text-slate-500'}`}>
                      {passHasUpper ? <Check className="w-3.5 h-3.5 shrink-0" /> : <XCircle className="w-3.5 h-3.5 shrink-0" />}
                      <span>{isRw ? 'Inyuguti nkuru (A-Z)' : 'Uppercase letter (A-Z)'}</span>
                    </div>

                    <div className={`flex items-center gap-1.5 ${passHasLower ? 'text-emerald-400' : 'text-slate-500'}`}>
                      {passHasLower ? <Check className="w-3.5 h-3.5 shrink-0" /> : <XCircle className="w-3.5 h-3.5 shrink-0" />}
                      <span>{isRw ? 'Inyuguti ntoya (a-z)' : 'Lowercase letter (a-z)'}</span>
                    </div>

                    <div className={`flex items-center gap-1.5 ${passHasNumber ? 'text-emerald-400' : 'text-slate-500'}`}>
                      {passHasNumber ? <Check className="w-3.5 h-3.5 shrink-0" /> : <XCircle className="w-3.5 h-3.5 shrink-0" />}
                      <span>{isRw ? 'Imibare (0-9)' : 'Number (0-9)'}</span>
                    </div>

                    <div className={`flex items-center gap-1.5 ${passHasSpecial ? 'text-emerald-400' : 'text-slate-500'}`}>
                      {passHasSpecial ? <Check className="w-3.5 h-3.5 shrink-0" /> : <XCircle className="w-3.5 h-3.5 shrink-0" />}
                      <span>{isRw ? 'Inyuguti y\'igishushanyo (!@#$)' : 'Special char (!@#$%^&*)'}</span>
                    </div>

                    <div className={`flex items-center gap-1.5 ${passwordsMatch ? 'text-emerald-400' : 'text-slate-500'}`}>
                      {passwordsMatch ? <Check className="w-3.5 h-3.5 shrink-0" /> : <XCircle className="w-3.5 h-3.5 shrink-0" />}
                      <span>{isRw ? 'Amajambo aragenda ahura' : 'Passwords match'}</span>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  id="reset-submit-new-pass-btn"
                  disabled={loading || !passHasMinLength || !passwordsMatch}
                  className="w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black py-3.5 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 text-sm uppercase tracking-wide disabled:opacity-50 cursor-pointer"
                >
                  {loading ? (
                    <>
                      <RotateCw className="w-5 h-5 animate-spin" />
                      <span>{isRw ? 'GUKORA IMPINDUKA...' : 'SAVING NEW PASSWORD...'}</span>
                    </>
                  ) : (
                    <>
                      <Lock className="w-5 h-5" />
                      <span>{isRw ? 'EMEZA IJAMBO RY\'IBANGA RISHYA' : 'SAVE NEW PASSWORD'}</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* STEP 4 / STATE B: PASSWORD RESET ACTUALLY COMPLETED                       */}
        {/* ========================================================================= */}
        {step === 'RESET_COMPLETED' && (
          <div className="text-center space-y-6 py-4 animate-fadeIn">
            <div className="w-20 h-20 mx-auto rounded-3xl bg-emerald-500/20 border-2 border-emerald-500/50 flex items-center justify-center text-emerald-400 shadow-2xl">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                {isRw ? 'Hindura Ijambo ry\'Ibanga Byarangiye Neza!' : 'Password Reset Successful'}
              </h2>
              <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                {isRw
                  ? 'Ijambo ry\'ibanga ryawe ryahinduwe neza. Ubu ushobora kwinjira ukoresheje ijambo ry\'ibanga rishya.'
                  : 'Your password has been successfully changed. You can now log in using your new password.'}
              </p>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl max-w-md mx-auto text-xs text-slate-400 space-y-1">
              <div className="flex items-center justify-center gap-1.5 text-emerald-400 font-bold">
                <ShieldCheck className="w-4 h-4" />
                <span>{isRw ? 'Umutekano wa Konti Wawe Urakomeje' : 'Account Security Confirmed'}</span>
              </div>
              <p className="text-[11px]">
                {isRw
                  ? 'Amakuru y\'umwirondoro wawe n\'inshingano zawe biracyari bya bindi.'
                  : 'Your account profile and existing permissions remain preserved.'}
              </p>
            </div>

            <button
              type="button"
              id="reset-success-goto-login-btn"
              onClick={onNavigateToLogin}
              className="w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black py-4 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 text-sm uppercase tracking-wide cursor-pointer"
            >
              <span>{isRw ? 'JYA KWINJIRA (GO TO LOGIN)' : 'GO TO LOGIN PAGE'}</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
