import React, { useState, useMemo } from 'react';
import { User, Language, UserRole } from '../../types';
import { translations } from '../../data/translations';
import { useAuth } from '../../context/AuthContext';
import {
  getRwandaProvinces,
  getRwandaDistricts,
  getRwandaSectors,
  getRwandaCells,
  getRwandaVillages
} from '../../data/rwandaLocations';
import {
  X,
  LogIn,
  UserPlus,
  ShieldCheck,
  Phone,
  Mail,
  Lock,
  User as UserIcon,
  MapPin,
  CheckCircle2,
  AlertCircle,
  Briefcase,
  Smartphone,
  RefreshCw
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  initialMode?: 'login' | 'register';
  language: Language;
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
  onRegisterSuccess: (newUser: User) => void;
  onOpenForgotPassword?: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode = 'login',
  language,
  onClose,
  onLoginSuccess,
  onRegisterSuccess,
  onOpenForgotPassword,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [successMsg, setSuccessMsg] = useState<string>('');

  // Login form state
  const [loginPhoneOrEmail, setLoginPhoneOrEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Register form state
  const [regFullName, setRegFullName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regNationalId, setRegNationalId] = useState('');
  
  // Rwanda Location Hierarchy State
  const provinces = useMemo(() => getRwandaProvinces(), []);
  const [regProvince, setRegProvince] = useState('Northern Province');
  const [regDistrict, setRegDistrict] = useState('Musanze');
  const [regSector, setRegSector] = useState('Kinigi');
  const [regCell, setRegCell] = useState('Kaguhu');
  const [regVillage, setRegVillage] = useState('Bisate');

  const availableDistricts = useMemo(() => getRwandaDistricts(regProvince), [regProvince]);
  const availableSectors = useMemo(() => getRwandaSectors(regProvince, regDistrict), [regProvince, regDistrict]);
  const availableCells = useMemo(() => getRwandaCells(regProvince, regDistrict, regSector), [regProvince, regDistrict, regSector]);
  const availableVillages = useMemo(() => getRwandaVillages(regProvince, regDistrict, regSector, regCell), [regProvince, regDistrict, regSector, regCell]);

  const [regRole, setRegRole] = useState<UserRole>('farmer');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [agreedTerms, setAgreedTerms] = useState(false);
  const [loading, setLoading] = useState(false);

  const t = translations[language] || translations['rw'];
  const { loginWithEmail, registerWithEmail, signInWithGoogle } = useAuth();

  const handleGoogleSignIn = async () => {
    if (loading) return;
    setErrorMsg('');
    setSuccessMsg('');
    setLoading(true);
    try {
      const res = await signInWithGoogle(language);
      if (res.success && res.user) {
        setSuccessMsg(
          language === 'rw'
            ? `Kwinjira kuri Google byagenze neza! Ikaze, ${res.user.name}.`
            : `Google sign-in successful! Welcome, ${res.user.name}.`
        );
        setTimeout(() => {
          onLoginSuccess(res.user!);
          onClose();
        }, 400);
      } else {
        setErrorMsg(res.error || 'Google sign-in error.');
      }
    } catch (err: any) {
      console.error('Modal Google sign-in error:', err);
      setErrorMsg(err?.message || 'Google sign-in error.');
    } finally {
      setLoading(false);
    }
  };

  const handleProvinceChange = (newProvinceName: string) => {
    setRegProvince(newProvinceName);
    const districts = getRwandaDistricts(newProvinceName);
    const firstDistrict = districts[0]?.name || '';
    setRegDistrict(firstDistrict);

    const sectors = getRwandaSectors(newProvinceName, firstDistrict);
    const firstSector = sectors[0]?.name || '';
    setRegSector(firstSector);

    const cells = getRwandaCells(newProvinceName, firstDistrict, firstSector);
    const firstCell = cells[0]?.name || '';
    setRegCell(firstCell);

    const villages = getRwandaVillages(newProvinceName, firstDistrict, firstSector, firstCell);
    setRegVillage(villages[0] || '');
  };

  const handleDistrictChange = (newDistrictName: string) => {
    setRegDistrict(newDistrictName);
    const sectors = getRwandaSectors(regProvince, newDistrictName);
    const firstSector = sectors[0]?.name || '';
    setRegSector(firstSector);

    const cells = getRwandaCells(regProvince, newDistrictName, firstSector);
    const firstCell = cells[0]?.name || '';
    setRegCell(firstCell);

    const villages = getRwandaVillages(regProvince, newDistrictName, firstSector, firstCell);
    setRegVillage(villages[0] || '');
  };

  const handleSectorChange = (newSectorName: string) => {
    setRegSector(newSectorName);
    const cells = getRwandaCells(regProvince, regDistrict, newSectorName);
    const firstCell = cells[0]?.name || '';
    setRegCell(firstCell);

    const villages = getRwandaVillages(regProvince, regDistrict, newSectorName, firstCell);
    setRegVillage(villages[0] || '');
  };

  const handleCellChange = (newCellName: string) => {
    setRegCell(newCellName);
    const villages = getRwandaVillages(regProvince, regDistrict, regSector, newCellName);
    setRegVillage(villages[0] || '');
  };

  if (!isOpen) return null;

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!loginPhoneOrEmail || !loginPassword) {
      setErrorMsg(
        language === 'rw'
          ? 'Uzuzamo nimero ya telefoni/i-meyiri n\'ijambo ry\'ibanga.'
          : 'Please enter your phone/email and password.'
      );
      return;
    }

    setLoading(true);
    try {
      const authResult = await loginWithEmail(loginPhoneOrEmail, loginPassword, language);

      if (!authResult.success || !authResult.user) {
        setErrorMsg(authResult.error || (language === 'rw' ? 'I-meyiri cyangwa ijambo ry\'ibanga ntabwo bihura.' : 'Invalid email/phone or password.'));
        return;
      }

      const matched = authResult.user;
      setSuccessMsg(
        language === 'rw'
          ? `Kwinjira byagenze neza! Murakaza neza, ${matched.name}.`
          : `Login successful! Welcome back, ${matched.name}.`
      );

      setTimeout(() => {
        onLoginSuccess(matched);
        onClose();
      }, 400);
    } catch (err: any) {
      console.error('Modal login error:', err);
      setErrorMsg(err?.message || 'Authentication error.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!regFullName || !regPhone || !regPassword) {
      setErrorMsg(
        language === 'rw'
          ? 'Nyamuneka uzuza amazina, telefoni n\'ijambo ry\'ibanga.'
          : 'Please fill in full name, phone number, and password.'
      );
      return;
    }

    if (regPassword.length < 6) {
      setErrorMsg(
        language === 'rw'
          ? 'Ijambo ry\'ibanga rigomba kuba rifite inyuguti 6 cyangwa zirenga.'
          : 'Password must be at least 6 characters long.'
      );
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setErrorMsg(
        language === 'rw'
          ? 'Amagambo y\'ibanga ntabwo ahura.'
          : 'Passwords do not match.'
      );
      return;
    }

    if (regNationalId) {
      const cleanId = regNationalId.replace(/\D/g, '');
      if (cleanId.length !== 16) {
        setErrorMsg(
          language === 'rw'
            ? 'Indangamuntu igomba kuba igizwe n\'imibare 16.'
            : 'National ID must be exactly 16 digits.'
        );
        return;
      }
    }

    if (!agreedTerms) {
      setErrorMsg(
        language === 'rw'
          ? 'Nyamuneka yemera amategeko n\'amabwiriza y\'ikoreshwa.'
          : 'Please accept the Terms & Conditions to register.'
      );
      return;
    }

    const cleanId = regNationalId ? regNationalId.replace(/\D/g, '') : undefined;
    const maskedId = cleanId && cleanId.length >= 4 ? `********${cleanId.slice(-4)}` : undefined;

    setLoading(true);
    try {
      const res = await registerWithEmail({
        fullName: regFullName,
        phone: regPhone,
        email: regEmail,
        role: regRole,
        province: regProvince,
        district: regDistrict,
        sector: regSector,
        cell: regCell,
        village: regVillage,
        password: regPassword,
        language: language,
        nationalIdMasked: maskedId,
        identityStatus: cleanId ? 'pending' : 'not_started',
      });

      if (!res.success || !res.user) {
        setErrorMsg(res.error || 'Registration failed.');
        return;
      }

      setSuccessMsg(
        language === 'rw'
          ? `Akaunti nshya yakozwe neza! Murakaza neza kuri AGRIWISE RWANDA.`
          : `Account successfully created! Welcome to AGRIWISE RWANDA.`
      );

      setTimeout(() => {
        onRegisterSuccess(res.user!);
        onClose();
      }, 500);
    } catch (err: any) {
      console.error('Modal register error:', err);
      setErrorMsg(err?.message || 'Registration error.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-slate-900 border border-emerald-500/30 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header Bar */}
        <div className="relative bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 p-6 border-b border-emerald-500/20">
          <button
            onClick={onClose}
            id="auth-modal-close-btn"
            className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/60 hover:bg-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <ShieldCheck className="w-7 h-7 text-emerald-400" />
              </div>
            </div>
            <div>
              <h2 className="text-xl font-black tracking-tight text-white flex items-center gap-2">
                AGRIWISE RWANDA
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded-full uppercase">
                  Auth Portal
                </span>
              </h2>
              <p className="text-xs text-emerald-300/80">
                {mode === 'login'
                  ? language === 'rw' ? 'Injira mu konti yawe y\'ubuhinzi' : 'Sign in to your agricultural account'
                  : language === 'rw' ? 'Fungura konti nshya kuri AGRIWISE' : 'Create a new AGRIWISE Rwanda account'}
              </p>
            </div>
          </div>

          {/* Tab Controls */}
          <div className="flex bg-slate-950/80 p-1.5 rounded-2xl border border-slate-800 mt-5">
            <button
              id="auth-tab-login-btn"
              onClick={() => {
                setMode('login');
                setErrorMsg('');
                setSuccessMsg('');
              }}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                mode === 'login'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <LogIn className="w-4 h-4" />
              <span>{t.login || 'Injira / Login'}</span>
            </button>
            <button
              id="auth-tab-register-btn"
              onClick={() => {
                setMode('register');
                setErrorMsg('');
                setSuccessMsg('');
              }}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                mode === 'register'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <UserPlus className="w-4 h-4" />
              <span>{t.register || 'Iyandikishe / Register'}</span>
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-5 custom-scrollbar text-xs">
          
          {/* Success / Error Banners */}
          {errorMsg && (
            <div className="p-3 bg-rose-950/60 border border-rose-500/50 rounded-2xl text-rose-300 animate-in fade-in space-y-2">
              <div className="flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                <span className="font-medium">{errorMsg}</span>
              </div>
              {mode === 'register' && (errorMsg.includes('already exists') || errorMsg.includes('isanzwe ifite') || errorMsg.includes('isanzwe ikoreshwa')) && (
                <div className="pt-1 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setLoginPhoneOrEmail(regEmail);
                      setMode('login');
                      setErrorMsg('');
                    }}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-[11px] transition-all cursor-pointer flex items-center gap-1 shadow-sm"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>{language === 'rw' ? 'Injira muri iyi Akaunti' : 'Sign in with this email'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleGoogleSignIn}
                    className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-900 rounded-lg font-bold text-[11px] transition-all cursor-pointer shadow-sm"
                  >
                    <span>Google Sign In</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {successMsg && (
            <div className="flex items-center space-x-2 p-3 bg-emerald-950/60 border border-emerald-500/50 rounded-2xl text-emerald-300 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span className="font-bold">{successMsg}</span>
            </div>
          )}

          {/* MODE 1: LOGIN FORM */}
          {mode === 'login' ? (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-slate-300 font-bold mb-1.5 flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                  {language === 'rw' ? 'Telefoni cyangwa I-meyiri' : 'Phone Number or Email'}
                </label>
                <input
                  type="text"
                  id="auth-login-phone-email-input"
                  value={loginPhoneOrEmail}
                  onChange={(e) => setLoginPhoneOrEmail(e.target.value)}
                  placeholder="e.g. +250 788 345 678 cyangwa farmer@agriwise.rw"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-white font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-slate-300 font-bold flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-emerald-400" />
                    {language === 'rw' ? 'Ijambo ry\'ibanga (Password)' : 'Password'}
                  </label>
                  {onOpenForgotPassword && (
                    <button
                      type="button"
                      id="auth-forgot-password-link"
                      onClick={() => {
                        onClose();
                        onOpenForgotPassword();
                      }}
                      className="text-xs text-emerald-400 hover:text-emerald-300 hover:underline font-bold transition-colors cursor-pointer"
                    >
                      {language === 'rw' ? 'Wibagiwe?' : 'Forgot Password?'}
                    </button>
                  )}
                </div>
                <input
                  type="password"
                  id="auth-login-password-input"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-white font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500 font-mono"
                />
              </div>

              <button
                type="submit"
                id="auth-modal-login-btn"
                disabled={loading}
                className="w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black py-3 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 text-sm uppercase tracking-wide mt-2 disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer"
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{language === 'rw' ? 'Birimo Gukorwa...' : 'Signing In...'}</span>
                  </>
                ) : (
                  <>
                    <LogIn className="w-4 h-4" />
                    <span>{language === 'rw' ? 'Injira Kuri AGRIWISE' : 'Sign In To AGRIWISE'}</span>
                  </>
                )}
              </button>

              <div className="relative my-3 flex items-center justify-center">
                <div className="border-t border-slate-800 w-full"></div>
                <span className="bg-slate-900 px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  {language === 'rw' ? 'Cyangwa' : 'OR'}
                </span>
                <div className="border-t border-slate-800 w-full"></div>
              </div>

              <button
                type="button"
                id="auth-modal-google-btn"
                onClick={handleGoogleSignIn}
                disabled={loading}
                className="w-full bg-white hover:bg-slate-100 text-slate-900 font-bold py-2.5 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2.5 border border-slate-300 text-xs disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer"
              >
                <svg className="w-4 h-4" viewBox="0 0 48 48">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                </svg>
                <span>{language === 'rw' ? 'Komeza ukoresheje Google' : 'Continue with Google'}</span>
              </button>
            </form>
          ) : (
            /* MODE 2: REGISTER FORM */
            <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1">
                    <UserIcon className="w-3.5 h-3.5 text-emerald-400" />
                    {language === 'rw' ? 'Izina Ryose' : 'Full Name'}
                  </label>
                  <input
                    type="text"
                    id="auth-reg-fullname-input"
                    value={regFullName}
                    onChange={(e) => setRegFullName(e.target.value)}
                    placeholder="e.g. Jean Baptiste Hakizimana"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-white font-medium focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-emerald-400" />
                    {language === 'rw' ? 'Telefoni (+250)' : 'Phone Number'}
                  </label>
                  <input
                    type="text"
                    id="auth-reg-phone-input"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder="+250 788 123 456"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-white font-medium focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    {language === 'rw' ? 'Indangamuntu (16 Digits)' : 'National ID (16 Digits)'}
                  </label>
                  <input
                    type="text"
                    id="auth-reg-nationalid-input"
                    value={regNationalId}
                    onChange={(e) => setRegNationalId(e.target.value)}
                    placeholder="1 1990 8 0012345 0 12"
                    maxLength={20}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-white font-medium focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1">
                    <Mail className="w-3.5 h-3.5 text-emerald-400" />
                    {language === 'rw' ? 'I-meyiri (Email)' : 'Email Address'}
                  </label>
                  <input
                    type="email"
                    id="auth-reg-email-input"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="hakizimana@agriwise.rw"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-white font-medium focus:outline-none"
                  />
                </div>
              </div>

              {/* RWANDA LOCATION CASCADE */}
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="text-emerald-300 font-bold flex items-center gap-1 text-[11px]">
                    <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{language === 'rw' ? 'Aderesi y\'Ahantu' : 'Administrative Location (Rwanda)'}</span>
                  </label>
                  <span className="text-[9px] text-slate-400">Province → District → Sector → Cell → Village</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="block text-slate-400 text-[10px] mb-0.5">Intara (Province)</label>
                    <select
                      id="auth-reg-province-select"
                      value={regProvince}
                      onChange={(e) => handleProvinceChange(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white outline-none focus:border-emerald-500"
                    >
                      {provinces.map((p) => (
                        <option key={p.id} value={p.name}>
                          {language === 'rw' ? p.nameRw : p.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 text-[10px] mb-0.5">Akarere (District)</label>
                    <select
                      id="auth-reg-district-select"
                      value={regDistrict}
                      onChange={(e) => handleDistrictChange(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white outline-none focus:border-emerald-500"
                    >
                      {availableDistricts.map((d) => (
                        <option key={d.id} value={d.name}>{d.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div>
                    <label className="block text-slate-400 text-[10px] mb-0.5">Umurenge (Sector)</label>
                    <select
                      id="auth-reg-sector-select"
                      value={regSector}
                      onChange={(e) => handleSectorChange(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white outline-none focus:border-emerald-500"
                    >
                      {availableSectors.map((s) => (
                        <option key={s.id} value={s.name}>{s.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 text-[10px] mb-0.5">Akagari (Cell)</label>
                    <select
                      id="auth-reg-cell-select"
                      value={regCell}
                      onChange={(e) => handleCellChange(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white outline-none focus:border-emerald-500"
                    >
                      {availableCells.map((c) => (
                        <option key={c.id} value={c.name}>{c.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 text-[10px] mb-0.5">Umudugudu (Village)</label>
                    <select
                      id="auth-reg-village-select"
                      value={regVillage}
                      onChange={(e) => setRegVillage(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white outline-none focus:border-emerald-500"
                    >
                      {availableVillages.map((v) => (
                        <option key={v} value={v}>{v}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1">
                  <Briefcase className="w-3.5 h-3.5 text-emerald-400" />
                  Inshingano (Account Role)
                </label>
                <select
                  id="auth-reg-role-select"
                  value={regRole}
                  onChange={(e) => setRegRole(e.target.value as UserRole)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-white font-medium focus:outline-none"
                >
                  <option value="farmer">Umuhinzi (Crop Farmer)</option>
                  <option value="livestock">Umworozi (Livestock)</option>
                  <option value="cooperative">Koperative</option>
                  <option value="agrodealer">Agro-dealer</option>
                  <option value="buyer">Umuguzi (Buyer)</option>
                  <option value="expert">Agronomist/Vet</option>
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    Ijambo ry'ibanga (Password)
                  </label>
                  <input
                    type="password"
                    id="auth-reg-password-input"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-white font-medium focus:outline-none font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    Emeza Ijambo ry'ibanga
                  </label>
                  <input
                    type="password"
                    id="auth-reg-confirm-password-input"
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-white font-medium focus:outline-none font-mono"
                    required
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2 pt-1">
                <input
                  type="checkbox"
                  id="agreedTerms"
                  checked={agreedTerms}
                  onChange={(e) => setAgreedTerms(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-500 focus:ring-emerald-500 bg-slate-950 border-slate-800 cursor-pointer"
                  required
                />
                <label htmlFor="agreedTerms" className="text-[11px] text-slate-400 cursor-pointer">
                  {language === 'rw'
                    ? 'Ndemera amategeko n\'amabwiriza ya AGRIWISE Rwanda'
                    : 'I agree to AGRIWISE Rwanda Terms & Privacy Policy'}
                </label>
              </div>

              <button
                type="submit"
                id="auth-modal-register-btn"
                disabled={loading}
                className="w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black py-3 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 text-sm uppercase tracking-wide disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer"
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{language === 'rw' ? 'Birimo Gukorwa...' : 'Creating Account...'}</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4" />
                    <span>{language === 'rw' ? 'Kora Konti Nshya' : 'Create Account'}</span>
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
