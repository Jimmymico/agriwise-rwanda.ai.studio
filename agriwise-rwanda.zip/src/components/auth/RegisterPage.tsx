import React, { useState, useMemo } from 'react';
import { User, Language, UserRole } from '../../types';
import { translations } from '../../data/translations';
import { useAuth, normalizePhoneNumber } from '../../context/AuthContext';
import {
  verifyNationalIdentityServerSide
} from '../../services/authService';
import {
  getRwandaProvinces,
  getRwandaDistricts,
  getRwandaSectors,
  getRwandaCells,
  getRwandaVillages
} from '../../data/rwandaLocations';
import {
  UserPlus,
  ShieldCheck,
  Phone,
  Mail,
  Lock,
  User as UserIcon,
  MapPin,
  CheckCircle2,
  AlertCircle,
  Briefcase,
  ArrowRight,
  Home,
  LogIn,
  Calendar,
  RefreshCw,
} from 'lucide-react';

interface RegisterPageProps {
  language: Language;
  onRegisterSuccess: (newUser: User) => void;
  onNavigateToLogin: () => void;
  onNavigateToHome: () => void;
  onNavigateToVerifyEmail?: () => void;
}

export const RegisterPage: React.FC<RegisterPageProps> = ({
  language,
  onRegisterSuccess,
  onNavigateToLogin,
  onNavigateToHome,
}) => {
  const t = translations[language] || translations['rw'];
  const { registerWithEmail, signInWithGoogle } = useAuth();

  // Registration Form Fields
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('farmer');
  
  // Rwanda Administrative Location Hierarchy: Province -> District -> Sector -> Cell -> Village
  const provinces = useMemo(() => getRwandaProvinces(), []);
  const [province, setProvince] = useState('Northern Province');
  const [district, setDistrict] = useState('Musanze');
  const [sector, setSector] = useState('Kinigi');
  const [cell, setCell] = useState('Kaguhu');
  const [village, setVillage] = useState('Bisate');

  // Dynamic Location Lists
  const availableDistricts = useMemo(() => getRwandaDistricts(province), [province]);
  const availableSectors = useMemo(() => getRwandaSectors(province, district), [province, district]);
  const availableCells = useMemo(() => getRwandaCells(province, district, sector), [province, district, sector]);
  const availableVillages = useMemo(() => getRwandaVillages(province, district, sector, cell), [province, district, sector, cell]);

  // Credentials & Verification State
  const [nationalId, setNationalId] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('1992-05-14');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [agreedTerms, setAgreedTerms] = useState(false);

  // Status & Feedback
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Cascading Location Handlers
  const handleProvinceChange = (newProvinceName: string) => {
    setProvince(newProvinceName);
    const districts = getRwandaDistricts(newProvinceName);
    const firstDistrict = districts[0]?.name || '';
    setDistrict(firstDistrict);

    const sectors = getRwandaSectors(newProvinceName, firstDistrict);
    const firstSector = sectors[0]?.name || '';
    setSector(firstSector);

    const cells = getRwandaCells(newProvinceName, firstDistrict, firstSector);
    const firstCell = cells[0]?.name || '';
    setCell(firstCell);

    const villages = getRwandaVillages(newProvinceName, firstDistrict, firstSector, firstCell);
    setVillage(villages[0] || '');
  };

  const handleDistrictChange = (newDistrictName: string) => {
    setDistrict(newDistrictName);
    const sectors = getRwandaSectors(province, newDistrictName);
    const firstSector = sectors[0]?.name || '';
    setSector(firstSector);

    const cells = getRwandaCells(province, newDistrictName, firstSector);
    const firstCell = cells[0]?.name || '';
    setCell(firstCell);

    const villages = getRwandaVillages(province, newDistrictName, firstSector, firstCell);
    setVillage(villages[0] || '');
  };

  const handleSectorChange = (newSectorName: string) => {
    setSector(newSectorName);
    const cells = getRwandaCells(province, district, newSectorName);
    const firstCell = cells[0]?.name || '';
    setCell(firstCell);

    const villages = getRwandaVillages(province, district, newSectorName, firstCell);
    setVillage(villages[0] || '');
  };

  const handleCellChange = (newCellName: string) => {
    setCell(newCellName);
    const villages = getRwandaVillages(province, district, sector, newCellName);
    setVillage(villages[0] || '');
  };

  // Form Submission Handler
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!fullName.trim() || !phone.trim() || !email.trim() || !password) {
      setErrorMsg(
        language === 'rw'
          ? 'Nyamuneka uzuze imyirondoro yawe yose (Izina, Telefoni, E-mail n\'Ijambo ry\'ibanga).'
          : language === 'fr'
          ? 'Veuillez remplir tous les champs obligatoires (Nom, Téléphone, E-mail et Mot de passe).'
          : 'Please fill in all required fields (Full name, Phone number, Email, and Password).'
      );
      return;
    }

    if (!province || !district || !sector) {
      setErrorMsg(
        language === 'rw'
          ? 'Nyamuneka hitamo Intara, Akarere, n\'Umurenge byawe.'
          : language === 'fr'
          ? 'Veuillez sélectionner votre Province, District et Secteur.'
          : 'Please select your Province, District, and Sector.'
      );
      return;
    }

    if (password.length < 6) {
      setErrorMsg(
        language === 'rw'
          ? 'Ijambo ry\'ibanga rigomba kurenza inyuguti 6.'
          : language === 'fr'
          ? 'Le mot de passe doit comporter au moins 6 caractères.'
          : 'Password must be at least 6 characters long.'
      );
      return;
    }

    if (password !== confirmPassword) {
      setErrorMsg(
        language === 'rw'
          ? 'Amagambo y\'ibanga ntabwo ahura.'
          : language === 'fr'
          ? 'Les mots de passe ne correspondent pas.'
          : 'Passwords do not match.'
      );
      return;
    }

    if (!agreedTerms) {
      setErrorMsg(
        language === 'rw'
          ? 'Mbanza kwemera amategeko n\'amabwiriza ya AGRIWISE Rwanda.'
          : language === 'fr'
          ? 'Vous devez accepter les conditions d\'utilisation de la plateforme AGRIWISE Rwanda.'
          : 'You must accept the AGRIWISE Rwanda platform terms and conditions.'
      );
      return;
    }

    setIsSubmitting(true);

    try {
      const normalizedPhone = normalizePhoneNumber(phone);

      // Optional National ID verification formatting
      let maskedId: string | undefined;
      let idHash: string | undefined;
      let idStatus: 'not_started' | 'pending' | 'verified' | 'failed' | 'manual_review' = 'not_started';
      let providerRef: string | undefined;

      const cleanId = nationalId.replace(/\D/g, '');
      if (cleanId.length > 0) {
        if (cleanId.length === 16) {
          try {
            const idRes = await verifyNationalIdentityServerSide({
              nationalIdNumber: cleanId,
              fullName,
              dateOfBirth,
              district,
            });
            maskedId = idRes.nationalIdMasked;
            idHash = idRes.nationalIdHash;
            idStatus = idRes.identityStatus;
            providerRef = idRes.providerReference;
          } catch (idErr) {
            console.warn('Optional national ID verification notice:', idErr);
            maskedId = `********${cleanId.slice(-4)}`;
            idStatus = 'pending';
          }
        } else {
          maskedId = cleanId.length >= 4 ? `********${cleanId.slice(-4)}` : undefined;
        }
      }

      const res = await registerWithEmail({
        fullName: fullName.trim(),
        phone: normalizedPhone,
        email: email.trim().toLowerCase(),
        role,
        province,
        district,
        sector,
        cell,
        village,
        password,
        language,
        nationalIdMasked: maskedId,
        nationalIdHash: idHash,
        identityStatus: idStatus,
        identityProviderReference: providerRef,
        dateOfBirth,
      });

      if (res.success && res.user) {
        setSuccessMsg(
          language === 'rw'
            ? `Akaunti yawe yafunguwe neza! Ikaze kuri AGRIWISE Rwanda, ${res.user.name}.`
            : language === 'fr'
            ? `Compte créé avec succès ! Bienvenue sur AGRIWISE Rwanda, ${res.user.name}.`
            : `Account created successfully! Welcome to AGRIWISE Rwanda, ${res.user.name}.`
        );
        setTimeout(() => {
          onRegisterSuccess(res.user!);
        }, 800);
      } else {
        setErrorMsg(res.error || 'Failed to create account. Please check your credentials.');
      }
    } catch (err: any) {
      console.error('Registration submission error:', err);
      setErrorMsg(err?.message || 'Failed to complete registration.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleRegistration = async () => {
    setErrorMsg('');
    setSuccessMsg('');
    try {
      const res = await signInWithGoogle(language);
      if (res.success && res.user) {
        setSuccessMsg(
          language === 'rw'
            ? `Wiyandikishije neza ukoresheje Google! Ikaze, ${res.user.name}.`
            : language === 'fr'
            ? `Inscription réussie avec Google ! Bienvenue, ${res.user.name}.`
            : `Successfully registered & signed in with Google! Welcome, ${res.user.name}.`
        );
        setTimeout(() => {
          onRegisterSuccess(res.user!);
        }, 600);
      } else {
        setErrorMsg(res.error || 'Google registration error.');
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Google registration error.');
    }
  };

  return (
    <div className="min-h-[85vh] flex flex-col justify-center items-center py-8 px-4 font-sans text-slate-100">
      <div className="w-full max-w-2xl bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 sm:p-10 shadow-2xl relative space-y-6">
        
        {/* Navigation Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <button
            onClick={onNavigateToHome}
            id="register-return-home-btn"
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-emerald-400 font-bold transition-colors cursor-pointer"
          >
            <Home className="w-4 h-4 text-emerald-400" />
            <span>{language === 'rw' ? '← Sura Paji y\'Ibanze (Home)' : language === 'fr' ? '← Retour à l\'Accueil' : '← Return to Home'}</span>
          </button>

          <span className="text-[10px] font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded-full uppercase">
            {language === 'rw' ? 'IYANDIKISHA RISHYA' : language === 'fr' ? 'NOUVELLE INSCRIPTION' : 'NEW REGISTRATION'}
          </span>
        </div>

        {/* Page Title & Intro */}
        <div className="text-center space-y-2">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-lg">
            <UserPlus className="w-7 h-7" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            {language === 'rw' ? 'Iyandikishe Kuri AGRIWISE Rwanda' : language === 'fr' ? 'Créer un Compte AGRIWISE' : 'Create an AGRIWISE Account'}
          </h1>
          <p className="text-xs text-slate-300 max-w-lg mx-auto leading-relaxed">
            {language === 'rw'
              ? 'Fungura akaunti wiyandikishe nk\'umuhinzi, umworozi, koperative, agro-dealer cyangwa umu-expert ubashe kubona AI n\'isoko ry\'ubuhinzi.'
              : language === 'fr'
              ? 'Rejoignez l\'écosystème agricole numérique du Rwanda en tant qu\'agriculteur, éleveur, coopérative, agro-dealer ou expert RAB.'
              : 'Join Rwanda\'s leading agricultural ecosystem as a farmer, livestock keeper, cooperative, agro-dealer, or RAB expert.'}
          </p>
        </div>

        {/* Feedback Alerts */}
        {errorMsg && (
          <div className="p-3.5 bg-rose-950/80 border border-rose-500/50 rounded-2xl text-rose-200 text-xs font-bold animate-fadeIn space-y-2">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMsg}</span>
            </div>
            {(errorMsg.includes('already exists') || errorMsg.includes('isanzwe ifite') || errorMsg.includes('isanzwe ikoreshwa')) && (
              <div className="pt-1 flex items-center gap-2">
                <button
                  type="button"
                  id="register-error-goto-login-btn"
                  onClick={onNavigateToLogin}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs transition-all cursor-pointer flex items-center gap-1.5 shadow-md"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>{language === 'rw' ? 'Injira muri Akaunti (Go to Login)' : language === 'fr' ? 'Se Connecter' : 'Go to Login'}</span>
                </button>
              </div>
            )}
          </div>
        )}

        {successMsg && (
          <div className="p-3.5 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl flex items-center gap-2 text-emerald-200 text-xs font-bold animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* REGISTRATION FORM */}
        <form onSubmit={handleRegisterSubmit} className="space-y-4 text-xs">
          
          {/* 1. Account Role Selection */}
          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
            <label className="block text-emerald-300 font-bold flex items-center gap-1.5">
              <Briefcase className="w-4 h-4 text-emerald-400" />
              <span>{language === 'rw' ? '1. Hitamo Icyiciro cy\'Umukoresha (Account Role):' : language === 'fr' ? '1. Choisissez votre rôle (Type de Compte) :' : '1. Choose Your Account Type:'}</span>
            </label>
            <select
              id="register-role-select"
              value={role}
              onChange={(e) => setRole(e.target.value as UserRole)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-white outline-none focus:border-emerald-500 font-bold cursor-pointer"
            >
              <option value="farmer">Umuhinzi (Smallholder Farmer)</option>
              <option value="livestock">Umworozi (Livestock Farmer)</option>
              <option value="cooperative">Koperative y'Ubuhinzi (Agricultural Cooperative)</option>
              <option value="agrodealer">Umunyaduka w'Ibyonyo & Inyongeramusaruro (Agro-dealer)</option>
              <option value="buyer">Umuguzi w'Umusaruro (Commodity Buyer / Offtaker)</option>
              <option value="expert">Umuhanga mu Buhinzi / Vet (RAB Certified Expert)</option>
              <option value="transporter">Umunyatagisi/Umwikorezi (Agri Logistics & Transporter)</option>
              <option value="bank_insurance">Inzego z'Imari/Inguzanyo (Bank & Microfinance Officer)</option>
              <option value="government_ngo">Leta & MINAGRI (Government Agronomist)</option>
            </select>
          </div>

          {/* 2. Personal Information Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1.5">
                <UserIcon className="w-3.5 h-3.5 text-emerald-400" />
                <span>{language === 'rw' ? 'Izina Ryose (Full Name):' : language === 'fr' ? 'Nom Complet :' : 'Full Name:'}</span>
              </label>
              <input
                type="text"
                id="register-fullname-input"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g., Jean de Dieu Nshimiyimana"
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3 text-white outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>{language === 'rw' ? 'Telefoni (MTN / Airtel / MoMo):' : language === 'fr' ? 'Téléphone (+250) :' : 'Phone Number (+250):'}</span>
              </label>
              <input
                type="tel"
                id="register-phone-input"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="0788 345 678 cyangwa +25078..."
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3 text-white outline-none focus:border-emerald-500"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-emerald-400" />
              <span>{language === 'rw' ? 'I-meyiri (Email Address):' : language === 'fr' ? 'Adresse E-mail :' : 'Email Address:'}</span>
            </label>
            <input
              type="email"
              id="register-email-input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="farmer@agriwise.rw"
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3 text-white outline-none focus:border-emerald-500"
              required
            />
          </div>

          {/* 3. COMPLETE RWANDA ADMINISTRATIVE LOCATION HIERARCHY DROPDOWNS */}
          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-emerald-300 font-bold flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-emerald-400" />
                <span>
                  {language === 'rw'
                    ? 'Aderesi y\'Ahantu (Rwanda Location Hierarchy)'
                    : language === 'fr'
                    ? 'Localisation Administrative (Rwanda)'
                    : 'Administrative Location (Rwanda Hierarchy)'}
                </span>
              </label>
              <span className="text-[10px] text-slate-400">
                Province → District → Sector → Cell → Village
              </span>
            </div>

            {/* Row 1: Province & District */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  {language === 'rw' ? 'Intara (Province):' : language === 'fr' ? 'Province :' : 'Province:'}
                </label>
                <select
                  id="register-province-select"
                  value={province}
                  onChange={(e) => handleProvinceChange(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white outline-none focus:border-emerald-500 font-medium cursor-pointer"
                >
                  {provinces.map((p) => (
                    <option key={p.id} value={p.name}>
                      {language === 'rw' ? p.nameRw : language === 'fr' ? p.nameFr : p.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  {language === 'rw' ? 'Akarere (District):' : language === 'fr' ? 'District :' : 'District:'}
                </label>
                <select
                  id="register-district-select"
                  value={district}
                  onChange={(e) => handleDistrictChange(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white outline-none focus:border-emerald-500 font-medium cursor-pointer"
                >
                  {availableDistricts.map((d) => (
                    <option key={d.id} value={d.name}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Row 2: Sector, Cell & Village */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  {language === 'rw' ? 'Umurenge (Sector):' : language === 'fr' ? 'Secteur :' : 'Sector:'}
                </label>
                <select
                  id="register-sector-select"
                  value={sector}
                  onChange={(e) => handleSectorChange(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white outline-none focus:border-emerald-500 font-medium cursor-pointer"
                >
                  {availableSectors.map((s) => (
                    <option key={s.id} value={s.name}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  {language === 'rw' ? 'Akagari (Cell):' : language === 'fr' ? 'Cellule :' : 'Cell:'}
                </label>
                <select
                  id="register-cell-select"
                  value={cell}
                  onChange={(e) => handleCellChange(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white outline-none focus:border-emerald-500 font-medium cursor-pointer"
                >
                  {availableCells.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  {language === 'rw' ? 'Umudugudu (Village):' : language === 'fr' ? 'Village :' : 'Village:'}
                </label>
                <select
                  id="register-village-select"
                  value={village}
                  onChange={(e) => setVillage(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white outline-none focus:border-emerald-500 font-medium cursor-pointer"
                >
                  {availableVillages.map((v) => (
                    <option key={v} value={v}>
                      {v}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* 4. National ID & Date of Birth (Optional) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>
                  {language === 'rw'
                    ? 'Nimero y\'Indangamuntu (16 Digits - NIDA):'
                    : language === 'fr'
                    ? 'Carte d\'Identité (16 Chiffres) :'
                    : 'National ID (16 Digits):'}
                </span>
              </label>
              <input
                type="text"
                id="register-national-id-input"
                value={nationalId}
                onChange={(e) => setNationalId(e.target.value)}
                placeholder="1 1990 8 0012345 0 12"
                maxLength={20}
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3 text-white outline-none focus:border-emerald-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                <span>
                  {language === 'rw'
                    ? 'Itariki y\'Amavuko (Date of Birth):'
                    : language === 'fr'
                    ? 'Date de Naissance :'
                    : 'Date of Birth:'}
                </span>
              </label>
              <input
                type="date"
                id="register-dob-input"
                value={dateOfBirth}
                onChange={(e) => setDateOfBirth(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3 text-white outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* 5. Password Setup */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                <span>{language === 'rw' ? 'Ijambo ry\'Ibanga (Password):' : language === 'fr' ? 'Mot de passe :' : 'Create Password:'}</span>
              </label>
              <input
                type="password"
                id="register-password-input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3 text-white outline-none focus:border-emerald-500 font-mono"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                <span>{language === 'rw' ? 'Komeza Ijambo ry\'Ibanga (Confirm):' : language === 'fr' ? 'Confirmer le mot de passe :' : 'Confirm Password:'}</span>
              </label>
              <input
                type="password"
                id="register-confirm-password-input"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3 text-white outline-none focus:border-emerald-500 font-mono"
                required
              />
            </div>
          </div>

          {/* 6. Terms and Conditions Checkbox */}
          <div className="flex items-start gap-2.5 pt-2">
            <input
              type="checkbox"
              id="terms"
              checked={agreedTerms}
              onChange={(e) => setAgreedTerms(e.target.checked)}
              className="mt-1 w-4 h-4 accent-emerald-500 cursor-pointer"
            />
            <label htmlFor="terms" className="text-slate-300 text-[11px] leading-relaxed cursor-pointer">
              {language === 'rw'
                ? 'Ndemeye amategeko n\'amabwiriza y\'ikoreshwa rya AGRIWISE Rwanda, kurengera amakuru n\'imikorere y\'isoko.'
                : language === 'fr'
                ? 'J\'accepte les conditions d\'utilisation, la politique de confidentialité et les règles d\'AGRIWISE Rwanda.'
                : 'I agree to AGRIWISE Rwanda Platform Terms of Service, Privacy Policy, and Mobile Money Escrow Rules.'}
            </label>
          </div>

          {/* Primary Submit Button */}
          <button
            type="submit"
            id="register-submit-btn"
            disabled={isSubmitting}
            className="w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black py-4 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 text-sm uppercase tracking-wide cursor-pointer disabled:opacity-50"
          >
            {isSubmitting ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>{language === 'rw' ? 'Kwandika Akaunti...' : language === 'fr' ? 'Création du Compte...' : 'Creating Account...'}</span>
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4" />
                <span>{language === 'rw' ? 'Fungura Akaunti (Register Account)' : language === 'fr' ? 'Créer mon Compte AGRIWISE' : 'Create AGRIWISE Account'}</span>
              </>
            )}
          </button>

          {/* Divider */}
          <div className="relative my-3 flex items-center justify-center">
            <div className="border-t border-slate-800 w-full"></div>
            <span className="bg-slate-900 px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {language === 'rw' ? 'Cyangwa' : language === 'fr' ? 'OU' : 'OR'}
            </span>
            <div className="border-t border-slate-800 w-full"></div>
          </div>

          {/* Google Quick Registration */}
          <button
            type="button"
            id="register-google-quick-btn"
            onClick={handleGoogleRegistration}
            className="w-full bg-white hover:bg-slate-100 text-slate-900 font-bold py-3 px-4 rounded-2xl shadow-md transition-all flex items-center justify-center gap-3 border border-slate-300 text-sm cursor-pointer"
          >
            <svg className="w-5 h-5" viewBox="0 0 48 48">
              <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
              <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
              <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
              <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
            </svg>
            <span>{language === 'rw' ? 'Iyandikishe na Google / Gmail' : language === 'fr' ? 'Inscription Rapide avec Google' : 'Quick Register with Google / Gmail'}</span>
          </button>
        </form>

        {/* Redirect to Login Page Footer */}
        <div className="border-t border-slate-800 pt-4 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-3">
          <div className="flex items-center gap-3">
            <span>
              {language === 'rw' ? 'Usanzwe ufite akaunti?' : language === 'fr' ? 'Vous avez déjà un compte ?' : 'Already have an AGRIWISE account?'}
            </span>
          </div>
          <button
            id="register-nav-to-login-btn"
            onClick={onNavigateToLogin}
            className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30 px-4 py-2 rounded-xl font-bold transition-all cursor-pointer"
          >
            <LogIn className="w-4 h-4 text-emerald-400" />
            <span>{language === 'rw' ? 'Injira (Login Page)' : language === 'fr' ? 'Se Connecter' : 'Go to Login Page'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

