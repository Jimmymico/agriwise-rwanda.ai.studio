import React, { useState } from 'react';
import { User, Language } from '../../types';
import { translations } from '../../data/translations';
import { useAuth } from '../../context/AuthContext';
import {
  LogIn,
  ShieldCheck,
  Mail,
  Lock,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Home,
  UserPlus,
  RefreshCw
} from 'lucide-react';

interface LoginPageProps {
  language: Language;
  onLoginSuccess: (user: User) => void;
  onNavigateToRegister: () => void;
  onNavigateToHome: () => void;
  onNavigateToForgotPassword?: () => void;
  onNavigateToVerifyEmail?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  language,
  onLoginSuccess,
  onNavigateToRegister,
  onNavigateToHome,
  onNavigateToForgotPassword,
  onNavigateToVerifyEmail,
}) => {
  const t = translations[language] || translations['rw'];
  const { loginWithEmail, signInWithGoogle } = useAuth();

  const [phoneOrEmail, setPhoneOrEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!phoneOrEmail || !password) {
      setErrorMsg(
        language === 'rw'
          ? 'Uzuzamo nimero ya telefoni/i-meyiri n\'ijambo ry\'ibanga.'
          : 'Please enter your phone/email and password.'
      );
      return;
    }

    setLoading(true);
    try {
      const authResult = await loginWithEmail(phoneOrEmail, password, language);

      if (!authResult.success || !authResult.user) {
        setErrorMsg(authResult.error || (language === 'rw' ? 'I-meyiri cyangwa ijambo ry\'ibanga ntabwo bihura.' : 'Invalid email/phone or password.'));
        return;
      }

      const user = authResult.user;
      setSuccessMsg(
        language === 'rw'
          ? `Kwinjira byagenze neza! Ikaze, ${user.name}.`
          : `Login successful! Welcome back, ${user.name}.`
      );

      setTimeout(() => {
        onLoginSuccess(user);
      }, 400);
    } catch (err: any) {
      console.error('Login submit error:', err);
      setErrorMsg(err?.message || (language === 'rw' ? 'Habaye ikibazo mu kwinjira.' : 'Authentication error. Please try again.'));
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    if (loading) return;
    setErrorMsg('');
    setSuccessMsg('');
    setLoading(true);
    try {
      const res = await signInWithGoogle(language);
      if (res.success && res.user) {
        setSuccessMsg(
          language === 'rw'
            ? `Kwinjira kuri Google byagenze neza! Ikaze, ${res.user.name}.`
            : `Google sign-in successful! Welcome, ${res.user.name}.`
        );
        setTimeout(() => {
          onLoginSuccess(res.user!);
        }, 400);
      } else {
        setErrorMsg(res.error || 'Google sign-in error.');
      }
    } catch (err: any) {
      console.error('Google sign-in error:', err);
      setErrorMsg(err?.message || 'Google sign-in error.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex flex-col justify-center items-center py-8 px-4 font-sans text-slate-100">
      <div className="w-full max-w-xl bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 sm:p-10 shadow-2xl relative space-y-6">
        
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <button
            onClick={onNavigateToHome}
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-emerald-400 font-bold transition-colors"
          >
            <Home className="w-4 h-4 text-emerald-400" />
            <span>{language === 'rw' ? '← Sura Paji y\'Ibanze (Home)' : '← Return to Home'}</span>
          </button>

          <span className="text-[10px] font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded-full uppercase">
            {language === 'rw' ? 'PAJI Y\'KWINJIRA' : 'LOGIN PAGE'}
          </span>
        </div>

        {/* Page Header */}
        <div className="text-center space-y-2">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-lg">
            <LogIn className="w-7 h-7" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            {language === 'rw' ? 'Injira mu Kigo cha AGRIWISE' : 'AGRIWISE User Portal Login'}
          </h1>
          <p className="text-xs text-slate-300 max-w-md mx-auto">
            {language === 'rw'
              ? 'Injiza nimero ya telefoni cyangwa i-meyiri yawe n\'ijambo ry\'ibanga ubashe kwinjira mu serivisi za AI n\'isoko.'
              : 'Enter your phone number or email address and password to access AI tools, GPS mapping, and marketplace.'}
          </p>
        </div>

        {/* Feedback Alerts */}
        {errorMsg && (
          <div className="p-3.5 bg-rose-950/80 border border-rose-500/50 rounded-2xl flex items-center gap-2 text-rose-200 text-xs font-bold animate-fadeIn">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3.5 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl flex items-center gap-2 text-emerald-200 text-xs font-bold animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-bold mb-1.5 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-emerald-400" />
              <span>{language === 'rw' ? 'Telefoni (+250) cyangwa Email:' : 'Phone (+250) or Email Address:'}</span>
            </label>
            <input
              type="text"
              value={phoneOrEmail}
              onChange={(e) => setPhoneOrEmail(e.target.value)}
              placeholder="e.g. farmer@agriwise.rw or +250 788 345 678"
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3.5 text-white outline-none focus:border-emerald-500 transition-colors"
              required
            />
          </div>

          <div>
            <label className="block text-slate-300 font-bold mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                <span>{language === 'rw' ? 'Ijambo ry\'Ibanga (Password):' : 'Password:'}</span>
              </span>
              <div className="flex items-center gap-3">
                {onNavigateToVerifyEmail && (
                  <button
                    type="button"
                    onClick={onNavigateToVerifyEmail}
                    className="text-xs text-slate-400 hover:text-emerald-400 hover:underline font-bold transition-colors cursor-pointer"
                  >
                    {language === 'rw' ? 'Kwemeza E-mail?' : 'Verify Email?'}
                  </button>
                )}
                <button
                  type="button"
                  onClick={onNavigateToForgotPassword}
                  className="text-xs text-emerald-400 hover:text-emerald-300 hover:underline font-bold transition-colors cursor-pointer"
                >
                  {language === 'rw' ? 'Wibagiwe Ijambo ry\'Ibanga?' : 'Forgot Password?'}
                </button>
              </div>
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3.5 text-white outline-none focus:border-emerald-500 transition-colors font-mono"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black py-3.5 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 text-sm uppercase tracking-wide disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer"
          >
            {loading ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>{language === 'rw' ? 'Birimo Gukorwa...' : 'Signing In...'}</span>
              </>
            ) : (
              <>
                <LogIn className="w-5 h-5" />
                <span>{language === 'rw' ? 'INJIRA MU KIGO (LOGIN)' : 'LOGIN TO ACCOUNT'}</span>
              </>
            )}
          </button>

          <div className="relative my-4 flex items-center justify-center">
            <div className="border-t border-slate-800 w-full"></div>
            <span className="bg-slate-900 px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {language === 'rw' ? 'Cyangwa' : 'OR'}
            </span>
            <div className="border-t border-slate-800 w-full"></div>
          </div>

          {/* Official Sign in with Google / Link Gmail button */}
          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={loading}
            className="w-full bg-white hover:bg-slate-100 text-slate-900 font-bold py-3 px-4 rounded-2xl shadow-md transition-all flex items-center justify-center gap-3 border border-slate-300 text-sm disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer"
          >
            <svg className="w-5 h-5" viewBox="0 0 48 48">
              <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
              <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
              <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
              <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
            </svg>
            <span>{language === 'rw' ? 'Injirana na Google / Gmail' : 'Sign in with Google / Link Gmail'}</span>
          </button>
        </form>

        {/* Redirect to Register Page Footer */}
        <div className="border-t border-slate-800 pt-4 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-3">
          <span>
            {language === 'rw' ? 'Nta kaunti ufite?' : "Don't have an account yet?"}
          </span>
          <button
            onClick={onNavigateToRegister}
            className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30 px-4 py-2 rounded-xl font-bold transition-all"
          >
            <UserPlus className="w-4 h-4 text-emerald-400" />
            <span>{language === 'rw' ? 'Iyandikishe (Register Page)' : 'Go to Register Page'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
