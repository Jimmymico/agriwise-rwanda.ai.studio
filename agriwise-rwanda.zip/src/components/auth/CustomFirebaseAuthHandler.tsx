import React, { useState, useEffect } from 'react';
import { Language } from '../../types';
import { auth } from '../../services/firebase';
import {
  verifyPasswordResetCode,
  confirmPasswordReset,
  applyActionCode,
  checkActionCode,
} from 'firebase/auth';
import { parseFirebaseActionParams, FirebaseActionParams } from '../../utils/firebaseActionParser';
import {
  KeyRound,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Eye,
  EyeOff,
  Lock,
  Mail,
  Loader2,
  Home,
  RefreshCw,
} from 'lucide-react';

interface CustomFirebaseAuthHandlerProps {
  language: Language;
  onNavigateToLogin: () => void;
  onNavigateHome: () => void;
  onRequestNewResetLink?: () => void;
}

type ActionStatus =
  | 'INITIALIZING'
  | 'RESET_PASSWORD_FORM'
  | 'RESET_PASSWORD_SUCCESS'
  | 'EMAIL_VERIFIED_SUCCESS'
  | 'EMAIL_RECOVERED_SUCCESS'
  | 'ERROR';

export const CustomFirebaseAuthHandler: React.FC<CustomFirebaseAuthHandlerProps> = ({
  language,
  onNavigateToLogin,
  onNavigateHome,
  onRequestNewResetLink,
}) => {
  const isRw = language === 'rw';
  const isFr = language === 'fr';

  const [status, setStatus] = useState<ActionStatus>('INITIALIZING');
  const [actionParams, setActionParams] = useState<FirebaseActionParams | null>(null);

  // Password reset specific state
  const [verifiedEmail, setVerifiedEmail] = useState<string>('');
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [showNewPassword, setShowNewPassword] = useState<boolean>(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Generic message states
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [errorTitle, setErrorTitle] = useState<string>('');
  const [restoredEmail, setRestoredEmail] = useState<string>('');

  // Password strength checks
  const hasMinLength = newPassword.length >= 8;
  const hasUpperCase = /[A-Z]/.test(newPassword);
  const hasLowerCase = /[a-z]/.test(newPassword);
  const hasNumber = /[0-9]/.test(newPassword);
  const hasSpecialChar = /[^A-Za-z0-9]/.test(newPassword);
  const isPasswordMatch = newPassword.length > 0 && newPassword === confirmPassword;
  const isPasswordValid =
    hasMinLength && hasUpperCase && hasLowerCase && hasNumber && hasSpecialChar && isPasswordMatch;

  useEffect(() => {
    const processFirebaseAction = async () => {
      const params = parseFirebaseActionParams();
      setActionParams(params);

      const { firebaseMode, oobCode } = params;

      if (!oobCode) {
        setErrorTitle(
          isRw
            ? 'Nta Code y\'Umutekano Yabonetse'
            : isFr
            ? 'Code d\'action manquante'
            : 'Missing Security Action Code'
        );
        setErrorMessage(
          isRw
            ? 'Link wakoresheje ntabwo ifite code y\'umutekano ya Firebase. Nyamuneka saba indi link nshya.'
            : isFr
            ? 'Le lien utilisé ne contient pas de code de sécurité valide. Veuillez demander un nouveau lien.'
            : 'The action link does not contain a valid security code. Please request a new link.'
        );
        setStatus('ERROR');
        return;
      }

      // Explicit Firebase Action Dispatcher
      switch (firebaseMode) {
        case 'resetPassword': {
          try {
            // Verify code with Firebase Auth SDK (retrieves registered email)
            const email = await verifyPasswordResetCode(auth, oobCode);
            setVerifiedEmail(email);
            setStatus('RESET_PASSWORD_FORM');
          } catch (err: any) {
            console.warn('Firebase verifyPasswordResetCode failed:', err?.code, err?.message);
            setErrorTitle(
              isRw
                ? 'Link yo Guhindura Ijambo ry\'Ibanga Ntabwo Yemewe'
                : isFr
                ? 'Lien de réinitialisation invalide ou expiré'
                : 'Password Reset Link Invalid or Expired'
            );
            setErrorMessage(
              isRw
                ? 'Link yo guhindura ijambo ry\'ibanga ikoreshwa rimwe gusa kandi ifite igihe ntarengwa cyo gukoreshwa. Nyamuneka saba indi nshya.'
                : isFr
                ? 'Ce lien de réinitialisation de mot de passe a déjà été utilisé ou a expiré. Veuillez demander un nouveau lien.'
                : 'This password reset link is invalid, has already been used, or has expired. Please request a fresh reset link.'
            );
            setStatus('ERROR');
          }
          break;
        }

        case 'verifyEmail': {
          try {
            await applyActionCode(auth, oobCode);
            setStatus('EMAIL_VERIFIED_SUCCESS');
          } catch (err: any) {
            console.warn('Firebase applyActionCode (verifyEmail) failed:', err?.code, err?.message);
            setErrorTitle(
              isRw
                ? 'Kwemeza E-mail Ntabwo Byakunze'
                : isFr
                ? 'Échec de la vérification de l\'e-mail'
                : 'Email Verification Failed'
            );
            setErrorMessage(
              isRw
                ? 'Link yo kwemeza e-mail ntabwo yemewe cyangwa yararangiye.'
                : isFr
                ? 'Le lien de vérification de l\'e-mail est invalide ou a expiré.'
                : 'The email verification link is invalid or has expired.'
            );
            setStatus('ERROR');
          }
          break;
        }

        case 'recoverEmail': {
          try {
            const info = await checkActionCode(auth, oobCode);
            const email = info.data.email || '';
            await applyActionCode(auth, oobCode);
            setRestoredEmail(email);
            setStatus('EMAIL_RECOVERED_SUCCESS');
          } catch (err: any) {
            console.warn('Firebase recoverEmail failed:', err?.code, err?.message);
            setErrorTitle(
              isRw
                ? 'Gusubiza E-mail Ntabwo Byakunze'
                : isFr
                ? 'Échec de la récupération de l\'e-mail'
                : 'Email Recovery Failed'
            );
            setErrorMessage(
              isRw
                ? 'Link yo kugarura e-mail ntabwo yemewe cyangwa yararangiye.'
                : isFr
                ? 'Le lien de récupération d\'e-mail est invalide ou a expiré.'
                : 'The email recovery link is invalid or has expired.'
            );
            setStatus('ERROR');
          }
          break;
        }

        default: {
          // If no specific mode is defined, but oobCode is present, attempt password reset verification
          try {
            const email = await verifyPasswordResetCode(auth, oobCode);
            setVerifiedEmail(email);
            setStatus('RESET_PASSWORD_FORM');
          } catch {
            setErrorTitle(
              isRw
                ? 'Igikorwa Ntabwo Kizwi'
                : isFr
                ? 'Action non reconnue'
                : 'Unrecognized Action'
            );
            setErrorMessage(
              isRw
                ? 'Ubu bwoko bw\'igikorwa ntabwo bwemewe na sisitemu ya Firebase.'
                : isFr
                ? 'Le type d\'action spécifié n\'est pas pris en charge.'
                : 'The requested action type is not supported or the security link is invalid.'
            );
            setStatus('ERROR');
          }
          break;
        }
      }
    };

    processFirebaseAction();
  }, [isRw, isFr]);

  const handlePasswordResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isPasswordValid || !actionParams?.oobCode) return;

    setIsSubmitting(true);
    setErrorMessage('');

    try {
      await confirmPasswordReset(auth, actionParams.oobCode, newPassword);

      // Clean URL query parameters to prevent reuse
      try {
        if (typeof window !== 'undefined' && window.history && window.history.replaceState) {
          window.history.replaceState({}, document.title, window.location.pathname);
        }
      } catch {
        // ignore history error
      }

      setStatus('RESET_PASSWORD_SUCCESS');
    } catch (err: any) {
      console.warn('Firebase confirmPasswordReset failed:', err?.code, err?.message);
      const code = err?.code || '';
      if (code === 'auth/weak-password') {
        setErrorMessage(
          isRw
            ? 'Ijambo ry\'ibanga ryoroshye cyane. Shyiramo inyuguti byibuze 8 zirimo inyuguti nkuru, nto, n\'imibare.'
            : 'The password is too weak. Please use at least 8 characters with letters and numbers.'
        );
      } else if (code === 'auth/expired-action-code' || code === 'auth/invalid-action-code') {
        setErrorTitle(
          isRw ? 'Link Yararangiye' : 'Link Expired or Invalid'
        );
        setErrorMessage(
          isRw
            ? 'Link yo guhindura ijambo ry\'ibanga yarangiye cyangwa yakoreshejwe. Nyamuneka saba indi nshya.'
            : 'The password reset link has expired or has already been used. Please request a new one.'
        );
        setStatus('ERROR');
      } else {
        setErrorMessage(
          isRw
            ? 'Habaye ikibazo mu guhindura ijambo ry\'ibanga. Nyamuneka gerageza nanone.'
            : 'An error occurred while resetting your password. Please try again.'
        );
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-emerald-500 selection:text-slate-950 font-sans">
      {/* Header */}
      <header className="border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md px-4 py-4 sticky top-0 z-50">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3 cursor-pointer" onClick={onNavigateHome}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <KeyRound className="w-5 h-5 text-slate-950 stroke-[2.5]" />
            </div>
            <div>
              <span className="font-extrabold text-lg tracking-tight text-white block">
                AGRIWISE <span className="text-emerald-400">RWANDA</span>
              </span>
              <span className="text-[10px] text-slate-400 tracking-wider uppercase font-semibold block -mt-1">
                {isRw ? 'Umutekano wa Konti' : 'Account Security Portal'}
              </span>
            </div>
          </div>

          <button
            onClick={onNavigateHome}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition-all"
          >
            <Home className="w-3.5 h-3.5" />
            <span>{isRw ? 'Ahabanza' : 'Home'}</span>
          </button>
        </div>
      </header>

      {/* Main Content Card */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6">
        <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/60 relative overflow-hidden">
          {/* Subtle background highlight */}
          <div className="absolute -top-24 -right-24 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* 1. INITIALIZING STATE */}
          {status === 'INITIALIZING' && (
            <div className="text-center py-10 space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 mx-auto flex items-center justify-center animate-pulse">
                <Loader2 className="w-7 h-7 animate-spin" />
              </div>
              <div className="space-y-1">
                <h2 className="text-lg font-bold text-white">
                  {isRw ? 'Gusuzuma Link ya Firebase...' : 'Verifying Firebase Security Link...'}
                </h2>
                <p className="text-xs text-slate-400">
                  {isRw
                    ? 'Tegereza gato mu gihe sisitemu isuzuma umutekano w\'iyi link.'
                    : 'Please wait while we authenticate and verify your action code.'}
                </p>
              </div>
            </div>
          )}

          {/* 2. RESET PASSWORD FORM STATE */}
          {status === 'RESET_PASSWORD_FORM' && (
            <div className="space-y-6">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 mx-auto flex items-center justify-center shadow-inner">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h2 className="text-xl font-black text-white tracking-tight">
                  {isRw ? 'Guhindura Ijambo ry\'Ibanga' : 'Set New Password'}
                </h2>
                <p className="text-xs text-slate-400">
                  {isRw
                    ? 'Shyiramo ijambo ry\'ibanga rishya rikomeye kuri konti yawe ya AGRIWISE.'
                    : 'Create a new secure password for your AGRIWISE RWANDA account.'}
                </p>
              </div>

              {/* Verified Email Banner */}
              {verifiedEmail && (
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex items-center gap-2.5">
                  <Mail className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <div className="overflow-hidden">
                    <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wider">
                      {isRw ? 'Konti Igiye Guhindurwa' : 'Target Account'}
                    </span>
                    <span className="text-xs font-semibold text-emerald-300 truncate block">
                      {verifiedEmail}
                    </span>
                  </div>
                </div>
              )}

              {errorMessage && (
                <div className="p-3.5 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-start gap-2.5 text-xs text-rose-300">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-rose-400" />
                  <span>{errorMessage}</span>
                </div>
              )}

              <form onSubmit={handlePasswordResetSubmit} className="space-y-4 text-xs">
                {/* New Password Input */}
                <div className="space-y-1.5">
                  <label className="text-slate-300 font-semibold flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{isRw ? 'Ijambo ry\'Ibanga Rishya' : 'New Password'}</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPassword ? 'text' : 'password'}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="••••••••"
                      required
                      autoComplete="new-password"
                      className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
                    >
                      {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Confirm Password Input */}
                <div className="space-y-1.5">
                  <label className="text-slate-300 font-semibold flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{isRw ? 'Emeza Ijambo ry\'Ibanga' : 'Confirm New Password'}</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showConfirmPassword ? 'text' : 'password'}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      required
                      autoComplete="new-password"
                      className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
                    >
                      {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Password Policy Validation Checklist */}
                <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl space-y-1.5 text-[11px]">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">
                    {isRw ? 'Ibisabwa ku Ijambo ry\'Ibanga:' : 'Password Requirements:'}
                  </span>
                  <div className="grid grid-cols-2 gap-1.5">
                    <div className={`flex items-center gap-1.5 ${hasMinLength ? 'text-emerald-400' : 'text-slate-500'}`}>
                      <CheckCircle2 className="w-3 h-3 flex-shrink-0" />
                      <span>{isRw ? 'Inyuguti 8+' : '8+ characters'}</span>
                    </div>
                    <div className={`flex items-center gap-1.5 ${hasUpperCase ? 'text-emerald-400' : 'text-slate-500'}`}>
                      <CheckCircle2 className="w-3 h-3 flex-shrink-0" />
                      <span>{isRw ? 'Inyuguti Nkuru' : 'Uppercase letter'}</span>
                    </div>
                    <div className={`flex items-center gap-1.5 ${hasLowerCase ? 'text-emerald-400' : 'text-slate-500'}`}>
                      <CheckCircle2 className="w-3 h-3 flex-shrink-0" />
                      <span>{isRw ? 'Inyuguti Nto' : 'Lowercase letter'}</span>
                    </div>
                    <div className={`flex items-center gap-1.5 ${hasNumber ? 'text-emerald-400' : 'text-slate-500'}`}>
                      <CheckCircle2 className="w-3 h-3 flex-shrink-0" />
                      <span>{isRw ? 'Umubare (0-9)' : 'Number (0-9)'}</span>
                    </div>
                    <div className={`flex items-center gap-1.5 ${hasSpecialChar ? 'text-emerald-400' : 'text-slate-500'}`}>
                      <CheckCircle2 className="w-3 h-3 flex-shrink-0" />
                      <span>{isRw ? 'Akamenyetso (@#$)' : 'Special char'}</span>
                    </div>
                    <div className={`flex items-center gap-1.5 ${isPasswordMatch ? 'text-emerald-400' : 'text-slate-500'}`}>
                      <CheckCircle2 className="w-3 h-3 flex-shrink-0" />
                      <span>{isRw ? 'Birasana' : 'Passwords match'}</span>
                    </div>
                  </div>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={!isPasswordValid || isSubmitting}
                  className="w-full bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-extrabold py-3.5 rounded-xl transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 text-xs"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>{isRw ? 'Guhindura...' : 'Updating Password...'}</span>
                    </>
                  ) : (
                    <>
                      <span>{isRw ? 'Emeza Ijambo ry\'Ibanga Rishya' : 'Confirm Password Reset'}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

          {/* 3. RESET PASSWORD SUCCESS STATE */}
          {status === 'RESET_PASSWORD_SUCCESS' && (
            <div className="text-center py-6 space-y-5">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-500 text-emerald-400 mx-auto flex items-center justify-center shadow-lg shadow-emerald-500/20">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-2">
                <h2 className="text-xl font-black text-white">
                  {isRw ? 'Ijambo ry\'Ibanga Ryahinduwe Neza!' : 'Password Reset Successful!'}
                </h2>
                <p className="text-xs text-slate-400 max-w-xs mx-auto">
                  {isRw
                    ? 'Konti yawe ifite umutekano usesuye. Ubu ushobora kwinjira muri AGRIWISE ukoresheje ijambo ry\'ibanga rishya.'
                    : 'Your password has been successfully updated in Firebase. You can now sign in with your new credentials.'}
                </p>
              </div>

              <button
                type="button"
                onClick={onNavigateToLogin}
                className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold py-3.5 rounded-xl transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 text-xs"
              >
                <span>{isRw ? 'Injira muri Konti' : 'Go to Login'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* 4. EMAIL VERIFIED SUCCESS STATE */}
          {status === 'EMAIL_VERIFIED_SUCCESS' && (
            <div className="text-center py-6 space-y-5">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-500 text-emerald-400 mx-auto flex items-center justify-center shadow-lg shadow-emerald-500/20">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-2">
                <h2 className="text-xl font-black text-white">
                  {isRw ? 'Aderesi ya E-mail Yemejwe Neza!' : 'Email Verified Successfully!'}
                </h2>
                <p className="text-xs text-slate-400 max-w-xs mx-auto">
                  {isRw
                    ? 'Konti yawe ya Firebase Auth yemejwe neza. Ubu ufite uburenganzira bwose muri AGRIWISE RWANDA.'
                    : 'Your email address has been verified with Firebase Authentication. You now have full access.'}
                </p>
              </div>

              <button
                type="button"
                onClick={onNavigateToLogin}
                className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold py-3.5 rounded-xl transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 text-xs"
              >
                <span>{isRw ? 'Komeza Kwinjira' : 'Continue to Sign In'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* 5. EMAIL RECOVERED SUCCESS STATE */}
          {status === 'EMAIL_RECOVERED_SUCCESS' && (
            <div className="text-center py-6 space-y-5">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-500 text-emerald-400 mx-auto flex items-center justify-center shadow-lg shadow-emerald-500/20">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-2">
                <h2 className="text-xl font-black text-white">
                  {isRw ? 'E-mail Yagaruwe Neza!' : 'Email Restored Successfully!'}
                </h2>
                <p className="text-xs text-slate-400 max-w-xs mx-auto">
                  {restoredEmail
                    ? `${restoredEmail} ${isRw ? 'yagaruwe nka aderesi yemewe ya konti yawe.' : 'has been restored as your account email.'}`
                    : isRw
                    ? 'Aderesi yawe ya e-mail yagaruwe neza.'
                    : 'Your original email address has been restored.'}
                </p>
              </div>

              <button
                type="button"
                onClick={onNavigateToLogin}
                className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold py-3.5 rounded-xl transition-all text-xs"
              >
                <span>{isRw ? 'Subira Kwinjira' : 'Back to Login'}</span>
              </button>
            </div>
          )}

          {/* 6. DEDICATED ERROR STATE */}
          {status === 'ERROR' && (
            <div className="text-center py-6 space-y-5">
              <div className="w-16 h-16 rounded-full bg-rose-500/20 border-2 border-rose-500 text-rose-400 mx-auto flex items-center justify-center shadow-lg shadow-rose-500/20">
                <AlertCircle className="w-8 h-8" />
              </div>
              <div className="space-y-2">
                <h2 className="text-lg font-black text-white">
                  {errorTitle || (isRw ? 'Link Ntabwo Yemewe Cyangwa Yararangiye' : 'Invalid or Expired Link')}
                </h2>
                <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
                  {errorMessage ||
                    (isRw
                      ? 'Link ya Firebase ikoreshwa rimwe gusa kandi ifite igihe ntarengwa. Nyamuneka saba indi nshya.'
                      : 'Firebase action links can only be used once and expire after a limited time. Please request a new link.')}
                </p>
              </div>

              <div className="space-y-2.5 pt-2">
                <button
                  type="button"
                  onClick={onRequestNewResetLink || onNavigateToLogin}
                  className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold py-3.5 rounded-xl transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 text-xs"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>{isRw ? 'Saba Indi Link Nshya' : 'Request New Reset Link'}</span>
                </button>

                <button
                  type="button"
                  onClick={onNavigateToLogin}
                  className="w-full bg-slate-800 hover:bg-slate-700 text-white font-semibold py-3 rounded-xl transition-all text-xs"
                >
                  {isRw ? 'Subira Kwinjira' : 'Back to Login'}
                </button>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="py-4 border-t border-slate-900 text-center text-[11px] text-slate-500">
        AGRIWISE RWANDA &copy; {new Date().getFullYear()} &bull; {isRw ? 'Umutekano Usesuye wa Firebase' : 'Secured by Firebase Authentication'}
      </footer>
    </div>
  );
};
