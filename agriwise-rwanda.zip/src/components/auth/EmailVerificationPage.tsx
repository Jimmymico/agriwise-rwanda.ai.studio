import React, { useState, useEffect } from 'react';
import { Language, User } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { auth } from '../../services/firebase';
import { applyActionCode } from 'firebase/auth';
import { verifyEmailToken } from '../../services/authService';
import { parseFirebaseActionParams } from '../../utils/firebaseActionParser';
import {
  Mail,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Send,
  ArrowRight,
  Home,
  LogIn,
  KeyRound,
  ShieldCheck,
  BadgeCheck,
  Sparkles
} from 'lucide-react';

interface EmailVerificationPageProps {
  language: Language;
  onNavigateToLogin: () => void;
  onNavigateToHome: () => void;
  onVerificationSuccess?: (user?: User) => void;
}

export const EmailVerificationPage: React.FC<EmailVerificationPageProps> = ({
  language,
  onNavigateToLogin,
  onNavigateToHome,
  onVerificationSuccess,
}) => {
  const { sendVerificationEmail, reloadUser, emailVerified, currentUser, firebaseUser } = useAuth();
  const [tokenInput, setTokenInput] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [isCheckingStatus, setIsCheckingStatus] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);

  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isVerified, setIsVerified] = useState(emailVerified || !!firebaseUser?.emailVerified);

  useEffect(() => {
    if (emailVerified || firebaseUser?.emailVerified) {
      setIsVerified(true);
    }
  }, [emailVerified, firebaseUser]);

  // Check URL query param or Firebase action code on load
  useEffect(() => {
    const handleInitialCode = async () => {
      const fbAction = parseFirebaseActionParams();
      if (fbAction.oobCode && fbAction.firebaseMode === 'verifyEmail') {
        setIsVerifying(true);
        setErrorMsg('');
        setSuccessMsg('');
        try {
          await applyActionCode(auth, fbAction.oobCode);
          await reloadUser();
          setIsVerified(true);
          setSuccessMsg(
            language === 'rw'
              ? 'Aderesi ya E-mail yemejwe neza binyuze muri Firebase Auth!'
              : language === 'fr'
              ? 'Adresse e-mail vérifiée avec succès via Firebase Auth !'
              : 'Email address successfully verified via Firebase Auth!'
          );
          if (onVerificationSuccess) {
            onVerificationSuccess(currentUser || undefined);
          }
        } catch (err: any) {
          setErrorMsg(
            language === 'rw'
              ? 'Link yo kwemeza e-mail ntabwo yemewe cyangwa yararangiye.'
              : 'The email verification link is invalid or has expired.'
          );
        } finally {
          setIsVerifying(false);
        }
        return;
      }

      const urlParams = new URLSearchParams(window.location.search);
      const urlToken = urlParams.get('token');
      if (urlToken) {
        setTokenInput(urlToken);
        handleVerify(urlToken);
      }
    };

    handleInitialCode();
  }, []);

  // Cooldown timer
  useEffect(() => {
    if (resendCooldown <= 0) return;
    const timer = setInterval(() => {
      setResendCooldown((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [resendCooldown]);

  // Direct check of Firebase Authentication emailVerified status
  const handleCheckStatus = async () => {
    setErrorMsg('');
    setSuccessMsg('');
    setIsCheckingStatus(true);
    try {
      await reloadUser();
      if (emailVerified || firebaseUser?.emailVerified) {
        setIsVerified(true);
        setSuccessMsg(
          language === 'rw'
            ? 'Aderesi ya E-mail yemejwe neza binyuze muri Firebase Auth!'
            : language === 'fr'
            ? 'Adresse e-mail vérifiée avec succès via Firebase Auth !'
            : 'Email address successfully verified via Firebase Auth!'
        );
        if (onVerificationSuccess) {
          onVerificationSuccess(currentUser || undefined);
        }
      } else {
        setErrorMsg(
          language === 'rw'
            ? 'E-mail ntabwo iratunganywa. Nyamuneka fungura ubutumwa bwo muri inbox yawe ukande kuri link, hanyuma wongere ugerageze.'
            : language === 'fr'
            ? 'L\'e-mail n\'est pas encore vérifié. Veuillez cliquer sur le lien reçu dans votre boîte de réception et réessayer.'
            : 'Email is not yet verified. Please click the verification link sent to your email inbox and try again.'
        );
      }
    } catch (err: any) {
      setErrorMsg(
        language === 'rw'
          ? 'Habaye ikosa mu kugenzura imeyiri.'
          : language === 'fr'
          ? 'Erreur lors de la vérification du statut.'
          : 'Error verifying email status from Firebase.'
      );
    } finally {
      setIsCheckingStatus(false);
    }
  };

  // Verify using token string (if provided via URL param or manual input)
  const handleVerify = async (tokenToVerify: string) => {
    if (!tokenToVerify.trim()) return;
    setErrorMsg('');
    setSuccessMsg('');
    setIsVerifying(true);
    try {
      const res = await verifyEmailToken(tokenToVerify.trim());
      await reloadUser();
      if (emailVerified || firebaseUser?.emailVerified || (!firebaseUser && res.success)) {
        setIsVerified(true);
        setSuccessMsg(
          language === 'rw'
            ? 'Aderesi ya E-mail yemejwe neza!'
            : language === 'fr'
            ? 'Adresse e-mail vérifiée avec succès !'
            : 'Email address successfully verified!'
        );
        if (onVerificationSuccess) {
          onVerificationSuccess(currentUser || undefined);
        }
      } else {
        setErrorMsg(
          language === 'rw'
            ? 'Kwemeza byanze cyangwa ukeneye gukanda kuri link yakoherejwe muri e-mail yawe.'
            : language === 'fr'
            ? 'Échec de la validation. Veuillez cliquer sur le lien envoyé à votre e-mail.'
            : 'Verification failed. Please click the authoritative confirmation link sent to your email.'
        );
      }
    } catch (err: any) {
      setErrorMsg(
        language === 'rw'
          ? 'Habaye ikosa mu kwemeza token.'
          : language === 'fr'
          ? 'Erreur lors de la validation du token.'
          : 'Error verifying email token.'
      );
    } finally {
      setIsVerifying(false);
    }
  };

  // Resend verification email via Firebase Authentication
  const handleResend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (resendCooldown > 0) return;

    setErrorMsg('');
    setSuccessMsg('');
    setIsResending(true);

    try {
      const res = await sendVerificationEmail();
      if (res.success) {
        setSuccessMsg(
          language === 'rw'
            ? 'Ubutumwa bwo kwemeza bwongeye koherezwa muri e-mail yawe (Firebase Auth).'
            : language === 'fr'
            ? 'E-mail de vérification renvoyé via Firebase Auth.'
            : res.message || 'Verification email sent via Firebase Auth.'
        );
        setResendCooldown(60);
      } else {
        setErrorMsg(
          res.error || (
            language === 'rw'
              ? 'Kwohereza e-mail byanze. Nyamuneka ongera ugerageze mu kanya.'
              : language === 'fr'
              ? 'Échec de l\'envoi de l\'e-mail de vérification.'
              : 'Failed to resend verification email.'
          )
        );
      }
    } catch (err: any) {
      setErrorMsg(
        language === 'rw'
          ? 'Kwohereza e-mail byanze.'
          : language === 'fr'
          ? 'Échec de l\'envoi.'
          : 'Failed to resend verification email.'
      );
    } finally {
      setIsResending(false);
    }
  };

  const userEmail = currentUser?.email || firebaseUser?.email || '';

  return (
    <div className="min-h-[80vh] flex flex-col justify-center items-center py-8 px-4 font-sans text-slate-100">
      <div className="w-full max-w-lg bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 relative">
        
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <button
            onClick={onNavigateToHome}
            id="email-verify-home-btn"
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-emerald-400 font-bold transition-colors cursor-pointer"
          >
            <Home className="w-4 h-4 text-emerald-400" />
            <span>
              {language === 'rw' ? '← Sura Paji y\'Ibanze' : language === 'fr' ? '← Retour à l\'Accueil' : '← Return to Home'}
            </span>
          </button>

          <span className="text-[10px] font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded-full uppercase">
            {language === 'rw' ? 'KWEMEZA E-MAIL' : language === 'fr' ? 'VÉRIFICATION E-MAIL' : 'EMAIL VERIFICATION'}
          </span>
        </div>

        {/* Page Header */}
        <div className="text-center space-y-2">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-lg">
            {isVerified ? <BadgeCheck className="w-8 h-8" /> : <Mail className="w-7 h-7" />}
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            {isVerified
              ? language === 'rw'
                ? 'Aderesi ya E-mail Yemejwe!'
                : language === 'fr'
                ? 'Adresse E-mail Vérifiée !'
                : 'Email Address Verified!'
              : language === 'rw'
              ? 'Kwemeza Aderesi ya E-mail'
              : language === 'fr'
              ? 'Vérifier l\'Adresse E-mail'
              : 'Verify Email Address'}
          </h1>
          <p className="text-xs text-slate-300 max-w-sm mx-auto">
            {isVerified
              ? language === 'rw'
                ? 'Aderesi yawe ya e-mail yemejwe neza. Ubu ushobora gukoresha serivisi zose za AGRIWISE RWANDA.'
                : language === 'fr'
                ? 'Votre adresse e-mail a été confirmée. Vous avez maintenant accès à AGRIWISE RWANDA.'
                : 'Your email ownership has been confirmed. You now have full access to AGRIWISE RWANDA.'
              : userEmail
              ? language === 'rw'
                ? `Twohereje link yo kwemeza kuri ${userEmail}. Kanda kuri link yakoherejwe muri inbox yawe hanyuma ugenzure hano.`
                : language === 'fr'
                ? `Nous avons envoyé un lien de confirmation à ${userEmail}. Veuillez cliquer sur le lien dans votre boîte de réception puis vérifier ici.`
                : `We sent a verification link to ${userEmail} via Firebase Auth. Please check your inbox and click the link to confirm.`
              : language === 'rw'
              ? 'Fungura link yo kwemeza yakoherejwe kuri e-mail yawe cyangwa ukande buto yo kugenzura.'
              : language === 'fr'
              ? 'Ouvrez le lien de confirmation envoyé à votre e-mail ou cliquez sur vérifier.'
              : 'Open the verification link sent to your email or click the status check button below.'}
          </p>
        </div>

        {/* Alert Messages */}
        {errorMsg && (
          <div className="p-3.5 bg-rose-950/80 border border-rose-500/50 rounded-2xl flex items-center gap-2 text-rose-200 text-xs font-bold animate-fadeIn">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3.5 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl flex items-center gap-2 text-emerald-200 text-xs font-bold animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {!isVerified ? (
          <div className="space-y-5">
            {/* Primary Action: Check Verification Status from Firebase */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-emerald-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>{language === 'rw' ? 'Genzura niba byemejwe:' : language === 'fr' ? 'Vérifier le statut :' : 'Firebase Verification Status:'}</span>
                </span>
                <span className="text-[10px] font-mono font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-md">
                  {language === 'rw' ? 'BITEGEREJWE' : language === 'fr' ? 'EN ATTENTE' : 'PENDING'}
                </span>
              </div>

              <button
                type="button"
                id="email-verify-check-status-btn"
                onClick={handleCheckStatus}
                disabled={isCheckingStatus || isVerifying}
                className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black py-3.5 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 text-xs uppercase tracking-wide cursor-pointer"
              >
                {isCheckingStatus ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{language === 'rw' ? 'Kugenzura...' : language === 'fr' ? 'Vérification...' : 'Checking Status...'}</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {language === 'rw'
                        ? 'Reba niba E-mail Yemejwe (Refresh)'
                        : language === 'fr'
                        ? 'Vérifier le Statut de l\'E-mail'
                        : 'Check Email Verification Status'}
                    </span>
                  </>
                )}
              </button>
            </div>

            {/* Optional Manual Token Input */}
            <form onSubmit={(e) => { e.preventDefault(); handleVerify(tokenInput); }} className="space-y-3">
              <div>
                <label className="block text-slate-300 font-bold mb-1 text-xs flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{language === 'rw' ? 'Token yo Kwemeza (Niba uyifite):' : language === 'fr' ? 'Jeton de vérification (Optionnel) :' : 'Verification Token (Optional):'}</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={tokenInput}
                    onChange={(e) => setTokenInput(e.target.value)}
                    placeholder="emv_..."
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white outline-none focus:border-emerald-500 font-mono text-xs"
                  />
                  <button
                    type="submit"
                    disabled={isVerifying || !tokenInput.trim()}
                    className="bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-emerald-300 border border-emerald-500/30 px-3 py-2.5 rounded-xl font-bold transition-all text-xs flex items-center gap-1 cursor-pointer"
                  >
                    {isVerifying ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <ShieldCheck className="w-3.5 h-3.5" />}
                    <span>{language === 'rw' ? 'Emeza' : language === 'fr' ? 'Valider' : 'Verify'}</span>
                  </button>
                </div>
              </div>
            </form>

            {/* Resend Verification Email Section */}
            <div className="border-t border-slate-800 pt-4 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 font-bold">
                  {language === 'rw' ? 'Ntabwo wabonye e-mail?' : language === 'fr' ? 'E-mail non reçu ?' : 'Didn\'t receive the email?'}
                </span>
                <button
                  type="button"
                  id="email-verify-resend-btn"
                  onClick={() => handleResend()}
                  disabled={resendCooldown > 0 || isResending}
                  className={`font-bold inline-flex items-center gap-1.5 ${
                    resendCooldown > 0
                      ? 'text-slate-500 cursor-not-allowed'
                      : 'text-emerald-400 hover:underline cursor-pointer'
                  }`}
                >
                  {isResending ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Send className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {resendCooldown > 0
                      ? `${language === 'rw' ? 'Tegereza' : language === 'fr' ? 'Attendez' : 'Wait'} (${resendCooldown}s)`
                      : language === 'rw'
                      ? 'Ongera Wohereze E-mail'
                      : language === 'fr'
                      ? 'Renvoyer l\'E-mail'
                      : 'Resend Verification Email'}
                  </span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4 pt-2">
            {currentUser && onVerificationSuccess ? (
              <button
                type="button"
                id="email-verify-enter-dashboard-btn"
                onClick={() => onVerificationSuccess(currentUser)}
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-black py-3.5 rounded-2xl shadow-xl hover:brightness-110 transition-all flex items-center justify-center gap-2 text-xs uppercase tracking-wide cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>
                  {language === 'rw'
                    ? 'Komeza muri Dashboard →'
                    : language === 'fr'
                    ? 'Accéder au Tableau de Bord →'
                    : 'Continue to Dashboard →'}
                </span>
              </button>
            ) : (
              <button
                type="button"
                id="email-verify-nav-login-btn"
                onClick={onNavigateToLogin}
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-black py-3.5 rounded-2xl shadow-xl hover:brightness-110 transition-all flex items-center justify-center gap-2 text-xs uppercase tracking-wide cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>
                  {language === 'rw'
                    ? 'Komeza ku Paji yo Kwinjira (Login)'
                    : language === 'fr'
                    ? 'Procéder à la Connexion'
                    : 'Proceed to Login Page'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        )}

        {/* Footer Link */}
        <div className="border-t border-slate-800 pt-3 text-center text-xs text-slate-400">
          <button
            onClick={onNavigateToLogin}
            id="email-verify-back-login-btn"
            className="hover:text-emerald-400 transition-colors cursor-pointer inline-flex items-center gap-1"
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>{language === 'rw' ? 'Subira ku Paji yo Kwinjira' : language === 'fr' ? 'Retour à la page de connexion' : 'Back to Login Page'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

