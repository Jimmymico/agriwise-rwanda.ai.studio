import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  sendEmailVerification,
  confirmPasswordReset,
  verifyPasswordResetCode,
  updateProfile,
  User as FirebaseUser,
  reload
} from 'firebase/auth';
import { auth } from '../services/firebase';
import { User, UserRole, Language, BusinessOrganization } from '../types';
import { signInWithGoogle as googleSignInService } from '../services/googleAuthService';
import { getRegisteredUsers, saveUsersList } from '../services/authService';
import {
  getUserProfileDoc,
  saveUserProfileDoc,
  createBusinessDoc,
  getBusinessDoc,
  createAuditLogDoc,
} from '../services/firestoreService';

export function normalizePhoneNumber(phone: string): string {
  const clean = phone.trim();
  const digits = clean.replace(/\D/g, '');
  if (digits.startsWith('250') && digits.length === 12) {
    return `+${digits}`;
  }
  if (digits.startsWith('0') && digits.length === 10) {
    return `+250${digits.substring(1)}`;
  }
  if (digits.length === 9) {
    return `+250${digits}`;
  }
  if (clean.startsWith('+')) {
    return clean;
  }
  return clean;
}

export interface RegisterParams {
  fullName: string;
  phone: string;
  email: string;
  role: UserRole;
  province?: string;
  district: string;
  sector: string;
  cell?: string;
  village?: string;
  password: string;
  language: Language;
  nationalIdMasked?: string;
  nationalIdHash?: string;
  identityStatus?: 'not_started' | 'pending' | 'verified' | 'failed' | 'manual_review';
  identityProviderReference?: string;
  dateOfBirth?: string;
}

interface AuthContextType {
  firebaseUser: FirebaseUser | null;
  currentUser: User | null;
  currentBusiness: BusinessOrganization | null;
  loading: boolean;
  emailVerified: boolean;
  loginWithEmail: (emailOrPhone: string, password: string, lang?: Language) => Promise<{ success: boolean; user?: User; error?: string }>;
  registerWithEmail: (params: RegisterParams) => Promise<{ success: boolean; user?: User; error?: string }>;
  signInWithGoogle: (lang?: Language) => Promise<{ success: boolean; user?: User; error?: string }>;
  logout: () => Promise<void>;
  sendPasswordReset: (email: string, lang?: Language) => Promise<{ success: boolean; message?: string; error?: string }>;
  confirmPasswordResetWithCode: (oobCode: string, newPass: string, lang?: Language) => Promise<{ success: boolean; message?: string; error?: string }>;
  verifyResetCode: (oobCode: string, lang?: Language) => Promise<{ success: boolean; email?: string; error?: string }>;
  sendVerificationEmail: (lang?: Language) => Promise<{ success: boolean; message?: string; error?: string }>;
  reloadUser: () => Promise<void>;
  updateCurrentUserProfile: (updated: Partial<User>) => Promise<void>;
  createBusiness: (data: Omit<BusinessOrganization, 'businessId' | 'ownerId' | 'createdAt' | 'updatedAt'>) => Promise<{ success: boolean; business?: BusinessOrganization; error?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Helper to map Firebase error codes to friendly localized messages
export function mapFirebaseError(errorCode: string, lang: Language = 'rw', customDetails?: string): string {
  const isRw = lang === 'rw';
  switch (errorCode) {
    case 'auth/invalid-login-credentials':
    case 'auth/invalid-credential':
    case 'auth/user-not-found':
    case 'auth/wrong-password':
      return isRw ? 'I-meyiri cyangwa ijambo ry\'ibanga ntabwo bihura. Ongera ugerageze.' : 'Invalid email/phone or password. Please try again.';
    case 'auth/invalid-email':
      return isRw ? 'Aderesi ya e-mail ntabwo yabazwe neza.' : 'Invalid email address format.';
    case 'auth/user-disabled':
      return isRw ? 'Akaunti yawe yafunzwe. Nyamuneka ikorane n\'ubuyobozi bwa AGRIWISE.' : 'This account has been disabled. Please contact support.';
    case 'auth/email-already-in-use':
      return isRw
        ? 'Iyi e-mail isanzwe ifite akaunti muri AGRIWISE. Nyamuneka kanda "Injira" (Sign In) cyangwa ukoreshe "Continue with Google".'
        : 'An account with this email address already exists in AGRIWISE. Please sign in or continue with Google.';
    case 'auth/weak-password':
      return isRw ? 'Ijambo ry\'ibanga ryanditse ni ryito cyane. Ryoza n\'inyuguti 6 cyangwa irenga.' : 'Password is too weak. Please use at least 6 characters.';
    case 'auth/too-many-requests':
      return isRw ? 'Hageragejwe inshuro nyinshi cyane. Rindira iminota mike ubone kwongera.' : 'Too many attempts. Please wait a few minutes and try again.';
    case 'auth/network-request-failed':
      return isRw ? 'Ikibazo cy\'umuyoboro wa interineti. Suza interineti yawe.' : 'Network error. Please check your internet connection.';
    case 'auth/operation-not-allowed':
      return isRw
        ? 'Uburyo bwo kwinjira bwa Email/Password ntabwo bwashyizwe mu bikorwa (enabled) muri Firebase Console. Koresha "Sign in with Google" hejuru cyangwa ubanze ubifungure muri Firebase Authentication > Sign-in method.'
        : 'Email/Password sign-in provider is not enabled in Firebase Console. Please use "Sign in with Google" or enable Email/Password in Firebase Console > Authentication > Sign-in method.';
    case 'auth/unauthorized-domain':
      return isRw ? 'Uru rubuga (domain) ntiruri muri Firebase Authorized Domains.' : 'This hosting domain is not authorized in Firebase Authentication settings.';
    case 'auth/popup-closed-by-user':
      return isRw ? 'Idirishya rya Google ryunzwe mbere yo kurangiza kwinjira.' : 'Google sign-in window was closed before completing.';
    case 'auth/popup-blocked':
      return isRw ? 'Browser yabujije idirishya rya Google gufunguka (Popup blocked).' : 'Popup was blocked by your browser. Please allow popups for this site.';
    case 'auth/account-exists-with-different-credential':
      return isRw ? 'Iyi e-mail isanzwe ifite akaunti mu bundi buryo bwo kwinjira.' : 'An account already exists with this email using a different sign-in method.';
    case 'auth/expired-action-code':
      return isRw ? 'Iyi link yo kwemeza cyangwa guhindura ijambo ry\'ibanga yararangiye.' : 'This verification or password reset link has expired.';
    case 'auth/invalid-action-code':
      return isRw ? 'Iyi link ntabwo yemewe cyangwa yarakoreshejwe.' : 'This verification link is invalid or has already been used.';
    case 'permission-denied':
      return isRw ? 'Ntabwo ufite uruhushya rwo kureba iyi profil muri Firestore.' : 'Firestore permission denied. Please verify user permissions.';
    default:
      if (customDetails && customDetails.trim().length > 0) {
        return isRw
          ? `Habaye ikibazo mu kwinjira: ${customDetails}`
          : `Authentication error: ${customDetails}`;
      }
      return isRw ? 'I-meyiri cyangwa ijambo ry\'ibanga ntabwo bihura. Ongera ugerageze.' : 'Invalid email or password. Please verify your credentials and try again.';
  }
}

// Find or create application user profile mapped to Firebase Auth UID & Firestore
export async function syncUserProfile(fbUser: FirebaseUser, extraData?: Partial<RegisterParams>): Promise<User> {
  const normalizedEmail = (fbUser.email || extraData?.email || '').toLowerCase();
  const isOwner = normalizedEmail === 'jimmymico45@gmail.com';
  const rawPhone = fbUser.phoneNumber || extraData?.phone || '';
  const normalizedPhone = rawPhone ? normalizePhoneNumber(rawPhone) : '';

  // 1. First try loading authoritative profile from Cloud Firestore users/{uid}
  try {
    const fsProfile = await getUserProfileDoc(fbUser.uid);
    if (fsProfile) {
      fsProfile.emailVerified = fbUser.emailVerified;
      if (normalizedPhone && !fsProfile.phoneNumber) {
        fsProfile.phoneNumber = normalizedPhone;
        fsProfile.phone = normalizedPhone;
      }
      if (isOwner) {
        fsProfile.role = 'system_owner';
      }
      fsProfile.accountStatus = 'active';
      fsProfile.userRegistrationStatus = 'Verified';
      fsProfile.verified = true;
      
      // Save synced verification state back to Firestore safely
      await saveUserProfileDoc(fsProfile).catch((err) => console.warn('Firestore sync save warning:', err));
      return fsProfile;
    }
  } catch (e) {
    console.warn('Firestore profile fetch warning:', e);
  }

  // 2. Fallback to registry check or create fresh profile
  try {
    const users = getRegisteredUsers();
    let found = users.find(u => u.id === fbUser.uid || (normalizedEmail && u.email.toLowerCase() === normalizedEmail));
    
    if (found) {
      found.id = fbUser.uid;
      found.emailVerified = fbUser.emailVerified;
      if (isOwner) {
        found.role = 'system_owner';
      }
      if (normalizedPhone) {
        found.phoneNumber = normalizedPhone;
        found.phone = normalizedPhone;
      }
      found.accountStatus = 'active';
      found.userRegistrationStatus = 'Verified';
      found.verified = true;
      // Save to Firestore authoritative collection
      await saveUserProfileDoc(found).catch((err) => console.warn('Save found profile warning:', err));
      return found;
    }
  } catch (e) {
    console.warn('Local users fallback note:', e);
  }

  // 3. Create new user profile for Firebase user
  const newProfile: User = {
    id: fbUser.uid,
    name: fbUser.displayName || extraData?.fullName || (fbUser.email ? fbUser.email.split('@')[0] : 'AgriWise Member'),
    phone: normalizedPhone || '+250780000000',
    phoneNumber: normalizedPhone || '+250780000000',
    email: normalizedEmail || `${fbUser.uid}@agriwise.rw`,
    role: isOwner ? 'system_owner' : (extraData?.role || 'farmer'),
    province: extraData?.province || 'Northern Province',
    district: extraData?.district || 'Musanze',
    sector: extraData?.sector || 'Kinigi',
    cell: extraData?.cell || '',
    village: extraData?.village || '',
    language: extraData?.language || 'rw',
    verified: true,
    accountStatus: 'active',
    userRegistrationStatus: 'Verified',
    identityStatus: extraData?.identityStatus || 'not_started',
    nationalIdMasked: extraData?.nationalIdMasked,
    nationalIdHash: extraData?.nationalIdHash,
    emailVerified: fbUser.emailVerified,
    notificationPreferences: {
      emailNotifications: true,
      systemNotifications: true,
      salesNotifications: true,
      paymentNotifications: true,
      securityAlerts: true,
      updatedAt: new Date().toISOString()
    },
    subscription: {
      planId: isOwner ? 'enterprise' : 'free',
      planName: isOwner ? 'Enterprise Super Admin' : 'Free Trial Plan',
      status: isOwner ? 'active' : 'trial',
      freeRequestsRemaining: isOwner ? 9999 : 2,
      maxFreeRequests: isOwner ? 9999 : 2,
      usedRequestsCount: 0,
    },
    creditScore: isOwner ? 900 : 720,
  };

  // Persist to Cloud Firestore users/{uid} safely
  await saveUserProfileDoc(newProfile).catch((err) => console.warn('Save new profile Firestore warning:', err));
  
  // Also log security audit
  createAuditLogDoc({
    userId: newProfile.id,
    userName: newProfile.name,
    action: 'USER_REGISTERED_FIRESTORE',
    description: `User account created for ${newProfile.email} with role ${newProfile.role}`,
    status: 'SUCCESS',
  }).catch(() => {});

  return newProfile;
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentBusiness, setCurrentBusiness] = useState<BusinessOrganization | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        const profile = await syncUserProfile(fbUser);
        setCurrentUser(profile);

        // Fetch associated business if businessId present
        if (profile.businessId) {
          const biz = await getBusinessDoc(profile.businessId);
          setCurrentBusiness(biz);
        } else {
          setCurrentBusiness(null);
        }
      } else {
        setCurrentUser(null);
        setCurrentBusiness(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithEmail = async (emailOrPhone: string, password: string, lang: Language = 'rw') => {
    let targetEmail = emailOrPhone.trim().toLowerCase();
    const isPhone = !targetEmail.includes('@');

    if (isPhone) {
      // Resolve phone to email from local registry
      const cleanPhone = emailOrPhone.replace(/\s+/g, '');
      const users = getRegisteredUsers();
      const matched = users.find(u => u.phone.replace(/\s+/g, '') === cleanPhone || (cleanPhone.length >= 8 && u.phone.includes(cleanPhone)));
      if (matched && matched.email) {
        targetEmail = matched.email.toLowerCase();
      } else {
        return {
          success: false,
          error: lang === 'rw' 
            ? 'Nta kaunti ibonetse kuri iyi nimero ya telefone. Nyamuneka koresha e-mail wandikishije.'
            : 'No account registered with this phone number. Please use your registered email address.'
        };
      }
    }

    try {
      const userCredential = await signInWithEmailAndPassword(auth, targetEmail, password);
      const fbUser = userCredential.user;
      const profile = await syncUserProfile(fbUser);
      setCurrentUser(profile);
      return { success: true, user: profile };
    } catch (err: any) {
      console.error('Firebase Email Login Error:', err?.code, err?.message);
      const friendlyMsg = mapFirebaseError(err?.code || 'auth/invalid-credential', lang, err?.message);
      return { success: false, error: friendlyMsg };
    }
  };

  const registerWithEmail = async (params: RegisterParams) => {
    if (params.role === 'admin' || params.role === 'system_owner') {
      return {
        success: false,
        error: 'Public registration for Administrator/Owner accounts is not allowed.',
      };
    }

    const normalizedEmail = params.email.trim().toLowerCase();

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, normalizedEmail, params.password);
      const fbUser = userCredential.user;

      // Update Firebase auth profile display name
      if (params.fullName) {
        await updateProfile(fbUser, { displayName: params.fullName }).catch(() => {});
      }

      // 1. Send Firebase's official email verification email
      await sendEmailVerification(fbUser).catch((e) => {
        console.warn('[AUTH] Firebase email verification dispatch warning:', e?.message || e);
      });

      // 2. Create authoritative app user profile in Cloud Firestore users/{uid}
      const profile = await syncUserProfile(fbUser, params);
      setCurrentUser(profile);

      // 3. Send customized AGRIWISE welcome email via Nodemailer SMTP service (Safe & non-blocking)
      fetch('/api/auth/send-welcome-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: profile.email,
          fullName: profile.name,
          role: profile.role,
          district: profile.district
        })
      }).catch((emailErr) => {
        console.warn('[AUTH] Welcome email dispatch warning (account remains safe):', emailErr?.message || emailErr);
      });

      return { success: true, user: profile };
    } catch (err: any) {
      console.error('Firebase Email Registration Error:', err?.code, err?.message);
      const friendlyMsg = mapFirebaseError(err?.code || 'auth/email-already-in-use', params.language, err?.message);
      return { success: false, error: friendlyMsg };
    }
  };

  const signInWithGoogle = async (lang: Language = 'rw') => {
    try {
      const { user } = await googleSignInService();
      if (auth.currentUser) {
        const profile = await syncUserProfile(auth.currentUser);
        setCurrentUser(profile);
        return { success: true, user: profile };
      }
      setCurrentUser(user);
      return { success: true, user };
    } catch (err: any) {
      console.error('Google Auth Error:', err);
      const friendlyMsg = mapFirebaseError(err?.code || 'auth/invalid-credential', lang, err?.message);
      return { success: false, error: friendlyMsg };
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.error('Logout error:', e);
    } finally {
      setFirebaseUser(null);
      setCurrentUser(null);
      setCurrentBusiness(null);
    }
  };

  const sendPasswordReset = async (email: string, lang: Language = 'rw') => {
    const normalizedEmail = email.trim().toLowerCase();
    if (!normalizedEmail || !normalizedEmail.includes('@')) {
      return {
        success: false,
        error: lang === 'rw' ? 'Nyamuneka shyiramo aderesi ya e-mail yemewe.' : 'Please enter a valid email address.'
      };
    }

    try {
      // Primary mechanism: Firebase Authentication native password reset
      // Construct clean dynamic origin URL pointing to AGRIWISE custom email action handler
      const continueUrl = `${window.location.origin}/auth/action`;
      const actionCodeSettings = {
        url: continueUrl,
        handleCodeInApp: false, // Must be FALSE for web SPA applications
      };

      try {
        await sendPasswordResetEmail(auth, normalizedEmail, actionCodeSettings);
      } catch (firstErr: any) {
        // If actionCodeSettings fails (e.g. domain not whitelisted in ActionCodeSettings continueUrl), fallback to standard sendPasswordResetEmail
        if (
          firstErr?.code === 'auth/unauthorized-continue-uri' ||
          firstErr?.code === 'auth/invalid-continue-uri' ||
          firstErr?.code === 'auth/argument-error'
        ) {
          console.warn('ActionCodeSettings continue URI warning, retrying standard sendPasswordResetEmail:', firstErr);
          await sendPasswordResetEmail(auth, normalizedEmail);
        } else {
          throw firstErr;
        }
      }

      return {
        success: true,
        message: lang === 'rw' 
          ? 'Ubutumwa bwo guhindura ijambo ry\'ibanga bwoherejwe kuri e-mail yawe. Nyamuneka reba muri inbox, spam cyangwa promotions yawe ukande kuri link ya Firebase.'
          : 'Password reset email sent. Please check your inbox and follow the link to create a new password.'
      };
    } catch (err: any) {
      const code = err?.code || '';
      console.warn('Firebase Password Reset Note:', code, err?.message);

      const friendlyMsg = mapFirebaseError(code, lang, err?.message);
      return { success: false, error: friendlyMsg };
    }
  };

  const verifyResetCode = async (oobCode: string, lang: Language = 'rw') => {
    try {
      const email = await verifyPasswordResetCode(auth, oobCode);
      return { success: true, email };
    } catch (err: any) {
      console.warn('Firebase verifyPasswordResetCode error:', err);
      const friendlyMsg = mapFirebaseError(err?.code || 'auth/invalid-action-code', lang, err?.message);
      return { success: false, error: friendlyMsg };
    }
  };

  const confirmPasswordResetWithCode = async (oobCode: string, newPass: string, lang: Language = 'rw') => {
    try {
      await confirmPasswordReset(auth, oobCode, newPass);
      return {
        success: true,
        message: lang === 'rw'
          ? 'Ijambo ry\'ibanga ryawe ryahinduwe neza. Ubu ushobora kwinjira ukoresheje ijambo ry\'ibanga rishya.'
          : 'Your password has been successfully changed. You can now log in using your new password.'
      };
    } catch (err: any) {
      console.warn('Firebase confirmPasswordReset error:', err);
      const friendlyMsg = mapFirebaseError(err?.code || 'auth/invalid-action-code', lang, err?.message);
      return { success: false, error: friendlyMsg };
    }
  };

  const sendVerificationEmail = async (lang: Language = 'rw') => {
    if (!auth.currentUser) {
      return { 
        success: false, 
        error: lang === 'rw' ? 'Nta mukoresha winjiye.' : 'No active user logged in.' 
      };
    }
    try {
      await sendEmailVerification(auth.currentUser);
      return {
        success: true,
        message: lang === 'rw'
          ? 'Link yo kwemeza e-mail yongeye koherezwa kuri e-mail yawe.'
          : 'A verification link has been resent to your registered email address.'
      };
    } catch (err: any) {
      console.error('Send verification warning:', err);
      return { success: false, error: mapFirebaseError(err?.code || 'auth/too-many-requests', lang, err?.message) };
    }
  };

  const reloadUser = async () => {
    if (auth.currentUser) {
      await reload(auth.currentUser).catch(() => {});
      const refreshedFbUser = auth.currentUser;
      setFirebaseUser(refreshedFbUser);
      if (refreshedFbUser) {
        const profile = await syncUserProfile(refreshedFbUser);
        setCurrentUser(profile);
      }
    }
  };

  const updateCurrentUserProfile = async (updated: Partial<User>) => {
    if (!currentUser) return;
    const newProfile = { ...currentUser, ...updated };
    setCurrentUser(newProfile);
    await saveUserProfileDoc(newProfile).catch((err) => console.warn('Save profile Firestore warning:', err));
  };

  const createBusiness = async (data: Omit<BusinessOrganization, 'businessId' | 'ownerId' | 'createdAt' | 'updatedAt'>) => {
    if (!currentUser || !auth.currentUser) {
      return { success: false, error: 'User must be authenticated to create a business.' };
    }
    try {
      const biz = await createBusinessDoc(data, auth.currentUser.uid);
      setCurrentBusiness(biz);
      await updateCurrentUserProfile({ businessId: biz.businessId });
      return { success: true, business: biz };
    } catch (err: any) {
      console.error('Create Business error:', err);
      return { success: false, error: 'Failed to create business record.' };
    }
  };

  const emailVerified = !!(firebaseUser?.emailVerified || currentUser?.emailVerified);

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        currentUser,
        currentBusiness,
        loading,
        emailVerified,
        loginWithEmail,
        registerWithEmail,
        signInWithGoogle,
        logout,
        sendPasswordReset,
        confirmPasswordResetWithCode,
        verifyResetCode,
        sendVerificationEmail,
        reloadUser,
        updateCurrentUserProfile,
        createBusiness,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
