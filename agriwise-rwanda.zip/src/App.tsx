import React, { useState, useEffect } from 'react';
import { User, Language, NavigationTab, FarmerProfileDetails, RegisteredFarm, FarmActivity, FarmDocumentRecord } from './types';
import {
  INITIAL_FARMER_PROFILE,
  INITIAL_REGISTERED_FARMS,
  INITIAL_FARM_ACTIVITIES,
  INITIAL_FARM_DOCUMENTS,
} from './data/mockData';
import { getCurrentSession, clearAuthSession } from './services/authService';
import { isTabAllowedForRole, DEFAULT_ROLE_DASHBOARD, getAccessDeniedReason } from './utils/rolePermissions';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { FarmerProfileSystem } from './components/features/FarmerProfileSystem';
import { FarmRegistration } from './components/features/FarmRegistration';
import { FarmActivityTracker } from './components/features/FarmActivityTracker';
import { FarmDocuments } from './components/features/FarmDocuments';
import { MapMyFarm } from './components/features/MapMyFarm';
import { AiChatAssistant } from './components/features/AiChatAssistant';
import { VoiceFarmAssistant } from './components/features/VoiceFarmAssistant';
import { UssdVoiceGatewayModule } from './components/features/UssdVoiceGatewayModule';
import { SystemAdminCenter } from './components/features/SystemAdminCenter';
import { DiseaseDetector } from './components/features/DiseaseDetector';
import { CropManager } from './components/features/CropManager';
import { LivestockManager } from './components/features/LivestockManager';
import { FinancialTracker } from './components/features/FinancialTracker';
import { Marketplace } from './components/features/Marketplace';
import { ExpertConsultation } from './components/features/ExpertConsultation';
import { CooperativeManagement } from './components/features/CooperativeManagement';
import { AgroDealerSupplyChain } from './components/features/AgroDealerSupplyChain';
import { AgriculturalLogistics } from './components/features/AgriculturalLogistics';
import { GovernmentPolicyDashboard } from './components/features/GovernmentPolicyDashboard';
import { BankingInsuranceModule } from './components/features/BankingInsuranceModule';
import { SatelliteMonitoringDashboard } from './components/features/SatelliteMonitoringDashboard';
import { IoTSmartFarmDashboard } from './components/features/IoTSmartFarmDashboard';
import { DroneAgricultureModule } from './components/features/DroneAgricultureModule';
import { CreditScoreModule } from './components/features/CreditScoreModule';
import { WeatherWidget } from './components/features/WeatherWidget';
import { FarmerTrainingAcademy } from './components/features/FarmerTrainingAcademy';
import { DataMarketplacePlatform } from './components/features/DataMarketplacePlatform';
import { GlobalExpansionPlatform } from './components/features/GlobalExpansionPlatform';
import { CloudInfrastructurePlatform } from './components/features/CloudInfrastructurePlatform';
import { QualityAssurancePlatform } from './components/features/QualityAssurancePlatform';
import { BusinessMonetizationPlatform } from './components/features/BusinessMonetizationPlatform';
import { CompanyLaunchPlatform } from './components/features/CompanyLaunchPlatform';
import { CommunityForum } from './components/features/CommunityForum';
import { PaymentModal } from './components/features/PaymentModal';
import { SubscriptionUpgradeModal } from './components/features/SubscriptionUpgradeModal';
import { AuthModal } from './components/auth/AuthModal';
import { LoginPage } from './components/auth/LoginPage';
import { RegisterPage } from './components/auth/RegisterPage';
import { ForgotPasswordPage } from './components/auth/ForgotPasswordPage';
import { EmailVerificationPage } from './components/auth/EmailVerificationPage';
import { CustomFirebaseAuthHandler } from './components/auth/CustomFirebaseAuthHandler';
import { LandingHomePage } from './components/home/LandingHomePage';
import { parseFirebaseActionParams } from './utils/firebaseActionParser';
import { Footer } from './components/Footer';
import { JimmyMicoPro } from './components/features/JimmyMicoPro';
import { AuthProvider, useAuth } from './context/AuthContext';
import { MaintenancePage } from './components/MaintenancePage';
import { getMaintenanceMode } from './services/systemSettingsService';
import { Home, Mic, Smartphone, MapPin, ShoppingBag, Lock, Clock, ShieldAlert, LogIn, UserPlus, PhoneCall, Mail, X, RefreshCw } from 'lucide-react';

function AppContent() {
  const { currentUser, logout, loading, updateCurrentUserProfile } = useAuth();
  const isAuthenticated = !!currentUser;
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [logoutNotification, setLogoutNotification] = useState<boolean>(false);

  // Active fallback for unauthenticated views or components expecting a user object
  const activeUser: User = currentUser || {
    id: 'unauthenticated_visitor',
    name: 'Visitor',
    email: 'visitor@agriwise.rw',
    phone: '+250 788 000 000',
    role: 'farmer',
    district: 'Kigali City',
    sector: 'Nyarugenge',
    language: 'rw',
    verified: false,
    accountStatus: 'active',
  };

  // Status Guard Modal state for unauthenticated or non-active access attempts
  const [statusGuardModal, setStatusGuardModal] = useState<{
    isOpen: boolean;
    type: 'unauthenticated' | 'pending' | 'suspended';
    title: string;
    message: string;
  }>({
    isOpen: false,
    type: 'unauthenticated',
    title: '',
    message: '',
  });

  const [language, setLanguage] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('agriwise_language');
      if (saved === 'rw' || saved === 'en' || saved === 'fr') {
        return saved;
      }
    } catch {
      // Fallback
    }
    return 'rw';
  });

  const [isActionRouteActive, setIsActionRouteActive] = useState<boolean>(() => {
    try {
      const fbAction = parseFirebaseActionParams();
      return fbAction.isActionRoute || !!fbAction.oobCode || fbAction.isPasswordReset || fbAction.isEmailVerification;
    } catch {
      return false;
    }
  });

  const handleLanguageChange = (newLang: Language) => {
    setLanguage(newLang);
    try {
      localStorage.setItem('agriwise_language', newLang);
    } catch (e) {
      console.error('Failed to save language preference:', e);
    }
  };
  const [activeTab, setActiveTab] = useState<NavigationTab>(() => {
    try {
      const fbAction = parseFirebaseActionParams();
      const pathname = typeof window !== 'undefined' ? window.location.pathname.toLowerCase() : '';

      if (
        fbAction.isPasswordReset ||
        pathname.includes('/reset-password') ||
        pathname.includes('/forgot-password')
      ) {
        return 'forgot_password';
      }

      if (
        fbAction.isEmailVerification ||
        pathname.includes('/verify-email')
      ) {
        return 'verify_email';
      }

      if (pathname === '/login') return 'login';
      if (pathname === '/register') return 'register';

      const saved = sessionStorage.getItem('agriwise_active_tab') as NavigationTab;
      if (saved) return saved;
    } catch (e) {
      console.warn('Initial tab resolution error:', e);
    }
    return 'home';
  });
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showNotificationsModal, setShowNotificationsModal] = useState(false);

  // Auto-restore tab or redirect when user logs in
  useEffect(() => {
    if (currentUser) {
      if (activeTab === 'login' || activeTab === 'register') {
        const target = DEFAULT_ROLE_DASHBOARD[currentUser.role] || 'dashboard';
        setActiveTab(target);
        try {
          sessionStorage.setItem('agriwise_active_tab', target);
        } catch {}
      }
    }
  }, [currentUser]);

  // Check URL query parameters and pathname for Firebase action links on startup & history changes
  useEffect(() => {
    try {
      const fbAction = parseFirebaseActionParams();
      const pathname = typeof window !== 'undefined' ? window.location.pathname.toLowerCase() : '';

      if (fbAction.isActionRoute || !!fbAction.oobCode) {
        setIsActionRouteActive(true);
      }

      if (
        fbAction.isPasswordReset ||
        pathname.includes('/reset-password') ||
        pathname.includes('/forgot-password')
      ) {
        setActiveTab('forgot_password');
      } else if (
        fbAction.isEmailVerification ||
        pathname.includes('/verify-email')
      ) {
        setActiveTab('verify_email');
      }
    } catch (e) {
      console.warn('URL parsing error:', e);
    }
  }, []);

  // Global Navigation Guard
  const handleTabChange = (targetTab: NavigationTab) => {
    try {
      sessionStorage.setItem('agriwise_active_tab', targetTab);
    } catch {}

    // Public Pages (Home Page, Login Page, Register Page, Forgot Password, Verify Email)
    if (
      targetTab === 'home' ||
      targetTab === 'login' ||
      targetTab === 'register' ||
      targetTab === 'forgot_password' ||
      targetTab === 'verify_email'
    ) {
      setActiveTab(targetTab);
      return;
    }

    // Guard 1: Authentication Check
    if (!isAuthenticated) {
      setStatusGuardModal({
        isOpen: true,
        type: 'unauthenticated',
        title: language === 'rw' ? 'Kwinjira Birakenewe' : 'Authentication Required',
        message: language === 'rw'
          ? 'Nyamuneka injira cyangwa ufungure akaunti kuri AGRIWISE kugira ngo ubashe gukoresha iyi serivisi.'
          : 'Please log in or create an account to access AGRIWISE services.',
      });
      return;
    }

    // Guard 2: Role Authorization Check
    const currentRole = currentUser?.role || 'farmer';
    const isAllowed = isTabAllowedForRole(currentRole, targetTab);
    if (!isAllowed) {
      const deniedInfo = getAccessDeniedReason(currentRole, targetTab, language);
      setStatusGuardModal({
        isOpen: true,
        type: 'unauthenticated',
        title: deniedInfo.title,
        message: deniedInfo.message,
      });

      // Audit Log security violation event
      fetch('/api/owner/audit-log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser?.id || 'unauthenticated',
          userName: currentUser?.name || 'Visitor',
          userRole: currentRole,
          eventType: 'UNAUTHORIZED_ACCESS_ATTEMPT',
          details: `403 Forbidden: User attempted unauthorized access to tab [${targetTab}]`,
        }),
      }).catch(() => {});
      return;
    }

    // Guard 3: Account Active Status Check
    const userStatus = currentUser?.accountStatus || 'active';
    if (userStatus === 'pending') {
      setStatusGuardModal({
        isOpen: true,
        type: 'pending',
        title: language === 'rw' ? 'Akaunti Itegereje Kwemezwa' : 'Account Pending Approval',
        message: language === 'rw'
          ? 'Akaunti yawe yanditswe neza ariko itegereje kwemezwa n\'ubuyobozi bwa AGRIWISE. Biremeza mu masaha 24.'
          : 'Your account is waiting for approval. AGRIWISE administrators verify accounts within 24 hours.',
      });
      return;
    }

    if (userStatus === 'suspended' || userStatus === 'blocked') {
      setStatusGuardModal({
        isOpen: true,
        type: 'suspended',
        title: language === 'rw' ? 'Akaunti Yaragagaritswe' : 'Account Suspended',
        message: language === 'rw'
          ? 'Akaunti yawe yaragagaritswe. Nyamuneka vugana n\'ubuyobozi bwa AGRIWISE kuri support@agriwise.rw cyangwa uhamagara 1111.'
          : 'Your account has been suspended. Please contact AGRIWISE support at support@agriwise.rw or call 1111.',
      });
      return;
    }

    // Access granted
    setActiveTab(targetTab);
  };

  // Farmer Core Platform State
  const [farmerProfile, setFarmerProfile] = useState<FarmerProfileDetails>(() => ({
    ...INITIAL_FARMER_PROFILE,
    photoUrl: currentUser?.avatarUrl || INITIAL_FARMER_PROFILE.photoUrl,
  }));

  useEffect(() => {
    if (currentUser) {
      setFarmerProfile((prev) => ({
        ...prev,
        fullName: currentUser.name || prev.fullName,
        email: currentUser.email || prev.email,
        district: currentUser.district || prev.district,
        sector: currentUser.sector || prev.sector,
        cell: currentUser.cell || prev.cell,
        village: currentUser.village || prev.village,
        phone: currentUser.phone || prev.phone,
        photoUrl: currentUser.avatarUrl || prev.photoUrl,
      }));
    }
  }, [currentUser]);

  const [registeredFarms, setRegisteredFarms] = useState<RegisteredFarm[]>(INITIAL_REGISTERED_FARMS);
  const [farmActivities, setFarmActivities] = useState<FarmActivity[]>(INITIAL_FARM_ACTIVITIES);
  const [farmDocuments, setFarmDocuments] = useState<FarmDocumentRecord[]>(INITIAL_FARM_DOCUMENTS);

  // Subscription Upgrade & Usage Limit Modal state
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [selectedPlanForPayment, setSelectedPlanForPayment] = useState<string>('');

  // Usage Limit Tracker: Check & Decrement Free AI Request
  const handleUseFreeRequest = (): boolean => {
    const sub = activeUser.subscription || {
      planId: 'free',
      planName: 'Free Trial Plan',
      status: 'trial',
      freeRequestsRemaining: 2,
      maxFreeRequests: 2,
      usedRequestsCount: 0,
    };

    // Paid plans have unlimited access
    if (sub.planId !== 'free') {
      return true;
    }

    // Check remaining free requests
    if (sub.freeRequestsRemaining > 0) {
      const updatedSub = {
        ...sub,
        freeRequestsRemaining: sub.freeRequestsRemaining - 1,
        usedRequestsCount: sub.usedRequestsCount + 1,
      };
      if (currentUser) {
        updateCurrentUserProfile({ subscription: updatedSub });
      }
      return true;
    }

    // Free limit reached
    setShowSubscriptionModal(true);
    return false;
  };

  // Mobile Money Payment Modal state
  const [paymentModal, setPaymentModal] = useState<{
    isOpen: boolean;
    amountRwf: number;
    title: string;
  }>({
    isOpen: false,
    amountRwf: 0,
    title: '',
  });

  const handleInitiateMomoPayment = (amountRwf: number, title: string) => {
    setPaymentModal({
      isOpen: true,
      amountRwf,
      title,
    });
  };

  const handlePaymentSuccess = (txRef: string) => {
    // Top-up simulation
    if (paymentModal.title.includes('MoMo Top-Up') && currentUser) {
      updateCurrentUserProfile({
        momoBalanceRwf: ((currentUser as any).momoBalanceRwf || 1850000) + paymentModal.amountRwf,
      });
    }

    // Subscription plan purchase
    if ((paymentModal.title.includes('Subscription') || selectedPlanForPayment) && currentUser) {
      const newPlanId = (selectedPlanForPayment || 'farmer_premium') as any;
      const planNames: Record<string, string> = {
        farmer_premium: 'Farmer Premium Plan',
        professional: 'Professional Agro-Expert Plan',
        enterprise: 'Enterprise Cooperative Plan',
      };
      updateCurrentUserProfile({
        subscription: {
          planId: newPlanId,
          planName: planNames[newPlanId] || 'Farmer Premium Plan',
          status: 'active',
          freeRequestsRemaining: 99999,
          maxFreeRequests: 99999,
          usedRequestsCount: currentUser.subscription?.usedRequestsCount || 0,
          renewsAt: '2026-12-31',
        },
      });
      setShowSubscriptionModal(false);
      setSelectedPlanForPayment('');
    }
  };

  const handleLogout = async () => {
    try {
      sessionStorage.removeItem('agriwise_active_tab');
    } catch {}
    clearAuthSession();
    await logout();
    setActiveTab('home');
    setLogoutNotification(true);
    setTimeout(() => {
      setLogoutNotification(false);
    }, 4000);
  };

  const handleLoginSuccess = (user: User) => {
    setShowAuthModal(false);
    const targetDashboard = DEFAULT_ROLE_DASHBOARD[user.role] || 'dashboard';
    try {
      sessionStorage.setItem('agriwise_active_tab', targetDashboard);
    } catch {}
    setActiveTab(targetDashboard);
  };

  const handleRegisterSuccess = (newUser: User) => {
    setShowAuthModal(false);
    const targetDashboard = DEFAULT_ROLE_DASHBOARD[newUser.role] || 'dashboard';
    setActiveTab(targetDashboard);
  };

  const isPublicPage =
    activeTab === 'home' ||
    activeTab === 'login' ||
    activeTab === 'register' ||
    activeTab === 'forgot_password' ||
    activeTab === 'verify_email';
  const maintenanceInfo = getMaintenanceMode();

  // If visiting dedicated Firebase Auth Action Handler route or holding Firebase Action parameters
  if (isActionRouteActive) {
    return (
      <CustomFirebaseAuthHandler
        language={language}
        onNavigateToLogin={() => {
          setIsActionRouteActive(false);
          setActiveTab('login');
          if (typeof window !== 'undefined' && window.history && window.history.replaceState) {
            window.history.replaceState({}, document.title, '/');
          }
        }}
        onNavigateHome={() => {
          setIsActionRouteActive(false);
          setActiveTab('home');
          if (typeof window !== 'undefined' && window.history && window.history.replaceState) {
            window.history.replaceState({}, document.title, '/');
          }
        }}
        onRequestNewResetLink={() => {
          setIsActionRouteActive(false);
          setActiveTab('forgot_password');
          if (typeof window !== 'undefined' && window.history && window.history.replaceState) {
            window.history.replaceState({}, document.title, '/');
          }
        }}
      />
    );
  }

  // If Maintenance Mode is enabled and user is NOT a System Owner / Admin, show Maintenance Page
  if (maintenanceInfo.enabled && currentUser?.role !== 'system_owner' && currentUser?.role !== 'admin' && activeTab !== 'login' && activeTab !== 'forgot_password') {
    return (
      <MaintenancePage
        language={language}
        onOpenLogin={() => setActiveTab('login')}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col selection:bg-emerald-500 selection:text-slate-950">
      
      {/* Logout Toast Alert */}
      {logoutNotification && (
        <div className="fixed top-20 right-5 z-50 bg-emerald-950 border border-emerald-500/50 text-emerald-300 px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top duration-300">
          <div className="w-3 h-3 bg-emerald-400 rounded-full animate-ping" />
          <div>
            <p className="font-bold text-xs">Wasohotse muri AGRIWISE neza!</p>
            <p className="text-[10px] text-slate-300">You have successfully logged out.</p>
          </div>
        </div>
      )}

      {/* Top Header */}
      <Header
        currentUser={currentUser || undefined}
        isAuthenticated={isAuthenticated}
        language={language}
        onLanguageChange={handleLanguageChange}
        onInitiateMomoPayment={handleInitiateMomoPayment}
        onOpenSubscriptionModal={() => setShowSubscriptionModal(true)}
        onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
        onOpenNotifications={() => setShowNotificationsModal(true)}
        onLogout={handleLogout}
        onOpenLogin={() => setActiveTab('login')}
        onOpenRegister={() => setActiveTab('register')}
        onOpenHome={() => setActiveTab('home')}
      />

      <div className="flex-1 flex flex-col md:flex-row max-w-[1600px] w-full mx-auto p-3 sm:p-6 gap-6">
        
        {/* Navigation Sidebar - Only shown on internal protected pages */}
        {!isPublicPage && (
          <Sidebar
            currentUser={activeUser}
            activeTab={activeTab}
            onTabChange={(tab) => handleTabChange(tab as NavigationTab)}
            language={language}
            isOpenMobile={isMobileMenuOpen}
            onCloseMobile={() => setIsMobileMenuOpen(false)}
          />
        )}

        {/* Main Workspace Area */}
        <main className="flex-1 min-w-0">
          {activeTab === 'home' && (
            <LandingHomePage
              language={language}
              onOpenLogin={() => setActiveTab('login')}
              onOpenRegister={() => setActiveTab('register')}
            />
          )}

          {activeTab === 'login' && (
            <LoginPage
              language={language}
              onLoginSuccess={handleLoginSuccess}
              onNavigateToRegister={() => setActiveTab('register')}
              onNavigateToHome={() => setActiveTab('home')}
              onNavigateToForgotPassword={() => setActiveTab('forgot_password')}
              onNavigateToVerifyEmail={() => setActiveTab('verify_email')}
            />
          )}

          {activeTab === 'register' && (
            <RegisterPage
              language={language}
              onRegisterSuccess={handleRegisterSuccess}
              onNavigateToLogin={() => setActiveTab('login')}
              onNavigateToHome={() => setActiveTab('home')}
              onNavigateToVerifyEmail={() => setActiveTab('verify_email')}
            />
          )}

          {activeTab === 'forgot_password' && (
            <ForgotPasswordPage
              language={language}
              onNavigateToLogin={() => setActiveTab('login')}
              onNavigateToHome={() => setActiveTab('home')}
            />
          )}

          {activeTab === 'verify_email' && (
            <EmailVerificationPage
              language={language}
              onNavigateToLogin={() => setActiveTab('login')}
              onNavigateToHome={() => setActiveTab('home')}
              onVerificationSuccess={(user) => {
                const targetDashboard = DEFAULT_ROLE_DASHBOARD[currentUser?.role || user?.role || 'farmer'] || 'dashboard';
                setActiveTab(targetDashboard);
              }}
            />
          )}

          {activeTab === 'dashboard' && (
            <Dashboard
              currentUser={activeUser}
              language={language}
              onNavigate={handleTabChange}
              onInitiateMomoPayment={handleInitiateMomoPayment}
            />
          )}

          {activeTab === 'farmer_profile' && (
            <FarmerProfileSystem
              currentUser={activeUser}
              profile={farmerProfile}
              onUpdateProfile={(updated) => {
                setFarmerProfile(updated);
                if (updated.photoUrl !== activeUser.avatarUrl || updated.fullName !== activeUser.name) {
                  updateCurrentUserProfile({
                    name: updated.fullName,
                    avatarUrl: updated.photoUrl,
                    district: updated.district,
                    sector: updated.sector,
                    cell: updated.cell,
                    village: updated.village,
                    phone: updated.phone,
                  });
                }
              }}
              language={language}
            />
          )}

          {activeTab === 'farm_registration' && (
            <FarmRegistration
              farms={registeredFarms}
              onAddFarm={(farm) => setRegisteredFarms((prev) => [...prev, farm])}
              onUpdateFarm={(updated) =>
                setRegisteredFarms((prev) => prev.map((f) => (f.id === updated.id ? updated : f)))
              }
              onDeleteFarm={(id) => setRegisteredFarms((prev) => prev.filter((f) => f.id !== id))}
              language={language}
            />
          )}

          {activeTab === 'activity_tracker' && (
            <FarmActivityTracker
              activities={farmActivities}
              farms={registeredFarms}
              onAddActivity={(act) => setFarmActivities((prev) => [act, ...prev])}
              onToggleComplete={(id) =>
                setFarmActivities((prev) =>
                  prev.map((a) => (a.id === id ? { ...a, status: a.status === 'completed' ? 'pending' : 'completed' } : a))
                )
              }
              language={language}
            />
          )}

          {activeTab === 'farm_documents' && (
            <FarmDocuments
              documents={farmDocuments}
              farms={registeredFarms}
              currentUser={activeUser}
              onUploadDocument={(doc) => setFarmDocuments((prev) => [doc, ...prev])}
              language={language}
            />
          )}

          {activeTab === 'map_my_farm' && (
            <MapMyFarm currentUser={activeUser} language={language} />
          )}

          {activeTab === 'ai_assistant' && (
            <AiChatAssistant
              currentUser={activeUser}
              language={language}
              onUseFreeRequest={handleUseFreeRequest}
              onOpenUpgradeModal={() => setShowSubscriptionModal(true)}
            />
          )}

          {activeTab === 'voice_assistant' && (
            <VoiceFarmAssistant
              currentUser={activeUser}
              language={language}
              registeredFarms={registeredFarms}
              onAddFarmActivity={(activity) => {
                const newAct: FarmActivity = {
                  ...activity,
                  id: `act-${Date.now()}`,
                };
                setFarmActivities((prev) => [newAct, ...prev]);
              }}
              onMakeMoMoPayment={(amount, title) => {
                handleInitiateMomoPayment(amount, title);
              }}
            />
          )}

          {activeTab === 'ussd_voice_gateway' && (
            <UssdVoiceGatewayModule currentUser={activeUser} language={language} />
          )}

          {activeTab === 'disease_detector' && (
            <DiseaseDetector
              currentUser={activeUser}
              language={language}
              registeredFarms={registeredFarms}
              onUpdateFarmHealth={(farmId, newScore) => {
                setRegisteredFarms((prev) =>
                  prev.map((f) => (f.id === farmId ? { ...f, healthScore: newScore } : f))
                );
              }}
              onAddFarmActivity={(activity) => {
                const newAct: FarmActivity = {
                  ...activity,
                  id: `act-${Date.now()}`,
                };
                setFarmActivities((prev) => [newAct, ...prev]);
              }}
              onMakeMoMoPayment={(amount, title) => {
                handleInitiateMomoPayment(amount, title);
              }}
            />
          )}

          {activeTab === 'crop_manager' && <CropManager language={language} />}

          {activeTab === 'livestock_manager' && <LivestockManager language={language} />}

          {activeTab === 'financials' && <FinancialTracker language={language} />}

          {activeTab === 'marketplace' && (
            <Marketplace
              currentUser={activeUser}
              language={language}
              onInitiateMomoPayment={handleInitiateMomoPayment}
            />
          )}

          {activeTab === 'experts' && (
            <ExpertConsultation
              currentUser={activeUser}
              language={language}
              onInitiateMomoPayment={handleInitiateMomoPayment}
            />
          )}

          {activeTab === 'cooperative' && (
            <CooperativeManagement
              currentUser={activeUser}
              language={language}
              onInitiateMomoPayment={handleInitiateMomoPayment}
            />
          )}

          {activeTab === 'agrodealer' && (
            <AgroDealerSupplyChain
              currentUser={activeUser}
              language={language}
              onInitiateMomoPayment={handleInitiateMomoPayment}
            />
          )}

          {activeTab === 'logistics' && (
            <AgriculturalLogistics
              currentUser={activeUser}
              language={language}
              onInitiateMomoPayment={handleInitiateMomoPayment}
            />
          )}

          {activeTab === 'government' && (
            <GovernmentPolicyDashboard
              currentUser={activeUser}
              language={language}
            />
          )}

          {activeTab === 'banking_insurance' && (
            <BankingInsuranceModule
              currentUser={activeUser}
              language={language}
            />
          )}

          {activeTab === 'satellite_monitoring' && (
            <SatelliteMonitoringDashboard
              currentUser={activeUser}
              language={language}
            />
          )}

          {activeTab === 'iot_smart_farm' && (
            <IoTSmartFarmDashboard />
          )}

          {activeTab === 'drone_agriculture' && (
            <DroneAgricultureModule />
          )}

          {activeTab === 'credit_score' && (
            <CreditScoreModule currentUser={activeUser} language={language} />
          )}

          {activeTab === 'weather' && (
            <WeatherWidget currentUser={activeUser} language={language} />
          )}

          {(activeTab === 'training' || activeTab === 'academy_training') && (
            <FarmerTrainingAcademy />
          )}

          {activeTab === 'data_marketplace' && (
            <DataMarketplacePlatform />
          )}

          {activeTab === 'global_expansion' && (
            <GlobalExpansionPlatform currentUser={activeUser} language={language} />
          )}

          {activeTab === 'cloud_infrastructure' && (
            <CloudInfrastructurePlatform currentUser={activeUser} language={language} />
          )}

          {activeTab === 'qa_testing' && (
            <QualityAssurancePlatform currentUser={activeUser} language={language} />
          )}

          {activeTab === 'business_model' && (
            <BusinessMonetizationPlatform currentUser={activeUser} language={language} />
          )}

          {activeTab === 'company_launch' && (
            <CompanyLaunchPlatform currentUser={activeUser} language={language} />
          )}

          {activeTab === 'community' && (
            <CommunityForum currentUser={activeUser} language={language} />
          )}

          {(activeTab === 'system_admin' || activeTab === 'admin') && (
            <SystemAdminCenter
              currentUser={activeUser}
              language={language}
              registeredFarms={registeredFarms}
            />
          )}

          {activeTab === 'jimmy_mico_pro' && (
            <JimmyMicoPro
              currentUser={activeUser}
              language={language}
            />
          )}
        </main>

      </div>

      {/* Mobile Sticky Bottom Navigation Bar (Smartphones & 320px-768px screens) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-slate-950/95 backdrop-blur-md border-t border-slate-800/80 px-2 py-1.5 flex items-center justify-around text-[10px] font-bold text-slate-400 shadow-2xl">
        <button
          onClick={() => handleTabChange('dashboard')}
          className={`flex flex-col items-center gap-0.5 p-1 rounded-xl transition-colors ${
            activeTab === 'dashboard' ? 'text-emerald-400 bg-slate-900' : 'hover:text-slate-200'
          }`}
        >
          <Home className="w-5 h-5" />
          <span>Ikaze</span>
        </button>

        <button
          onClick={() => handleTabChange('voice_assistant')}
          className={`flex flex-col items-center gap-0.5 p-1 rounded-xl transition-colors ${
            activeTab === 'voice_assistant' ? 'text-emerald-400 bg-slate-900' : 'hover:text-slate-200'
          }`}
        >
          <Mic className="w-5 h-5 text-emerald-400" />
          <span>Voice 1111</span>
        </button>

        <button
          onClick={() => handleTabChange('ussd_voice_gateway')}
          className={`flex flex-col items-center gap-0.5 p-1 rounded-xl transition-colors ${
            activeTab === 'ussd_voice_gateway' ? 'text-emerald-400 bg-slate-900' : 'hover:text-slate-200'
          }`}
        >
          <Smartphone className="w-5 h-5 text-teal-400" />
          <span>USSD *111#</span>
        </button>

        <button
          onClick={() => handleTabChange('map_my_farm')}
          className={`flex flex-col items-center gap-0.5 p-1 rounded-xl transition-colors ${
            activeTab === 'map_my_farm' ? 'text-emerald-400 bg-slate-900' : 'hover:text-slate-200'
          }`}
        >
          <MapPin className="w-5 h-5" />
          <span>GPS Map</span>
        </button>

        <button
          onClick={() => handleTabChange('marketplace')}
          className={`flex flex-col items-center gap-0.5 p-1 rounded-xl transition-colors ${
            activeTab === 'marketplace' ? 'text-emerald-400 bg-slate-900' : 'hover:text-slate-200'
          }`}
        >
          <ShoppingBag className="w-5 h-5" />
          <span>Isoko</span>
        </button>
      </div>

      {/* Global AGRIWISE Reusable Footer */}
      <Footer
        language={language}
        onNavigate={(tab) => handleTabChange(tab as NavigationTab)}
        onOpenLogin={() => {
          setAuthMode('login');
          setShowAuthModal(true);
        }}
        onOpenRegister={() => {
          setAuthMode('register');
          setShowAuthModal(true);
        }}
      />

      {/* Status & Authentication Guard Modal */}
      {statusGuardModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-md bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 shadow-2xl space-y-5 text-center">
            <button
              onClick={() => setStatusGuardModal({ ...statusGuardModal, isOpen: false })}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/60 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center">
              {statusGuardModal.type === 'unauthenticated' ? (
                <Lock className="w-8 h-8 text-emerald-400" />
              ) : statusGuardModal.type === 'pending' ? (
                <Clock className="w-8 h-8 text-amber-400" />
              ) : (
                <ShieldAlert className="w-8 h-8 text-rose-400" />
              )}
            </div>

            <div className="space-y-2">
              <h3 className="text-xl font-black text-white">{statusGuardModal.title}</h3>
              <p className="text-xs text-slate-300 leading-relaxed">{statusGuardModal.message}</p>
            </div>

            <div className="pt-2 flex flex-col gap-2">
              {statusGuardModal.type === 'unauthenticated' ? (
                <>
                  <button
                    onClick={() => {
                      setStatusGuardModal({ ...statusGuardModal, isOpen: false });
                      setActiveTab('login');
                    }}
                    className="w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black py-3 rounded-2xl shadow-lg text-xs uppercase tracking-wide flex items-center justify-center gap-2"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>Injira (Go to Login Page)</span>
                  </button>
                  <button
                    onClick={() => {
                      setStatusGuardModal({ ...statusGuardModal, isOpen: false });
                      setActiveTab('register');
                    }}
                    className="w-full bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30 font-bold py-2.5 rounded-2xl text-xs flex items-center justify-center gap-2"
                  >
                    <UserPlus className="w-4 h-4 text-emerald-400" />
                    <span>Fungura Akaunti (Go to Register Page)</span>
                  </button>
                </>
              ) : statusGuardModal.type === 'pending' ? (
                <a
                  href="tel:1111"
                  className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-black py-3 rounded-2xl shadow-lg text-xs flex items-center justify-center gap-2"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>Hamagara RAB Hotline (1111)</span>
                </a>
              ) : (
                <a
                  href="mailto:support@agriwise.rw"
                  className="w-full bg-rose-600 hover:bg-rose-500 text-white font-bold py-3 rounded-2xl shadow-lg text-xs flex items-center justify-center gap-2 font-mono"
                >
                  <Mail className="w-4 h-4" />
                  <span>support@agriwise.rw</span>
                </a>
              )}

              <button
                onClick={() => setStatusGuardModal({ ...statusGuardModal, isOpen: false })}
                className="text-slate-400 hover:text-slate-200 text-xs pt-1 font-medium"
              >
                Guma ku Rubuga (Return to Home)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Subscription Upgrade & Monetization Modal */}
      {showSubscriptionModal && (
        <SubscriptionUpgradeModal
          subscription={
            currentUser.subscription || {
              planId: 'free',
              planName: 'Free Trial Plan',
              status: 'trial',
              freeRequestsRemaining: 0,
              maxFreeRequests: 2,
              usedRequestsCount: 2,
            }
          }
          language={language}
          onClose={() => setShowSubscriptionModal(false)}
          onSelectPlanPayment={(planId, amountRwf, title) => {
            setSelectedPlanForPayment(planId);
            setShowSubscriptionModal(false);
            handleInitiateMomoPayment(amountRwf, title);
          }}
        />
      )}

      {/* Global Payment Modal */}
      {paymentModal.isOpen && (
        <PaymentModal
          amountRwf={paymentModal.amountRwf}
          itemTitle={paymentModal.title}
          language={language}
          onClose={() => setPaymentModal((prev) => ({ ...prev, isOpen: false }))}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {/* Notifications Modal */}
      {showNotificationsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl relative text-slate-100 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2 text-emerald-400">
                <span className="font-bold text-base">RAB & MINAGRI Advisories</span>
              </div>
              <button
                onClick={() => setShowNotificationsModal(false)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded-lg bg-slate-800"
              >
                ✕ Close
              </button>
            </div>

            <div className="space-y-3 max-h-80 overflow-y-auto text-xs">
              <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30">
                <p className="font-bold text-amber-300">🌧️ Rainfall Advisory - Northern Province</p>
                <p className="text-slate-300 text-[11px] mt-1">
                  Meteo Rwanda forecasts heavy rainfall in Musanze & Burera next 48 hours. Ensure terracing drainage is cleared.
                </p>
                <span className="text-[10px] text-slate-400 mt-1 block">10 mins ago</span>
              </div>

              <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30">
                <p className="font-bold text-emerald-300">🥔 Irish Potato Blight Warning (Kinigi)</p>
                <p className="text-slate-300 text-[11px] mt-1">
                  Apply copper-based fungicides proactively before expected rain. Recommended products available at agrodealers.
                </p>
                <span className="text-[10px] text-slate-400 mt-1 block">2 hours ago</span>
              </div>

              <div className="p-3 rounded-xl bg-blue-950/30 border border-blue-500/30">
                <p className="font-bold text-blue-300">💰 MoMo Subsidy Voucher Disbursed</p>
                <p className="text-slate-300 text-[11px] mt-1">
                  Your Smart Nkunganire System (SNS) fertilizer subsidy voucher has been credited to your phone number.
                </p>
                <span className="text-[10px] text-slate-400 mt-1 block">Yesterday</span>
              </div>
            </div>

            <button
              onClick={() => setShowNotificationsModal(false)}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl text-xs transition-colors"
            >
              Mark All as Read
            </button>
          </div>
        </div>
      )}

      {/* Auth Portal Modal (Login / Register) */}
      <AuthModal
        isOpen={showAuthModal}
        initialMode={authMode}
        language={language}
        onClose={() => setShowAuthModal(false)}
        onLoginSuccess={handleLoginSuccess}
        onRegisterSuccess={handleRegisterSuccess}
        onOpenForgotPassword={() => setActiveTab('forgot_password')}
      />

    </div>
  );
}

export function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
