import {
  User,
  FarmProfile,
  CropRecord,
  LivestockRecord,
  FinancialTransaction,
  MarketplaceItem,
  MarketplaceOrder,
  ExpertConsultant,
  ConsultationBooking,
  WeatherData,
  CommunityPost,
  Course
} from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'user_0_owner',
    name: 'Jimmy Mico (AGRIWISE Platform Owner)',
    email: 'jimmymico45@gmail.com',
    phone: '0792426760',
    role: 'system_owner',
    district: 'Kigali City',
    sector: 'Nyarugenge',
    language: 'en',
    verified: true,
    accountStatus: 'active',
    subscription: {
      planId: 'enterprise',
      planName: 'Enterprise Super Admin',
      status: 'active',
      freeRequestsRemaining: 9999,
      maxFreeRequests: 9999,
      usedRequestsCount: 42,
    },
    creditScore: 900,
  },
  {
    id: 'user_1',
    name: 'Jean de Dieu Nshimiyimana',
    email: 'jeandedieu@agriwise.rw',
    phone: '+250 788 345 678',
    role: 'farmer',
    district: 'Musanze',
    sector: 'Kinigi',
    language: 'rw',
    verified: true,
    accountStatus: 'active',
    subscription: {
      planId: 'free',
      planName: 'Free Trial Plan',
      status: 'trial',
      freeRequestsRemaining: 2,
      maxFreeRequests: 2,
      usedRequestsCount: 0,
    },
    creditScore: 780,
    momoNumber: '+250 788 345 678',
    farmSizeHectares: 2.5,
    primaryCrops: ['Irish Potatoes (Kinigi)', 'Maize (H513)', 'Pyrethrum'],
  },
  {
    id: 'user_2',
    name: 'Marie Claire Uwase',
    email: 'uwase.livestock@agriwise.rw',
    phone: '+250 789 234 567',
    role: 'livestock',
    district: 'Nyagatare',
    sector: 'Matimba',
    language: 'rw',
    verified: true,
    accountStatus: 'active',
    subscription: {
      planId: 'farmer_premium',
      planName: 'Farmer Premium',
      status: 'active',
      freeRequestsRemaining: 9999,
      maxFreeRequests: 9999,
      usedRequestsCount: 15,
      renewsAt: '2026-12-31',
    },
    creditScore: 810,
    momoNumber: '+250 789 234 567',
    primaryLivestock: ['Friesian Dairy Cattle', 'Gyr Goats'],
  },
  {
    id: 'user_3',
    name: 'Abahizi Kinigi Potato Cooperative',
    email: 'coop.kinigi@agriwise.rw',
    phone: '+250 788 998 877',
    role: 'cooperative',
    district: 'Musanze',
    sector: 'Kinigi',
    language: 'rw',
    verified: true,
    accountStatus: 'active',
    creditScore: 840,
    cooperativeName: 'Abahizi Kinigi Potato Farmers Cooperative (450 Members)',
  },
  {
    id: 'user_4',
    name: 'Inyange Agro-Dealer Supplies',
    email: 'sales@inyangeagro.rw',
    phone: '+250 788 112 233',
    role: 'agrodealer',
    district: 'Rubavu',
    sector: 'Gisenyi',
    language: 'en',
    verified: true,
    accountStatus: 'active',
    creditScore: 790,
  },
  {
    id: 'user_5',
    name: 'Rwanda Grain & Milling Industries',
    email: 'procurement@rwandagrain.rw',
    phone: '+250 788 445 566',
    role: 'buyer',
    district: 'Kigali City',
    sector: 'Kicukiro',
    language: 'en',
    verified: true,
    accountStatus: 'active',
    creditScore: 850,
  },
  {
    id: 'user_6',
    name: 'Dr. Emmanuel Mukamana',
    email: 'e.mukamana@rab.gov.rw',
    phone: '+250 788 123 456',
    role: 'expert',
    district: 'Musanze',
    sector: 'Muhoza',
    language: 'rw',
    verified: true,
    accountStatus: 'active',
    creditScore: 820,
  },
  {
    id: 'user_7',
    name: 'Kigali Express Agribusiness Logistics',
    email: 'dispatch@kigalilogistics.rw',
    phone: '+250 788 776 655',
    role: 'transporter',
    district: 'Kigali City',
    sector: 'Nyarugenge',
    language: 'fr',
    verified: true,
    accountStatus: 'active',
    creditScore: 760,
  },
  {
    id: 'user_8',
    name: 'Bank of Kigali Agribusiness Division',
    email: 'agri-loans@bk.rw',
    phone: '+250 788 000 111',
    role: 'bank_insurance',
    district: 'Kigali City',
    sector: 'Nyarugenge',
    language: 'en',
    verified: true,
    accountStatus: 'active',
    creditScore: 850,
  },
  {
    id: 'user_9',
    name: 'Rwanda Agricultural Board (RAB - MINAGRI)',
    email: 'info@rab.gov.rw',
    phone: '+250 788 555 444',
    role: 'government_ngo',
    district: 'Kigali City',
    sector: 'Gasabo',
    language: 'rw',
    verified: true,
    accountStatus: 'active',
    creditScore: 850,
  },
  {
    id: 'user_10',
    name: 'AgriWise System Administrator',
    email: 'admin@agriwise.rw',
    phone: '+250 788 999 000',
    role: 'admin',
    district: 'Kigali City',
    sector: 'Gasabo',
    language: 'en',
    verified: true,
    accountStatus: 'active',
    creditScore: 850,
  },
  {
    id: 'user_11',
    name: 'Eric Kwizera (Pending Verification)',
    email: 'eric.kwizera@gmail.com',
    phone: '+250 788 222 333',
    role: 'farmer',
    district: 'Nyagatare',
    sector: 'Rwamagana',
    language: 'rw',
    verified: false,
    accountStatus: 'pending',
    creditScore: 650,
  },
  {
    id: 'user_12',
    name: 'Suspended Account User',
    email: 'suspended@agriwise.rw',
    phone: '+250 788 000 999',
    role: 'buyer',
    district: 'Huye',
    sector: 'Ngoma',
    language: 'rw',
    verified: false,
    accountStatus: 'suspended',
    creditScore: 500,
  }
];

export const INITIAL_FARM: FarmProfile = {
  id: 'farm_001',
  farmerId: 'user_1',
  farmerName: 'Jean de Dieu Nshimiyimana',
  farmName: 'Kinigi Volcanic Valley Farm #4',
  district: 'Musanze',
  sector: 'Kinigi',
  sizeHectares: 2.5,
  boundaryCoordinates: [
    { lat: -1.4392, lng: 29.5891 },
    { lat: -1.4405, lng: 29.5912 },
    { lat: -1.4421, lng: 29.5898 },
    { lat: -1.4408, lng: 29.5879 }
  ],
  soilType: 'Volcanic rich loam soil (pH 6.3)',
  crops: ['Irish Potatoes (Kinigi)', 'Maize (H513)'],
  livestock: ['Dairy Cows (2)'],
  irrigationType: 'Gravity fed drip & rainwater harvesting',
  creditScore: 780,
  totalIncomeRwf: 4850000,
  totalExpenseRwf: 1620000,
  verifiedByGovernment: true,
};

export const INITIAL_CROPS: CropRecord[] = [
  {
    id: 'crop_101',
    farmerId: 'user_1',
    cropName: 'Irish Potatoes (Kinigi Variety)',
    variety: 'Kinigi Certified Seed A',
    acreageHectares: 1.5,
    plantingDate: '2026-03-15',
    stage: 'fruiting',
    expectedHarvestDate: '2026-08-28',
    expectedYieldTons: 12.5,
    status: 'healthy',
    lastFertilizerDate: '2026-04-20',
    notes: 'Applied NPK 17-17-17. Excellent tuber formation observed.'
  },
  {
    id: 'crop_102',
    farmerId: 'user_1',
    cropName: 'Hybrid Maize',
    variety: 'H513 High Altitude',
    acreageHectares: 1.0,
    plantingDate: '2026-04-01',
    stage: 'flowering',
    expectedHarvestDate: '2026-09-15',
    expectedYieldTons: 4.8,
    status: 'attention_needed',
    lastFertilizerDate: '2026-05-10',
    notes: 'Minor leaf yellowing observed on lower leaves. Scheduled Urea top-dressing.'
  }
];

export const INITIAL_LIVESTOCK: LivestockRecord[] = [
  {
    id: 'live_1',
    farmerId: 'user_2',
    tagNumber: 'RWA-NYA-2024-089',
    animalType: 'Cattle',
    breed: 'Friesian Holstein Purebred',
    gender: 'Female',
    ageMonths: 32,
    healthStatus: 'Excellent',
    lastVaccinationDate: '2026-05-12',
    dailyYieldLitersOrEggs: 26.5
  },
  {
    id: 'live_2',
    farmerId: 'user_2',
    tagNumber: 'RWA-NYA-2025-112',
    animalType: 'Cattle',
    breed: 'Friesian Crossbreed',
    gender: 'Female',
    ageMonths: 22,
    healthStatus: 'Good',
    lastVaccinationDate: '2026-05-12',
    dailyYieldLitersOrEggs: 18.0
  }
];

export const INITIAL_TRANSACTIONS: FinancialTransaction[] = [
  {
    id: 'tx_101',
    farmerId: 'user_1',
    date: '2026-07-28',
    category: 'Produce Sale',
    type: 'income',
    amountRwf: 1250000,
    description: 'Bulk sale of 3.5 Tons Irish Potatoes to Kigali Grain Buyer',
    paymentMethod: 'MTN Mobile Money',
    receiptRef: 'MOMO-RW-9872134'
  },
  {
    id: 'tx_102',
    farmerId: 'user_1',
    date: '2026-07-15',
    category: 'Fertilizer',
    type: 'expense',
    amountRwf: 240000,
    description: '4 Bags NPK 17-17-17 (50kg) from Inyange Agro-Dealer',
    paymentMethod: 'MTN Mobile Money',
    receiptRef: 'AGRO-INV-4412'
  },
  {
    id: 'tx_103',
    farmerId: 'user_1',
    date: '2026-06-30',
    category: 'Labor',
    type: 'expense',
    amountRwf: 180000,
    description: 'Weeding labor cost for 1.5 Ha potato field (6 workers, 3 days)',
    paymentMethod: 'Cash',
  }
];

export const INITIAL_MARKETPLACE: MarketplaceItem[] = [
  {
    id: 'market_1',
    sellerId: 'user_1',
    sellerName: 'Jean de Dieu Nshimiyimana',
    sellerRole: 'farmer',
    sellerPhone: '+250 788 345 678',
    district: 'Musanze',
    title: 'Fresh Grade A1 Kinigi Irish Potatoes',
    category: 'Produce',
    quantity: 8,
    unit: 'Tons',
    pricePerUnitRwf: 320,
    imageUrl: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=600&auto=format&fit=crop&q=80',
    description: 'Clean, disease-free, high density red potatoes harvested from Musanze volcanic soils.',
    verifiedGrade: 'Grade A1',
    status: 'available'
  },
  {
    id: 'market_2',
    sellerId: 'user_4',
    sellerName: 'Inyange Agro-Dealer Supplies',
    sellerRole: 'agrodealer',
    sellerPhone: '+250 788 112 233',
    district: 'Rubavu',
    title: 'Certified NPK 17-17-17 Fertilizer (50Kg Bag)',
    category: 'Inputs',
    quantity: 120,
    unit: 'Bags',
    pricePerUnitRwf: 48000,
    imageUrl: 'https://images.unsplash.com/photo-1628352081506-83c43123ed6d?w=600&auto=format&fit=crop&q=80',
    description: 'RAB approved balanced granular fertilizer for root crops and maize.',
    verifiedGrade: 'Grade A1',
    status: 'available'
  },
  {
    id: 'market_3',
    sellerId: 'user_2',
    sellerName: 'Marie Claire Uwase',
    sellerRole: 'livestock',
    sellerPhone: '+250 789 234 567',
    district: 'Nyagatare',
    title: 'High Yield Fresh Raw Milk (Daily Supply)',
    category: 'Produce',
    quantity: 500,
    unit: 'Liters',
    pricePerUnitRwf: 350,
    imageUrl: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=600&auto=format&fit=crop&q=80',
    description: 'Pure, chilled raw cow milk from Friesian cows in Nyagatare dairy belt.',
    verifiedGrade: 'Grade A1',
    status: 'available'
  },
  {
    id: 'market_4',
    sellerId: 'user_3',
    sellerName: 'Abahizi Kinigi Potato Cooperative',
    sellerRole: 'cooperative',
    sellerPhone: '+250 788 998 877',
    district: 'Musanze',
    title: 'Consolidated Bulk Maize Harvest (Season A)',
    category: 'Produce',
    quantity: 45,
    unit: 'Tons',
    pricePerUnitRwf: 280,
    imageUrl: 'https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=600&auto=format&fit=crop&q=80',
    description: 'Aflatoxin-tested, moisture-controlled grain corn suitable for commercial milling.',
    verifiedGrade: 'Grade A1',
    status: 'available'
  }
];

export const INITIAL_EXPERTS: ExpertConsultant[] = [
  {
    id: 'exp_1',
    name: 'Dr. Emmanuel Mukamana',
    role: 'Agronomist',
    organization: 'Rwanda Agricultural Board (RAB)',
    district: 'Musanze',
    rating: 4.9,
    reviewsCount: 84,
    consultationFeeRwf: 5000,
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
    phone: '+250 788 123 456',
    specialization: ['Irish Potato Blight', 'Maize Armyworm', 'Soil Acid Mitigation'],
    availableDays: ['Mon', 'Wed', 'Fri', 'Sat']
  },
  {
    id: 'exp_2',
    name: 'Dr. Chantal Ingabire',
    role: 'Veterinarian',
    organization: 'Eastern Province Animal Health Services',
    district: 'Nyagatare',
    rating: 4.8,
    reviewsCount: 62,
    consultationFeeRwf: 6000,
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&auto=format&fit=crop&q=80',
    phone: '+250 788 654 321',
    specialization: ['Dairy Cattle Diseases', 'Mastitis Prevention', 'Vaccination Plans'],
    availableDays: ['Tue', 'Thu', 'Sat']
  }
];

export const INITIAL_WEATHER: WeatherData = {
  district: 'Musanze',
  temperatureC: 22,
  humidityPct: 78,
  rainfallProbabilityPct: 65,
  windSpeedKmh: 12,
  condition: 'Scattered Showers',
  alert: 'Heavy rain expected on Northern Ridge on Thursday afternoon. Protect terraced slopes.',
  farmingAdvice: 'Ideal humidity for potato tuber growth. Spray protective fungicide against late blight before rain.',
  forecast7Days: [
    { day: 'Today', tempHighC: 23, tempLowC: 15, rainPct: 65, condition: 'Scattered Showers' },
    { day: 'Tomorrow', tempHighC: 22, tempLowC: 14, rainPct: 70, condition: 'Heavy Rain' },
    { day: 'Wed', tempHighC: 24, tempLowC: 15, rainPct: 30, condition: 'Partly Cloudy' },
    { day: 'Thu', tempHighC: 25, tempLowC: 16, rainPct: 20, condition: 'Sunny' },
    { day: 'Fri', tempHighC: 23, tempLowC: 15, rainPct: 45, condition: 'Light Rain' },
    { day: 'Sat', tempHighC: 24, tempLowC: 14, rainPct: 25, condition: 'Sunny' },
    { day: 'Sun', tempHighC: 25, tempLowC: 15, rainPct: 10, condition: 'Clear Sky' }
  ]
};

export const INITIAL_POSTS: CommunityPost[] = [
  {
    id: 'post_1',
    authorId: 'user_1',
    authorName: 'Jean de Dieu Nshimiyimana',
    authorRole: 'farmer',
    authorDistrict: 'Musanze',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    title: 'Inyungu zo gukoresha fumbire y\'imborera hamwe na NPK mu birayi',
    content: 'Mwaramutse bahinzi bagenzi banjye! Mu gihe gishize nakoresheje ifumbire y\'imborera iboleye neza maze nyongeraho NPK 17-17-17. Umusaruro wazamutse ku kigero cyo hejuru ya 30%. Ni inde ufite uburambe kuri iri vanga?',
    category: 'Fertilizers & Soil',
    likes: 34,
    commentsCount: 12,
    createdAt: '2 hours ago',
    isSolved: true,
    verifiedExpertAnswer: 'Dr. Emmanuel Mukamana: Ivanga rya NPK n\'imborera ryongeera ubushobozi bw\'ubutaka bwo kubika amazi no kongera umusaruro kikagabanya aside mu butaka.'
  },
  {
    id: 'post_2',
    authorId: 'user_2',
    authorName: 'Marie Claire Uwase',
    authorRole: 'livestock',
    authorDistrict: 'Nyagatare',
    authorAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    title: 'How to maintain high milk yield during dry spell in Eastern Province?',
    content: 'Hello livestock owners in Nyagatare & Gatsibo! What fodder storage methods (silage/hay) do you recommend before the dry season hits?',
    category: 'Livestock Care',
    likes: 21,
    commentsCount: 8,
    createdAt: '1 day ago',
    isSolved: false
  }
];

export const INITIAL_COURSES: Course[] = [
  {
    id: 'course_1',
    title: {
      rw: 'Ubworozi Bwijejwe bw\'Inka z\'Amata mu Rwanda',
      en: 'Modern Dairy Cattle Management in Rwanda',
      fr: 'Gestion Moderne de l\'Élevage Laitier au Rwanda'
    },
    category: 'Livestock',
    durationMinutes: 45,
    instructor: 'RAB Livestock Experts',
    thumbnailUrl: 'https://images.unsplash.com/photo-1527153857715-3908f2bae5e8?w=600&auto=format&fit=crop&q=80',
    description: {
      rw: 'Iga uburyo bwo kugaburira inka z\'amata, gukama mu buryo bw\'isuku, no kurinda indwara z\'amabele (Mastitis).',
      en: 'Learn best practices in dairy cattle nutrition, hygienic milking techniques, and mastitis prevention.',
      fr: 'Apprenez les meilleures pratiques de nutrition des vaches laitières, de traite hygiénique et de prévention de la mastite.'
    },
    enrolledStudents: 1240,
    rating: 4.9
  },
  {
    id: 'course_2',
    title: {
      rw: 'Guhiga n\'Guhina Ibirayi mu Turee tw\'Ikirunga',
      en: 'High-Yield Potato Farming in Volcanic Soil',
      fr: 'Culture de la Pomme de Terre à Haut Rendement'
    },
    category: 'Crops',
    durationMinutes: 60,
    instructor: 'Dr. Emmanuel Mukamana',
    thumbnailUrl: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=600&auto=format&fit=crop&q=80',
    description: {
      rw: 'Inzira yose ku kuva ku guhitamo imbuto y\'ikirayi (Kinigi, Rwayingabo) kugeza ku sarura no gukora ububiko.',
      en: 'Complete guide from certified seed selection (Kinigi, Rwayingabo) to harvesting and dark storage setup.',
      fr: 'Guide complet de la sélection de semences certifiées au stockage et à la récolte.'
    },
    enrolledStudents: 2150,
    rating: 4.95
  }
];

export const MOCK_USERS = INITIAL_USERS;

// ==========================================
// FARMER CORE PLATFORM INITIAL MOCK DATA
// ==========================================

export const INITIAL_FARMER_PROFILE = {
  id: 'profile_user_1',
  userId: 'user_1',
  fullName: 'Jean de Dieu Nshimiyimana',
  photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
  phone: '+250 788 345 678',
  email: 'jeandedieu@agriwise.rw',
  district: 'Musanze',
  sector: 'Kinigi',
  cell: 'Kampanga',
  village: 'Bishoke',
  preferredLanguage: 'rw' as const,
  farmingExperienceYears: 12,
  mainActivities: ['Crop Farming', 'Livestock Raising', 'Horticulture'] as ('Crop Farming' | 'Livestock Raising' | 'Agro-Forestry' | 'Horticulture' | 'Aquaculture')[],
  totalFarmAreaHectares: 2.5,
  mainCrops: ['Irish Potatoes (Kinigi)', 'Maize (H513)', 'Pyrethrum'],
  livestockTypes: ['Friesian Cattle', 'Goats'],
  farmingGoals: 'Expand organic Irish Potato exports to EAC markets and adopt solar micro-irrigation.',
  cooperativeMembership: 'Abahizi Kinigi Potato Farmers Cooperative',
  nationalIdNumber: '1 1988 8 0034125 1 23'
};

export const INITIAL_REGISTERED_FARMS = [
  {
    id: 'farm_1',
    farmerId: 'user_1',
    farmName: 'Kinigi Volcanic Ridge Plot #1',
    district: 'Musanze',
    sector: 'Kinigi',
    cell: 'Kampanga',
    sizeHectares: 1.8,
    gpsCoordinates: [
      { lat: -1.432, lng: 29.589 },
      { lat: -1.435, lng: 29.593 },
      { lat: -1.439, lng: 29.588 },
      { lat: -1.433, lng: 29.584 }
    ],
    landOwnershipType: 'Owned (Title Deed)' as const,
    soilType: 'Volcanic (Rich Organic)' as const,
    waterSource: 'Rainfed' as const,
    farmingMethod: 'Organic Certified' as const,
    photoUrls: ['https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&auto=format&fit=crop&q=80'],
    createdAt: '2024-02-10',
    healthScore: 88
  },
  {
    id: 'farm_2',
    farmerId: 'user_1',
    farmName: 'Nyange Terrace & Livestock Pad',
    district: 'Musanze',
    sector: 'Nyange',
    cell: 'Ninda',
    sizeHectares: 0.7,
    gpsCoordinates: [
      { lat: -1.451, lng: 29.610 },
      { lat: -1.454, lng: 29.614 },
      { lat: -1.458, lng: 29.608 }
    ],
    landOwnershipType: 'Owned (Title Deed)' as const,
    soilType: 'Volcanic (Rich Organic)' as const,
    waterSource: 'Solar Drip Irrigation' as const,
    farmingMethod: 'Integrated / Mixed' as const,
    photoUrls: ['https://images.unsplash.com/photo-1500595046743-cd271d694d30?w=600&auto=format&fit=crop&q=80'],
    createdAt: '2024-05-18',
    healthScore: 84
  }
];

export const INITIAL_FARM_ACTIVITIES = [
  {
    id: 'act_1',
    farmId: 'farm_1',
    farmName: 'Kinigi Volcanic Ridge Plot #1',
    activityType: 'Spraying' as const,
    title: 'Fungicide Preventive Spray for Late Blight',
    description: 'Applied Mancozeb 80% WP early morning to protect potato leaves against humidity moisture.',
    date: '2026-08-04',
    status: 'completed' as const,
    cropOrAnimalTarget: 'Irish Potatoes (Kinigi)',
    inputUsed: 'Mancozeb 80% WP',
    inputQuantity: '2.5 Kg',
    assignedLaborers: 2,
    costRwf: 18000
  },
  {
    id: 'act_2',
    farmId: 'farm_1',
    farmName: 'Kinigi Volcanic Ridge Plot #1',
    activityType: 'Fertilizing' as const,
    title: 'Top-dressing NPK 17-17-17 Application',
    description: 'Apply granular NPK along potato hills before expected afternoon showers.',
    date: '2026-08-06',
    status: 'pending' as const,
    cropOrAnimalTarget: 'Irish Potatoes (Kinigi)',
    inputUsed: 'NPK 17-17-17',
    inputQuantity: '50 Kg',
    assignedLaborers: 3,
    costRwf: 42000
  },
  {
    id: 'act_3',
    farmId: 'farm_2',
    farmName: 'Nyange Terrace & Livestock Pad',
    activityType: 'Animal Vaccination' as const,
    title: 'FMD & Brucellosis Cattle Booster',
    description: 'Routine veterinary booster dose administered by RAB extension officer.',
    date: '2026-08-02',
    status: 'completed' as const,
    cropOrAnimalTarget: 'Friesian Dairy Cow #RW-882',
    inputUsed: 'RAB FMD Vaccine',
    inputQuantity: '1 Vial',
    assignedLaborers: 1,
    costRwf: 5000
  }
];

export const INITIAL_FARM_DOCUMENTS = [
  {
    id: 'doc_1',
    farmId: 'farm_1',
    title: 'Official Land Certificate (UPI 1/02/08/04/123)',
    category: 'Land Title' as const,
    uploadDate: '2024-02-11',
    fileUrl: '#',
    fileType: 'pdf' as const,
    fileSizeMb: 2.4,
    verificationStatus: 'Verified by RAB' as const
  },
  {
    id: 'doc_2',
    farmId: 'farm_1',
    title: 'Rwanda Agriculture Board Organic Crop Certificate',
    category: 'Organic Certificate' as const,
    uploadDate: '2024-06-15',
    fileUrl: '#',
    fileType: 'pdf' as const,
    fileSizeMb: 1.8,
    verificationStatus: 'Verified by RAB' as const
  },
  {
    id: 'doc_3',
    farmId: 'farm_2',
    title: 'Volcanic Soil pH & Mineral Analysis Report',
    category: 'Soil Test Report' as const,
    uploadDate: '2025-01-20',
    fileUrl: '#',
    fileType: 'pdf' as const,
    fileSizeMb: 3.1,
    verificationStatus: 'Self Uploaded' as const
  }
];

export const INITIAL_FARM_HEALTH_SCORE = {
  overallScore: 86,
  cropVitalityScore: 90,
  soilHealthScore: 88,
  livestockCareScore: 84,
  activityComplianceScore: 85,
  documentCompletenessScore: 82,
  strengths: [
    {
      rw: 'Ubutaka burimo urugero ruhanitse rw\'ifumbire y\'icyatsi (Organic Volcanic Soil).',
      en: 'High soil organic carbon content in Musanze volcanic belt.',
      fr: 'Haute teneur en carbone organique dans le sol volcanique.'
    },
    {
      rw: 'Umutekano n\'urukingo rwo kurinda indwara z\'amfoto (FMD) rugenzurwa neza.',
      en: 'Up-to-date cattle vaccination records verified by RAB extension team.',
      fr: 'Dossier de vaccination du bétail à jour et vérifié.'
    }
  ],
  recommendations: [
    {
      rw: 'Shyiraho ifumbire ya Urea mu cyumweru gikurikira mbere y\'isaruza.',
      en: 'Schedule top-dressing Urea fertilizer before crop flowering stage.',
      fr: 'Planifier l\'engrais Urea avant la floraison.'
    },
    {
      rw: 'Shyira mucyo icyemezo cy\'ubutaka cya Plot #2 (Nyange Terrace).',
      en: 'Upload official UPI land deed for Nyange Terrace to reach 95% Health Score.',
      fr: 'Télécharger le titre foncier officiel pour le terrain de Nyange.'
    }
  ]
};

