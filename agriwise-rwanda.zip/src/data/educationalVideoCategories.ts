export interface VideoCategoryConfig {
  id: string;
  name: string;
  nameRw: string;
  nameFr: string;
  description: string;
  iconName: string;
  topics: string[];
}

export const AGRICULTURAL_VIDEO_CATEGORIES: VideoCategoryConfig[] = [
  {
    id: 'crop_production',
    name: 'Crop Production',
    nameRw: 'Ihingwa ry\'Ibihingwa',
    nameFr: 'Production Végétale',
    description: 'Best practices for planting, weeding, spacing, and optimizing yields.',
    iconName: 'Sprout',
    topics: [
      'Land Preparation & Planting Techniques',
      'Seed Selection & Spacing',
      'Crop Rotation & Intercropping',
      'Yield Maximization Strategies',
      'Seasonal Calendar & Planting Timing'
    ]
  },
  {
    id: 'livestock_farming',
    name: 'Livestock Farming',
    nameRw: 'Ubworozi bw\'Amatungo',
    nameFr: 'Élevage du Bétail',
    description: 'Dairy cattle, goats, pigs, sheep husbandry and veterinary care.',
    iconName: 'Tractor',
    topics: [
      'Dairy Cattle Management & Girinka Program',
      'Animal Housing & Hygiene',
      'Fodder Cultivation & Silage Preparation',
      'Artificial Insemination (AI) & Breeding',
      'Preventative Vaccination & Veterinary Care'
    ]
  },
  {
    id: 'poultry',
    name: 'Poultry',
    nameRw: 'Ubworozi bw\'Inkoko',
    nameFr: 'Aviculture / Volaille',
    description: 'Broiler and layer management, bio-security, brooding and feeds.',
    iconName: 'Egg',
    topics: [
      'Brooding & Chick Care',
      'Layer Management & Egg Production',
      'Broiler Feeding & Weight Optimization',
      'Poultry Housing & Bio-security',
      'Newcastle & Gumboro Disease Prevention'
    ]
  },
  {
    id: 'agribusiness',
    name: 'Agribusiness',
    nameRw: 'Ubucuruzi bw\'Ubuhinzi',
    nameFr: 'Agrobusiness',
    description: 'Value chains, enterprise budgeting, contract farming and aggregation.',
    iconName: 'Briefcase',
    topics: [
      'Agribusiness Business Planning',
      'Contract Farming & Off-taker Agreements',
      'Bulk Aggregation & Value Chain Integration',
      'Agricultural Export Readiness (NAEB Compliance)',
      'Enterprise Cost-Benefit Analysis'
    ]
  },
  {
    id: 'farm_management',
    name: 'Farm Management',
    nameRw: 'Gucunga Umushinga w\'Ubuhinzi',
    nameFr: 'Gestion de la Ferme',
    description: 'Labor planning, farm record-keeping, and operational efficiency.',
    iconName: 'ClipboardList',
    topics: [
      'Digital Farm Record Keeping',
      'Seasonal Farm Budgeting & Cash Flow',
      'Farm Labor Organization & Productivity',
      'Farm Equipment Maintenance',
      'Risk Management & Emergency Planning'
    ]
  },
  {
    id: 'soil_health',
    name: 'Soil Health',
    nameRw: 'Ubuzima bw\'Ubutaka',
    nameFr: 'Santé des Sols',
    description: 'Soil pH testing, erosion control, liming, and organic matter enrichment.',
    iconName: 'Layers',
    topics: [
      'Soil Sampling & pH Testing',
      'Radical Terracing & Erosion Control',
      'Agricultural Lime Application',
      'Composting & Green Manuring',
      'Conservation Tillage Techniques'
    ]
  },
  {
    id: 'fertilizer_management',
    name: 'Fertilizer Management',
    nameRw: 'Gukoresha Ifumbire',
    nameFr: 'Gestion des Engrais',
    description: 'Smart Nkunganire subsidies, NPK, DAP, Urea, and organic combinations.',
    iconName: 'FlaskConical',
    topics: [
      'Smart Nkunganire (SNS) Fertilizer Protocols',
      'NPK Basal & Top-dressing Schedules',
      'Organic & Inorganic Fertilizer Combinations',
      'Micro-dosing Techniques for Smallholders',
      'Foliar Feeding & Micronutrient Sprays'
    ]
  },
  {
    id: 'pest_disease_management',
    name: 'Pest & Disease Management',
    nameRw: 'Kwirinda & Kurwanya Indwara n\'Ibyonnyi',
    nameFr: 'Gestion des Ravageurs et Maladies',
    description: 'Fall Armyworm, Cassava Mosaic, Coffee Borer, and IPM bio-controls.',
    iconName: 'ShieldAlert',
    topics: [
      'Fall Armyworm Early Scouting & Bio-pesticides',
      'Potato Late Blight & Fungicide Timing',
      'Coffee Berry Borer & Antestia Bug Management',
      'Cassava Brown Streak & Mosaic Disease Control',
      'Integrated Pest Management (IPM) Protocols'
    ]
  },
  {
    id: 'irrigation',
    name: 'Irrigation',
    nameRw: 'Kuhira Imyaka',
    nameFr: 'Irrigation',
    description: 'Solar-powered pumps, drip systems, hillside rainwater harvesting.',
    iconName: 'Droplets',
    topics: [
      'Solar-Powered Drip Irrigation Installation',
      'Hillside Rainwater Harvesting Reservoirs',
      'Small-Scale Irrigation Technology (SSIT) Subsidies',
      'Water Scheduling & Soil Moisture Monitoring',
      'Furrow & Sprinkler Maintenance'
    ]
  },
  {
    id: 'climate_smart_agriculture',
    name: 'Climate-Smart Agriculture',
    nameRw: 'Ubuhinzi Buhangana n\'Imihindagurikire y\'Ikirere',
    nameFr: 'Agriculture Intelligente face au Climat',
    description: 'Drought-resistant seeds, agroforestry, weather indices and resilience.',
    iconName: 'Sun',
    topics: [
      'Agroforestry with Calliandra & Grevillea',
      'Drought-Tolerant Seed Varieties',
      'Mulching for Moisture Retention',
      'Meteo Rwanda Weather Forecast Application',
      'Carbon Credit & Regenerative Farming'
    ]
  },
  {
    id: 'post_harvest_handling',
    name: 'Post-Harvest Handling',
    nameRw: 'Gusarura & Kubika Umusaruro Neza',
    nameFr: 'Gestion Post-Récolte',
    description: 'Grain drying, hermetic storage bags (PICS), grading and aflatoxin prevention.',
    iconName: 'PackageCheck',
    topics: [
      'Proper Grain Moisture Testing & Solar Dryers',
      'Hermetic Storage Bags (PICS Bags) Usage',
      'Aflatoxin Prevention & Detection',
      'Horticultural Cold Chain & Crates Packaging',
      'Warehouse Receipt System Standards'
    ]
  },
  {
    id: 'market_pricing',
    name: 'Market & Pricing',
    nameRw: 'Isoko ry\'Ibihingwa & Ibiciro',
    nameFr: 'Marché et Prix',
    description: 'e-Soko price tracking, negotiation with wholesale off-takers, and logistics.',
    iconName: 'TrendingUp',
    topics: [
      'MINAGRI e-Soko Daily Market Price Tracking',
      'Wholesale Off-taker Quality Grading & Standards',
      'Collective Marketing via Cooperatives',
      'Cross-Border Trade with EAC Markets',
      'Supply & Demand Seasonality Forecasting'
    ]
  },
  {
    id: 'financial_literacy',
    name: 'Financial Literacy',
    nameRw: 'Ubumenyi mu By\'Imari',
    nameFr: 'Éducation Financière',
    description: 'Savings groups (VSLA), AgriCredit scoring, MoMo escrow and bank loans.',
    iconName: 'Coins',
    topics: [
      'VSLA & Village Savings Group Management',
      'BRD & Commercial Bank Agricultural Loans',
      'Mobile Money Escrow (MoMo Lockbox) Security',
      'Crop & Livestock Insurance (NAIS Subsidy)',
      'Building Digital Credit Profile (AgriCredit)'
    ]
  },
  {
    id: 'agricultural_technology',
    name: 'Agricultural Technology',
    nameRw: 'Ikoranabuhanga mu Buhinzi',
    nameFr: 'Technologie Agricole',
    description: 'AI crop diagnosis, IoT soil moisture sensors, satellite mapping & drones.',
    iconName: 'Cpu',
    topics: [
      'Using AI Disease Detector on Smartphone',
      'IoT Sensor Deployment & Real-time Telemetry',
      'Satellite NDVI Crop Health Interpretation',
      'Agricultural Drone Spraying & Mapping',
      'USSD & Voice Advisory System (803#)'
    ]
  },
  {
    id: 'cooperatives',
    name: 'Cooperatives',
    nameRw: 'Amakoperative y\'Abahinzi',
    nameFr: 'Coopératives Agricoles',
    description: 'RCA governance, dividend distribution, bulk purchasing and audits.',
    iconName: 'Building2',
    topics: [
      'RCA Regulatory Compliance & Governance',
      'Bulk Input Purchasing & Volume Discounts',
      'Fair Member Dividend & Payout Calculation',
      'Cooperative Accounting & Audit Preparation',
      'Youth & Women Leadership in Cooperatives'
    ]
  },
  {
    id: 'food_safety',
    name: 'Food Safety',
    nameRw: 'Umutekano w\'Ibiribwa',
    nameFr: 'Sécurité Sanitaire des Aliments',
    description: 'Pesticide withdrawal periods, FDA certifications, post-harvest sanitation.',
    iconName: 'ShieldCheck',
    topics: [
      'Pesticide Maximum Residue Limits (MRL) & Pre-Harvest Intervals (PHI)',
      'Safe Chemical Spraying & PPE Safety',
      'Post-Harvest Hygiene & Sanitized Washing',
      'Rwanda FDA Certification Requirements',
      'Traceability from Farm Gate to Consumer'
    ]
  }
];

export const TARGET_AUDIENCE_OPTIONS = [
  'Farmers (Abahinzi)',
  'Livestock Keepers (Aborozi)',
  'Poultry Farmers (Aborozi b\'Inkoko)',
  'Agro-dealers (Abadandaza)',
  'Cooperatives (Amakoperative)',
  'Youth & Agri-entrepreneurs (Urubyiruko)',
  'Agronomists & Extension Officers',
  'All Stakeholders (Bose Hamwe)'
];

export const RWANDAN_CROPS_OPTIONS = [
  'Maize (Ibigori)',
  'Irish Potato (Ibirayi)',
  'Beans (Ibishyimbo)',
  'Coffee (Ikawa)',
  'Tea (Icyayi)',
  'Rice (Umuceri)',
  'Cassava (Imyumbati)',
  'Banana (Ibitoki)',
  'Soybean (Soya)',
  'Vegetables & Horticulture (Imboga)',
  'Wheat (Ingano)',
  'Pyrethrum (Iparetre)',
  'Fruits / Avocado (Imbuto / Avoka)'
];

export const RWANDAN_LIVESTOCK_OPTIONS = [
  'Dairy Cattle (Inka z\'Amata)',
  'Beef Cattle (Inka z\'Inyama)',
  'Poultry / Broilers / Layers (Inkoko)',
  'Pigs (Ingurube)',
  'Goats (Ihene)',
  'Sheep (Intama)',
  'Rabbits (Inkwavu)',
  'Fish / Aquaculture (Amafi)',
  'Bees / Apiculture (Inzuki)'
];

export const RWANDAN_DISTRICTS_OPTIONS = [
  'All Rwanda (Igihugu Cyose)',
  'Musanze (Northern)',
  'Nyagatare (Eastern)',
  'Gicumbi (Northern)',
  'Bugesera (Eastern)',
  'Huye (Southern)',
  'Rubavu (Western)',
  'Rwamagana (Eastern)',
  'Kayonza (Eastern)',
  'Kirehe (Eastern)',
  'Gatsibo (Eastern)',
  'Gasabo (Kigali)',
  'Kicukiro (Kigali)',
  'Nyarugenge (Kigali)',
  'Kamonyi (Southern)',
  'Muhanga (Southern)',
  'Ruhango (Southern)',
  'Nyanza (Southern)',
  'Gisagara (Southern)',
  'Nyamagabe (Southern)',
  'Nyaruguru (Southern)',
  'Rulindo (Northern)',
  'Burera (Northern)',
  'Karongi (Western)',
  'Rutsiro (Western)',
  'Ngororero (Western)',
  'Nyabihu (Western)',
  'Nyamasheke (Western)',
  'Rusizi (Western)'
];
