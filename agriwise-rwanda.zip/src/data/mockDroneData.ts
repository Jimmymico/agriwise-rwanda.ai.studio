import {
  DroneOperator,
  DroneHardware,
  DroneFlightRequest,
  DroneAerialInspectionReport,
  PrecisionSprayingPrescription,
  TriDataFusionMatrix
} from '../types';

export const MOCK_DRONE_OPERATORS: DroneOperator[] = [
  {
    id: 'op-01',
    operatorName: 'Jean-Luc Nshimiyimana',
    companyName: 'AgriFly Precision Drone Services Rwanda',
    rcaaLicenseNumber: 'RCAA-UAS-2025-084',
    certificationStatus: 'RCAA Certified',
    phoneContact: '+250 788 123 456',
    districtBase: 'Musanze District (Northern Province)',
    ratingScore: 4.95,
    completedFlightsCount: 342,
    fleetSizeCount: 4,
    hourlyServiceRateRwf: 25000
  },
  {
    id: 'op-02',
    operatorName: 'Aline Umutoni',
    companyName: 'Charis Aerial Agricultural Analytics Ltd',
    rcaaLicenseNumber: 'RCAA-UAS-2024-012',
    certificationStatus: 'RCAA Certified',
    phoneContact: '+250 785 987 654',
    districtBase: 'Nyagatare District (Eastern Province)',
    ratingScore: 4.88,
    completedFlightsCount: 512,
    fleetSizeCount: 8,
    hourlyServiceRateRwf: 30000
  },
  {
    id: 'op-03',
    operatorName: 'Pascal Habimana',
    companyName: 'Kivu Agro-Drones Cooperative',
    rcaaLicenseNumber: 'RCAA-UAS-2025-119',
    certificationStatus: 'RAB Approved',
    phoneContact: '+250 783 456 789',
    districtBase: 'Rubavu District (Western Province)',
    ratingScore: 4.75,
    completedFlightsCount: 180,
    fleetSizeCount: 3,
    hourlyServiceRateRwf: 22000
  }
];

export const MOCK_DRONES: DroneHardware[] = [
  {
    id: 'drn-101',
    operatorId: 'op-01',
    modelName: 'DJI Agras T40 Heavy Sprayer',
    droneType: 'Quadcopter Sprayer',
    payloadSensors: ['40L Ultra-Low Volume Centrifugal Spray Tank', 'Dual Radar Obstacle Avoidance', '4K RGB Camera'],
    maxFlightTimeMins: 22,
    maxAreaPerFlightHa: 16.0,
    batteryStatusPct: 94,
    rcaaRegistrationNumber: '9O-AGR-401',
    isAvailable: true
  },
  {
    id: 'drn-102',
    operatorId: 'op-01',
    modelName: 'DJI Mavic 3 Multispectral (M3M)',
    droneType: 'Multispectral Scout',
    payloadSensors: ['4-Band Multispectral (G/R/RE/NIR)', '20MP RGB Survey Camera', 'Sunlight Irradiance Sensor'],
    maxFlightTimeMins: 43,
    maxAreaPerFlightHa: 30.0,
    batteryStatusPct: 88,
    rcaaRegistrationNumber: '9O-AGR-302',
    isAvailable: true
  },
  {
    id: 'drn-103',
    operatorId: 'op-02',
    modelName: 'WingtraOne GEN II VTOL Fixed-Wing',
    droneType: 'Fixed-Wing VTOL Mapper',
    payloadSensors: ['42MP Full-Frame Sony Mapping Camera', 'MicaSense RedEdge-P 5-Band'],
    maxFlightTimeMins: 59,
    maxAreaPerFlightHa: 110.0,
    batteryStatusPct: 100,
    rcaaRegistrationNumber: '9O-AGR-509',
    isAvailable: true
  }
];

export const MOCK_FLIGHT_REQUESTS: DroneFlightRequest[] = [
  {
    id: 'flt-801',
    farmerName: 'Jean-Baptiste Hakizimana',
    farmName: 'Hakizimana Maize & Bean Plot A',
    district: 'Nyagatare District',
    farmAreaHa: 2.5,
    serviceRequested: 'Multispectral Crop Health Scan (NDVI/RE)',
    scheduledDate: 'Tomorrow at 08:30 AM',
    offeredFeeRwf: 35000,
    status: 'Weather Approved',
    assignedOperatorName: 'Jean-Luc Nshimiyimana',
    assignedDroneModel: 'DJI Mavic 3 Multispectral',
    flightBoundaryCoordinates: 'POLYGON((30.321 1.304, 30.325 1.304, 30.325 1.308, 30.321 1.308))'
  },
  {
    id: 'flt-802',
    farmerName: 'Musanze Kinigi Seed Potato Cooperative',
    farmName: 'Kinigi High-Altitude Seed Plot 3',
    district: 'Musanze District',
    farmAreaHa: 12.0,
    serviceRequested: 'Targeted Precision Bio-Spraying',
    scheduledDate: '2 Days Ago',
    offeredFeeRwf: 120000,
    status: 'Completed',
    assignedOperatorName: 'Aline Umutoni',
    assignedDroneModel: 'DJI Agras T40 Heavy Sprayer',
    flightBoundaryCoordinates: 'POLYGON((29.541 1.489, 29.549 1.489, 29.549 1.498, 29.541 1.498))'
  },
  {
    id: 'flt-803',
    farmerName: 'Gisagara Rice Farmers Association',
    farmName: 'Gisagara Marshland Rice Zone B',
    district: 'Gisagara District',
    farmAreaHa: 45.0,
    serviceRequested: 'Plant Stand Density & Counting',
    scheduledDate: 'In 3 Days',
    offeredFeeRwf: 220000,
    status: 'Planned',
    assignedOperatorName: 'Pascal Habimana',
    assignedDroneModel: 'WingtraOne GEN II VTOL',
    flightBoundaryCoordinates: 'POLYGON((29.832 2.611, 29.845 2.611, 29.845 2.625, 29.832 2.625))'
  }
];

export const MOCK_AERIAL_INSPECTION_REPORT: DroneAerialInspectionReport = {
  id: 'rpt-901',
  flightRequestId: 'flt-801',
  farmName: 'Hakizimana Maize & Bean Plot A',
  flightDate: 'Today (0.8cm/pixel RGB + 5-Band RE)',
  averageNdviScore: 0.74,
  plantStandCountEstimated: 142500,
  emergedPlantsCountExpected: 150000,
  emergentRatePct: 95.0,
  detectedStressZonesCount: 2,
  pestDiseaseRiskLevel: 'Moderate',
  weedInfestationRatePct: 4.2,
  orthomosaicMapUrl: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=1200&auto=format&fit=crop',
  aiDiagnosticSummary: 'High-resolution 0.8 cm/pixel aerial orthomosaic shows robust canopy vigor (NDVI 0.74) across 88% of the plot. Sub-centimeter camera identified 2 distinct water-stress pockets in Quadrant B caused by delayed drip irrigation line pressure.',
  recommendedPrescription: 'Apply 1,200 Liters/Ha targeted drip irrigation to Quadrant B and deploy 15L/Ha organic neem foliar spray along the eastern perimeter to control early fall armyworm egg masses.'
};

export const MOCK_SPRAYING_PRESCRIPTION: PrecisionSprayingPrescription = {
  id: 'psp-301',
  farmName: 'Kinigi High-Altitude Seed Plot 3',
  targetZoneName: 'Zone C (Potato Late Blight Perimeter Buffer)',
  areaHa: 4.5,
  chemicalOrBioInput: 'RAB Certified Copper Hydroxide Organic Bio-Fungicide + Liquid Zinc Chelate',
  dosagePerHaLiters: 12.5,
  totalLiquidVolumeLiters: 56.25,
  droneFlightAltitudeMeters: 3.5,
  swathWidthMeters: 6.5,
  nozzleFlowRateLmin: 4.2,
  environmentalSafetyStatus: 'Safe Wind (<12km/h) & 50m Water Buffer Compliant'
};

export const MOCK_TRI_DATA_FUSION: TriDataFusionMatrix = {
  farmName: 'Hakizimana Maize & Bean Plot A',
  satelliteData: {
    sensor: 'Sentinel-2 Optical (10m Resolution)',
    ndviVigor: 0.68,
    droughtIndex: 'Mild Canopy Moisture Deficit'
  },
  droneData: {
    resolutionCmPixel: 0.8,
    plantHealthScore: 0.74,
    diseaseHotspotFound: true
  },
  iotSensorData: {
    soilMoisturePct: 32,
    soilTempC: 24.5,
    phLevel: 6.4
  },
  unifiedAiRecommendation: 'TRIPLE-VERIFIED SYNTHESIS: Satellite flags macro vegetation dip in Plot A -> Drone sub-cm scan pinpointed exact 0.4 Ha fall armyworm egg cluster in East Quadrant -> LoRaWAN soil probe confirms 32% moisture. ACTION: Trigger Valve #2 drip for 45 mins & schedule DJI Agras T40 bio-pesticide spray at 18:00.'
};
