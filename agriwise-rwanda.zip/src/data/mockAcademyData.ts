import {
  AcademyCourse,
  FarmerCertificate,
  FarmerGamificationProfile,
  GovernmentTrainingProgram,
  CommunityDiscussionPost
} from '../types';

export const MOCK_ACADEMY_COURSES: AcademyCourse[] = [
  {
    id: 'crs-101',
    title: 'Modern Maize Cultivation & Fall Armyworm Pest Management',
    category: 'Crop Production',
    instructorName: 'Dr. Agnes Mukamana',
    instructorTitle: 'Senior Maize Agronomist, RAB Musanze',
    difficulty: 'Beginner',
    totalDurationHours: 3.5,
    totalLessonsCount: 4,
    ratingScore: 4.92,
    enrolledStudentsCount: 1420,
    thumbnailUrl: 'https://images.unsplash.com/photo-1551754655-cd27e38d2076?q=80&w=800&auto=format&fit=crop',
    description: 'Master high-yield hybrid seed planting, optimal NPK micro-dosing, soil ph testing, and biological neem pest management approved by MINAGRI.',
    skillsLearned: ['Hybrid Maize Spacing', 'NPK Micro-Dosing', 'Fall Armyworm Scouting', 'Post-Harvest Drying'],
    isRabCertified: true,
    lessons: [
      {
        id: 'lsn-101',
        courseId: 'crs-101',
        lessonTitle: 'Soil Preparation & Certified Hybrid Seed Selection',
        durationMins: 25,
        videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
        summaryText: 'Learn to measure soil pH and plant certified RAB-selected hybrid seed (RHM 104) with exact 75cm x 25cm row spacing.',
        isCompleted: true,
        quiz: {
          id: 'qz-101',
          questionText: 'What is the recommended row spacing for hybrid maize (RHM 104) in Rwanda?',
          options: ['50cm x 10cm', '75cm x 25cm', '100cm x 50cm', '30cm x 30cm'],
          correctAnswerIndex: 1,
          explanation: '75cm between rows and 25cm between seeds yields optimal 53,333 plant population per hectare.'
        }
      },
      {
        id: 'lsn-102',
        courseId: 'crs-101',
        lessonTitle: 'Precision Organic Neem & Chemical Pest Control',
        durationMins: 35,
        videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
        summaryText: 'Scouting fall armyworm egg masses in leaf whorls and applying targeted bio-pesticide spray.',
        isCompleted: false,
        quiz: {
          id: 'qz-102',
          questionText: 'When is the most effective time to apply bio-pesticide for Fall Armyworm?',
          options: ['At noon during direct sun', 'Early morning or late afternoon', 'During heavy rainfall', 'After harvesting'],
          correctAnswerIndex: 1,
          explanation: 'Early morning or late evening prevents solar breakdown of active bio-compounds and targets active larvae.'
        }
      }
    ]
  },
  {
    id: 'crs-102',
    title: 'Smart IoT Sensors & Drone Agriculture Masterclass',
    category: 'Smart Tech & Drones',
    instructorName: 'Eng. Eric Habimana',
    instructorTitle: 'UAS Aerial Specialist & Smart Agronomy Engineer',
    difficulty: 'Intermediate',
    totalDurationHours: 5.0,
    totalLessonsCount: 5,
    ratingScore: 4.88,
    enrolledStudentsCount: 890,
    thumbnailUrl: 'https://images.unsplash.com/photo-1508614589041-895b88991e3e?q=80&w=800&auto=format&fit=crop',
    description: 'Learn how to read multispectral NDVI aerial maps, configure LoRaWAN soil probes, and command automated solar drip solenoids.',
    skillsLearned: ['NDVI Vigor Analysis', 'LoRaWAN Probe Calibration', 'Precision Drone Spraying', 'Variable Rate Irrigation'],
    isRabCertified: true,
    lessons: [
      {
        id: 'lsn-201',
        courseId: 'crs-102',
        lessonTitle: 'Understanding 5-Band Multispectral NDVI & Red Edge Vigor',
        durationMins: 40,
        summaryText: 'Decode false-color infrared drone images to isolate plant chlorophyll absorption and water deficit stress.',
        isCompleted: false
      }
    ]
  },
  {
    id: 'crs-103',
    title: 'Financial Management, Agribusiness & MoMo Micro-Credit',
    category: 'Agribusiness & Finance',
    instructorName: 'Clarisse Uwineza',
    instructorTitle: 'Agri-Finance Specialist, BDF Rwanda',
    difficulty: 'Beginner',
    totalDurationHours: 2.5,
    totalLessonsCount: 3,
    ratingScore: 4.95,
    enrolledStudentsCount: 2150,
    thumbnailUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?q=80&w=800&auto=format&fit=crop',
    description: 'Build your farm budget, track seasonal inputs vs revenues, maximize AGRIWISE credit scores (0-100), and access NAIS 50% insurance subsidies.',
    skillsLearned: ['Farm Bookkeeping', 'AGRIWISE Credit Building', 'NAIS Insurance Claims', 'Cooperative Profit Sharing'],
    isRabCertified: true,
    lessons: [
      {
        id: 'lsn-301',
        courseId: 'crs-103',
        lessonTitle: 'Digital Record Keeping & Credit Rating Optimization',
        durationMins: 30,
        summaryText: 'Logging harvest sales on MoMo Pay to automatically raise your credit tier for pre-approved seeds & fertilizer loans.',
        isCompleted: true
      }
    ]
  }
];

export const MOCK_FARMER_CERTIFICATES: FarmerCertificate[] = [
  {
    id: 'crt-901',
    certificateNumber: 'RAB-CERT-2026-8942',
    farmerName: 'Jean-Baptiste Hakizimana',
    courseTitle: 'Modern Maize Cultivation & Fall Armyworm Pest Management',
    issueDate: '2026-02-14',
    verifiableQrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=RAB-CERT-2026-8942',
    rabSealApproved: true,
    skillBadgeTitle: 'Certified Modern Maize Specialist'
  },
  {
    id: 'crt-902',
    certificateNumber: 'MINAGRI-CERT-2025-4120',
    farmerName: 'Jean-Baptiste Hakizimana',
    courseTitle: 'Financial Management, Agribusiness & MoMo Micro-Credit',
    issueDate: '2025-11-20',
    verifiableQrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=MINAGRI-CERT-2025-4120',
    rabSealApproved: true,
    skillBadgeTitle: 'Certified Agribusiness Planner'
  }
];

export const MOCK_GAMIFICATION_PROFILE: FarmerGamificationProfile = {
  farmerName: 'Jean-Baptiste Hakizimana',
  totalLearningPoints: 1250,
  currentRankBadge: 'Master Agro-Innovator',
  coursesCompletedCount: 2,
  quizzesPassedCount: 6,
  districtRankPosition: 3,
  districtName: 'Nyagatare District',
  earnedBadges: [
    { title: 'Maize Master', icon: '🌽', dateEarned: '2026-02-14' },
    { title: 'Smart Irrigation Tech', icon: '💧', dateEarned: '2026-01-10' },
    { title: 'Agri-Credit Champion', icon: '🏆', dateEarned: '2025-11-20' },
    { title: 'Drone Data Pioneer', icon: '🛸', dateEarned: '2026-03-01' }
  ]
};

export const MOCK_GOVT_PROGRAMS: GovernmentTrainingProgram[] = [
  {
    id: 'gov-01',
    programTitle: 'National Youth in Agriculture Modernization Initiative (RYAF 2026)',
    sponsoringAgency: 'MINAGRI & RYAF Rwanda',
    targetAudience: 'Youth Farmers aged 18-35 across all 30 Districts',
    enrolledCount: 14500,
    completionRatePct: 88.5,
    startDate: '2026-01-15',
    endDate: '2026-06-30',
    status: 'In Progress'
  },
  {
    id: 'gov-02',
    programTitle: 'Smart Climate & Soil Health Cooperative Certification',
    sponsoringAgency: 'Rwanda Agriculture Board (RAB)',
    targetAudience: 'Cooperative Leaders & Extension Officers',
    enrolledCount: 3200,
    completionRatePct: 94.0,
    startDate: '2026-02-01',
    endDate: '2026-11-30',
    status: 'In Progress'
  }
];

export const MOCK_COMMUNITY_POSTS: CommunityDiscussionPost[] = [
  {
    id: 'post-101',
    authorName: 'Emmanuel Nsengiyumva',
    authorRole: 'Nyagatare Rice Farmers Coop President',
    postTitle: 'Best bio-pesticide timing for Stem Borer in marshland rice?',
    postContent: 'Greetings fellow farmers! In our marshland plot, we noticed early signs of stem borer. Has anyone tried mixing neem oil with liquid zinc foliar during early tillering?',
    likesCount: 24,
    commentsCount: 9,
    createdTime: '2 Hours Ago',
    topicTag: 'Pest Control'
  },
  {
    id: 'post-102',
    authorName: 'Marie-Rose Uwimana',
    authorRole: 'Musanze High-Altitude Seed Grower',
    postTitle: 'RAB Certified Potato Seed Germination Results',
    postContent: 'Completed the Potato Late Blight Prevention course on AGRIWISE Academy! Applying ridging at 20cm increased our seed potato yield by 35% this season.',
    likesCount: 45,
    commentsCount: 14,
    createdTime: '1 Day Ago',
    topicTag: 'Success Story'
  }
];
