import {
  FinancialInstitution,
  AgriLoanApplication,
  InsuranceProduct,
  InsurancePolicy,
  InsuranceClaim,
  AgriInvestmentProject
} from '../types';

export const MOCK_FINANCIAL_INSTITUTIONS: FinancialInstitution[] = [
  {
    id: 'inst-bk-01',
    name: 'Bank of Kigali (BK) Agri-Specialized Division',
    type: 'Bank',
    licenseNumber: 'BNK-BNR-2024-002',
    contactEmail: 'agri.loans@bk.rw',
    contactPhone: '+250 788 123 456',
    servicesOffered: ['Input Working Capital Loans', 'Equipment Asset Financing', 'Export Invoice Factoring'],
    regionsServed: ['Eastern Province', 'Northern Province', 'Southern Province', 'Western Province', 'Kigali City'],
    verificationStatus: 'Approved',
    totalCapitalDeployedRwf: 12500000000,
    activePortfoliosCount: 1420
  },
  {
    id: 'inst-mfi-02',
    name: 'Umutanguha Finance Company (Microfinance)',
    type: 'Microfinance',
    licenseNumber: 'MFI-BNR-2023-018',
    contactEmail: 'info@umutanguha.rw',
    contactPhone: '+250 788 987 654',
    servicesOffered: ['Smallholder Micro-Loans', 'Group Co-Op Lending', 'Mobile Money Express Credit'],
    regionsServed: ['Northern Province', 'Western Province', 'Southern Province'],
    verificationStatus: 'Approved',
    totalCapitalDeployedRwf: 3800000000,
    activePortfoliosCount: 2850
  },
  {
    id: 'inst-ins-03',
    name: 'SONARWA Agricultural Insurance Corp',
    type: 'Insurance',
    licenseNumber: 'INS-BNR-2022-005',
    contactEmail: 'agri.claims@sonarwa.rw',
    contactPhone: '+250 788 555 777',
    servicesOffered: ['National NAIS Crop Insurance', 'Girinka Livestock Health Policy', 'Satellite Weather Index Cover'],
    regionsServed: ['Eastern Province', 'Northern Province', 'Southern Province', 'Western Province'],
    verificationStatus: 'Approved',
    totalCapitalDeployedRwf: 8900000000,
    activePortfoliosCount: 5200
  },
  {
    id: 'inst-inv-04',
    name: 'Rwanda Green Fund (FONERWA) Agribusiness Desk',
    type: 'Investor Organization',
    licenseNumber: 'INV-RDB-2025-099',
    contactEmail: 'investments@fonerwa.rw',
    contactPhone: '+250 788 333 111',
    servicesOffered: ['Solar Irrigation Co-Investment', 'Post-Harvest Cold Chain Bonds', 'Climate-Smart Equity'],
    regionsServed: ['Eastern Province', 'Southern Province'],
    verificationStatus: 'Approved',
    totalCapitalDeployedRwf: 15200000000,
    activePortfoliosCount: 18
  }
];

export const MOCK_LOAN_APPLICATIONS: AgriLoanApplication[] = [
  {
    id: 'loan-101',
    farmerId: 'farmer-01',
    farmerName: 'Jean De Dieu Hakizimana',
    district: 'Nyagatare',
    institutionId: 'inst-bk-01',
    institutionName: 'Bank of Kigali (BK)',
    loanType: 'Irrigation',
    requestedAmountRwf: 1800000,
    approvedAmountRwf: 1800000,
    interestRatePct: 12.5,
    durationMonths: 18,
    monthlyRepaymentRwf: 110000,
    status: 'Disbursed',
    aiCreditScore: 84,
    aiEligibilityRecommendation: 'Qualified for Medium Agricultural Equipment Loan backed by 2.5 Ha Maize twin yield history.',
    repaymentStatusPct: 35,
    appliedDate: '2026-05-10'
  },
  {
    id: 'loan-102',
    farmerId: 'farmer-02',
    farmerName: 'Marie Claire Uwimana',
    district: 'Musanze',
    institutionId: 'inst-mfi-02',
    institutionName: 'Umutanguha Finance',
    loanType: 'Seeds',
    requestedAmountRwf: 450000,
    approvedAmountRwf: 450000,
    interestRatePct: 14.0,
    durationMonths: 6,
    monthlyRepaymentRwf: 78000,
    status: 'Approved',
    aiCreditScore: 78,
    aiEligibilityRecommendation: 'Recommended for Certified Seed Micro-loan with automatic MoMo harvest deduct.',
    repaymentStatusPct: 0,
    appliedDate: '2026-07-28'
  },
  {
    id: 'loan-103',
    farmerId: 'farmer-03',
    farmerName: 'Emmanuel Nshimiyimana',
    district: 'Huye',
    institutionId: 'inst-bk-01',
    institutionName: 'Bank of Kigali (BK)',
    loanType: 'Expansion',
    requestedAmountRwf: 3500000,
    interestRatePct: 13.0,
    durationMonths: 24,
    monthlyRepaymentRwf: 166000,
    status: 'AI Assessed',
    aiCreditScore: 81,
    aiEligibilityRecommendation: 'High creditworthiness rating based on 3 years of prompt co-op dividend repayments.',
    repaymentStatusPct: 0,
    appliedDate: '2026-08-02'
  }
];

export const MOCK_INSURANCE_PRODUCTS: InsuranceProduct[] = [
  {
    id: 'prod-nais-01',
    providerId: 'inst-ins-03',
    providerName: 'SONARWA Insurance',
    insuranceType: 'Crop Insurance',
    productName: 'National Agricultural Insurance Scheme (NAIS) Crop Shield',
    coveragePerHectareRwf: 1200000,
    annualPremiumRwf: 60000,
    subsidizedPremiumRwf: 30000, // Government pays 50%
    coveredRiskEvents: ['Severe Drought', 'Unseasonal Heavy Rains', 'Fall Armyworm Outbreak', 'Hailstorm Damage'],
    minimumLossThresholdPct: 20,
    termsSummary: 'Supported by MINAGRI 50% premium subsidy. Satellite Sentinel-2 verification enables automatic claim payouts within 5 business days.'
  },
  {
    id: 'prod-girinka-02',
    providerId: 'inst-ins-03',
    providerName: 'SONARWA Insurance',
    insuranceType: 'Livestock Insurance',
    productName: 'Girinka Dairy Cattle Health & Mortality Cover',
    coveragePerHectareRwf: 850000, // Per Head
    annualPremiumRwf: 42500,
    subsidizedPremiumRwf: 21250,
    coveredRiskEvents: ['Accidental Mortality', 'Foot and Mouth Disease (FMD)', 'Mastitis Complications'],
    minimumLossThresholdPct: 10,
    termsSummary: 'Covers cross-bred and Friesian milk cows. Includes tele-veterinary inspection and automatic RFID tag validation.'
  }
];

export const MOCK_INSURANCE_POLICIES: InsurancePolicy[] = [
  {
    id: 'pol-8801',
    farmerId: 'farmer-01',
    farmerName: 'Jean De Dieu Hakizimana',
    productId: 'prod-nais-01',
    productName: 'NAIS Crop Shield',
    providerName: 'SONARWA Insurance',
    insuranceType: 'Crop Insurance',
    insuredHectaresOrHeads: 2.5,
    totalPremiumRwf: 150000,
    farmerPaidRwf: 75000,
    govSubsidyPaidRwf: 75000,
    startDate: '2026-03-01',
    endDate: '2027-03-01',
    status: 'Active'
  }
];

export const MOCK_INSURANCE_CLAIMS: InsuranceClaim[] = [
  {
    id: 'clm-901',
    policyId: 'pol-8801',
    farmerId: 'farmer-01',
    farmerName: 'Jean De Dieu Hakizimana',
    claimReason: 'Mid-season dry spell drought damage to 1.2 Hectares of Maize flowering.',
    affectedHectaresOrHeads: 1.2,
    estimatedLossRwf: 720000,
    approvedPayoutRwf: 680000,
    status: 'AI Verified',
    evidenceType: 'Satellite NDVI Loss Data',
    evidenceSummary: 'Sentinel-2 imagery confirms 28% drop in NDVI vegetation vigor over 21 consecutive rainless days.',
    submissionDate: '2026-08-01'
  }
];

export const MOCK_INVESTMENT_PROJECTS: AgriInvestmentProject[] = [
  {
    id: 'inv-proj-01',
    cooperativeOrFarmerName: 'Nyagatare Maize Producers Co-Op',
    projectTitle: '100-Hectare Solar Valley Dam & Center-Pivot Irrigation Installation',
    category: 'Irrigation Dam',
    targetFundingRwf: 45000000,
    raisedFundingRwf: 32000000,
    minInvestmentRwf: 100000,
    projectedReturnPct: 16.5,
    tenureMonths: 12,
    riskRating: 'Moderate Risk',
    summary: 'Installing two solar-powered water pumping stations along the Muvumba river to guarantee 3 full crop cycles per year.',
    investorCount: 142,
    status: 'Funding Open'
  },
  {
    id: 'inv-proj-02',
    cooperativeOrFarmerName: 'Musanze Potato Seed Cooperative',
    projectTitle: 'Smart Cold-Storage Potato Seed Vault (500-Ton Capacity)',
    category: 'Cold Storage Hub',
    targetFundingRwf: 28000000,
    raisedFundingRwf: 28000000,
    minInvestmentRwf: 50000,
    projectedReturnPct: 14.2,
    tenureMonths: 9,
    riskRating: 'Low Risk',
    summary: 'Constructing temperature and humidity-controlled seed storage vault to eliminate 18% post-harvest spoilage.',
    investorCount: 98,
    status: 'Fully Funded'
  }
];
