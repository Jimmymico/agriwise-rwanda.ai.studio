/**
 * Official Rwanda Administrative Hierarchy Dataset
 * 
 * Authoritative Hierarchy:
 * Province (5) -> District (30) -> Sector (416) -> Cell (2,148) -> Village (14,837)
 */

import rwandaAdminData from './rwandaAdministrativeData.json';

export interface RwandaProvince {
  id: string;
  name: string;
  nameRw: string;
  nameFr: string;
  districts: RwandaDistrict[];
}

export interface RwandaDistrict {
  id: string;
  name: string;
  provinceId: string;
  sectors: RwandaSector[];
}

export interface RwandaSector {
  id: string;
  name: string;
  districtId: string;
  cells: RwandaCell[];
}

export interface RwandaCell {
  id: string;
  name: string;
  sectorId: string;
  villages: string[];
}

export const RWANDA_ADMINISTRATIVE_DATA: RwandaProvince[] = rwandaAdminData as RwandaProvince[];

/**
 * Get all 5 Provinces in Rwanda
 */
export function getRwandaProvinces(): RwandaProvince[] {
  return RWANDA_ADMINISTRATIVE_DATA;
}

/**
 * Get districts by province Name or ID
 */
export function getRwandaDistricts(provinceNameOrId: string): RwandaDistrict[] {
  const normalized = (provinceNameOrId || '').trim().toLowerCase();
  const prov = RWANDA_ADMINISTRATIVE_DATA.find(
    p =>
      p.id.toLowerCase() === normalized ||
      p.name.toLowerCase() === normalized ||
      p.nameRw.toLowerCase() === normalized ||
      p.nameFr.toLowerCase() === normalized
  );
  return prov ? prov.districts : [];
}

/**
 * Get sectors by district Name or ID
 */
export function getRwandaSectors(provinceNameOrId: string, districtNameOrId: string): RwandaSector[] {
  const districts = getRwandaDistricts(provinceNameOrId);
  const normalizedDist = (districtNameOrId || '').trim().toLowerCase();
  const dist = districts.find(
    d => d.id.toLowerCase() === normalizedDist || d.name.toLowerCase() === normalizedDist
  );
  return dist ? dist.sectors : [];
}

/**
 * Get cells by sector Name or ID
 */
export function getRwandaCells(provinceNameOrId: string, districtNameOrId: string, sectorNameOrId: string): RwandaCell[] {
  const sectors = getRwandaSectors(provinceNameOrId, districtNameOrId);
  const normalizedSec = (sectorNameOrId || '').trim().toLowerCase();
  const sec = sectors.find(
    s => s.id.toLowerCase() === normalizedSec || s.name.toLowerCase() === normalizedSec
  );
  return sec ? sec.cells : [];
}

/**
 * Get villages by cell Name or ID
 */
export function getRwandaVillages(
  provinceNameOrId: string,
  districtNameOrId: string,
  sectorNameOrId: string,
  cellNameOrId: string
): string[] {
  const cells = getRwandaCells(provinceNameOrId, districtNameOrId, sectorNameOrId);
  const normalizedCell = (cellNameOrId || '').trim().toLowerCase();
  const cell = cells.find(
    c => c.id.toLowerCase() === normalizedCell || c.name.toLowerCase() === normalizedCell
  );
  return cell ? cell.villages : [];
}

/**
 * Find Province given a District Name
 */
export function findProvinceByDistrict(districtName: string): RwandaProvince | undefined {
  const normalized = (districtName || '').trim().toLowerCase();
  for (const prov of RWANDA_ADMINISTRATIVE_DATA) {
    if (prov.districts.some(d => d.name.toLowerCase() === normalized || d.id.toLowerCase() === normalized)) {
      return prov;
    }
  }
  return undefined;
}
