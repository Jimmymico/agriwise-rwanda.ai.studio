import {
  NationalAgStats,
  RegionalAgStats,
  GovDiseaseAlert,
  GovFoodSecurityAlert,
  GovPolicyScenario
} from '../types';

export const MOCK_NATIONAL_STATS: NationalAgStats = {
  totalRegisteredFarmers: 1248500,
  totalMappedFarms: 892100,
  totalCultivatedHectares: 1450000,
  totalAnnualYieldTons: 3820000,
  totalMarketplaceVolumeRwf: 48500000000,
  totalActiveCooperatives: 1420,
  totalRabAgrodealers: 2850,
  totalRuraTransporters: 680,
  livestockHeadCount: {
    cattle: 1480000,
    goats: 2200000,
    sheep: 680000,
    poultry: 5400000
  },
  cropDistributionPct: {
    maize: 28,
    beans: 24,
    rice: 14,
    irishPotatoes: 18,
    coffeeTea: 10,
    other: 6
  }
};

export const MOCK_REGIONAL_STATS: RegionalAgStats[] = [
  {
    id: 'reg-01',
    province: 'Eastern Province',
    district: 'Nyagatare',
    registeredFarmersCount: 142000,
    cultivatedHectares: 210000,
    mainCrops: ['Maize Grain', 'Beans', 'Rice', 'Milk Cattle'],
    expectedHarvestTons: 620000,
    droughtRiskLevel: 'High',
    diseaseOutbreakCount: 14,
    irrigationCoveragePct: 24,
    inputSubsidyUtilizationPct: 88
  },
  {
    id: 'reg-02',
    province: 'Northern Province',
    district: 'Musanze',
    registeredFarmersCount: 118000,
    cultivatedHectares: 145000,
    mainCrops: ['Kinigi Seed Potatoes', 'Pyrethrum', 'Vegetables', 'Maize'],
    expectedHarvestTons: 840000,
    droughtRiskLevel: 'Low',
    diseaseOutbreakCount: 22,
    irrigationCoveragePct: 42,
    inputSubsidyUtilizationPct: 94
  },
  {
    id: 'reg-03',
    province: 'Southern Province',
    district: 'Huye',
    registeredFarmersCount: 135000,
    cultivatedHectares: 180000,
    mainCrops: ['Rice Marshland', 'Coffee Cherries', 'Cassava', 'Beans'],
    expectedHarvestTons: 490000,
    droughtRiskLevel: 'Moderate',
    diseaseOutbreakCount: 8,
    irrigationCoveragePct: 38,
    inputSubsidyUtilizationPct: 82
  },
  {
    id: 'reg-04',
    province: 'Western Province',
    district: 'Rubavu',
    registeredFarmersCount: 126000,
    cultivatedHectares: 160000,
    mainCrops: ['Tea Plantations', 'Irish Potatoes', 'Maize', 'Horticulture'],
    expectedHarvestTons: 580000,
    droughtRiskLevel: 'Low',
    diseaseOutbreakCount: 11,
    irrigationCoveragePct: 35,
    inputSubsidyUtilizationPct: 91
  },
  {
    id: 'reg-05',
    province: 'Kigali City',
    district: 'Gasabo',
    registeredFarmersCount: 38000,
    cultivatedHectares: 45000,
    mainCrops: ['Urban Horticulture', 'Poultry Eggs', 'Dairy Processing'],
    expectedHarvestTons: 110000,
    droughtRiskLevel: 'Low',
    diseaseOutbreakCount: 3,
    irrigationCoveragePct: 62,
    inputSubsidyUtilizationPct: 96
  }
];

export const MOCK_DISEASE_ALERTS: GovDiseaseAlert[] = [
  {
    id: 'dis-101',
    diseaseName: 'Potato Late Blight (Phytophthora infestans)',
    cropAffected: 'Kinigi Irish Potatoes',
    district: 'Musanze',
    sector: 'Kinigi & Muhoza',
    severity: 'Outbreak Alert',
    confirmedCasesCount: 142,
    spreadTrend: 'Rapidly Spreading',
    recommendedAction: 'Dispatch RAB Fungicide Spray Squads & Distribute Systemic Mancozeb Subsidies.',
    reportedDate: '2026-08-04'
  },
  {
    id: 'dis-102',
    diseaseName: 'Fall Armyworm (Spodoptera frugiperda)',
    cropAffected: 'Maize Grain',
    district: 'Nyagatare',
    sector: 'Karangazi & Katabagemu',
    severity: 'Warning',
    confirmedCasesCount: 89,
    spreadTrend: 'Stable',
    recommendedAction: 'Deploy Emamectin Benzoate bio-pesticides via Agro-dealer distribution hubs.',
    reportedDate: '2026-08-02'
  },
  {
    id: 'dis-103',
    diseaseName: 'Cassava Brown Streak Virus (CBSV)',
    cropAffected: 'Cassava',
    district: 'Huye',
    sector: 'Ngoma',
    severity: 'Watch',
    confirmedCasesCount: 24,
    spreadTrend: 'Decreasing',
    recommendedAction: 'Isolate affected cuttings & supply CBSV-resistant clean stem stock.',
    reportedDate: '2026-07-28'
  }
];

export const MOCK_FOOD_SECURITY_ALERTS: GovFoodSecurityAlert[] = [
  {
    id: 'fs-01',
    province: 'Eastern Province',
    district: 'Nyagatare',
    riskType: 'Rainfall Shortage',
    impactDescription: 'Maize yield output in Karangazi & Rwimiyaga may decrease by 12% to 15% due to a 21-day dry spell during flowering stage.',
    estimatedProductionDeficitPct: 14,
    affectedPopulationEstimate: 42000,
    strategicGrainReserveRequirementTons: 8500,
    aiConfidencePct: 94,
    alertDate: '2026-08-03'
  },
  {
    id: 'fs-02',
    province: 'Northern Province',
    district: 'Musanze',
    riskType: 'Post-Harvest Losses',
    impactDescription: 'Cold-chain storage capacity deficit causing 8% potato spoilage during heavy monsoon rains.',
    estimatedProductionDeficitPct: 8,
    affectedPopulationEstimate: 18000,
    strategicGrainReserveRequirementTons: 3200,
    aiConfidencePct: 91,
    alertDate: '2026-08-01'
  }
];

export const MOCK_POLICY_SCENARIOS: GovPolicyScenario[] = [
  {
    id: 'pol-01',
    policyTitle: '20% DAP & NPK Fertilizer Subsidy Expansion for Eastern Smallholders',
    targetProvince: 'Eastern Province',
    targetCrop: 'Maize & Beans',
    fertilizerSubsidyPctChange: 20,
    irrigationInvestmentHectares: 1500,
    projectedYieldIncreasePct: 18.5,
    projectedEconomicReturnRwf: 4200000000,
    farmerIncomeImpactPct: 24.0,
    aiAnalysisSummary: 'Increasing fertilizer subsidies from 40% to 60% combined with solar-powered valley dam irrigation in Nyagatare is projected to boost regional maize harvest by 42,000 Tons and reduce Rwanda\'s grain import dependence by 8.4%.'
  },
  {
    id: 'pol-02',
    policyTitle: 'Northern Province Cold-Storage Potato Reserve Subsidization',
    targetProvince: 'Northern Province',
    targetCrop: 'Kinigi Seed Potatoes',
    fertilizerSubsidyPctChange: 5,
    irrigationInvestmentHectares: 800,
    projectedYieldIncreasePct: 12.0,
    projectedEconomicReturnRwf: 2800000000,
    farmerIncomeImpactPct: 19.5,
    aiAnalysisSummary: 'Subsidizing 12 cold-chain warehouse hubs across Musanze and Nyabihu will cut post-harvest decay from 18% down to 3%, preserving 65,000 Tons of table and seed potatoes for urban Kigali markets.'
  }
];
