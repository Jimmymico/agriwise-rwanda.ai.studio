import {
  PricingTierPlan,
  RevenueStreamBreakdown,
  PlatformFinancialKpi,
  FiveYearFinancialProjection,
} from '../types';

export const PRICING_PLANS: PricingTierPlan[] = [
  {
    id: 'tier_free',
    name: 'Smallholder Free (Ubuhinzi Busa)',
    priceMonthlyUsd: 0,
    priceAnnualUsd: 0,
    targetAudience: 'Smallholder farmers (< 2 hectares) & individual growers',
    includedAiQueriesPerMonth: 50,
    maxMappedFarms: 3,
    storageLimitGb: 1,
    features: [
      'Free offline-first farm boundary mapping',
      'Basic daily weather forecasts & frost alert SMS',
      '50 Gemini AI voice & text disease questions/mo',
      'Agriwise Marketplace buying & selling access',
      'Digital harvest logbook & RAB certificate storage',
    ],
  },
  {
    id: 'tier_coop',
    name: 'Cooperative Starter',
    priceMonthlyUsd: 29,
    priceAnnualUsd: 290,
    targetAudience: 'Farmer cooperatives (50 - 500 member farmers)',
    includedAiQueriesPerMonth: 2500,
    maxMappedFarms: 500,
    storageLimitGb: 50,
    recommendedBadge: 'Most Popular for Co-ops',
    features: [
      'Cooperative member directory & land aggregation',
      'Bulk input procurement discount bidding engine',
      'MoMo escrow group payout & dividend auto-distribution',
      'Sentinel-2 satellite NDVI crop health alerts for all members',
      'Priority agronomist chat support & RAB export clearance',
    ],
  },
  {
    id: 'tier_commercial',
    name: 'Commercial Farm Pro',
    priceMonthlyUsd: 99,
    priceAnnualUsd: 990,
    targetAudience: 'Commercial agricultural estates (20 - 500+ hectares)',
    includedAiQueriesPerMonth: 10000,
    maxMappedFarms: 50,
    storageLimitGb: 250,
    features: [
      'High-resolution multi-spectral satellite & drone GIS layers',
      'IoT LoRaWAN soil moisture & weather station telematics',
      'Yield prediction ML model & automated irrigation control',
      'Agronomist pest outbreak early warning radar',
      'Dedicated Customer Success Manager & 99.9% Uptime SLA',
    ],
  },
  {
    id: 'tier_enterprise',
    name: 'Agribusiness Enterprise',
    priceMonthlyUsd: 499,
    priceAnnualUsd: 4990,
    targetAudience: 'Financial institutions, exporters, & food processors',
    includedAiQueriesPerMonth: 'Unlimited',
    maxMappedFarms: 'Unlimited',
    storageLimitGb: 2000,
    features: [
      'Full REST & PostGIS Developer API key access',
      'Alternative credit scoring engine for bank loan underwriting',
      'Blockchain farm-to-table export traceability ledger',
      'Custom white-label web & mobile portal integration',
      'Custom fine-tuned Gemini AI model training on company data',
    ],
  },
  {
    id: 'tier_government',
    name: 'National Government Sovereign',
    priceMonthlyUsd: 2500,
    priceAnnualUsd: 25000,
    targetAudience: 'Ministries of Agriculture (MINAGRI) & Regional Bodies (EAC/AfCFTA)',
    includedAiQueriesPerMonth: 'Unlimited',
    maxMappedFarms: 'Unlimited',
    storageLimitGb: 'Unlimited',
    features: [
      'National Food Security & Drought Vulnerability Dashboard',
      'District-level yield forecasting & emergency grain reserve tracking',
      'Sovereign Cloud Data Residency in Kigali / regional data nodes',
      'AfCFTA cross-border trade & phytosanitary clearance verification',
      'Dedicated 24/7 Security Operations Center (SOC) support',
    ],
  },
];

export const REVENUE_STREAMS: RevenueStreamBreakdown[] = [
  {
    streamName: 'SaaS Platform Subscriptions',
    mrrContributionUsd: 48500,
    percentageOfTotal: 38.5,
    annualGrowthRatePct: 142.0,
    description: 'Tiered monthly & annual subscriptions paid by cooperatives, commercial estates, and agribusiness exporters.',
  },
  {
    streamName: 'Marketplace Commissions (2.5% Take Rate)',
    mrrContributionUsd: 38200,
    percentageOfTotal: 30.3,
    annualGrowthRatePct: 185.0,
    description: '2.5% transaction fee on produce sales and input purchases processed through the MoMo escrow engine.',
  },
  {
    streamName: 'FinTech Credit Scoring & Referral Fees',
    mrrContributionUsd: 19800,
    percentageOfTotal: 15.7,
    annualGrowthRatePct: 210.0,
    description: '1.5% loan origin fee paid by partner commercial banks (BK, I&M, Equity) for AI-scored farmer micro-loans.',
  },
  {
    streamName: 'Pay-per-Service (Drone Scanning & Soil Tests)',
    mrrContributionUsd: 11400,
    percentageOfTotal: 9.0,
    annualGrowthRatePct: 95.0,
    description: 'On-demand $15/hectare drone multi-spectral flights and certified soil chemistry lab testing.',
  },
  {
    streamName: 'Enterprise Data API & Research Licensing',
    mrrContributionUsd: 8100,
    percentageOfTotal: 6.5,
    annualGrowthRatePct: 115.0,
    description: 'Developer API usage fees and anonymized research dataset subscriptions for global agricultural research institutes.',
  },
];

export const FINANCIAL_KPIS: PlatformFinancialKpi = {
  mrrUsd: 126000,
  arrUsd: 1512000,
  cacUsd: 18.5,
  ltvUsd: 420.0,
  ltvToCacRatio: 22.7,
  monthlyChurnRatePct: 0.85,
  arpuUsd: 8.4,
  grossMarginPct: 84.5,
  paybackPeriodMonths: 2.2,
};

export const FIVE_YEAR_PROJECTIONS: FiveYearFinancialProjection[] = [
  {
    year: 2026,
    activeFarmersCount: 150000,
    activeCooperativesCount: 450,
    annualRevenueUsd: 1512000,
    grossProfitUsd: 1277640,
    ebitdaUsd: 380000,
    expansionCountries: 2, // Rwanda & Kenya
  },
  {
    year: 2027,
    activeFarmersCount: 520000,
    activeCooperativesCount: 1400,
    annualRevenueUsd: 5800000,
    grossProfitUsd: 4930000,
    ebitdaUsd: 1850000,
    expansionCountries: 4, // + Uganda & Tanzania
  },
  {
    year: 2028,
    activeFarmersCount: 1400000,
    activeCooperativesCount: 3800,
    annualRevenueUsd: 16500000,
    grossProfitUsd: 14190000,
    ebitdaUsd: 5900000,
    expansionCountries: 6, // + Ethiopia & Ghana
  },
  {
    year: 2029,
    activeFarmersCount: 3500000,
    activeCooperativesCount: 9500,
    annualRevenueUsd: 42000000,
    grossProfitUsd: 36540000,
    ebitdaUsd: 16200000,
    expansionCountries: 8, // + Nigeria & Cote d'Ivoire
  },
  {
    year: 2030,
    activeFarmersCount: 8000000,
    activeCooperativesCount: 22000,
    annualRevenueUsd: 105000000,
    grossProfitUsd: 92400000,
    ebitdaUsd: 44000000,
    expansionCountries: 15, // Pan-African Leader
  },
];
