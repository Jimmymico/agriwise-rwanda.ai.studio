export interface DiseasePreset {
  id: string;
  category: 'crop' | 'livestock';
  targetName: { rw: string; en: string; fr: string };
  diseaseName: { rw: string; en: string; fr: string };
  scientificName: string;
  imageUrl: string;
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  confidenceScore: number;
  symptoms: { rw: string[]; en: string[]; fr: string[] };
  organicTreatment: { rw: string; en: string; fr: string };
  chemicalTreatment: { rw: string; en: string; fr: string };
  preventativeAdvice: { rw: string; en: string; fr: string };
  momoProduct: {
    productName: string;
    priceRwf: number;
    dealerName: string;
    dosage: string;
  };
  rabAgronomist: {
    name: string;
    station: string;
    phone: string;
  };
  audioSummary: { rw: string; en: string; fr: string };
}

export const DISEASE_PRESETS: DiseasePreset[] = [
  {
    id: "preset-maize-fall-armyworm",
    category: "crop",
    targetName: { rw: "Ibigori (Maize)", en: "Maize (Corn)", fr: "Maïs" },
    diseaseName: {
      rw: "Nkongwa y'Ibigori (Fall Armyworm)",
      en: "Fall Armyworm (Spodoptera frugiperda)",
      fr: "Légionnaire d'Automne (Fall Armyworm)"
    },
    scientificName: "Spodoptera frugiperda",
    imageUrl: "https://images.unsplash.com/photo-1592417817098-8f3d6ef23a28?w=800&auto=format&fit=crop&q=80",
    severity: "High",
    confidenceScore: 94,
    symptoms: {
      rw: [
        "Imyobo n'isura idafite gahunda mu bibabi by'ibigori",
        "Amase y'ibinyabwoya n'imisumbuko mu mutima w'igihingwa",
        "Gukonja n'isuku nke y'ibitumbwe bitangiye gukura"
      ],
      en: [
        "Ragged holes and feeding windows in expanding whorl leaves",
        "Moist frass (caterpillar droppings) visible inside leaf whorls",
        "Severe defoliation of young corn stalks"
      ],
      fr: [
        "Trous irréguliers et fenêtres de nutrition sur les jeunes feuilles",
        "Excréments humides visibles dans le cornet des feuilles",
        "Défoliation sévère des tiges de maïs"
      ]
    },
    organicTreatment: {
      rw: "Vanga ivu ry'inkwi ritameneka n'umusenyi uvanze n'amazi y'icyunyoni cy'igiti cy'ikireni (Neem) uhereze mu mutima w'igihingwa mu gitondo.",
      en: "Mix dry wood ash or fine sand with neem leaf extract and drop directly into the leaf whorls during early morning.",
      fr: "Mélangez de la cendre de bois sèche avec de l'extrait de neem et déposez directement dans le cornet des feuilles."
    },
    chemicalTreatment: {
      rw: "Tera umuti wa Emamectin Benzoate 5% SG (garama 10 mu jerekani y'amazi litiro 20) cyangwa Cypermethrin mu gitondo kare.",
      en: "Spray Emamectin Benzoate 5% SG (10g per 20L sprayer) or Cypermethrin during early morning or late afternoon.",
      fr: "Vaporisez de l'Émamectine Benzoate 5% SG (10g par pulvérisateur 20L) tôt le matin ou en fin d'après-midi."
    },
    preventativeAdvice: {
      rw: "Tanya ibigori mu gihe gikwiriye, uhindure ibihingwa uvanzamo ibishyimbo, kandi usukure umurima ukuramo ibishingwe.",
      en: "Practice early planting with RAB certified seeds, maintain crop rotation with legumes, and clear field weeds regularly.",
      fr: "Pratiquez le semis précoce avec des semences certifiées RAB, effectuez des rotations avec des légumineuses et nettoyez le champ."
    },
    momoProduct: {
      productName: "Emamectin Benzoate 5% SG (250g)",
      priceRwf: 4500,
      dealerName: "AgriPro Agrodealers Musanze",
      dosage: "10g per 20L water tank"
    },
    rabAgronomist: {
      name: "Dr. Emmanuel Mukamana",
      station: "RAB Musanze Station",
      phone: "+250 788 123 456"
    },
    audioSummary: {
      rw: "Igihingwa cyawe gifite Nkongwa y'Ibigori. Severity ni ya hejuru. Sugera uzafata umuti wa Emamectin Benzoate ufurere mu gitondo.",
      en: "Your maize crop shows signs of Fall Armyworm with 94% confidence. Immediate treatment with Emamectin Benzoate is recommended.",
      fr: "Votre culture de maïs présente des signes de Légionnaire d'Automne. Un traitement immédiat à l'Émamectine Benzoate est recommandé."
    }
  },
  {
    id: "preset-potato-late-blight",
    category: "crop",
    targetName: { rw: "Ibirayi (Irish Potato)", en: "Irish Potato", fr: "Pomme de Terre" },
    diseaseName: {
      rw: "Ihanga ryo mu Birayi (Late Blight)",
      en: "Late Blight (Phytophthora infestans)",
      fr: "Mildiou de la Pomme de Terre"
    },
    scientificName: "Phytophthora infestans",
    imageUrl: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=800&auto=format&fit=crop&q=80",
    severity: "Critical",
    confidenceScore: 96,
    symptoms: {
      rw: [
        "Ibibabi bifite ibizinga by'umukara n'umweru mu nsi y'ibibabi",
        "Ururo rwa fungi runuka neza mu gitondo gifite igihugu",
        "Gushya n'igihingwa kigahita cyuma cyose mu minsi 3-5"
      ],
      en: [
        "Water-soaked dark lesions on leaves with white fuzzy mold underneath",
        "Rapid browning and collapse of foliage during high humidity",
        "Foul-smelling rotting potato vines"
      ],
      fr: [
        "Lésions sombres détrempées sur les feuilles avec duvet blanc en dessous",
        "Brunissement rapide et effondrement du feuillage",
        "Odeur désagréable de pourriture des tiges"
      ]
    },
    organicTreatment: {
      rw: "Fuha amashaza arimo umuti w'umwimerere wa Copper Sulfate (Bordeaux Mixture) mu gitondo imvura itaragwa.",
      en: "Spray organic Bordeaux mixture (copper sulfate + lime) prevention layer before heavy seasonal rains.",
      fr: "Pulvérisez de la bouillie bordelaise (sulfate de cuivre + chaux) comme barrière organique préventive."
    },
    chemicalTreatment: {
      rw: "Tera Mancozeb 80% WP (garama 50 mu litiro 20) cyangwa Ridomil Gold harimo uburyo bwo kurwanya uburyaryate.",
      en: "Apply Ridomil Gold MZ or Mancozeb 80% WP (50g per 20L water) every 7 days in wet weather conditions.",
      fr: "Appliquez Ridomil Gold MZ ou Mancozeb 80% WP (50g par 20L) tous les 7 jours par temps humide."
    },
    preventativeAdvice: {
      rw: "Koresha imbuto z'Ibirayi za Kinigi zifite ubushobozi bwo kurwanya ihanga, wirinde kuhira hejuru y'ibibabi.",
      en: "Plant certified clean Kinigi or Victoria seed potatoes, maintain high ridges for drainage, and destroy infected vines immediately.",
      fr: "Utilisez des semences certifiées Kinigi résistantes, butter généreusement pour le drainage et détruisez les fanes infectées."
    },
    momoProduct: {
      productName: "Ridomil Gold MZ Fungicide (500g)",
      priceRwf: 8500,
      dealerName: "Kivu Agri-Inputs Rubavu",
      dosage: "50g per 20L water tank"
    },
    rabAgronomist: {
      name: "Agronomist Jean-Bosco Niyonzima",
      station: "RAB Northern Zone Potato Center",
      phone: "+250 788 987 654"
    },
    audioSummary: {
      rw: "Ibirayi byawe bifite indwara y'Ihanga (Late Blight). Umuti uzafata ni Ridomil Gold ku buryo buhuse.",
      en: "Late Blight detected on your potatoes with 96% confidence. Apply Ridomil Gold immediately to protect tubers.",
      fr: "Mildiou détecté sur vos pommes de terre avec 96% de confiance. Appliquez Ridomil Gold immédiatement."
    }
  },
  {
    id: "preset-banana-bxw",
    category: "crop",
    targetName: { rw: "Ibitoki (Banana)", en: "Banana", fr: "Bananier" },
    diseaseName: {
      rw: "Kazooba / Kirabiranya y'Ibitoki (BXW)",
      en: "Banana Xanthomonas Wilt (BXW)",
      fr: "Flétrissement Bactérien du Bananier (BXW)"
    },
    scientificName: "Xanthomonas vasicola pv. musacearum",
    imageUrl: "https://images.unsplash.com/photo-1528825871115-3581a5387919?w=800&auto=format&fit=crop&q=80",
    severity: "Critical",
    confidenceScore: 91,
    symptoms: {
      rw: [
        "Umutobe w'umuhondo ugwa mu gitoki n'amababi ahita ahina akuma",
        "Iseri ry'ibitoki rishya hashingiwe ku mutobe w'umuhondo imbere",
        "Urupfu rw'igihingwa kidasanzwe mu cyumweru kimwe"
      ],
      en: [
        "Premature yellowing and wilting of leaves starting from inner whorls",
        "Yellow bacterial ooze visible inside cut pseudostems and fruit stalks",
        "Uneven premature ripening and internal brown discolorations of fruit"
      ],
      fr: [
        "Jaunissement et flétrissement prématurés des feuilles",
        "Exsudat bactérien jaune visible à la coupe des fausses tiges",
        "Mûrissement prématuré et inégal des fruits avec décoloration interne"
      ]
    },
    organicTreatment: {
      rw: "Kata umutwe w'ururabyo (male bud) ukoresheje igiti gitoya kidasangiwe n'ibindi bitoki. Temagura igitoki cyanduye ugitwike.",
      en: "Debud male flowers using a forked wooden stick. Cut down infected banana mats, chop pseudostem, and bury or burn.",
      fr: "Coupez le bourgeon mâle avec un bâton fourchu. Rasez les touffes infectées et brûlez les débris."
    },
    chemicalTreatment: {
      rw: "Nta muti w'uruganda uraboneka ubyimula bacterie. Sukura ibikoresho byo gukata na Javel cyangwa umuriro.",
      en: "No chemical bactericide cure exists. Disinfect all machetes and tools in 20% Javel bleach or open fire after each cut.",
      fr: "Aucun traitement chimique n'existe. Désinfectez les machettes à l'eau de Javel à 20% ou au feu."
    },
    preventativeAdvice: {
      rw: "Wirinde gukoresha imiyugubwe y'ibitoki ikomoka mu mirima irwaye. Koresha uburyo bwo Single Stem Removal (SSR).",
      en: "Practice Single Stem Removal (SSR), restrict movement of banana suckers from diseased zones, and sanitize pruning tools.",
      fr: "Appliquez l'élimination de tige unique (SSR), évitez le transport de rejets malades et désinfectez les outils."
    },
    momoProduct: {
      productName: "Javel Disinfectant Solution (5 Liters)",
      priceRwf: 3200,
      dealerName: "Rwamagana Farmer Cooperative Store",
      dosage: "200ml per 1L water for tool sterilisation"
    },
    rabAgronomist: {
      name: "Agronomist Chantal Mukamazimpaka",
      station: "RAB Eastern Agriculture Taskforce",
      phone: "+250 788 456 789"
    },
    audioSummary: {
      rw: "Ibitoki byawe birwaye Kazooba ya Xanthomonas. Temagura igihingwa cyanduye usukure umuhoro na Javel.",
      en: "Banana Xanthomonas Wilt (BXW) detected. Immediately remove infected stem and sterilize all cutting tools with Javel.",
      fr: "Flétrissement bactérien (BXW) détecté. Éliminez immédiatement la tige infectée et stérilisez les outils."
    }
  },
  {
    id: "preset-coffee-rust",
    category: "crop",
    targetName: { rw: "Kahawa (Coffee)", en: "Coffee", fr: "Caféier" },
    diseaseName: {
      rw: "Ihanga ryo mu Kahawa (Coffee Leaf Rust)",
      en: "Coffee Leaf Rust (Hemileia vastatrix)",
      fr: "Rouille du Caféier"
    },
    scientificName: "Hemileia vastatrix",
    imageUrl: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=800&auto=format&fit=crop&q=80",
    severity: "Medium",
    confidenceScore: 89,
    symptoms: {
      rw: [
        "Ibizinga by'umuhondo no mu nsi y'ibibabi harimo umukungugu w'icungwa",
        "Amababi ahita agwa mu nsi hagasigara ibiti bitariho amababi",
        "Kugabanuka kw'umusaruro w'ibishyimbo bya kahawa"
      ],
      en: [
        "Orange-yellow powdery spots on the lower leaf surface",
        "Severe premature defoliation leaving bare coffee branches",
        "Reduced cherry formation and lower cup quality"
      ],
      fr: [
        "Taches poudreuses jaune-orange sur la face inférieure des feuilles",
        "Chute prématurée des feuilles laissant les branches nues",
        "Réduction de la formation de cerises de café"
      ]
    },
    organicTreatment: {
      rw: "Tera Bordeaux Mixture (Copper Hydroxide) n'umusemburo w'igiti cy'icyunyoni cy'igiti.",
      en: "Apply preventative copper hydroxide spray coupled with canopy pruning for ventilation.",
      fr: "Appliquez une pulvérisation d'hydroxydes de cuivre et taillez l'ombrage pour aérer."
    },
    chemicalTreatment: {
      rw: "Tera Triadimefon 25% EC cyangwa Copper Oxychloride imbere y'imvura y'itumba.",
      en: "Spray Copper Oxychloride 50% WP (50g/20L) or Systemic Triadimefon fungicide every 21 days during rainy months.",
      fr: "Pulvérisez de l'Oxychlorure de cuivre 50% WP (50g/20L) ou du Triadiméfon tous les 21 jours pendant la saison des pluies."
    },
    preventativeAdvice: {
      rw: "Kata amashami ya kahawa kugira ngo umuyaga ubyine neza mu giti, ugabanye igicucu.",
      en: "Prune excess shade trees, maintain optimal plant density, and top-dress with composted manure.",
      fr: "Taillez l'ombrage excessif, maintenez une densité optimale et apportez du compost."
    },
    momoProduct: {
      productName: "Copper Oxychloride Fungicide 50% (1Kg)",
      priceRwf: 6800,
      dealerName: "Huye Coffee Farmers Supply Union",
      dosage: "50g per 20L sprayer tank"
    },
    rabAgronomist: {
      name: "Agronomist Fabrice Habimana",
      station: "RAB Southern Station Huye",
      phone: "+250 788 654 321"
    },
    audioSummary: {
      rw: "Kahawa yagize ihanga ryo mu bibabi. Tera Copper Oxychloride ukate amashami arimo igicucu.",
      en: "Coffee Leaf Rust detected with 89% confidence. Apply Copper Oxychloride and prune dense shade branches.",
      fr: "Rouille du caféier détectée. Appliquez de l'oxychlorure de cuivre et taillez l'ombrage."
    }
  },
  {
    id: "preset-livestock-mastitis",
    category: "livestock",
    targetName: { rw: "Inka d'Amashereka (Dairy Cattle)", en: "Dairy Cattle", fr: "Vache Laitière" },
    diseaseName: {
      rw: "Infection y'Amabehere ya Inka (Mastitis)",
      en: "Bovine Mastitis (Udder Infection)",
      fr: "Mammite Bovine (Infection de la Mamelle)"
    },
    scientificName: "Streptococcus uberis / Staphylococcus aureus",
    imageUrl: "https://images.unsplash.com/photo-1546445317-29f4545f9d52?w=800&auto=format&fit=crop&q=80",
    severity: "High",
    confidenceScore: 93,
    symptoms: {
      rw: [
        "Ibehere ryatukuye, ryabimbye kandi rishyushye cyane rirya inka",
        "Amashereka arimo ubusa, amaraso cyangwa ubuvungukira",
        "Inka iragwingira, ntirya kandi ifite umuriro"
      ],
      en: [
        "Swollen, hot, firm, and painful udder quarters",
        "Clotted, watery, or blood-tinged milk secretion",
        "Fever, loss of appetite, and reduced milk yield"
      ],
      fr: [
        "Quartiers de la mamelle enflés, chauds, fermes et douloureux",
        "Lait grumeleux, aqueux ou teinté de sang",
        "Fièvre, perte d'appétit et baisse de production laitière"
      ]
    },
    organicTreatment: {
      rw: "Sukura ibehere n'amazi y'akazuyazi arimo umunyu w'igikoni, kanda amashereka wanduje mu kintu kiharaye.",
      en: "Foment udder with warm salty water cloth compress and strip infected quarter thoroughly into a strip cup.",
      fr: "Lavez le pisse à l'eau tiède salée et tirez le lait infecté dans un récipient dédié."
    },
    chemicalTreatment: {
      rw: "Injiza Intramammary Antibiotic Tubes (Multi-mastitis tube) mu kanyango k'ibehere biruhukije umuganga.",
      en: "Administer intramammary Penicillin-Streptomycin intramammary infusion tubes after complete milking. Give injectable NSAID for pain relief.",
      fr: "Administrez des tubes antibiotiques intramammaires après traite complète et un anti-inflammatoire."
    },
    preventativeAdvice: {
      rw: "Oza ibehere mu muti wa Teat Dip (Iodine dip) imbere n'inyuma yo gukama. Zirika mu gikoni gisukuye.",
      en: "Apply pre- and post-milking teat dip (0.5% Iodine), keep cow standing for 30 minutes post-milking, and sanitize bedding.",
      fr: "Utilisez un bain de mamelons à l'iode avant et après la traite et gardez l'étable propre."
    },
    momoProduct: {
      productName: "Mastitis Intramammary Tubes (Pack of 4)",
      priceRwf: 5200,
      dealerName: "Nyagatare Vet Supply Pharmacy",
      dosage: "1 tube per infected quarter after complete milking"
    },
    rabAgronomist: {
      name: "Dr. Vet Patrick Nshimiyimana",
      station: "Nyagatare District Veterinary Officer",
      phone: "+250 788 333 222"
    },
    audioSummary: {
      rw: "Inka yawe ifite Mastitis mu behere. Oza ibehere mu amazi ashyushye ukoreshe umuti wa intramammary tube.",
      en: "Bovine Mastitis detected with 93% confidence. Treat with intramammary antibiotic tubes and practice teat dipping.",
      fr: "Mammite bovine détectée avec 93% de confiance. Traitez avec des tubes antibiotiques intramammaires."
    }
  }
];
