import {
  FarmSatelliteMonitoringRecord,
  SatelliteNdviTimelinePoint
} from '../types';

export const MOCK_FARM_SATELLITE_RECORDS: FarmSatelliteMonitoringRecord[] = [
  {
    id: 'sat-farm-01',
    farmId: 'farm-001',
    farmName: 'Hakizimana Maize & Bean Plot A',
    farmerName: 'Jean De Dieu Hakizimana',
    district: 'Nyagatare',
    province: 'Eastern Province',
    cropType: 'Hybrid Maize Grain',
    farmAreaHectares: 2.5,
    lastSatellitePassDate: '2026-08-04',
    constellation: 'Sentinel-2 Multispectral',
    ndviScore: 0.76, // Healthy vegetation
    ndwiWaterStressIndex: 0.42,
    soilMoisturePct: 38,
    canopyChlorophyllMgM2: 45,
    cropHealthStatus: 'Optimal Growth',
    droughtRiskLevel: 'Moderate',
    historicalNdviComparisonPct: +12,
    predictedYieldTonsPerHa: 4.2,
    aiYieldConfidencePct: 91,
    cloudCoverPct: 4,
    recommendedAction: 'Crop vigor is strong. Maintain drip irrigation during flowering stage next week.'
  },
  {
    id: 'sat-farm-02',
    farmId: 'farm-002',
    farmName: 'Musanze Kinigi Potato Seed Field B',
    farmerName: 'Marie Claire Uwimana',
    district: 'Musanze',
    province: 'Northern Province',
    cropType: 'Kinigi Seed Potatoes',
    farmAreaHectares: 1.8,
    lastSatellitePassDate: '2026-08-03',
    constellation: 'PlanetScope High-Res',
    ndviScore: 0.52, // Moderate Stress due to Late Blight
    ndwiWaterStressIndex: 0.65,
    soilMoisturePct: 62,
    canopyChlorophyllMgM2: 28,
    cropHealthStatus: 'Moderate Vegetation Stress',
    droughtRiskLevel: 'Low',
    historicalNdviComparisonPct: -14,
    predictedYieldTonsPerHa: 14.5,
    aiYieldConfidencePct: 88,
    cloudCoverPct: 8,
    recommendedAction: 'Satellite spectral band decay detected in North-West quadrant. Spray systemic fungicide immediately.'
  },
  {
    id: 'sat-farm-03',
    farmId: 'farm-003',
    farmName: 'Huye Marshland Rice Plot C',
    farmerName: 'Emmanuel Nshimiyimana',
    district: 'Huye',
    province: 'Southern Province',
    cropType: 'Marshland Paddy Rice',
    farmAreaHectares: 3.2,
    lastSatellitePassDate: '2026-08-02',
    constellation: 'Landsat-9 Operational Land Imager',
    ndviScore: 0.81, // Lush
    ndwiWaterStressIndex: 0.82,
    soilMoisturePct: 85,
    canopyChlorophyllMgM2: 52,
    cropHealthStatus: 'Optimal Growth',
    droughtRiskLevel: 'Low',
    historicalNdviComparisonPct: +18,
    predictedYieldTonsPerHa: 5.8,
    aiYieldConfidencePct: 94,
    cloudCoverPct: 2,
    recommendedAction: 'Submerged paddy water levels optimal. Apply top-dressing urea fertilizer.'
  }
];

export const MOCK_NDVI_TIMELINE: SatelliteNdviTimelinePoint[] = [
  { date: '2026-04-01', ndviScore: 0.22, rainfallMm: 85, temperatureC: 22 },
  { date: '2026-04-15', ndviScore: 0.38, rainfallMm: 110, temperatureC: 23 },
  { date: '2026-05-01', ndviScore: 0.54, rainfallMm: 90, temperatureC: 24 },
  { date: '2026-05-15', ndviScore: 0.68, rainfallMm: 65, temperatureC: 25 },
  { date: '2026-06-01', ndviScore: 0.79, rainfallMm: 40, temperatureC: 26 },
  { date: '2026-06-15', ndviScore: 0.82, rainfallMm: 15, temperatureC: 27 },
  { date: '2026-07-01', ndviScore: 0.78, rainfallMm: 5, temperatureC: 28 },
  { date: '2026-07-15', ndviScore: 0.74, rainfallMm: 8, temperatureC: 27 },
  { date: '2026-08-01', ndviScore: 0.76, rainfallMm: 12, temperatureC: 26 }
];
