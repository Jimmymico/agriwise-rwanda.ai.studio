import {
  AgriculturalDataset,
  FarmerConsentSettings,
  DataAccessRequest,
  ResearchPublication,
  DeveloperApiKey,
  AiModelRetrainingLog
} from '../types';

export const MOCK_DATASETS: AgriculturalDataset[] = [
  {
    id: 'ds-101',
    title: 'Rwanda Multispectral Maize NDVI & Yield Time-Series (2023-2026)',
    category: 'Crop Yield & Remote Sensing',
    providerOrganization: 'AGRIWISE Remote Sensing Lab & RAB',
    description: 'Anonymized Sentinel-2 & PlanetScope multispectral vegetation indices correlated with harvested metric tons across 15,000 maize plots in Nyagatare, Gatsibo, and Musanze.',
    fileFormat: 'CSV / GeoJSON',
    totalRecordsCount: 145000,
    dataSizeMb: 420,
    licenseTier: 'Open Research (Free)',
    priceUsdOrRwf: 'Free for Academic / $200 Commercial',
    anonymizationStatus: 'Differential Privacy Verified',
    lastUpdatedDate: '2026-07-28',
    samplePreviewSnippet: `{"sector": "Nyagatare", "season": "2025B", "avg_ndvi": 0.74, "rainfall_mm": 680, "yield_ton_per_ha": 4.85}`,
    downloadUrl: '#',
    tags: ['NDVI', 'Maize Yield', 'Sentinel-2', 'Rwanda Agriculture']
  },
  {
    id: 'ds-102',
    title: 'LoRaWAN Soil Probes Telemetry & Micro-Climate Dataset',
    category: 'IoT Soil & Telemetry',
    providerOrganization: 'AGRIWISE IoT Network & University of Rwanda',
    description: 'Continuous 15-minute interval soil moisture, pH, nitrogen-phosphorus-potassium (NPK) electrical conductivity, and ambient solar ET from 450 deployed smart probes.',
    fileFormat: 'Parquet / NetCDF',
    totalRecordsCount: 2850000,
    dataSizeMb: 1250,
    licenseTier: 'Commercial Enterprise',
    priceUsdOrRwf: '$350 API Access',
    anonymizationStatus: 'Aggregated Regional',
    lastUpdatedDate: '2026-08-01',
    samplePreviewSnippet: `{"node_id": "RW-IOT-884", "soil_moisture_pct": 28.4, "soil_ph": 6.3, "ambient_temp_c": 24.2, "timestamp": "2026-08-01T14:30:00Z"}`,
    downloadUrl: '#',
    tags: ['IoT', 'Soil Health', 'LoRaWAN', 'Microclimate']
  },
  {
    id: 'ds-103',
    title: 'Sub-Saharan Crop Pathology Image Corpus (100k Multi-Angle Scans)',
    category: 'AI Vision & Pathology',
    providerOrganization: 'AGRIWISE AI Research & MINAGRI',
    description: 'High-resolution RGB diagnostic leaf images annotated by senior extension pathologists covering Fall Armyworm, Maize Streak Virus, Potato Late Blight, and Cassava Mosaic.',
    fileFormat: 'JSON API',
    totalRecordsCount: 102000,
    dataSizeMb: 8500,
    licenseTier: 'Open Research (Free)',
    priceUsdOrRwf: 'Free Academic License',
    anonymizationStatus: 'Differential Privacy Verified',
    lastUpdatedDate: '2026-06-15',
    samplePreviewSnippet: `{"image_id": "IMG-9942", "label": "Fall Armyworm Damage Tier 3", "confidence": 0.98, "district": "Gatsibo"}`,
    downloadUrl: '#',
    tags: ['AI Vision', 'Plant Pathology', 'Deep Learning', 'Computer Vision']
  },
  {
    id: 'ds-104',
    title: 'Cooperative MoMo Transaction Trends & AGRIWISE Micro-Credit Index',
    category: 'Agri-Credit & Financial',
    providerOrganization: 'AGRIWISE Financial Intelligence & BDF',
    description: 'Anonymized transaction volume, harvest sales receipts, input purchasing cycles, and default risk probabilities across 85 agricultural cooperatives.',
    fileFormat: 'CSV / GeoJSON',
    totalRecordsCount: 320000,
    dataSizeMb: 180,
    licenseTier: 'Government Policy',
    priceUsdOrRwf: 'Restricted Government & Bank Access',
    anonymizationStatus: 'Aggregated Regional',
    lastUpdatedDate: '2026-07-30',
    samplePreviewSnippet: `{"coop_id": "COP-774", "district": "Musanze", "avg_credit_score": 78, "annual_turnover_rwf": 45000000}`,
    downloadUrl: '#',
    tags: ['Financial Inclusion', 'Credit Score', 'Mobile Money', 'Cooperative Trade']
  }
];

export const MOCK_FARMER_CONSENT: FarmerConsentSettings = {
  farmerId: 'frm-8842',
  farmerName: 'Jean-Baptiste Hakizimana',
  district: 'Nyagatare District',
  allowAnonymizedYieldSharing: true,
  allowIoTTelemetryResearch: true,
  allowMarketplaceTradeInsights: true,
  optInMonetizationDividend: true,
  accumulatedDataRoyaltiesRwf: 18500
};

export const MOCK_ACCESS_REQUESTS: DataAccessRequest[] = [
  {
    id: 'req-501',
    researcherName: 'Dr. Arabelle Murekatete',
    organizationName: 'University of Rwanda College of Agriculture',
    projectTitle: 'AI-Driven Predictive Climate Resilience for Eastern Province Smallholders',
    datasetId: 'ds-101',
    requestedLicense: 'Open Research (Free)',
    requestDate: '2026-07-20',
    status: 'Approved',
    approvalToken: 'AGRIWISE-AUTH-TOK-9942'
  },
  {
    id: 'req-502',
    researcherName: 'Marcus Vance',
    organizationName: 'Global Agritech Solutions Inc.',
    projectTitle: 'Commercial Machine Learning Model Training for Precision Drone Spraying',
    datasetId: 'ds-103',
    requestedLicense: 'Commercial Enterprise',
    requestDate: '2026-08-02',
    status: 'Pending Review'
  }
];

export const MOCK_RESEARCH_PUBLICATIONS: ResearchPublication[] = [
  {
    id: 'pub-301',
    paperTitle: 'Quantifying Smallholder Maize Nitrogen Stress using Sentinel-2 and LoRaWAN Ground Telemetry in Rwanda',
    authors: ['Dr. Agnes Mukamana', 'Prof. Eric Habimana', 'Dr. Arabelle Murekatete'],
    institution: 'University of Rwanda & RAB',
    publishedDate: '2026-05-12',
    datasetUsedId: 'ds-101',
    abstract: 'We present a empirical study combining 10-meter Sentinel-2 bands with 450 ground soil probes across Nyagatare District. Results show a 24% yield gain when precision NPK timing is triggered by satellite NDWI thresholding.',
    doiOrUrl: 'https://doi.org/10.1016/j.agwat.2026.04.012',
    citationCount: 14
  }
];

export const MOCK_DEVELOPER_API_KEYS: DeveloperApiKey[] = [
  {
    id: 'key-901',
    keyName: 'UR Agriculture AI Research Key',
    apiKeyString: 'agriwise_live_8942a7f00192bc884e1',
    organization: 'University of Rwanda',
    createdDate: '2026-01-10',
    dailyQueryLimit: 10000,
    queriesUsedToday: 2450,
    status: 'Active'
  },
  {
    id: 'key-902',
    keyName: 'Commercial Climate Analytics Key',
    apiKeyString: 'agriwise_live_5541e9903b11894a772',
    organization: 'East Africa AgriInsure Corp',
    createdDate: '2026-03-15',
    dailyQueryLimit: 50000,
    queriesUsedToday: 18400,
    status: 'Active'
  }
];

export const MOCK_AI_RETRAINING_LOGS: AiModelRetrainingLog[] = [
  {
    id: 'log-01',
    modelName: 'AGRIWISE Vision Crop Pathology Net',
    currentVersion: 'v4.2.0-Prod',
    trainingSampleCount: 102000,
    accuracyScorePct: 98.4,
    lastRetrainedDate: '2026-07-25',
    expertFeedbacksProcessed: 1420,
    status: 'Deployed in Production'
  },
  {
    id: 'log-02',
    modelName: 'Sentinel-2 Yield Neural Estimator',
    currentVersion: 'v3.1.5-Beta',
    trainingSampleCount: 145000,
    accuracyScorePct: 94.2,
    lastRetrainedDate: '2026-07-30',
    expertFeedbacksProcessed: 890,
    status: 'Training in Progress'
  }
];
