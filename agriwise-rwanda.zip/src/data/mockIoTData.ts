import {
  IoTDevice,
  SoilSensorTelemetry,
  WeatherStationTelemetry,
  IrrigationControllerTelemetry,
  GreenhouseTelemetry,
  LivestockCollarTelemetry,
  IoTAutomationRule,
  IoTAlertNotification
} from '../types';

export const MOCK_IOT_DEVICES: IoTDevice[] = [
  {
    id: 'iot-soil-01',
    deviceName: 'Dragino LSE01 Soil Moisture & NPK Probe #1',
    farmId: 'farm-001',
    farmName: 'Hakizimana Maize & Bean Plot A',
    deviceType: 'Soil Sensor Node',
    status: 'Online',
    batteryPct: 92,
    signalStrengthDbm: -74, // Strong LoRaWAN
    lastTelemetryTimestamp: 'Just Now (Live)',
    firmwareVersion: 'v2.4.1-LoRa',
    macAddressOrDevEui: '70-B3-D5-7E-D0-04-A1-12',
    fieldLocation: 'Field A (East Quadrant - Flowering Maize)'
  },
  {
    id: 'iot-weather-02',
    deviceName: 'Milesight WTS505 Solar Weather Station',
    farmId: 'farm-001',
    farmName: 'Hakizimana Maize & Bean Plot A',
    deviceType: 'Weather Station',
    status: 'Online',
    batteryPct: 100,
    signalStrengthDbm: -68,
    lastTelemetryTimestamp: '2 Mins Ago',
    firmwareVersion: 'v1.8.0-NB-IoT',
    macAddressOrDevEui: '24-E1-24-60-00-11-22-33',
    fieldLocation: 'Central Ridge Elevation Point'
  },
  {
    id: 'iot-irrig-03',
    deviceName: 'AGRIWISE Solar Solenoid Drip Actuator #2',
    farmId: 'farm-001',
    farmName: 'Hakizimana Maize & Bean Plot A',
    deviceType: 'Smart Irrigation Controller',
    status: 'Online',
    batteryPct: 88,
    signalStrengthDbm: -82,
    lastTelemetryTimestamp: 'Just Now (Live)',
    firmwareVersion: 'v3.1.0-Relay',
    macAddressOrDevEui: '80-E4-DA-70-12-FE',
    fieldLocation: 'Main Drip Manifold Header B'
  },
  {
    id: 'iot-greenhouse-04',
    deviceName: 'Musanze Climate-Controlled Greenhouse Node',
    farmId: 'farm-002',
    farmName: 'Musanze Kinigi Potato Seed Field B',
    deviceType: 'Greenhouse Controller',
    status: 'Online',
    batteryPct: 95,
    signalStrengthDbm: -65,
    lastTelemetryTimestamp: '1 Min Ago',
    firmwareVersion: 'v4.0.2-Mesh',
    macAddressOrDevEui: '32-A1-88-FF-90-11',
    fieldLocation: 'Musanze Hydroponic Vault 1'
  },
  {
    id: 'iot-livestock-05',
    deviceName: 'Girinka Smart Collar Tag #044 (Friesian Cow)',
    farmId: 'farm-001',
    farmName: 'Hakizimana Dairy Pen',
    deviceType: 'Livestock Collar Tag',
    status: 'Online',
    batteryPct: 79,
    signalStrengthDbm: -85,
    lastTelemetryTimestamp: '5 Mins Ago',
    firmwareVersion: 'v1.2-BLE-GPS',
    macAddressOrDevEui: '50-C7-BF-00-44-AB',
    fieldLocation: 'Nyagatare Pasture Area C'
  }
];

export const MOCK_SOIL_TELEMETRY: SoilSensorTelemetry = {
  moisturePct: 32, // Below 35% threshold -> triggers irrigation recommendation
  temperatureC: 24.5,
  phLevel: 6.4, // Optimal for Maize
  nitrogenMgKg: 42,
  phosphorusMgKg: 18,
  potassiumMgKg: 165,
  electricalConductivityDsM: 1.2
};

export const MOCK_WEATHER_TELEMETRY: WeatherStationTelemetry = {
  ambientTempC: 26.8,
  humidityPct: 48,
  rainfall24hMm: 0.0,
  windSpeedKmH: 12.4,
  solarRadiationWM2: 780,
  evapotranspirationMmDay: 5.2
};

export const MOCK_IRRIGATION_TELEMETRY: IrrigationControllerTelemetry = {
  valveState: 'CLOSED (Idle)',
  controlMode: 'AI Autonomous',
  waterFlowRateLitersMin: 0,
  totalWaterDeliveredTodayLiters: 4200,
  nextScheduledWatering: 'Today at 17:30 (Auto AI Triggered)'
};

export const MOCK_GREENHOUSE_TELEMETRY: GreenhouseTelemetry = {
  insideTempC: 22.4,
  insideHumidityPct: 75,
  co2Ppm: 680,
  photosyntheticLightLux: 45000,
  roofVentPositionPct: 40,
  mistingSystemStatus: 'OFF'
};

export const MOCK_LIVESTOCK_TELEMETRY: LivestockCollarTelemetry = {
  animalId: 'cow-044',
  animalName: 'Mugisha (Friesian Milk Cow)',
  species: 'Dairy Friesian Cow',
  bodyTempC: 38.6, // Normal (38.0 - 39.3 C)
  heartRateBpm: 68,
  dailyRuminationHours: 8.4,
  gpsLatitude: -1.3045,
  gpsLongitude: 30.3218,
  healthAlertStatus: 'Healthy'
};

export const MOCK_AUTOMATION_RULES: IoTAutomationRule[] = [
  {
    id: 'rule-01',
    ruleName: 'Auto Drip Irrigation Trigger',
    sensorTriggerCondition: 'Soil Moisture < 35% AND Weather Rain Forecast < 2mm',
    actionToExecute: 'Open Solenoid Valve #2 for 45 Minutes (Deliver 1,200 Liters)',
    isActive: true,
    lastTriggeredTimestamp: 'Yesterday at 17:00'
  },
  {
    id: 'rule-02',
    ruleName: 'Greenhouse Automated Roof Cooling Vent',
    sensorTriggerCondition: 'Inside Temp > 28°C OR Humidity > 85%',
    actionToExecute: 'Open Roof Vent to 80% & Activate Misting Fans for 15 Mins',
    isActive: true,
    lastTriggeredTimestamp: 'Today at 12:15'
  },
  {
    id: 'rule-03',
    ruleName: 'Livestock Fever & Anomaly Alert',
    sensorTriggerCondition: 'Animal Body Temp > 39.5°C OR Rumination < 4.0 Hours',
    actionToExecute: 'Send SMS & Push Alert to Farmer + Tele-Vet Network',
    isActive: true,
    lastTriggeredTimestamp: '3 Days Ago'
  }
];

export const MOCK_IOT_ALERTS: IoTAlertNotification[] = [
  {
    id: 'alt-101',
    deviceId: 'iot-soil-01',
    deviceName: 'Soil Probe #1 (Maize Plot A)',
    severity: 'Warning',
    title: 'Low Soil Moisture Warning',
    message: 'Soil moisture dropped to 32% in Field A. AI recommends initiating drip irrigation before 18:00.',
    timestamp: '10 Mins Ago',
    isAcknowledged: false
  },
  {
    id: 'alt-102',
    deviceId: 'iot-weather-02',
    deviceName: 'Solar Weather Station',
    severity: 'Info',
    title: 'High Evapotranspiration Rate',
    message: 'Solar radiation reached 780 W/m². Water loss rate is 5.2 mm/day.',
    timestamp: '1 Hour Ago',
    isAcknowledged: true
  }
];
