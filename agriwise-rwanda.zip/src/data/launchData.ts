import {
  ReleaseFeatureHighlight,
  LaunchChecklistItem,
  ProductRoadmapMilestone,
} from '../types';

export const RELEASE_V1_HIGHLIGHTS: ReleaseFeatureHighlight[] = [
  {
    moduleNumber: 'MOD-01',
    featureName: 'Multi-lingual Voice & Offline Farm Polygon Mapping',
    category: 'GIS & Satellite',
    status: 'Production Ready',
    description: 'Offline-first CRDT polygon GPS boundary capture with Kinyarwanda, Swahili, French, and English voice guided assistance.',
  },
  {
    moduleNumber: 'MOD-06',
    featureName: 'Gemini 3.6 Flash Multi-Spectral Leaf Disease Diagnostics',
    category: 'Core AI',
    status: 'Certified',
    description: 'Real-time multi-spectral camera leaf disease diagnosis verified against 250k RAB agronomic ground-truth image sets.',
  },
  {
    moduleNumber: 'MOD-12',
    featureName: 'MoMo Escrow Produce Marketplace & Bidding Engine',
    category: 'FinTech & Escrow',
    status: 'Certified',
    description: 'MTN Mobile Money & Airtel Money instant escrow lock-box for harvest batch trading with 2.5% platform take rate.',
  },
  {
    moduleNumber: 'MOD-18',
    featureName: 'Alternative Agronomic Credit Scoring & Bank Loan Underwriting',
    category: 'FinTech & Escrow',
    status: 'Production Ready',
    description: 'Algorithmic credit risk model based on satellite NDVI historical yields and co-op repayment behavior for commercial banks.',
  },
  {
    moduleNumber: 'MOD-24',
    featureName: 'Pan-African AfCFTA Cross-Border Trade & Phytosanitary Portal',
    category: 'Supply Chain',
    status: 'Certified',
    description: 'Cross-border commodity trading corridor across 8 African nations with Rab/MINAGRI digital phytosanitary verification.',
  },
  {
    moduleNumber: 'MOD-25',
    featureName: 'GKE Autopilot High-Availability Serverless Cluster (SLA 99.99%)',
    category: 'Enterprise SaaS',
    status: 'Production Ready',
    description: 'Containerized microservices running on PostGIS sharded database replicas with L2 Redis caching and sub-100ms API latency.',
  },
];

export const LAUNCH_CHECKLIST_ITEMS: LaunchChecklistItem[] = [
  {
    category: 'Production Infrastructure',
    itemTitle: 'Cloud Run & GKE Autopilot clusters provisioned in Kigali and Nairobi nodes',
    owner: 'DevOps Lead',
    isCompleted: true,
  },
  {
    category: 'Production Infrastructure',
    itemTitle: 'PostGIS spatial database WAL replication & Redis cluster edge caching enabled',
    owner: 'Database Administrator',
    isCompleted: true,
  },
  {
    category: 'Security & Compliance',
    itemTitle: 'OWASP Top 10 penetration audit cleared with zero critical/high vulnerabilities',
    owner: 'Security Architect',
    isCompleted: true,
  },
  {
    category: 'Security & Compliance',
    itemTitle: 'GDPR & Rwanda NPSA Data Protection & Sovereignty residency locks verified',
    owner: 'Legal & Compliance Officer',
    isCompleted: true,
  },
  {
    category: 'Mobile Apps & Distribution',
    itemTitle: 'Android APK and iOS App Store binaries signed with offline SQLite bundle',
    owner: 'Mobile Tech Lead',
    isCompleted: true,
  },
  {
    category: 'Marketing & Partnerships',
    itemTitle: 'Official launch press release & MINAGRI / RAB co-branding alignment signed',
    owner: 'Chief Marketing Officer',
    isCompleted: true,
  },
];

export const ROADMAP_MILESTONES: ProductRoadmapMilestone[] = [
  {
    version: 'v1.0 (Current Launch)',
    targetDate: 'Q3 2026',
    focusArea: 'Rwanda National Launch & EAC Trade Corridor',
    keyDeliverables: [
      'Full 27-module AGRIWISE platform online',
      'Free offline farmer polygon mapping & Gemini AI assistant',
      'MoMo escrow produce trading & Rab phytosanitary clearance',
      'Bank credit scoring API integration for BK & Equity Bank',
    ],
  },
  {
    version: 'v1.1 (Q4 2026)',
    targetDate: 'Q4 2026',
    focusArea: 'East African Community Expansion',
    keyDeliverables: [
      'Full localization for Swahili & Amharic voice navigation',
      'Parametric Index Crop Insurance automated payout engine',
      'Drone multi-spectral automated flight plan integration',
      'Cooperative bulk tractor & heavy equipment sharing portal',
    ],
  },
  {
    version: 'v2.0 (2027)',
    targetDate: 'Q2 2027',
    focusArea: 'Pan-African Commodity Exchange & IoT Telematics',
    keyDeliverables: [
      'Direct integration with East Africa Grain Council (EAGC)',
      'LoRaWAN IoT soil moisture telematics auto-irrigation mesh',
      'Carbon credit verification & regenerative farming rewards',
      'Autonomous AI agent agronomist proactive SMS dispatch',
    ],
  },
  {
    version: 'v3.0 (2028-2030)',
    targetDate: '2028 - 2030',
    focusArea: 'Global Agricultural Intelligence & Sovereign AI Models',
    keyDeliverables: [
      'Pan-African coverage across 15 nations with 8M active farmers',
      'Custom fine-tuned AGRIWISE LLM hosted on sovereign African data centers',
      'Space-borne radar SAR satellite crop moisture estimation',
      'Global food security predictive grain reserve AI engine for UN FAO / WFP',
    ],
  },
];
