# AGRIWISE RWANDA 🌾🇷🇼
**National Agricultural Decision Support System & Smart Advisory Platform**

---

## 🇷🇼 Uko Wamanura (Download) no Gukorera Setup iyi Platform

Iyi platform ya **AGRIWISE RWANDA** yubatse neza mu buryo bworoshye kumanurwa (download) no gukoreshwa kuri computer yawe cyangwa kuri Server.

### 1. Uko Wamanura Project (Download Options)
Kuri **Google AI Studio**:
1. Kanda kuri menu iri hejuru ku ruhande rw'ibyo (Settings / Code / Export).
2. Hitamo **Export as ZIP** (Kumanura nka dosiye yipfutse) cyangwa **Export to GitHub** (Kuyishyira kuri GitHub repo yawe).

---

### 2. Ibintu Ukeneye kuri Computer yawe (Prerequisites)
- **Node.js**: Version 18 cyangwa 20+ ([Yimanure hano](https://nodejs.org/))
- **npm** cyangwa **bun** / **yarn**

---

### 3. Uko Uyizamura kuri Computer yako (Local Setup)

1. **Fungura Terminal/Command Prompt** mu mushinga wamanuye:
   ```bash
   cd agriwise-rwanda
   ```

2. **Shyiramo ama Packages (Install Dependencies)**:
   ```bash
   npm install
   ```

3. **Kora Environment Variables (.env)**:
   Koporora `.env.example` uyihindure `.env`:
   ```bash
   cp .env.example .env
   ```
   Fungura `.env` maze ushyiremo:
   - `GEMINI_API_KEY`: API Key ya Google Gemini (niba uyifite)
   - `SMTP_USER`: Email yawe ya Gmail (`jimmymico45@gmail.com`)
   - `SMTP_PASS`: Google App Password yako ya Gmail (16 digits)

4. **Tanga amategeko yo kuyitangiza mu buryo bwo kwipima (Development Mode)**:
   ```bash
   npm run dev
   ```
   Platform irahita ifungukira kuri: `http://localhost:3000`

---

### 4. Uko Uyishyira mu buryo bwo Gukora neza (Production Build & Run)

1. **Kora Build**:
   ```bash
   npm run build
   ```
2. **Yitangize mu Production**:
   ```bash
   npm start
   ```

---

## 🇬🇧 English Setup & Export Guide

### 1. How to Download / Export from AI Studio
1. Click the **Settings/Export** menu in the top right corner of AI Studio.
2. Select **Export as ZIP** to download the complete source code package, or **Export to GitHub** to push to your GitHub account.

### 2. Prerequisites
- Node.js v18 or v20+
- npm (comes with Node.js)

### 3. Quick Local Installation
```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env

# 3. Start development server
npm run dev
```
The application will run at `http://localhost:3000`.

---

## 📁 System Architecture & Directory Overview

```text
├── server.ts                  # Express backend & API service (SMTP, Auth, Weather, Market APIs)
├── src/                       # React frontend source code
│   ├── components/            # UI Components (Dashboards, Weather, Advisory, Auth)
│   ├── services/              # Auth, Google OAuth, Gemini AI, Weather Services
│   ├── data/                  # Localized datasets & Rwanda district maps
│   ├── types.ts               # TypeScript data models & definitions
│   └── main.tsx               # Main React entry point
├── .env.example               # Template for environment credentials
├── firebase-applet-config.json# Firebase Authentication & Firestore configuration
└── package.json               # Application dependencies & npm scripts
```

---

## 📧 SMTP EMAIL CONFIGURATION

AGRIWISE RWANDA features a unified, secure server-side SMTP email notification engine. It handles all platform outgoing emails, including:
- User registration welcome emails & verification tokens
- Password reset instructions
- Sales & Agro-dealer POS tax receipts / invoices
- System security alerts and administrator notifications

### 1. Environment Variables Overview

Add these variables to your `.env` file (copied from `.env.example`):

| Variable | Description | Example (Gmail) | Example (Custom SMTP) |
| :--- | :--- | :--- | :--- |
| `SMTP_HOST` | Hostname of the outgoing SMTP server | `smtp.gmail.com` | `smtp.mailgun.org` / `smtp.sendgrid.net` |
| `SMTP_PORT` | Network port for the SMTP connection | `587` | `465` or `587` |
| `SMTP_USER` | Authenticated email address or username | `your-email@gmail.com` | `apikey` or `postmaster@domain.com` |
| `SMTP_PASSWORD` | Password or Google App Password | `abcd efgh ijkl mnop` | `your_secret_api_key_or_password` |
| `SMTP_SECURE` | Encryption protocol flag | `false` (TLS / 587) | `true` (SSL / 465) or `false` (TLS) |
| `SMTP_FROM` | Outgoing sender email address | `your-email@gmail.com` | `noreply@agriwise.rw` |
| `SMTP_FROM_NAME`| Display sender name in recipients' inbox| `AGRIWISE RWANDA` | `AGRIWISE Support` |

---

### 2. When to Use Port 587 vs Port 465

- **Port 587 (`SMTP_SECURE=false`) — Recommended for Gmail & Most Providers**:
  - Uses **STARTTLS** (the connection starts unencrypted and immediately upgrades to encrypted TLS).
  - Standard for modern mail submission.
- **Port 465 (`SMTP_SECURE=true`)**:
  - Uses direct **SSL/TLS** encryption from the initial TCP handshake.
  - Required if your cloud provider or ISP blocks port 587.

---

### 3. How to Obtain a Google App Password (Gmail)

If using a Gmail or Google Workspace account:
1. Open your **Google Account Settings** ([myaccount.google.com](https://myaccount.google.com/)).
2. Navigate to **Security** in the left sidebar.
3. Under *How you sign in to Google*, ensure **2-Step Verification** is enabled.
4. Search for or click on **App Passwords** ([myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)).
5. Enter an app name (e.g. `AGRIWISE RWANDA`) and click **Create**.
6. Google will generate a **16-character password** (e.g. `abcd efgh ijkl mnop`).
7. Paste this 16-character code directly into `SMTP_PASSWORD` in your `.env` file (spaces can be kept or removed).
8. **NEVER** use your regular Google account password.

---

### 4. How to Test the SMTP Email Setup

#### Option A: Built-in Admin API Endpoint
Send a `POST` request to the test endpoint:
```bash
curl -X POST http://localhost:3000/api/admin/smtp/test \
  -H "Content-Type: application/json" \
  -d '{"testRecipient": "your-email@gmail.com"}'
```
**Expected Success Response:**
```json
{
  "success": true,
  "message": "SMTP connection successful. Test email sent successfully.",
  "recipient": "your-email@gmail.com",
  "messageId": "<...>"
}
```

#### Option B: Check SMTP Readiness Status
Send a `GET` request:
```bash
curl http://localhost:3000/api/admin/smtp/status
```
Returns configuration validation without revealing passwords.

---

### 5. Troubleshooting Failed Email Delivery

| Issue / Error | Root Cause | Solution |
| :--- | :--- | :--- |
| `SMTP configuration is incomplete` | One or more required environment variables are missing | Ensure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, and `SMTP_FROM` are present in `.env`. |
| `Invalid login / 535-5.7.8 Username and Password not accepted` | Standard Gmail password was used instead of App Password, or 2FA is off | Generate and configure a 16-character **Google App Password**. |
| `ETIMEDOUT` or `ECONNREFUSED` | Port is blocked by hosting environment or firewall | Try switching from port `587` (`SMTP_SECURE=false`) to port `465` (`SMTP_SECURE=true`). |
| `Self-signed certificate in certificate chain` | Custom SSL certificate on corporate/staging proxy | Transporter is configured with `tls: { rejectUnauthorized: false }` to prevent proxy drops. |

